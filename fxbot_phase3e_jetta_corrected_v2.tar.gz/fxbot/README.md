# fxbot - strategy core, signals and backtester (Phases 2-3b)

Pure, broker-free, stdlib-only core: Decimal cost model, position lifecycle, stop/trailing maths,
cost-aware exits, Forex currency-balance controls, risk governor, per-pair state machine, config audit,
reporting + locked readiness criteria, indicators (EMA, RSI, MACD, ADX, ATR, Stochastic, activity proxy), closed-candle
bars, the `ema_trend_v0` entry engine, same/opposite-direction re-entry gate and the combined entry decision.
plus the backtester (bid/ask ingestion, realistic fills, walk-forward with an enforced single-look holdout, sweeps, reports).
**No live trading, no broker code.**

    python -m unittest discover -s tests -t .      # about 210 tests (pytest also works; ~2 min, the backtester tests dominate)

Read `docs/ASSUMPTIONS.md` first (items needing your approval), then `docs/DUKASCOPY_RUNBOOK.md`, `docs/DATA_VALIDATION_REPORT.md`, `docs/SESSIONS.md`, `docs/STRATEGY_SPEC.md`, `docs/BACKTESTING.md`, `docs/INDICATOR_CONVENTIONS.md` and `docs/STATE_MACHINES.md`.
Research CLI: `python tools/run_research.py dev|holdout ...` (format: `docs/research.example.json`). TA-Lib check: `python tools/crosscheck_talib.py`.

## Coverage of your 25 required tests
| # | Status | Where |
|---|--------|-------|
| 1-2 LONG/SHORT entry + initial stop | done | test_trailing_and_position |
| 3-7 trailing activation/tighten-only/never backwards/% of entry | done (incl. randomised property + mirror-symmetry tests) | test_trailing_and_position |
| 8 bid/ask executable side | done | test_trailing_and_position |
| 9-10 cost calc, cost-adjusted net, break-even price | done (golden commission values) | test_exits_and_costs |
| 11-12 protective exit despite net loss; profit-taking | done | test_exits_and_costs |
| 13-16 reverse confirmation, no immediate reversal, cooldown | done | test_strategy_config_reporting |
| 17 independence | done | test_trailing_and_position |
| 18-19 partial fills / rejects | state-machine level done; broker-level in Phase 4 | |
| 20-21 broker timeout/reconnect, duplicate ORDER prevention | Phase 4 (duplicate execution acks already ignored) | |
| 22 unprotected detection | done | test_trailing_and_position |
| 23-24 daily lockout, max holding | done | test_risk_and_currency / test_exits_and_costs |
| 25 restart reconciliation | state-machine level done; broker reconciliation in Phase 4 | |
| 9 scenarios | all nine done | test_scenarios |

## Tests added for the 2026-11-07 amendments
`test_reentry_and_trailing_rules.py`: LONG/SHORT trailing symmetry (property), threshold follows new extremes, never
loosens (property), activation and retracement behaviour, spec example 100.00/101.00/100.90, restore after restart,
stop-replacement planner, same-direction re-entry after a fresh signal, rejection without a fresh signal, same vs
opposite thresholds, per-pair independence. `test_indicators_bars.py`, `test_signals_and_entry.py`: indicator
correctness/causality/symmetry, closed-candle bars, engine, no look-ahead, entry filters.

## Data validation
`python tools/validate_ticks.py <ticks.csv> [--format dukascopy_csv|canonical|ibkr_ticks_provisional] --out report.md` - run on every new dataset first.

## Dukascopy tick data
`python tools/dukascopy.py env-check | verify-jetta | plan | download | build | run | merge` - resumable JETTA JSON raw store, normalised CSV, manifest with SHA-256s, automatic validation and quality report. The legacy BI5 source remains selectable with `--source bi5`; JETTA is selected with `--source jetta`. Research reads only validated datasets (`tools/run_research.py --dataset DIR`). Not runnable in the authoring sandbox (no network): see `docs/DUKASCOPY_RUNBOOK.md`.

## Running the tests in parts (the full suite takes ~3 minutes)
    python -m unittest tests.test_dukascopy tests.test_jetta tests.test_data_validation          # data pipeline, ~20 s
    python -m unittest tests.test_sessions_and_reentry_modes tests.test_reentry_and_trailing_rules tests.test_trailing_and_position tests.test_exits_and_costs tests.test_risk_and_currency tests.test_strategy_config_reporting tests.test_indicators_bars tests.test_signals_and_entry   # core, ~30 s
    python -m unittest tests.test_studies tests.test_backtest tests.test_scenarios   # backtester (slowest, ~2 min)

## CI / phone workflow
`.github/workflows/dukascopy_dataset.yml` + `tools/ci_run.sh` + `tools/ci_verdict.py`: tests -> network check -> live decoder verification -> download/validate -> one verdict; review pack always, dataset artifacts only when validated.
Step-by-step Android instructions and the workflow review: `docs/DUKASCOPY_RUNBOOK.md`. Streaming engine (Milestone 2, design only): `docs/STREAMING_DESIGN.md`.
