#!/usr/bin/env python3
"""Run:  python tools/crosscheck_talib.py [--seeds 1 2 3] [--bars 3000] [--csv ohlc.csv]
Requires TA-Lib. Writes a Markdown report to stdout; exit code 1 if any indicator is outside tolerance
AFTER warm-up. CSV (optional) must have columns high,low,close (real FX mid bars are the best test data)."""
import argparse, csv, sys
from fxbot.indicators.crosscheck import edge_cases, random_ohlc, render_markdown, run_crosscheck

try:
    import talib
except ImportError:
    sys.exit("TA-Lib is not installed; cannot run the cross-check.")

ap = argparse.ArgumentParser()
ap.add_argument("--seeds", type=int, nargs="*", default=[1, 2, 3])
ap.add_argument("--bars", type=int, default=3000)
ap.add_argument("--csv")
a = ap.parse_args()
sets = []
if a.csv:
    rows = list(csv.DictReader(open(a.csv)))
    sets.append(("csv", [float(r["high"]) for r in rows], [float(r["low"]) for r in rows], [float(r["close"]) for r in rows]))
for s in a.seeds:
    h, l, c = random_ohlc(a.bars, s)
    sets.append((f"seed {s}", h, l, c))
bad = False
for name, h, l, c in sets:
    diffs = run_crosscheck(talib, h, l, c)
    print(f"\n### {name} ({len(c)} bars, TA-Lib {talib.__version__})\n")
    print(render_markdown(diffs))
    bad |= any(not d.ok for d in diffs)
print("\n### Edge cases\n")
for k, v in edge_cases(talib).items():
    print(f"- {k}: {v}")
sys.exit(1 if bad else 0)
