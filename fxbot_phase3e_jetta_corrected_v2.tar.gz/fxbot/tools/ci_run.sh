#!/usr/bin/env bash
# Pipeline for CI (GitHub Actions) or any machine.   usage: tools/ci_run.sh OUT INSTRUMENT START END SLEEP [LEGACY_REFERENCE_RANGE]
# Stages stop at the first problem and record their exit codes in OUT/review/stages.txt; tools/ci_verdict.py turns them into the verdict.
set -u -o pipefail
OUT="$1"; INST="$2"; START="$3"; END="$4"; SLEEP="${5:-0.3}"; REF="${6:-}"
LOGS="$OUT/review/logs"; STAGES="$OUT/review/stages.txt"
mkdir -p "$LOGS" "$OUT/dataset"; : > "$STAGES"
rec() { echo "$1=$2" >> "$STAGES"; }
skip() { for s in "$@"; do rec "$s" skipped; done; }

echo "== stage 1: offline unit tests of the pipeline =="
python -m unittest tests.test_dukascopy tests.test_jetta tests.test_data_validation tests.test_decoder_verification tests.test_ci_pipeline 2>&1 | tee "$LOGS/1_unit_tests.txt"
rc=${PIPESTATUS[0]}; rec tests "$rc"
if [ "$rc" -ne 0 ]; then skip env decoder run; exit 1; fi

echo "== stage 2: can this machine reach the Dukascopy JETTA API? =="
python tools/dukascopy.py env-check --source jetta 2>&1 | tee "$LOGS/2_env_check.txt"
rc=${PIPESTATUS[0]}; rec env "$rc"
if [ "$rc" -ne 0 ]; then skip decoder run; exit 1; fi

echo "== stage 3: JETTA decoder verification on representative live hours + BI5 parity anchor =="
python tools/dukascopy.py verify-jetta --instrument "$INST" --start "$START" --end "$END" --out "$OUT/dataset" 2>&1 | tee "$LOGS/3_verify_jetta.txt"
rc=${PIPESTATUS[0]}; rec decoder "$rc"
if [ "$rc" -ne 0 ]; then skip run; exit 1; fi

echo "== stage 4: download everything, build the normalised CSV, validate =="
python tools/dukascopy.py run --instrument "$INST" --source jetta --start "$START" --end "$END" --out "$OUT/dataset" --sleep "$SLEEP" 2>&1 | tee "$LOGS/4_run.txt"
rc=${PIPESTATUS[0]}; rec run "$rc"
exit "$rc"
