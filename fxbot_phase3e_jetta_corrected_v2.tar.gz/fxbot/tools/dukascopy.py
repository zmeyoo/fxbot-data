#!/usr/bin/env python3
"""Dukascopy tick-data pipeline.  Examples (see docs/DUKASCOPY_RUNBOOK.md):
  python tools/dukascopy.py env-check
  python tools/dukascopy.py verify-sample --out data/verify
  python tools/dukascopy.py run --instrument EURUSD --start 2024-03-04 --end 2024-03-18 --out data/EURUSD_pilot
  python tools/dukascopy.py plan --instrument EURUSD --start 2025-01-01 --end 2025-07-01 --calibrate data/EURUSD_pilot
"""
import sys
from fxbot.data_sources.cli import main
sys.exit(main())
