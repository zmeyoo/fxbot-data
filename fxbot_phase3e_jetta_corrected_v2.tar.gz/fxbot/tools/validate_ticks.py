#!/usr/bin/env python3
"""python tools/validate_ticks.py ticks.csv [--format dukascopy_csv|canonical|ibkr_ticks_provisional] [--pair EURUSD] [--out report.md]
Exit code 1 if any check FAILS. Run it on every new dataset BEFORE using it for research."""
import sys
from fxbot.backtesting.validate import main
sys.exit(main())
