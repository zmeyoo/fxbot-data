#!/usr/bin/env python3
"""python tools/run_research.py dev     --config research.json --ticks ticks.csv --out out/
   python tools/run_research.py holdout --config research.json --ticks ticks.csv --out out/ --variant "<name>" --confirm-single-look
The holdout command evaluates ONE operator-named variant ONCE per dataset+plan (registry file in --out)."""
import argparse, os, sys
from fxbot.backtesting.data import load_bars_csv, load_ticks_csv
from fxbot.backtesting.research import load_config, make_plan, run_dev_research, run_holdout

ap = argparse.ArgumentParser()
ap.add_argument("mode", choices=["dev", "holdout"])
ap.add_argument("--config", required=True); ap.add_argument("--dataset", help="validated dataset directory (preferred)"); ap.add_argument("--ticks"); ap.add_argument("--bars")
ap.add_argument("--allow-unvalidated", action="store_true", help="accept a bare, unvalidated file (not recommended)")
ap.add_argument("--out", required=True); ap.add_argument("--variant"); ap.add_argument("--confirm-single-look", action="store_true")
ap.add_argument("--min-trades-train", type=int, default=30)
a = ap.parse_args()
base, grid, split = load_config(a.config)
from fxbot.backtesting.research import load_research_data
data, rep, banner = load_research_data(a.dataset, a.ticks, a.bars, a.allow_unvalidated, base.spec.symbol)
print("DATA:", banner)
for line in rep.summary_lines():
    print(line)
plan = make_plan(rep, split)
reg = os.path.join(a.out, "holdout_registry.json")
if a.mode == "dev":
    out = run_dev_research(data, rep, base, grid, plan, a.out, reg, a.min_trades_train,
                           compare_train_days=tuple(split.get("compare_train_days", ())),
                           latencies=tuple(split.get("latencies", (0.5, 1, 2, 5))),
                           compare_eod_minutes=tuple(split.get("compare_eod_minutes", (15, 30, 60))))
else:
    if not (a.variant and a.confirm_single_look):
        sys.exit("holdout needs --variant NAME and --confirm-single-look (it can only be run once)")
    out = run_holdout(data, rep, base, grid, plan, a.variant, a.out, reg, a.min_trades_train)
print("report:", out["report"])
