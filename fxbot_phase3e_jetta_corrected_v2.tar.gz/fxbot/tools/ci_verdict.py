#!/usr/bin/env python3
"""Turns the pipeline stage results into ONE unambiguous verdict and builds the small 'review pack'.
A dataset is VALIDATED only if every stage succeeded, the decoder verification passed, dataset.json says PASSED and the CSV still matches
its manifest SHA-256. Anything else is NOT VALIDATED, with the reason; the full dataset is then never published as an artifact.
usage: python tools/ci_verdict.py --out OUT [--summary FILE] [--github-output FILE]"""
import argparse
import hashlib
import json
import os
import platform
import shutil
import sys
from typing import Any, Dict, List, Optional

STAGE_ORDER = ["tests", "env", "decoder", "run"]
STAGE_TEXT = {"tests": "offline unit tests", "env": "network reachability", "decoder": "decoder verification (live)", "run": "download + build + validate"}
MAX_SUMMARY_BYTES = 900_000


def read_stages(path: str) -> Dict[str, str]:
    out: Dict[str, str] = {}
    if os.path.exists(path):
        for ln in open(path):
            if "=" in ln:
                k, v = ln.strip().split("=", 1)
                out[k] = v
    return out


def sha256_file(p: str) -> str:
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def compute_verdict(out_dir: str) -> Dict[str, Any]:
    stages = read_stages(os.path.join(out_dir, "review", "stages.txt"))
    ds = os.path.join(out_dir, "dataset")
    v: Dict[str, Any] = {"stages": {s: stages.get(s, "not_run") for s in STAGE_ORDER}, "status": None, "reason": "", "validated": False}

    def fail(status: str, reason: str) -> Dict[str, Any]:
        v["status"], v["reason"], v["validated"] = status, reason, False
        return v
    st = v["stages"]
    if not stages:
        return fail("PIPELINE_CRASHED", "no stage results were recorded (the pipeline script did not run to its first stage)")
    if st["tests"] != "0":
        return fail("TESTS_FAILED", f"offline unit tests exit code {st['tests']}: the pipeline code itself is not healthy; nothing was downloaded")
    if st["env"] != "0":
        return fail("NETWORK_UNAVAILABLE", "this machine cannot reach jetta.dukascopy.com (see logs/2_env_check.txt); nothing was downloaded or substituted")
    if st["decoder"] == "5":
        return fail("DECODER_ASSUMPTION_FAILED", "an independent JETTA decoder/source check FAILED (see DECODER_VERIFICATION.md); the download was stopped")
    if st["decoder"] != "0":
        return fail("DECODER_NOT_VERIFIED", f"JETTA verification could not complete (exit code {st['decoder']}); see logs/3_verify_jetta.txt")
    dec_json = os.path.join(ds, "decoder_verification.json")
    if not os.path.exists(dec_json) or not json.load(open(dec_json)).get("passed"):
        return fail("DECODER_NOT_VERIFIED", "decoder_verification.json missing or not passed")
    if st["run"] == "3":
        return fail("DOWNLOAD_INCOMPLETE", "some hours could not be downloaded; the dataset was not built (see logs/4_run.txt). Re-run to resume is only possible on the same machine/cache")
    man_path = os.path.join(ds, "dataset.json")
    if not os.path.exists(man_path):
        return fail("DOWNLOAD_INCOMPLETE", "dataset.json does not exist: the dataset was never built")
    man = json.load(open(man_path))
    val = man.get("validation", {})
    if not val.get("passed"):
        bad = [c for c in val.get("checks", []) if c.get("status") == "FAIL"]
        return fail("VALIDATION_FAILED", "dataset validation FAILED: " + "; ".join(f"{c['name']}: {c['detail'][:160]}" for c in bad[:4]))
    csv_path = os.path.join(ds, man["normalised"]["path"])
    if not os.path.exists(csv_path) or sha256_file(csv_path) != man["normalised"]["sha256"]:
        return fail("INTEGRITY_FAILED", "normalised CSV is missing or does not match the manifest SHA-256")
    if st["run"] != "0":
        return fail("RUN_FAILED", f"run stage exit code {st['run']} although a manifest exists")
    v.update(status="PASSED", reason="all stages succeeded, decoder verification passed, dataset validation PASSED, CSV matches its SHA-256", validated=True)
    v["dataset_id"], v["csv_sha256"] = man["dataset_id"], man["normalised"]["sha256"]
    v["rows"], v["instrument"], v["range_utc"] = man["normalised"]["rows"], man["instrument"], man["range_utc"]
    v["warnings"] = [f"{c['name']}: {c['detail'][:200]}" for c in val.get("checks", []) if c.get("status") == "WARN"]
    return v


def dir_size(path: str) -> int:
    return sum(os.path.getsize(os.path.join(dp, f)) for dp, _, fs in os.walk(path) for f in fs)


def build_review_pack(out_dir: str, v: Dict[str, Any]) -> None:
    rev, ds = os.path.join(out_dir, "review"), os.path.join(out_dir, "dataset")
    os.makedirs(rev, exist_ok=True)
    for name in ("dataset.json", "DATA_QUALITY_REPORT.md", "DECODER_VERIFICATION.md", "decoder_verification.json"):
        if os.path.exists(os.path.join(ds, name)):
            shutil.copy(os.path.join(ds, name), os.path.join(rev, name))
    for dp, _, fs in os.walk(os.path.join(ds, "raw")):                       # per-hour metadata (URL, status, sha256, time): small
        for f in fs:
            if f.endswith(".meta.json"):
                dst = os.path.join(rev, "raw_meta", os.path.relpath(dp, ds))
                os.makedirs(dst, exist_ok=True); shutil.copy(os.path.join(dp, f), dst)
    sums = []
    for dp, _, fs in sorted(os.walk(ds)):
        for f in sorted(fs):
            p = os.path.join(dp, f)
            sums.append(f"{sha256_file(p)}  {os.path.relpath(p, ds)}")
    with open(os.path.join(rev, "SHA256SUMS.txt"), "w") as f:
        f.write("\n".join(sums) + ("\n" if sums else ""))
    prov = {k: os.environ.get(k) for k in ("GITHUB_REPOSITORY", "GITHUB_RUN_ID", "GITHUB_RUN_ATTEMPT", "GITHUB_SHA", "GITHUB_SERVER_URL", "RUNNER_OS")}
    prov.update(python=platform.python_version(), dataset_bytes=dir_size(ds) if os.path.exists(ds) else 0)
    v["provenance"] = prov
    with open(os.path.join(rev, "VERDICT.json"), "w") as f:
        json.dump(v, f, indent=1, sort_keys=True)
    head = ("STATUS: PASSED - the dataset is validated.\n" if v["validated"] else
            f"STATUS: {v['status']} - NOT VALIDATED. DO NOT USE ANY DATA FROM THIS RUN.\n")
    with open(os.path.join(rev, "VERDICT.txt"), "w") as f:
        f.write(head + f"reason: {v['reason']}\nstages: {v['stages']}\n")
        if v["validated"]:
            f.write(f"dataset_id: {v['dataset_id']}\ncsv_sha256: {v['csv_sha256']}\nrows: {v['rows']}\n")
        f.write(f"dataset size on disk: {prov['dataset_bytes'] / 1e6:.1f} MB\n")


def markdown_summary(out_dir: str, v: Dict[str, Any]) -> str:
    rev = os.path.join(out_dir, "review")
    out = [f"# Dukascopy dataset run: {'PASSED' if v['validated'] else v['status'] + ' - NOT VALIDATED'}", "", f"**{v['reason']}**", "",
           "| stage | result |", "|---|---|"]
    out += [f"| {STAGE_TEXT[s]} | {'ok' if v['stages'][s] == '0' else v['stages'][s]} |" for s in STAGE_ORDER]
    if v["validated"]:
        out += ["", f"dataset id `{v['dataset_id']}` - {v['rows']} rows - CSV SHA-256 `{v['csv_sha256']}`"]
        if v.get("warnings"):
            out += ["", "WARN items to review:"] + [f"- {w}" for w in v["warnings"]]
    else:
        out += ["", "No dataset artifact is published for a run that is not validated; only the review pack (reports, logs, hashes) is attached."]
    size_mb = dir_size(os.path.join(out_dir, "dataset")) / 1e6 if os.path.exists(os.path.join(out_dir, "dataset")) else 0
    out += ["", f"dataset directory size: {size_mb:.1f} MB (check your GitHub storage quota before keeping several runs)"]
    for name, title in (("DECODER_VERIFICATION.md", "Decoder verification"), ("DATA_QUALITY_REPORT.md", "Data quality report")):
        p = os.path.join(rev, name)
        if os.path.exists(p):
            out += ["", f"---", open(p).read()]
    txt = "\n".join(out)
    if len(txt.encode()) > MAX_SUMMARY_BYTES:
        txt = txt.encode()[:MAX_SUMMARY_BYTES].decode(errors="ignore") + "\n\n[summary truncated; see the review pack]"
    return txt


def main(argv: Optional[List[str]] = None) -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", required=True); ap.add_argument("--summary"); ap.add_argument("--github-output")
    a = ap.parse_args(argv)
    v = compute_verdict(a.out)
    build_review_pack(a.out, v)
    txt = markdown_summary(a.out, v)
    if a.summary:
        with open(a.summary, "a") as f:
            f.write(txt + "\n")
    if a.github_output:
        with open(a.github_output, "a") as f:
            f.write(f"status={v['status']}\nvalidated={'true' if v['validated'] else 'false'}\n")
    print(open(os.path.join(a.out, "review", "VERDICT.txt")).read())
    return 0 if v["validated"] else 1


if __name__ == "__main__":
    sys.exit(main())
