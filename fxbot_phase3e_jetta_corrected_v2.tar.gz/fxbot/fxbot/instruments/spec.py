from __future__ import annotations

from dataclasses import dataclass
from decimal import Decimal, ROUND_CEILING, ROUND_FLOOR

from ..core.types import Side


@dataclass(frozen=True)
class PairSpec:
    """Contract facts. NO defaults on purpose: tick size, minimum size and increments
    must come from IBKR contract details (verified by the paper-trading probe), not from
    assumptions baked into code."""
    symbol: str          # e.g. "EURUSD"
    base: str
    quote: str
    tick_size: Decimal
    qty_step: Decimal    # order-size increment, in base-currency units
    min_qty: Decimal
    max_qty: Decimal

    def floor_qty(self, qty: Decimal) -> Decimal:
        if qty < self.min_qty:
            return Decimal(0)
        steps = qty // self.qty_step
        return min(steps * self.qty_step, self.max_qty)

    def round_stop(self, side: Side, price: Decimal) -> Decimal:
        """Round a protective stop onto the tick grid in the TIGHTER direction so rounding
        can never loosen protection: LONG stops round up, SHORT stops round down."""
        mode = ROUND_CEILING if side is Side.LONG else ROUND_FLOOR
        return (price / self.tick_size).to_integral_value(rounding=mode) * self.tick_size
