"""Decimal cost model. All amounts are in the PAIR'S QUOTE CURRENCY unless stated.

Cost accounting convention (avoids double counting spread):
  gross_pnl  = mid-to-mid price movement * qty                (what a frictionless fill would earn)
  costs      = commission + spread (half at each side, vs mid) + slippage (fill vs touch)
               + financing + other
  net_pnl    = gross_pnl - costs
  identity   : net_pnl == sign*(exit_fill - entry_fill)*qty - commissions - financing - other
Commission schedules are NOT hardcoded: the operator supplies them and records where they
were verified. Unverified schedules are allowed for research but block live trading.
"""
from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from datetime import date
from decimal import Decimal
from typing import Dict, List, Mapping, Optional, Tuple

from ..config.schema import MinNetProfit, MinNetProfitMode, PairConfig
from ..core.money import FxRates, Money
from ..core.types import HUNDRED, ZERO, FxBotError, Quote, Side


# ------------------------------------------------------------------ breakdown
@dataclass(frozen=True)
class CostBreakdown:
    commission: Decimal = ZERO
    spread: Decimal = ZERO
    slippage: Decimal = ZERO       # may be negative (price improvement)
    financing: Decimal = ZERO
    other: Decimal = ZERO

    @property
    def total(self) -> Decimal:
        return self.commission + self.spread + self.slippage + self.financing + self.other

    def __add__(self, o: "CostBreakdown") -> "CostBreakdown":
        return CostBreakdown(self.commission + o.commission, self.spread + o.spread,
                             self.slippage + o.slippage, self.financing + o.financing,
                             self.other + o.other)

    def __sub__(self, o: "CostBreakdown") -> "CostBreakdown":
        return CostBreakdown(self.commission - o.commission, self.spread - o.spread,
                             self.slippage - o.slippage, self.financing - o.financing,
                             self.other - o.other)

    def scaled(self, f: Decimal) -> "CostBreakdown":
        return CostBreakdown(self.commission * f, self.spread * f, self.slippage * f,
                             self.financing * f, self.other * f)


@dataclass(frozen=True)
class CostRecord:
    """Estimated vs realised costs for one phase (entry or exit) of one position."""
    phase: str
    estimated: CostBreakdown
    realised: CostBreakdown

    @property
    def variance(self) -> CostBreakdown:
        return self.realised - self.estimated


# ------------------------------------------------------------ commission models
@dataclass(frozen=True)
class ScheduleVerification:
    source: str                       # e.g. "IBKR commission page + account statement"
    verified: bool = False
    verified_on: Optional[date] = None
    account_id: Optional[str] = None


class CommissionSchedule(ABC):
    verification: ScheduleVerification

    @abstractmethod
    def commission(self, notional: Money, rates: FxRates, month_volume: Decimal = ZERO) -> Money: ...


def _to(m: Money, ccy: str, rates: FxRates) -> Decimal:
    return rates.convert(m.amount, m.ccy, ccy)


@dataclass(frozen=True)
class PercentOfNotional(CommissionSchedule):
    rate_bps: Decimal
    min_per_order: Money
    charge_ccy: str
    verification: ScheduleVerification
    cap_pct_of_notional: Optional[Decimal] = None
    fixed_per_order: Optional[Money] = None        # exchange/clearing/regulatory per-order fee

    def commission(self, notional, rates, month_volume=ZERO) -> Money:
        n = _to(notional, self.charge_ccy, rates)
        amt = max(n * self.rate_bps / Decimal(10000), _to(self.min_per_order, self.charge_ccy, rates))
        if self.cap_pct_of_notional is not None:
            amt = min(amt, n * self.cap_pct_of_notional / HUNDRED)
        if self.fixed_per_order is not None:
            amt += _to(self.fixed_per_order, self.charge_ccy, rates)
        return Money(amt, self.charge_ccy)


@dataclass(frozen=True)
class FlatPerOrder(CommissionSchedule):
    fee: Money
    verification: ScheduleVerification

    def commission(self, notional, rates, month_volume=ZERO) -> Money:
        return self.fee


@dataclass(frozen=True)
class TieredPercent(CommissionSchedule):
    """tiers: ((monthly_volume_threshold_in_charge_ccy, rate_bps), ...) ascending.
    The tier is chosen from month-to-date volume at order time."""
    tiers: Tuple[Tuple[Decimal, Decimal], ...]
    min_per_order: Money
    charge_ccy: str
    verification: ScheduleVerification

    def commission(self, notional, rates, month_volume=ZERO) -> Money:
        if not self.tiers:
            raise FxBotError("empty tier table")
        rate = self.tiers[0][1]
        for thr, r in sorted(self.tiers):
            if month_volume >= thr:
                rate = r
        n = _to(notional, self.charge_ccy, rates)
        amt = max(n * rate / Decimal(10000), _to(self.min_per_order, self.charge_ccy, rates))
        return Money(amt, self.charge_ccy)


# ----------------------------------------------------------------- financing
@dataclass(frozen=True)
class FinancingModel:
    """Estimate only. `annual_rates_pct[ccy] = (debit_pct, credit_pct)` must come from the
    broker (benchmark +/- IBKR spread). Real accruals from the broker always override it.
    Returns None when a needed rate is missing, never a silent zero."""
    annual_rates_pct: Mapping[str, Tuple[Decimal, Decimal]]
    day_count: int = 360
    credit_on_short_proceeds: bool = False   # short-sale proceeds are not freely available cash

    def carry_cost(self, side: Side, base: str, quote: str, qty: Decimal, price: Decimal,
                   seconds: int) -> Optional[Decimal]:
        try:
            rb, rq = self.annual_rates_pct[base], self.annual_rates_pct[quote]
        except KeyError:
            return None
        t = Decimal(seconds) / (Decimal(self.day_count) * 86400)
        notional = qty * price
        if side is Side.LONG:    # hold +base (earn credit), spent quote cash (lose its credit)
            rate = (rq[1] - rb[1]) / HUNDRED
        else:                    # -base borrowed (pay debit); proceeds optionally credited
            rate = (rb[0] - (rq[1] if self.credit_on_short_proceeds else ZERO)) / HUNDRED
        return notional * rate * t


# ------------------------------------------------------------------- context
@dataclass(frozen=True)
class CostContext:
    schedule: CommissionSchedule
    rates: FxRates
    base_ccy: str
    slippage_pct: Decimal                    # per side, % of price (calibrate from paper data)
    financing: Optional[FinancingModel] = None
    month_volume: Decimal = ZERO

    def commission_quote(self, qty: Decimal, price: Decimal, quote_ccy: str) -> Decimal:
        c = self.schedule.commission(Money(qty * price, quote_ccy), self.rates, self.month_volume)
        return self.rates.convert(c.amount, c.ccy, quote_ccy)

    def slip_price(self, price: Decimal) -> Decimal:
        return price * self.slippage_pct / HUNDRED

    def to_base(self, amount: Decimal, ccy: str) -> Decimal:
        return self.rates.convert(amount, ccy, self.base_ccy)


def resolve_min_net_profit(mnp: MinNetProfit, ctx: CostContext, qty: Decimal,
                           price: Decimal, quote_ccy: str) -> Decimal:
    """Minimum net profit target in QUOTE currency for `qty` units entered at `price`."""
    if mnp.mode is MinNetProfitMode.PCT_NOTIONAL:
        return qty * price * mnp.value / HUNDRED
    return ctx.rates.convert(mnp.value, ctx.base_ccy, quote_ccy)


# ----------------------------------------------------------- pre-trade assessment
@dataclass(frozen=True)
class EntryCostAssessment:
    accepted: bool
    reasons: Tuple[str, ...]
    warnings: Tuple[str, ...]
    expected_entry_price: Optional[Decimal] = None
    entry_costs: CostBreakdown = CostBreakdown()
    exit_costs: CostBreakdown = CostBreakdown()
    total_costs: Decimal = ZERO
    stop_distance_money: Decimal = ZERO
    reward_money: Decimal = ZERO
    cost_to_stop_ratio: Optional[Decimal] = None
    cost_to_reward_ratio: Optional[Decimal] = None
    net_at_stop: Optional[Decimal] = None
    net_at_trail_activation: Optional[Decimal] = None
    net_at_first_protected_level: Optional[Decimal] = None
    net_at_profit_target: Optional[Decimal] = None


def assess_entry_costs(*, side: Side, quote: Quote, qty: Decimal, cfg: PairConfig,
                       ctx: CostContext, base: str, quote_ccy: str,
                       hold_seconds: Optional[int] = None) -> EntryCostAssessment:
    """Hard entry filter (decision 1E). Rejects structurally unattractive trades."""
    missing = [n for n in ("max_spread_pct", "est_slippage_pct", "max_cost_to_stop_ratio",
                           "max_cost_to_reward_ratio") if getattr(cfg, n) is None]
    if missing:
        return EntryCostAssessment(False, tuple(f"{cfg.symbol}.{m} not configured" for m in missing), ())
    if qty <= 0:
        return EntryCostAssessment(False, ("quantity must be > 0",), ())

    reasons: List[str] = []
    warnings: List[str] = []
    sgn = Decimal(side.sign)
    slip_pct = cfg.est_slippage_pct
    touch = quote.entry_price(side)
    p0 = touch * (1 + sgn * slip_pct / HUNDRED)             # expected average fill
    spread_pct = quote.spread / quote.mid * HUNDRED
    if spread_pct > cfg.max_spread_pct:
        reasons.append(f"spread {spread_pct:.5f}% > max {cfg.max_spread_pct}%")

    comm_in = ctx.commission_quote(qty, p0, quote_ccy)
    comm_out = ctx.commission_quote(qty, p0, quote_ccy)
    half = quote.spread / 2
    slip_in = abs(p0 - touch) * qty
    slip_out = p0 * slip_pct / HUNDRED * qty
    secs = hold_seconds if hold_seconds is not None else cfg.max_hold_minutes * 60
    fin: Optional[Decimal] = ctx.financing.carry_cost(side, base, quote_ccy, qty, p0, secs) if ctx.financing else None
    if fin is None:
        warnings.append("financing estimate unavailable (no reliable rates)"
                        + (" - SHORT borrow cost unknown" if side is Side.SHORT else ""))
    fin_v = fin if fin is not None else ZERO

    entry = CostBreakdown(commission=comm_in, spread=half * qty, slippage=slip_in)
    exit_ = CostBreakdown(commission=comm_out, spread=half * qty, slippage=slip_out, financing=fin_v)
    total = entry.total + exit_.total

    stop_money = p0 * cfg.initial_stop_pct / HUNDRED * qty
    reward_money = p0 * cfg.trailing_activation_pct / HUNDRED * qty
    ratio_stop = total / stop_money
    ratio_reward = total / reward_money
    if ratio_stop > cfg.max_cost_to_stop_ratio:
        reasons.append(f"cost/stop {ratio_stop:.3f} > max {cfg.max_cost_to_stop_ratio}")
    if ratio_reward > cfg.max_cost_to_reward_ratio:
        reasons.append(f"cost/reward {ratio_reward:.3f} > max {cfg.max_cost_to_reward_ratio}")

    # Net at an executable exit r% from P0 (spread already inside P0 and the exit side).
    fixed = comm_in + comm_out + fin_v + slip_out
    def net_at(r_pct: Decimal) -> Decimal:
        return p0 * r_pct / HUNDRED * qty - fixed

    target = None
    if cfg.profit_taking_enabled and cfg.min_net_profit is not None:
        target = resolve_min_net_profit(cfg.min_net_profit, ctx, qty, p0, quote_ccy)
    return EntryCostAssessment(
        accepted=not reasons, reasons=tuple(reasons), warnings=tuple(warnings),
        expected_entry_price=p0, entry_costs=entry, exit_costs=exit_, total_costs=total,
        stop_distance_money=stop_money, reward_money=reward_money,
        cost_to_stop_ratio=ratio_stop, cost_to_reward_ratio=ratio_reward,
        net_at_stop=net_at(-cfg.initial_stop_pct),
        net_at_trail_activation=net_at(cfg.trailing_activation_pct),
        net_at_first_protected_level=net_at(cfg.trailing_activation_pct - cfg.trailing_distance_pct),
        net_at_profit_target=target)
