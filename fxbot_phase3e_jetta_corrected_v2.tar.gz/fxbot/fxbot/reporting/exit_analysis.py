"""Reports required before Phase 2 (items 5-7): estimated-vs-realised costs, trailing exits at
gross breakeven with negative net P&L, and trailing-only vs trailing+profit-taking."""
from __future__ import annotations

from dataclasses import dataclass
from decimal import Decimal
from typing import Dict, Mapping, Optional, Sequence

from ..core.types import ZERO
from ..costs.model import CostBreakdown
from ..position_manager.position import ExitReason, TradeRecord
from .metrics import Summary, summarise


@dataclass(frozen=True)
class GrossBreakevenReport:
    trailing_exits: int
    at_gross_breakeven_level: int      # protected level <= tolerance when the trailing stop fired
    of_which_negative_net: int
    share_negative_net: Optional[Decimal]   # of breakeven-level trailing exits
    total_net_loss_base: Decimal
    avg_net_loss_base: Optional[Decimal]
    total_costs_base: Decimal


def trailing_gross_breakeven_report(trades: Sequence[TradeRecord],
                                    tolerance_pp: Decimal = ZERO) -> GrossBreakevenReport:
    tr = [t for t in trades if t.exit_reason is ExitReason.TRAILING_STOP]
    be = [t for t in tr if t.trail_protected_pct_at_exit is not None
          and t.trail_protected_pct_at_exit <= tolerance_pp]
    neg = [t for t in be if t.net_pnl < 0]
    loss = sum((t.net_pnl_base for t in neg), ZERO)
    return GrossBreakevenReport(
        len(tr), len(be), len(neg),
        (Decimal(len(neg)) / len(be)) if be else None,
        loss, (loss / len(neg)) if neg else None,
        sum((t.costs_base for t in be), ZERO))


def compare_exit_modes(modes: Mapping[str, Sequence[TradeRecord]],
                       equity0: Optional[Decimal] = None) -> Dict[str, Summary]:
    """e.g. {"trailing_only": [...], "trailing+pt(0.02%)": [...]} -> side-by-side summaries.
    Phase 3 produces each list by replaying the SAME signals/data with different exit settings."""
    return {k: summarise(v, equity0) for k, v in modes.items()}


def exit_reason_breakdown(trades: Sequence[TradeRecord]) -> Dict[str, Summary]:
    out: Dict[str, list] = {}
    for t in trades:
        out.setdefault(t.exit_reason.value, []).append(t)
    return {k: summarise(v) for k, v in out.items()}


def estimated_vs_realised(trades: Sequence[TradeRecord]) -> Optional[Dict[str, Dict[str, Decimal]]]:
    """Per-component totals (quote ccy converted to base) of estimated vs realised costs, over
    trades that carry both estimates. Positive variance = costs were higher than estimated."""
    sel = [t for t in trades if t.est_entry_costs is not None and t.est_exit_costs is not None]
    if not sel:
        return None
    out = {}
    for comp in ("commission", "spread", "slippage", "financing", "other"):
        est = sum(((getattr(t.est_entry_costs, comp) + getattr(t.est_exit_costs, comp)) * t.fx_to_base
                   for t in sel), ZERO)
        real = sum((getattr(t.costs, comp) * t.fx_to_base for t in sel), ZERO)
        out[comp] = {"estimated": est, "realised": real, "variance": real - est}
    return out
