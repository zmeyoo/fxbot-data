"""Live-readiness criteria, LOCKED IN CODE before any out-of-sample result is examined.
`criteria.fingerprint()` is recorded with every report so thresholds cannot be tuned afterwards.
Evidence that is too thin is reported as INSUFFICIENT_EVIDENCE, never as validated."""
from __future__ import annotations

import hashlib
import json
from dataclasses import asdict, dataclass, field
from decimal import Decimal
from enum import Enum
from typing import Dict, FrozenSet, List, Optional, Sequence

from ..core.types import Side
from ..position_manager.position import TradeRecord
from .metrics import Summary, sharpe_from_daily_returns, summarise


class Status(str, Enum):
    PASS = "PASS"
    FAIL = "FAIL"
    INSUFFICIENT_EVIDENCE = "INSUFFICIENT_EVIDENCE"


@dataclass(frozen=True)
class ReadinessCriteria:
    # --- approved by you ---
    min_oos_trades: int = 300
    min_profit_factor: Decimal = Decimal("1.30")
    min_sharpe: float = 0.80
    max_drawdown_pct: Decimal = Decimal("10")
    max_unresolved_recon_errors: int = 0
    max_unprotected_positions: int = 0
    max_duplicate_orders: int = 0
    max_critical_failures: int = 0
    min_paper_days: int = 90
    # --- PROPOSED by me, need your approval (see docs/ASSUMPTIONS.md A-5, A-7) ---
    min_trades_per_segment: int = 30
    required_recovery_drills: FrozenSet[str] = frozenset({"forced_disconnect", "app_restart", "broker_timeout"})

    def fingerprint(self) -> str:
        d = {k: (sorted(v) if isinstance(v, frozenset) else str(v)) for k, v in asdict(self).items()}
        return hashlib.sha256(json.dumps(d, sort_keys=True).encode()).hexdigest()


@dataclass(frozen=True)
class OperationalCounts:
    unresolved_recon_errors: int
    unprotected_positions: int
    duplicate_orders: int
    critical_failures: int
    paper_days: int
    recovery_drills_passed: FrozenSet[str]


@dataclass(frozen=True)
class SegmentResult:
    name: str
    n: int
    status: Status
    summary: Summary
    reasons: tuple


@dataclass(frozen=True)
class ReadinessReport:
    status: Status
    criteria_fingerprint: str
    overall: Summary
    sharpe: Optional[float]
    segments: Dict[str, SegmentResult]
    validated_pairs: List[str]
    reasons: List[str]


def _segment(name: str, trades: Sequence[TradeRecord], c: ReadinessCriteria) -> SegmentResult:
    s = summarise(trades)
    if s.n < c.min_trades_per_segment:
        return SegmentResult(name, s.n, Status.INSUFFICIENT_EVIDENCE, s,
                             (f"only {s.n} trades (< {c.min_trades_per_segment})",))
    r = []
    if s.expectancy_base is None or s.expectancy_base <= 0:
        r.append("net expectancy not positive")
    if s.profit_factor is not None and s.profit_factor < c.min_profit_factor:
        r.append(f"profit factor {s.profit_factor:.2f} < {c.min_profit_factor}")
    return SegmentResult(name, s.n, Status.FAIL if r else Status.PASS, s, tuple(r))


@dataclass(frozen=True)
class StrategyEvidence:
    """Strategy-metric part of the criteria (no operational / paper-trading conditions)."""
    status: Status
    criteria_fingerprint: str
    overall: Summary
    sharpe: Optional[float]
    segments: Dict[str, SegmentResult]
    validated_pairs: List[str]
    reasons: List[str]


def evaluate_strategy_evidence(c: ReadinessCriteria, oos_trades: Sequence[TradeRecord],
                               daily_returns: Sequence[float], equity0: Decimal,
                               pairs_in_scope: Sequence[str]) -> StrategyEvidence:
    reasons: List[str] = []
    fail = insufficient = False
    overall = summarise(oos_trades, equity0)
    sharpe = sharpe_from_daily_returns(daily_returns)
    segs: Dict[str, SegmentResult] = {}
    for p in pairs_in_scope:
        segs[f"pair:{p}"] = _segment(f"pair:{p}", [t for t in oos_trades if t.pair == p], c)
    for sd in Side:
        segs[f"side:{sd.value}"] = _segment(f"side:{sd.value}", [t for t in oos_trades if t.side is sd], c)
    if overall.n < c.min_oos_trades:
        insufficient = True; reasons.append(f"out-of-sample trades {overall.n} < {c.min_oos_trades}")
    else:
        if overall.expectancy_base is None or overall.expectancy_base <= 0:
            fail = True; reasons.append("net expectancy after costs not positive")
        if overall.profit_factor is not None and overall.profit_factor < c.min_profit_factor:
            fail = True; reasons.append(f"profit factor {overall.profit_factor:.2f} < {c.min_profit_factor}")
        if sharpe is None:
            insufficient = True; reasons.append("Sharpe not computable")
        elif sharpe < c.min_sharpe:
            fail = True; reasons.append(f"Sharpe {sharpe:.2f} < {c.min_sharpe}")
        if overall.max_drawdown_pct is not None and overall.max_drawdown_pct > c.max_drawdown_pct:
            fail = True; reasons.append(f"max drawdown {overall.max_drawdown_pct:.2f}% > {c.max_drawdown_pct}%")
    for name, sr in segs.items():
        if name.startswith("side:"):
            if sr.status is Status.FAIL:
                fail = True; reasons.append(f"{name} fails: {'; '.join(sr.reasons)}")
            elif sr.status is Status.INSUFFICIENT_EVIDENCE:
                insufficient = True; reasons.append(f"{name}: {sr.reasons[0]}")
        elif sr.status is Status.FAIL:                      # a strong pair must not hide a failing pair
            fail = True; reasons.append(f"{name} fails: {'; '.join(sr.reasons)}")
    validated = [n.split(":", 1)[1] for n, s_ in segs.items() if n.startswith("pair:") and s_.status is Status.PASS]
    for n, s_ in segs.items():
        if n.startswith("pair:") and s_.status is Status.INSUFFICIENT_EVIDENCE:
            reasons.append(f"{n}: insufficient evidence - NOT validated, must stay disabled for live")
    if not validated:
        insufficient = True; reasons.append("no pair has validated evidence")
    status = Status.FAIL if fail else Status.INSUFFICIENT_EVIDENCE if insufficient else Status.PASS
    return StrategyEvidence(status, c.fingerprint(), overall, sharpe, segs, validated, reasons)


def evaluate_readiness(c: ReadinessCriteria, oos_trades: Sequence[TradeRecord],
                       daily_returns: Sequence[float], equity0: Decimal,
                       ops: OperationalCounts, pairs_in_scope: Sequence[str]) -> ReadinessReport:
    ev = evaluate_strategy_evidence(c, oos_trades, daily_returns, equity0, pairs_in_scope)
    reasons = list(ev.reasons)
    fail = ev.status is Status.FAIL
    insufficient = ev.status is Status.INSUFFICIENT_EVIDENCE
    for label, val, lim in (("unresolved reconciliation errors", ops.unresolved_recon_errors, c.max_unresolved_recon_errors),
                            ("unprotected positions", ops.unprotected_positions, c.max_unprotected_positions),
                            ("duplicate unintended orders", ops.duplicate_orders, c.max_duplicate_orders),
                            ("critical execution/recovery failures", ops.critical_failures, c.max_critical_failures)):
        if val > lim:
            fail = True; reasons.append(f"{label}: {val} > {lim}")
    if ops.paper_days < c.min_paper_days:
        insufficient = True; reasons.append(f"paper trading {ops.paper_days}d < {c.min_paper_days}d")
    missing = c.required_recovery_drills - ops.recovery_drills_passed
    if missing:
        insufficient = True; reasons.append(f"recovery drills not passed: {sorted(missing)}")
    status = Status.FAIL if fail else Status.INSUFFICIENT_EVIDENCE if insufficient else Status.PASS
    return ReadinessReport(status, c.fingerprint(), ev.overall, ev.sharpe, ev.segments, ev.validated_pairs, reasons)
