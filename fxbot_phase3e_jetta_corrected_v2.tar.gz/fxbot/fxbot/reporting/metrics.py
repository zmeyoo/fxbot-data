from __future__ import annotations

import math
import statistics
from dataclasses import dataclass
from decimal import Decimal
from typing import List, Optional, Sequence

from ..core.types import HUNDRED, ZERO
from ..position_manager.position import TradeRecord


@dataclass(frozen=True)
class Summary:
    n: int
    net_pnl_base: Decimal
    gross_pnl_base: Decimal
    costs_base: Decimal
    costs_pct_of_gross_profit: Optional[Decimal]   # None when gross P&L <= 0 (costs exceed/absorb it)
    win_rate: Optional[Decimal]
    avg_win_base: Optional[Decimal]
    avg_loss_base: Optional[Decimal]
    expectancy_base: Optional[Decimal]
    profit_factor: Optional[Decimal]               # None when there are no losing trades
    max_consecutive_losses: int
    avg_hold_seconds: Optional[Decimal]
    max_drawdown_pct: Optional[Decimal]            # needs starting equity


def summarise(trades: Sequence[TradeRecord], equity0: Optional[Decimal] = None) -> Summary:
    ts = sorted(trades, key=lambda t: t.closed_ts)
    n = len(ts)
    nets = [t.net_pnl_base for t in ts]
    wins = [x for x in nets if x > 0]
    losses = [x for x in nets if x < 0]
    gross = sum((t.gross_pnl_base for t in ts), ZERO)
    costs = sum((t.costs_base for t in ts), ZERO)
    streak = best = 0
    for x in nets:
        streak = streak + 1 if x < 0 else 0
        best = max(best, streak)
    dd = None
    if equity0 is not None and n:
        eq, peak, worst = equity0, equity0, ZERO
        for x in nets:
            eq += x
            peak = max(peak, eq)
            worst = max(worst, (peak - eq) / peak * HUNDRED)
        dd = worst
    return Summary(
        n=n, net_pnl_base=sum(nets, ZERO), gross_pnl_base=gross, costs_base=costs,
        costs_pct_of_gross_profit=(costs / gross * HUNDRED) if gross > 0 else None,
        win_rate=(Decimal(len(wins)) / n * HUNDRED) if n else None,
        avg_win_base=(sum(wins, ZERO) / len(wins)) if wins else None,
        avg_loss_base=(sum(losses, ZERO) / len(losses)) if losses else None,
        expectancy_base=(sum(nets, ZERO) / n) if n else None,
        profit_factor=(sum(wins, ZERO) / -sum(losses, ZERO)) if losses else None,
        max_consecutive_losses=best,
        avg_hold_seconds=(Decimal(sum(t.hold_seconds for t in ts)) / n) if n else None,
        max_drawdown_pct=dd)


def sharpe_from_daily_returns(daily_returns: Sequence[float], periods: int = 252) -> Optional[float]:
    """Annualised Sharpe from DAILY net returns (fraction of equity), risk-free = 0.
    Convention proposed in docs/ASSUMPTIONS.md (A-6); needs your confirmation."""
    if len(daily_returns) < 2:
        return None
    sd = statistics.stdev(daily_returns)
    return None if sd == 0 else statistics.mean(daily_returns) / sd * math.sqrt(periods)


def daily_returns_from_trades(trades: Sequence[TradeRecord], equity0: Decimal, include_flat_weekdays: bool = True,
                              calendar=None) -> List[float]:
    """Return per TRADING SESSION (17:00 New York close, labelled by the closing date; see core/sessions.py) as a fraction of
    start-of-session equity. With include_flat_weekdays the series covers every Mon-Fri session label between the first and last
    trade (flat sessions = 0), so Sharpe is not inflated by counting only active days."""
    from datetime import timedelta
    from ..core.sessions import SessionCalendar
    cal = calendar or SessionCalendar()
    if not trades:
        return []
    by_day = {}
    for t in sorted(trades, key=lambda x: x.closed_ts):
        lab = cal.session_of(t.closed_ts).label
        by_day[lab] = by_day.get(lab, ZERO) + t.net_pnl_base
    first, last = min(by_day), max(by_day)
    days = [first + timedelta(days=i) for i in range((last - first).days + 1)]
    days = [d for d in days if d.weekday() < 5 or d in by_day] if include_flat_weekdays else sorted(by_day)
    eq, out = equity0, []
    for d in days:
        pnl = by_day.get(d, ZERO)
        out.append(float(pnl / eq))
        eq += pnl
    return out
