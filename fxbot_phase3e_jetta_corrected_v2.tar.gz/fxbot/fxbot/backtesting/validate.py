"""Tick-file validation report: independent re-reads of the raw file compared against what the loader produced.
Checks are honest about sample size: statistics that cannot be assessed on a tiny file are marked NOT TESTABLE,
not PASS."""
from __future__ import annotations

import csv
from dataclasses import dataclass
from datetime import timedelta
from decimal import Decimal
from typing import Any, Dict, List, Optional, Sequence, Tuple

from ..core.sessions import SessionCalendar
from ..core.types import Side
from .data import (DatasetReport, TickFormat, _EPOCH, _UNIT_US, DataError, detect_format, load_ticks_csv)

MIN_N_FOR_STATS = 100


@dataclass(frozen=True)
class Check:
    name: str
    status: str          # PASS | FAIL | NOT TESTABLE | INFO
    detail: str


@dataclass
class ValidationResult:
    path: str
    fmt: TickFormat
    report: DatasetReport
    checks: List[Check]
    sample: List[Dict[str, Any]]

    @property
    def ok(self) -> bool:
        return not any(c.status == "FAIL" for c in self.checks)


def _raw_rows(path: str, fmt: TickFormat) -> List[Dict[str, str]]:
    with open(path, newline="") as f:
        return list(csv.DictReader(f))


def validate_tick_file(path: str, pair: str = "EURUSD", fmt: Optional[TickFormat] = None, gap_threshold_s: int = 120,
                       sample_n: int = 3) -> ValidationResult:
    cal = SessionCalendar()
    with open(path, newline="") as f:
        header = csv.DictReader(f).fieldnames or []
    fmt = fmt or detect_format(header)
    quotes, rep = load_ticks_csv(path, pair, gap_threshold_s, fmt)
    raw = _raw_rows(path, fmt)
    checks: List[Check] = []
    small = rep.n_records < MIN_N_FOR_STATS
    if rep.n_records == 0:                           # e.g. an aborted/failed download: report it, never crash
        checks.append(Check("Dataset contains quotes", "FAIL", f"0 usable quotes kept from {len(raw)} raw rows"))
        return ValidationResult(path, fmt, rep, checks, [])

    # ---- 1. timestamps
    numeric = bool(rep.ts_unit) and rep.ts_unit != "iso" and all(r[fmt.ts_col].strip().replace(".", "", 1).isdigit() for r in raw)
    bad_rt = 0
    if numeric:
        factor = _UNIT_US[rep.ts_unit]
        for r, q in zip(raw, quotes):                    # only for rows that survived (no drops in a clean file)
            micros = (q.market_ts - _EPOCH) // timedelta(microseconds=1)
            if Decimal(micros) / factor != Decimal(r[fmt.ts_col].strip()) and len(raw) == len(quotes):
                bad_rt += 1
    aware = all(q.market_ts.tzinfo is not None and q.market_ts.utcoffset() == timedelta(0) for q in quotes)
    mono = all(a.market_ts <= b.market_ts for a, b in zip(quotes, quotes[1:]))
    checks.append(Check("Timestamp parsing / timezone",
                        "PASS" if (aware and mono and bad_rt == 0) else "FAIL",
                        f"unit={rep.ts_unit}; all UTC-aware={aware}; non-decreasing={mono}; "
                        f"exact epoch round-trip mismatches={bad_rt if numeric else 'n/a (ISO text)'}; resolution={rep.ts_resolution}; "
                        f"max quotes sharing one timestamp={rep.max_ticks_per_timestamp}"))
    # ---- 2. mapping + executable sides
    wrong = 0
    if len(raw) == len(quotes):
        for r, q in zip(raw, quotes):
            if Decimal(r[fmt.bid_col]) != q.bid or Decimal(r[fmt.ask_col]) != q.ask:
                wrong += 1
    ok_order = all(q.bid <= q.ask for q in quotes)
    q0 = quotes[0] if quotes else None
    side_ok = q0 is not None and q0.entry_price(Side.LONG) == q0.ask and q0.exit_price(Side.LONG) == q0.bid \
        and q0.entry_price(Side.SHORT) == q0.bid and q0.exit_price(Side.SHORT) == q0.ask
    checks.append(Check("BID/ASK field mapping + executable side",
                        "PASS" if (wrong == 0 and ok_order and side_ok) else "FAIL",
                        f"mapped by NAME: bid<-'{fmt.bid_col}', ask<-'{fmt.ask_col}'; rows where parsed != raw column: {wrong}; "
                        f"bid<=ask on all kept rows: {ok_order}; crossed fraction in file: {rep.crossed_fraction:.3f}; "
                        "LONG enters at ASK and exits at BID, SHORT enters at BID and exits at ASK: " + str(side_ok)))
    # ---- 3. duplicates / ooo / stale
    ia = rep.interarrival_s
    detail = (f"dropped: {rep.dropped_duplicate} exact duplicates, {rep.dropped_out_of_order} out-of-order, "
              f"{rep.dropped_crossed_or_invalid} crossed/invalid; unchanged-price re-quotes kept: {rep.unchanged_quotes}; "
              + (f"inter-arrival s median/p95/p99/max = {ia[0]:.3f}/{ia[1]:.3f}/{ia[2]:.3f}/{ia[3]:.3f}; "
                 f"intervals >10s/30s/60s: {rep.n_gaps_over}" if ia else "inter-arrival: n/a"))
    checks.append(Check("Duplicate / out-of-order / stale quotes",
                        "NOT TESTABLE" if small else "PASS",
                        detail + (f"  [only {rep.n_records} records: code paths are covered by synthetic-file unit tests, "
                                  "the statistics here say nothing about the feed]" if small else "")))
    # ---- 4. spreads recomputed independently
    rows = []
    mism = 0
    for r, q in list(zip(raw, quotes))[: max(sample_n, 0)]:
        sp = Decimal(r[fmt.ask_col]) - Decimal(r[fmt.bid_col])
        mid = (Decimal(r[fmt.ask_col]) + Decimal(r[fmt.bid_col])) / 2
        if sp != q.spread or mid != q.mid:
            mism += 1
        rows.append({"raw": r, "ts_utc": q.market_ts.isoformat(), "ts_ny": q.market_ts.astimezone(cal._tz()).isoformat(),
                     "session": cal.session_of(q.market_ts), "bid": str(q.bid), "ask": str(q.ask), "spread": str(q.spread),
                     "mid": str(q.mid), "spread_pct": f"{float(q.spread / q.mid * 100):.5f}",
                     "spread_pips": str(q.spread / Decimal("0.0001"))})
    checks.append(Check("Bid/ask spread calculation", "PASS" if mism == 0 else "FAIL",
                        f"spread=ask-bid, mid=(ask+bid)/2 recomputed from the raw text with exact Decimals; mismatches vs loader: {mism}; "
                        f"mean/median/max spread % = {rep.mean_spread_pct:.5f}/{rep.median_spread_pct:.5f}/{rep.max_spread_pct:.5f}"
                        if rep.mean_spread_pct is not None else "no quotes"))
    # ---- 5. gaps / sessions
    s_desc = "; ".join(f"{lab}: {n} quotes {a.isoformat()}..{b.isoformat()}" for lab, n, a, b in rep.sessions[:4])
    first = quotes[0].market_ts if quotes else None
    sess = cal.session_of(first) if first else None
    checks.append(Check("Data gaps and session boundaries", "NOT TESTABLE" if small else "PASS" if rep.quotes_in_closure == 0 else "FAIL",
                        f"unexpected gaps (> {gap_threshold_s}s, outside the weekly closure): {len(rep.gaps)}; weekend closures: {len(rep.closures)}; "
                        f"quotes stamped inside the Fri-17:00/Sun-17:00 New York closure: {rep.quotes_in_closure}; sessions seen: {s_desc}"
                        + (f"; first quote falls in session '{sess.label}' = {sess.start_utc.isoformat()} .. {sess.end_utc.isoformat()}" if sess else "")))
    # ---- 6. precision
    changed = 0
    if len(raw) == len(quotes):
        for r, q in zip(raw, quotes):
            if str(q.bid) != r[fmt.bid_col].strip() or str(q.ask) != r[fmt.ask_col].strip():
                changed += 1
    is_dec = all(isinstance(q.bid, Decimal) and isinstance(q.ask, Decimal) for q in quotes)
    checks.append(Check("Original quote precision preserved", "PASS" if (changed == 0 and is_dec) else "FAIL",
                        f"prices stored as exact Decimal (no float); text of every price identical after parsing "
                        f"(rows changed: {changed}); decimal places seen: {rep.price_decimals}"))
    checks.append(Check("Dataset fingerprint", "INFO", f"sha256 of canonical (ts,bid,ask) = {rep.sha256}"))
    return ValidationResult(path, fmt, rep, checks, rows)


def render_markdown(res: ValidationResult, title: str = "Tick data validation report") -> str:
    r = res.report
    out = [f"# {title}", "", f"- file: `{res.path}`", f"- format: **{res.fmt.name}** (ts=`{res.fmt.ts_col}` [{r.ts_unit}], bid=`{res.fmt.bid_col}`, ask=`{res.fmt.ask_col}`)",
           f"- records kept: {r.n_records}; span {r.first_ts} .. {r.last_ts}",
           f"- overall: **{'NO FAILED CHECKS' if res.ok else 'FAILED CHECKS - do not use this file'}**", "",
           "| check | status | detail |", "|---|---|---|"]
    out += [f"| {c.name} | **{c.status}** | {c.detail} |" for c in res.checks]
    out += ["", "## Sample rows (raw text -> parsed)", ""]
    for i, s in enumerate(res.sample):
        out += [f"**Row {i + 1}** raw: `{dict(s['raw'])}`", f"- UTC `{s['ts_utc']}`  |  New York `{s['ts_ny']}`  |  session `{s['session'].label}` "
                f"({s['session'].start_utc.isoformat()} .. {s['session'].end_utc.isoformat()})",
                f"- bid `{s['bid']}`  ask `{s['ask']}`  spread `{s['spread']}` ({s['spread_pips']} pips, {s['spread_pct']}%)  mid `{s['mid']}`", ""]
    out += ["## Limitations", "- " + "\n- ".join(r.limitations)]
    return "\n".join(out) + "\n"


def main(argv: Optional[Sequence[str]] = None) -> int:
    import argparse
    from .data import FORMATS
    ap = argparse.ArgumentParser(description="Validate a tick CSV and print a Markdown report")
    ap.add_argument("file"); ap.add_argument("--pair", default="EURUSD"); ap.add_argument("--format", choices=sorted(FORMATS))
    ap.add_argument("--out"); a = ap.parse_args(argv)
    res = validate_tick_file(a.file, a.pair, FORMATS[a.format] if a.format else None)
    md = render_markdown(res)
    if a.out:
        with open(a.out, "w") as f:
            f.write(md)
    print(md)
    return 0 if res.ok else 1
