"""Sensitivity studies on DEVELOPMENT data only: execution latency, and walk-forward methodology (training window length).
Neither study selects anything for the holdout."""
from __future__ import annotations

import statistics
from dataclasses import dataclass, replace
from datetime import datetime
from decimal import Decimal
from typing import Dict, List, Optional, Sequence, Tuple

from ..core.sessions import SessionCalendar
from ..core.types import FxBotError
from ..position_manager.position import TradeRecord
from ..reporting.metrics import Summary, summarise
from .data import DatasetReport
from .engine import BacktestResult, BacktestSettings
from .splits import ResearchSession, SplitPlan
from .sweeps import ParamGrid, VariantResult
from .walkforward import WalkForwardResult, walk_forward
from .sweeps import Variant

DEFAULT_LATENCIES = (0.5, 1, 2, 5)


@dataclass(frozen=True)
class LatencyRow:
    latency_s: Decimal
    summary: Summary
    mean_entry_delay_s: Optional[float]
    mean_exit_delay_s: Optional[float]
    n_entries_cancelled_spread: int


def latency_study(session: ResearchSession, base: BacktestSettings, trade_from: datetime, trade_until: datetime,
                  latencies: Sequence = DEFAULT_LATENCIES, variant_values: Optional[dict] = None) -> List[LatencyRow]:
    """Same data window, same strategy settings, only the fill latency changes. The base settings are used as given
    (optionally with `variant_values` axes applied); this is a SENSITIVITY check, not a selection."""
    vals = dict(variant_values or {})
    variants = [Variant(f"latency_s={l}", {"bt.latency_s": i}, {**vals, "bt.latency_s": l}) for i, l in enumerate(latencies)]
    return latency_rows_from_results(session.run_dev(base, variants, trade_from, trade_until))


def latency_rows_from_results(res: Sequence[VariantResult]) -> List[LatencyRow]:
    out = []
    for r in res:
        m = r.result.meta
        ed = [v["entry_delay_s"] for v in m.values() if "entry_delay_s" in v]
        xd = [v["exit_delay_s"] for v in m.values() if "exit_delay_s" in v]
        out.append(LatencyRow(Decimal(str(r.variant.values["bt.latency_s"])), summarise(r.result.trades, r.result.equity0_base),
                              statistics.fmean(ed) if ed else None, statistics.fmean(xd) if xd else None,
                              r.result.counters.get("entry_cancelled_spread", 0)))
    return out


def latency_section(rows: Sequence[LatencyRow], dataset: Optional[DatasetReport] = None) -> str:
    f = lambda x, nd=2: "n/a" if x is None else f"{float(x):.{nd}f}"
    out = ["### Execution-latency sensitivity (development data; same settings, only latency changes)",
           "| latency s | n | net P&L (base) | expectancy | PF | avg entry delay s | avg exit delay s |", "|---|---|---|---|---|---|---|"]
    for r in rows:
        s = r.summary
        out.append(f"| {r.latency_s} | {s.n} | {f(s.net_pnl_base)} | {f(s.expectancy_base)} | {f(s.profit_factor)} | {f(r.mean_entry_delay_s)} | {f(r.mean_exit_delay_s)} |")
    out.append("\n1 s is only an initial default and is NOT assumed representative: calibrate against measured paper-trading latency "
               "(order submit -> execution report). The realised delay can exceed the setting because fills use the next quote.")
    if dataset is not None and dataset.interarrival_s:
        med = dataset.interarrival_s[0]
        out.append(f"Quote granularity: median inter-quote gap {med:.3f}s (p95 {dataset.interarrival_s[1]:.3f}s). "
                   + ("Latencies below the median gap are not distinguishable from each other in this dataset." if any(float(r.latency_s) < med for r in rows) else ""))
    return "\n".join(out)


@dataclass
class WfMethodRow:
    label: str
    train_days: int
    wf: Optional[WalkForwardResult]
    error: Optional[str]


def compare_walk_forward_windows(source: Sequence, dataset: DatasetReport, base: BacktestSettings, grid: ParamGrid,
                                 plan: SplitPlan, registry_path: str, train_days: Sequence[int] = (20, 60, 120),
                                 min_trades_train: int = 30) -> List[WfMethodRow]:
    """Walk-forward with different training-window lengths. All use development data only; the holdout boundary
    (and therefore the single-look registry) is identical for every window length."""
    variants = grid.variants()
    rows: List[WfMethodRow] = []
    for d in train_days:
        p = replace(plan, wf_train_days=d)
        assert p.holdout_start == plan.holdout_start
        try:
            wf = walk_forward(ResearchSession(source, p, dataset.sha256, registry_path), base, variants, min_trades_train, f"train={d}d")
            rows.append(WfMethodRow(f"train {d}d / test {p.wf_test_days}d", d, wf, None))
        except FxBotError as e:
            rows.append(WfMethodRow(f"train {d}d / test {p.wf_test_days}d", d, None, f"not computable on this data span: {e}"))
    return rows


def common_period_trades(rows: Sequence[WfMethodRow]) -> Tuple[Optional[datetime], Dict[str, List[TradeRecord]]]:
    """Longer training windows start their out-of-sample period later. For a like-for-like comparison, restrict every
    methodology to the OOS period they all cover (from the latest first test window)."""
    ok = [r for r in rows if r.wf is not None and r.wf.folds]
    if not ok:
        return None, {}
    start = max(r.wf.folds[0].fold.test_start for r in ok)
    out = {}
    for r in ok:
        out[r.label] = [t for t in r.wf.oos_trades if t.opened_ts >= start]
    return start, out


def wf_methodology_section(rows: Sequence[WfMethodRow], equity0: Optional[Decimal]) -> str:
    from . import report as R
    out = ["### Walk-forward methodology comparison (training-window length; OUT-OF-SAMPLE, development period only)",
           "| methodology | folds | OOS span | n OOS | expectancy | net P&L | PF | distinct variants chosen |", "|---|---|---|---|---|---|---|---|"]
    for r in rows:
        if r.wf is None:
            out.append(f"| {r.label} | - | - | - | - | - | - | {r.error} |")
            continue
        s = summarise(r.wf.oos_trades, equity0)
        span = f"{r.wf.folds[0].fold.test_start:%Y-%m-%d}..{r.wf.folds[-1].fold.test_end:%Y-%m-%d}"
        out.append(f"| {r.label} | {len(r.wf.folds)} | {span} | {s.n} | {R._f(s.expectancy_base)} | {R._f(s.net_pnl_base)} | "
                   f"{R._f(s.profit_factor)} | {len({n for n in r.wf.chosen_names if n})} |")
    start, common = common_period_trades(rows)
    if common:
        out += [f"\nLike-for-like: only trades opened on/after {start:%Y-%m-%d} (the OOS period every methodology covers):",
                R.table(list(common.items()), equity0)]
    out.append("\nThe holdout is untouched by this comparison; no methodology is chosen from it automatically. "
               "Longer windows give fewer folds and a later OOS start - compare on the common period and on stability, not on one number.")
    return "\n".join(out)


DEFAULT_EOD_MINUTES = (15, 30, 60)


@dataclass(frozen=True)
class EodRow:
    minutes: int
    summary: Summary
    n_eod_exits: int
    trades_per_session: Optional[float]


def eod_cutoff_study(session: ResearchSession, base: BacktestSettings, trade_from: datetime, trade_until: datetime,
                     minutes: Sequence[int] = DEFAULT_EOD_MINUTES, variant_values: Optional[dict] = None) -> List[EodRow]:
    """Same data and strategy settings; only `eod_cutoff_minutes_before_rollover` changes. Development data only; a SENSITIVITY
    comparison - nothing is selected from it automatically."""
    vals = dict(variant_values or {})
    variants = [Variant(f"eod_cutoff={m}min", {"global.eod_cutoff_minutes_before_rollover": i},
                        {**vals, "global.eod_cutoff_minutes_before_rollover": m}) for i, m in enumerate(minutes)]
    out = []
    cal = SessionCalendar()
    for r in session.run_dev(base, variants, trade_from, trade_until):
        labels = set()
        d = trade_from
        while d < trade_until:
            sess = cal.session_of(d)
            if sess.is_trading_day:
                labels.add(sess.label)
            d = sess.end_utc
        n = len(r.result.trades)
        out.append(EodRow(int(r.variant.values["global.eod_cutoff_minutes_before_rollover"]),
                          summarise(r.result.trades, r.result.equity0_base), r.result.counters.get("exit_END_OF_DAY", 0),
                          (n / len(labels)) if labels else None))
    return out


def eod_section(rows: Sequence[EodRow], approved: Optional[int] = 30) -> str:
    f = lambda x, nd=2: "n/a" if x is None else f"{float(x):.{nd}f}"
    out = ["### End-of-day cutoff comparison (development data; minutes before the 17:00 New York rollover)",
           "| cutoff min | n | net P&L (base) | expectancy | PF | EOD exits | trades / session |", "|---|---|---|---|---|---|---|"]
    for r in rows:
        s = r.summary
        out.append(f"| {r.minutes}{' (provisional)' if r.minutes == approved else ''} | {s.n} | {f(s.net_pnl_base)} | "
                   f"{f(s.expectancy_base)} | {f(s.profit_factor)} | {r.n_eod_exits} | {f(r.trades_per_session)} |")
    out.append(f"\n{approved} minutes is the approved provisional value. This comparison uses development data only and the "
               "holdout is untouched; no value is selected from it automatically.")
    return "\n".join(out)
