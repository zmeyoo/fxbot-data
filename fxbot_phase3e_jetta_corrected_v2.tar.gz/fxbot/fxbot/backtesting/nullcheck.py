"""Null (no-edge) study statistics, with units and the uncertainty method stated explicitly.

For each trade we use the base-currency amounts recorded on the TradeRecord:
  gross = mid-to-mid price movement x quantity (before any cost);  costs = commission + spread + slippage (+ financing);
  net = gross - costs.  Unit: base currency (e.g. EUR) PER TRADE.
mean      = pooled mean over ALL trades from ALL seeds (not a mean of per-seed means).
SE naive  = sample stdev / sqrt(N)  (one standard error, assumes trades are independent).
SE cluster= ratio-estimator standard error treating each seed (an independent random path) as a cluster.
CI95      = mean +/- 1.96 SE.  z = mean / SE.  Two-sided normal p-value for H0: mean = 0.
"""
from __future__ import annotations

import math
import statistics
from dataclasses import dataclass
from typing import Optional, Sequence, Tuple

from ..position_manager.position import TradeRecord


@dataclass(frozen=True)
class MeanSE:
    mean: float
    se_naive: float
    se_cluster: Optional[float]

    @property
    def z(self) -> float:
        return self.mean / self.se_naive if self.se_naive else float("nan")

    @property
    def p_two_sided(self) -> float:
        return 2 * (1 - 0.5 * (1 + math.erf(abs(self.z) / math.sqrt(2))))

    @property
    def ci95(self) -> Tuple[float, float]:
        return (self.mean - 1.96 * self.se_naive, self.mean + 1.96 * self.se_naive)


@dataclass(frozen=True)
class NullStudy:
    unit: str
    n_seeds: int
    n_trades: int
    gross: MeanSE
    costs: MeanSE
    net: MeanSE
    stdev_gross: float
    min_detectable_gross_2se: float      # smallest mean gross edge this sample could flag at ~2 SE


def _mean_se(per_seed: Sequence[Sequence[float]]) -> MeanSE:
    allx = [x for s in per_seed for x in s]
    n = len(allx)
    mean = statistics.fmean(allx)
    se_n = statistics.stdev(allx) / math.sqrt(n)
    ks = [s for s in per_seed if len(s) > 0]
    se_c = None
    if len(ks) >= 2:
        nb = n / len(ks)
        resid = [sum(s) - mean * len(s) for s in ks]
        se_c = math.sqrt(sum(r * r for r in resid) / (len(ks) * (len(ks) - 1))) / nb
    return MeanSE(mean, se_n, se_c)


def null_study(per_seed_trades: Sequence[Sequence[TradeRecord]], unit: str = "base currency per trade") -> NullStudy:
    g = [[float(t.gross_pnl_base) for t in s] for s in per_seed_trades]
    c = [[float(t.costs_base) for t in s] for s in per_seed_trades]
    n_ = [[float(t.net_pnl_base) for t in s] for s in per_seed_trades]
    gm = _mean_se(g)
    allg = [x for s in g for x in s]
    return NullStudy(unit, len(per_seed_trades), len(allg), gm, _mean_se(c), _mean_se(n_), statistics.stdev(allg), 2 * gm.se_naive)


def render(s: NullStudy) -> str:
    f = lambda m: (f"{m.mean:+.2f} (SE naive {m.se_naive:.2f}" + (f", SE by seed {m.se_cluster:.2f}" if m.se_cluster is not None else "")
                   + f"; z={m.z:.2f}; p={m.p_two_sided:.3f}; 95% CI [{m.ci95[0]:.1f}, {m.ci95[1]:.1f}])")
    return "\n".join([f"Null study: {s.n_trades} trades from {s.n_seeds} independent seeds; unit = {s.unit}; means are pooled over trades",
                      f"  gross: {f(s.gross)}", f"  costs: {f(s.costs)}", f"  net  : {f(s.net)}",
                      f"  per-trade stdev of gross {s.stdev_gross:.1f}; smallest gross edge detectable at ~2 SE: {s.min_detectable_gross_2se:.1f}"])
