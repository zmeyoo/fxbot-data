"""Research workflow. `run_dev_research` NEVER touches the holdout. `run_holdout` is a separate explicit call that
the registry allows once per dataset+plan. Nothing is auto-selected for the holdout: the operator names the variant."""
from __future__ import annotations

import json
import os
from dataclasses import replace
from datetime import datetime, timedelta, timezone
from decimal import Decimal
from typing import Any, Dict, List, Mapping, Optional, Sequence

from ..config.schema import GlobalConfig, PairConfig, _build
from ..core.money import FxRates, Money
from ..costs.model import (CostContext, FlatPerOrder, FinancingModel, PercentOfNotional, ScheduleVerification,
                           TieredPercent)
from ..instruments.spec import PairSpec
from ..reporting.metrics import daily_returns_from_trades
from ..reporting.readiness import ReadinessCriteria
from ..signals.ema_trend import EmaTrendParams
from . import report as R
from .data import DatasetReport
from .engine import BacktestSettings
from .sensitivity import (DEFAULT_EOD_MINUTES, DEFAULT_LATENCIES, compare_walk_forward_windows, eod_cutoff_study,
                          eod_section, latency_section, latency_study, wf_methodology_section)
from .splits import ResearchSession, SplitPlan
from .sweeps import ParamGrid, Variant, VariantResult
from .walkforward import WalkForwardResult, walk_forward, walk_forward_by_axis


def _d(x) -> Decimal:
    return Decimal(str(x))


def build_commission(c: Mapping[str, Any]):
    ver = ScheduleVerification(c.get("source", "unspecified"), bool(c.get("verified", False)))
    mn = c.get("min_per_order")
    mn = Money(_d(mn["amount"]), mn["ccy"]) if mn else None
    t = c["type"]
    if t == "percent_of_notional":
        cap = c.get("cap_pct_of_notional")
        fx = c.get("fixed_per_order")
        return PercentOfNotional(_d(c["rate_bps"]), mn, c["charge_ccy"], ver, None if cap is None else _d(cap),
                                 None if fx is None else Money(_d(fx["amount"]), fx["ccy"]))
    if t == "flat_per_order":
        return FlatPerOrder(Money(_d(c["fee"]["amount"]), c["fee"]["ccy"]), ver)
    if t == "tiered":
        return TieredPercent(tuple((_d(a), _d(b)) for a, b in c["tiers"]), mn, c["charge_ccy"], ver)
    raise ValueError(f"unknown commission type {t!r}")


def load_config(path: str):
    """JSON -> (BacktestSettings, ParamGrid, SplitPlan-kwargs). Missing limits are NOT defaulted: the engine refuses to run."""
    with open(path) as f:
        j = json.load(f)
    p = j["pair"]
    spec = PairSpec(p["symbol"], p["base"], p["quote"], _d(p["tick_size"]), _d(p["qty_step"]), _d(p["min_qty"]), _d(p["max_qty"]))
    cfg = _build(PairConfig, {"symbol": p["symbol"], **j.get("pair_cfg", {})})
    g = _build(GlobalConfig, j.get("global_cfg", {}))
    c = j["costs"]
    fin = None
    if c.get("financing_rates_pct"):
        fin = FinancingModel({k: (_d(v[0]), _d(v[1])) for k, v in c["financing_rates_pct"].items()})
    ctx = CostContext(build_commission(c["commission"]), FxRates({k: _d(v) for k, v in c["fx_rates"].items()}),
                      g.base_currency, cfg.est_slippage_pct if cfg.est_slippage_pct is not None else Decimal(0), fin)
    ep = EmaTrendParams.from_mapping({k: str(v) for k, v in j.get("engine_params", {}).items()})
    s = BacktestSettings(spec=spec, cfg=cfg, gcfg=g, ctx=ctx, engine_params=ep,
                         initial_balances={k: _d(v) for k, v in j["balances"].items()},
                         fx_margin_rate_pct=None if j.get("fx_margin_rate_pct") is None else _d(j["fx_margin_rate_pct"]),
                         latency_s=_d(j.get("latency_s", "1")),
                         strategy_version=j.get("strategy_version", "bt-0"))
    return s, ParamGrid(j.get("grid", {})), j.get("split", {})


def make_plan(report: DatasetReport, split: Mapping[str, Any]) -> SplitPlan:
    kw = {k: v for k, v in split.items() if k not in ("compare_train_days", "latencies", "compare_eod_minutes")}
    return SplitPlan(report.first_ts, report.last_ts, **kw)


def run_dev_research(source: Sequence, dataset: DatasetReport, base: BacktestSettings, grid: ParamGrid, plan: SplitPlan,
                     out_dir: str, registry_path: str, min_trades_train: int = 30,
                     split_axes: Sequence[str] = ("engine.macd_mode", "pair.min_net_profit_pct", "pair.reentry_reference_reset"),
                     criteria: ReadinessCriteria = ReadinessCriteria(),
                     latencies: Sequence = DEFAULT_LATENCIES, compare_train_days: Sequence[int] = (),
                     compare_eod_minutes: Sequence[int] = DEFAULT_EOD_MINUTES) -> Dict[str, Any]:
    os.makedirs(out_dir, exist_ok=True)
    variants = grid.variants()
    sess = ResearchSession(source, plan, dataset.sha256, registry_path)
    dev_start, dev_end = plan.data_start + plan.warmup, plan.holdout_start
    sweep = sess.run_dev(base, variants, dev_start, dev_end)            # in-sample over ALL development data
    equity0 = sweep[0].result.equity0_base if sweep else Decimal(1)
    sections = [R.run_section(sweep[0].result) if sweep else "", R.sweep_section(sweep, min_trades_train),
                "_The sweep above is IN-SAMPLE (development data). Only the walk-forward sections below are out-of-sample._"]
    wf_all: Dict[str, WalkForwardResult] = {"all": walk_forward(sess, base, variants, min_trades_train, "all variants")}
    for axis in split_axes:
        if len({v.values.get(axis) for v in variants}) > 1:
            for k, w in walk_forward_by_axis(sess, base, variants, axis, min_trades_train).items():
                wf_all[f"{axis}={k}"] = w
    for k, w in wf_all.items():
        sections += [R.walk_forward_section(w, equity0), R.evidence_section(w.oos_trades, equity0, [base.spec.symbol], criteria),
                     R.pair_side_section(w.oos_trades, equity0), R.r_multiple_section(w.oos_trades, w.oos_meta), R.regime_section(w.oos_trades, w.oos_meta, equity0),
                     R.exit_section(w.oos_trades)]
    sections.insert(3, R.comparison_section("Walk-forward OUT-OF-SAMPLE comparison by mode",
                                            {k: w.oos_trades for k, w in wf_all.items()}, equity0))
    sections.insert(4, R.frequency_section(wf_all))
    lat_rows = latency_study(sess, base, dev_start, dev_end, latencies) if latencies else []
    if lat_rows:
        sections.insert(5, latency_section(lat_rows, dataset))
    eod_rows = []
    if compare_eod_minutes and base.gcfg.eod_cutoff_minutes_before_rollover is not None:
        eod_rows = eod_cutoff_study(sess, base, dev_start, dev_end, compare_eod_minutes)
        sections.insert(6, eod_section(eod_rows, base.gcfg.eod_cutoff_minutes_before_rollover))
    methods = []
    if compare_train_days:
        methods = compare_walk_forward_windows(source, dataset, base, grid, plan, registry_path, compare_train_days, min_trades_train)
        sections.insert(7, wf_methodology_section(methods, equity0))
    md = R.full_report(f"Development research - {base.spec.symbol}", [dataset], sections)
    path = os.path.join(out_dir, f"dev_report_{base.spec.symbol}.md")
    with open(path, "w") as f:
        f.write(md)
    R.export_trades_csv(os.path.join(out_dir, f"dev_oos_trades_{base.spec.symbol}.csv"),
                        wf_all["all"].oos_trades, wf_all["all"].oos_meta)
    return {"report": path, "sweep": sweep, "walk_forward": wf_all, "session": sess, "plan": plan, "variants": variants,
            "latency": lat_rows, "methods": methods, "eod": eod_rows}


def run_holdout(source: Sequence, dataset: DatasetReport, base: BacktestSettings, grid: ParamGrid, plan: SplitPlan,
                variant_name: str, out_dir: str, registry_path: str, min_trades_train: int = 30,
                criteria: ReadinessCriteria = ReadinessCriteria()) -> Dict[str, Any]:
    """The ONE holdout evaluation. The operator names the variant; evidence = dev sweep results (recomputed)."""
    os.makedirs(out_dir, exist_ok=True)
    variants = grid.variants()
    chosen = next((v for v in variants if v.name == variant_name), None)
    if chosen is None:
        raise ValueError(f"variant {variant_name!r} not in the grid")
    sess = ResearchSession(source, plan, dataset.sha256, registry_path)
    if sess.holdout_uses():
        sess.run_holdout_once(None, base)                               # raises HoldoutAlreadyUsed with details
    evidence = sess.run_dev(base, variants, plan.data_start + plan.warmup, plan.holdout_start)
    cand = sess.freeze(chosen, evidence)
    res = sess.run_holdout_once(cand, base)
    eq = res.equity0_base
    sections = [R.run_section(res), R.evidence_section(res.trades, eq, [base.spec.symbol], criteria),
                R.pair_side_section(res.trades, eq), R.r_multiple_section(res.trades, res.meta), R.regime_section(res.trades, res.meta, eq), R.exit_section(res.trades)]
    md = R.full_report(f"FINAL HOLDOUT (single look) - {base.spec.symbol} - variant {variant_name}", [dataset], sections)
    path = os.path.join(out_dir, f"holdout_report_{base.spec.symbol}.md")
    with open(path, "w") as f:
        f.write(md)
    return {"report": path, "result": res, "candidate": cand}


def load_research_data(dataset: Optional[str] = None, ticks: Optional[str] = None, bars: Optional[str] = None,
                       allow_unvalidated: bool = False, symbol: str = "EURUSD"):
    """Single entry point for research data. A downloaded dataset must have PASSED validation (dataset.json); a bare file is
    refused unless the operator explicitly accepts the risk, and then the banner says so in every report."""
    from ..data_sources.dataset import DatasetNotValidated, load_validated_dataset
    from .data import load_bars_csv, load_ticks_csv
    if dataset:
        q, rep, m = load_validated_dataset(dataset)
        return q, rep, f"validated dataset {m['dataset_id']} (CSV SHA-256 {m['normalised']['sha256'][:16]}...)"
    if not allow_unvalidated:
        raise DatasetNotValidated("refusing an unvalidated data file: use --dataset <validated dir> or pass --allow-unvalidated explicitly")
    if ticks:
        q, rep = load_ticks_csv(ticks, symbol)
    elif bars:
        q, rep = load_bars_csv(bars, symbol)
    else:
        raise DatasetNotValidated("no data source given")
    return q, rep, "UNVALIDATED DATA FILE (explicitly allowed): results are not reliable"
