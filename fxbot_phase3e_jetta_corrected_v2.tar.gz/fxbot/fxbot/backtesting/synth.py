"""Synthetic bid/ask generators. ONLY for exercising the machinery and for null/planted-edge sanity tests.
Nothing measured on synthetic data says anything about real profitability."""
from __future__ import annotations

import math
import random
from datetime import datetime, timedelta, timezone
from decimal import Decimal
from typing import Callable, List, Optional

from ..core.types import Quote

MONDAY = datetime(2026, 1, 5, 0, 0, tzinfo=timezone.utc)


def synth_ticks(days: int = 5, seed: int = 1, start: datetime = MONDAY, base: float = 1.10000,
                sigma_pct_per_min: float = 0.0116, tick_s: int = 10, spread: float = 0.00008,
                spread_jitter: float = 0.00002, drift_fn: Optional[Callable[[int], float]] = None,
                pair: str = "EURUSD", weekdays_only: bool = True) -> List[Quote]:
    """Random-walk bid/ask quotes. drift_fn(minute_index) -> drift in % per minute (planted edge); default 0 (null)."""
    rnd = random.Random(seed)
    px, out = base, []
    steps_per_day = 86400 // tick_s
    sd = sigma_pct_per_min / 100 * math.sqrt(tick_s / 60)
    day, produced, minute = start, 0, 0.0
    while produced < days:
        if weekdays_only and day.weekday() >= 5:
            day += timedelta(days=1)
            continue
        for i in range(steps_per_day):
            drift = (drift_fn(int(minute)) if drift_fn else 0.0) / 100 * (tick_s / 60)
            px *= 1 + rnd.gauss(drift, sd)
            half = max(spread + rnd.uniform(-spread_jitter, spread_jitter), 0.00002) / 2
            bid, ask = Decimal(f"{px - half:.5f}"), Decimal(f"{px + half:.5f}")
            if bid >= ask:
                ask = bid + Decimal("0.00001")
            t = day + timedelta(seconds=i * tick_s)
            out.append(Quote(pair, bid, ask, t, t))
            minute += tick_s / 60
        produced += 1
        day += timedelta(days=1)
    return out


def trending_regime(period_min: int = 240, drift_pct_per_min: float = 0.004, seed: int = 0) -> Callable[[int], float]:
    """Alternating up/down trend segments (planted edge for a trend follower)."""
    rnd = random.Random(seed)
    cache = {}

    def f(minute: int) -> float:
        seg = int(minute // period_min)
        if seg not in cache:
            cache[seg] = rnd.choice([-1, 1]) * drift_pct_per_min
        return cache[seg]
    return f
