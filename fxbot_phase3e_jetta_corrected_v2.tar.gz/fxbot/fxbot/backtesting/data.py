"""Historical bid/ask data ingestion for backtests.

Supported inputs (never silently downgraded to mid/last prices):
  TICK              CSV  ts,bid,ask                      (e.g. IBKR reqHistoricalTicks BID_ASK)  -> best resolution
  BAR_BID_ASK_OHLC  CSV  ts,bid_open,bid_high,bid_low,bid_close,ask_open,ask_high,ask_low,ask_close  (1m bars; IBKR
                    BID and ASK bar series downloaded separately and merged, see merge_bid_ask_csv)
A dataset report states resolution, gaps, dropped records and what the resolution CANNOT support. Bar data cannot
reproduce intrabar ordering, so stop/trailing execution on bars is approximate and must be validated with ticks.
"""
from __future__ import annotations

import csv
import hashlib
import statistics
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from decimal import Decimal, InvalidOperation
from typing import Iterable, List, Optional, Sequence, Tuple

from ..core.sessions import SessionCalendar
from ..core.types import FxBotError, Quote, Side


class DataError(FxBotError):
    pass


@dataclass(frozen=True)
class BidAskBar:
    start_ts: datetime
    end_ts: datetime
    bid_open: Decimal; bid_high: Decimal; bid_low: Decimal; bid_close: Decimal
    ask_open: Decimal; ask_high: Decimal; ask_low: Decimal; ask_close: Decimal
    ticks: int = 0


@dataclass(frozen=True)
class TickFormat:
    """Explicit column mapping BY NAME (never by position) and timestamp unit. unit: auto|iso|s|ms|us|ns."""
    name: str
    ts_col: str
    bid_col: str
    ask_col: str
    ts_unit: str = "auto"
    extra_cols: Tuple[str, ...] = ()


CANONICAL = TickFormat("canonical", "ts", "bid", "ask")
# Dukascopy published CSV: epoch MILLISECONDS (UTC); NOTE the column order is ask BEFORE bid; volumes in millions of units.
DUKASCOPY = TickFormat("dukascopy_csv", "timestamp", "bidPrice", "askPrice", "ms", ("askVolume", "bidVolume"))
# What our own IBKR tick downloader will write (reqHistoricalTicks BID_ASK). PROVISIONAL until validated on a real IBKR sample.
IBKR_PROVISIONAL = TickFormat("ibkr_ticks_provisional", "ts", "bid", "ask", "auto", ("bid_size", "ask_size"))
FORMATS = {f.name: f for f in (CANONICAL, DUKASCOPY, IBKR_PROVISIONAL)}


def detect_format(header: Sequence[str]) -> TickFormat:
    h = set(header)
    for f in (CANONICAL, DUKASCOPY):
        if {f.ts_col, f.bid_col, f.ask_col} <= h:
            return f
    raise DataError(f"unrecognised tick columns {list(header)}; pass an explicit TickFormat (mid/last-only data is not accepted)")


@dataclass(frozen=True)
class DatasetReport:
    pair: str
    resolution: str                    # TICK | BAR_BID_ASK_OHLC
    n_records: int
    first_ts: Optional[datetime]
    last_ts: Optional[datetime]
    mean_spread_pct: Optional[float]
    median_spread_pct: Optional[float]
    max_spread_pct: Optional[float]
    dropped_crossed_or_invalid: int
    dropped_duplicate: int
    dropped_out_of_order: int
    gaps: Tuple[Tuple[datetime, datetime], ...]          # unexpected gaps > gap_threshold_s (not weekend closures)
    closures: Tuple[Tuple[datetime, datetime], ...]      # gaps lying (>=90%) inside the Fri 17:00 - Sun 17:00 New York closure
    gap_threshold_s: int
    sha256: str
    limitations: Tuple[str, ...]
    format_name: str = ""
    ts_unit: str = ""
    ts_resolution: str = ""                              # "sub-second" | "1 second"
    max_ticks_per_timestamp: int = 0
    interarrival_s: Tuple[float, ...] = ()               # (median, p95, p99, max) seconds between consecutive quotes
    n_gaps_over: Tuple[Tuple[int, int], ...] = ()        # ((10, n), (30, n), (60, n)) inter-arrival counts
    unchanged_quotes: int = 0                            # consecutive quotes with identical bid/ask but a newer timestamp
    quotes_in_closure: int = 0                           # quotes stamped inside the weekly closure (should be ~0)
    crossed_fraction: float = 0.0
    price_decimals: Tuple[int, ...] = ()
    sessions: Tuple[Tuple[object, int, datetime, datetime], ...] = ()   # (label, n, first, last)

    def summary_lines(self) -> List[str]:
        return [f"{self.pair} | {self.resolution} | {self.n_records} records | "
                f"{self.first_ts} .. {self.last_ts} | sha256 {self.sha256[:16]}",
                f"mean spread {self.mean_spread_pct:.5f}% median {self.median_spread_pct:.5f}% max {self.max_spread_pct:.5f}%"
                if self.mean_spread_pct is not None else "no spread statistics",
                f"dropped: {self.dropped_crossed_or_invalid} crossed/invalid, {self.dropped_duplicate} duplicate, "
                f"{self.dropped_out_of_order} out-of-order; unexpected gaps {len(self.gaps)}, weekend closures {len(self.closures)}"] \
               + [f"LIMITATION: {x}" for x in self.limitations]


_TICK_LIMITS = ("Tick data: stop/trailing fills are simulated at the first quote after the trigger plus latency; "
                "quote timestamps have the source's granularity (IBKR ticks are not guaranteed to be every quote).",
                "Financing/rollover is not modelled unless rates are supplied; positions are flat before the EOD cutoff.",
                "No economic calendar is connected: the backtest has NO news protection.")
_BAR_LIMITS = ("BAR resolution: the order of the bid/ask extremes inside a bar is unknown. Paths assume "
               "adverse-first (or favourable-first when stress-testing); stop and trailing execution is therefore "
               "APPROXIMATE and results are not a reliable estimate of live execution. Validate with tick data.",
               "Bar spreads at the extremes are assumed equal to the spread at the bar open.") + _TICK_LIMITS[1:]

_EPOCH = datetime(1970, 1, 1, tzinfo=timezone.utc)
_UNIT_US = {"s": Decimal(1_000_000), "ms": Decimal(1_000), "us": Decimal(1), "ns": Decimal("0.001")}


def infer_epoch_unit(value: Decimal) -> str:
    v = abs(value)
    return "s" if v < Decimal(10) ** 11 else "ms" if v < Decimal(10) ** 14 else "us" if v < Decimal(10) ** 17 else "ns"


def parse_epoch(raw: str, unit: str = "auto") -> Tuple[datetime, str]:
    """Exact epoch parsing with Decimal/integer arithmetic (no float rounding). Returns (UTC datetime, unit used).
    The result must fall in 2000-2100, otherwise the unit is wrong and we refuse rather than guess."""
    try:
        v = Decimal(raw.strip())
    except InvalidOperation as e:
        raise DataError(f"bad timestamp {raw!r}") from e
    u = infer_epoch_unit(v) if unit == "auto" else unit
    if u not in _UNIT_US:
        raise DataError(f"unknown timestamp unit {unit!r}")
    micros = int((v * _UNIT_US[u]).to_integral_value(rounding="ROUND_FLOOR"))
    try:
        d = _EPOCH + timedelta(microseconds=micros)
    except OverflowError as e:
        raise DataError(f"timestamp {raw!r} out of range for unit {u}") from e
    if not (2000 <= d.year <= 2100):
        raise DataError(f"timestamp {raw!r} read as {u} gives year {d.year}: wrong unit?")
    return d, u


def parse_ts(s: str, unit: str = "auto") -> datetime:
    s = s.strip()
    if s.replace(".", "", 1).lstrip("-").isdigit():
        return parse_epoch(s, "auto" if unit in ("auto", "iso") else unit)[0]
    try:
        d = datetime.fromisoformat(s.replace("Z", "+00:00"))
    except ValueError as e:
        raise DataError(f"bad timestamp {s!r}") from e
    if d.tzinfo is None:
        raise DataError(f"timestamp without timezone: {s!r} (must be UTC)")
    return d.astimezone(timezone.utc)


def _dec(x: str) -> Decimal:
    try:
        return Decimal(x.strip())
    except InvalidOperation as e:
        raise DataError(f"bad number {x!r}") from e


def classify_gap(a: datetime, b: datetime, cal: SessionCalendar) -> str:
    """'weekend_closure' if >= 90% of the gap lies inside the Fri 17:00 - Sun 17:00 New York closure;
    'rollover_gap' if it spans a 17:00 New York boundary on a trading day; else 'intra_session_gap'."""
    n = max(int((b - a).total_seconds() // 3600), 1)
    step = (b - a) / (n + 1)
    pts = [a + step * (i + 1) for i in range(min(n, 200))]
    if pts and sum(cal.closure_contains(p) for p in pts) / len(pts) >= 0.9 and (b - a) >= timedelta(hours=24):
        return "weekend_closure"
    sa, sb = cal.session_of(a), cal.session_of(b)
    return "rollover_gap" if sa.label != sb.label else "intra_session_gap"


def _gaps(times: Sequence[datetime], threshold_s: int, cal: Optional[SessionCalendar] = None):
    cal = cal or SessionCalendar()
    gaps, closures = [], []
    for a, b in zip(times, times[1:]):
        if (b - a).total_seconds() > threshold_s:
            (closures if classify_gap(a, b, cal) == "weekend_closure" else gaps).append((a, b))
    return tuple(gaps), tuple(closures)


def _hash(lines: Iterable[str]) -> str:
    h = hashlib.sha256()
    for ln in lines:
        h.update(ln.encode()); h.update(b"\n")
    return h.hexdigest()


def load_ticks_csv(path: str, pair: str, gap_threshold_s: int = 120, fmt: Optional[TickFormat] = None
                   ) -> Tuple[List[Quote], DatasetReport]:
    quotes: List[Quote] = []
    crossed = dup = ooo = total = 0
    last = None
    unit_used = ""
    with open(path, newline="") as f:
        rd = csv.DictReader(f)
        fmt = fmt or detect_format(rd.fieldnames or [])
        for need in (fmt.ts_col, fmt.bid_col, fmt.ask_col):
            if need not in (rd.fieldnames or []):
                raise DataError(f"missing column {need!r} for format {fmt.name}; have {rd.fieldnames}. "
                                "Full bid AND ask quotes are required - mid/last-only data is not accepted")
        for row in rd:
            total += 1
            ts, u = (parse_epoch(row[fmt.ts_col], fmt.ts_unit) if fmt.ts_unit not in ("iso",) and row[fmt.ts_col].strip().replace(".", "", 1).isdigit()
                     else (parse_ts(row[fmt.ts_col]), "iso"))
            unit_used = unit_used or u
            bid, ask = _dec(row[fmt.bid_col]), _dec(row[fmt.ask_col])
            if bid <= 0 or ask <= 0 or bid > ask:
                crossed += 1; continue
            if last is not None:
                if ts < last[0]:
                    ooo += 1; continue
                if (ts, bid, ask) == last:
                    dup += 1; continue
            last = (ts, bid, ask)
            quotes.append(Quote(pair, bid, ask, ts, ts))
    if total and crossed / total >= 0.5:
        raise DataError(f"{crossed} of {total} rows have bid > ask (or non-positive prices): the BID and ASK columns are "
                        f"probably mapped the wrong way round (format {fmt.name}: bid={fmt.bid_col}, ask={fmt.ask_col})")
    return quotes, quote_report(quotes, pair, crossed, dup, ooo, gap_threshold_s, fmt_name=fmt.name, ts_unit=unit_used,
                                total_rows=total)


def _pct(xs: Sequence[float], q: float) -> float:
    xs = sorted(xs)
    return xs[min(int(q * (len(xs) - 1) + 0.5), len(xs) - 1)]


def quote_report(quotes: Sequence[Quote], pair: str, crossed=0, dup=0, ooo=0, gap_threshold_s=120, fmt_name: str = "",
                 ts_unit: str = "", total_rows: Optional[int] = None, calendar: Optional[SessionCalendar] = None) -> DatasetReport:
    cal = calendar or SessionCalendar()
    sp = [float(q.spread / q.mid * 100) for q in quotes]
    times = [q.market_ts for q in quotes]
    gaps, closures = _gaps(times, gap_threshold_s, cal)
    dts = [(b - a).total_seconds() for a, b in zip(times, times[1:])]
    # exclude closures from inter-arrival statistics so they describe live-market behaviour
    clos = {(a, b) for a, b in closures}
    live = [d for (a, b), d in zip(zip(times, times[1:]), dts) if (a, b) not in clos]
    same_ts: dict = {}
    for t in times:
        same_ts[t] = same_ts.get(t, 0) + 1
    sub = any(t.microsecond for t in times)
    per_session: dict = {}
    for q in quotes:
        lab = cal.session_of(q.market_ts).label
        e = per_session.get(lab)
        per_session[lab] = (1, q.market_ts, q.market_ts) if e is None else (e[0] + 1, e[1], q.market_ts)
    decs = sorted({max(-q.bid.as_tuple().exponent, 0) for q in quotes} | {max(-q.ask.as_tuple().exponent, 0) for q in quotes})
    return DatasetReport(
        pair, "TICK", len(quotes), quotes[0].market_ts if quotes else None, quotes[-1].market_ts if quotes else None,
        statistics.fmean(sp) if sp else None, statistics.median(sp) if sp else None, max(sp) if sp else None,
        crossed, dup, ooo, gaps, closures, gap_threshold_s,
        _hash(f"{q.market_ts.isoformat()},{q.bid},{q.ask}" for q in quotes), _TICK_LIMITS,
        format_name=fmt_name, ts_unit=ts_unit, ts_resolution="sub-second" if sub else "1 second",
        max_ticks_per_timestamp=max(same_ts.values()) if same_ts else 0,
        interarrival_s=(statistics.median(live), _pct(live, 0.95), _pct(live, 0.99), max(live)) if live else (),
        n_gaps_over=tuple((k, sum(1 for d in live if d > k)) for k in (10, 30, 60)),
        unchanged_quotes=sum(1 for a, b in zip(quotes, quotes[1:]) if (a.bid, a.ask) == (b.bid, b.ask)),
        quotes_in_closure=sum(1 for q in quotes if cal.closure_contains(q.market_ts)),
        crossed_fraction=(crossed / total_rows) if total_rows else 0.0, price_decimals=tuple(decs),
        sessions=tuple((k, v[0], v[1], v[2]) for k, v in sorted(per_session.items())))


_BAR_COLS = ["bid_open", "bid_high", "bid_low", "bid_close", "ask_open", "ask_high", "ask_low", "ask_close"]


def load_bars_csv(path: str, pair: str, tf_s: int = 60, gap_threshold_s: int = 300
                  ) -> Tuple[List[BidAskBar], DatasetReport]:
    bars: List[BidAskBar] = []
    bad = dup = ooo = 0
    last_ts = None
    with open(path, newline="") as f:
        for row in csv.DictReader(f):
            try:
                ts = parse_ts(row["ts"])
                v = [_dec(row[c]) for c in _BAR_COLS]
            except KeyError as e:
                raise DataError(f"missing column {e}; full bid AND ask OHLC is required (no mid substitution)") from e
            bo, bh, bl, bc, ao, ah, al, ac = v
            ok = (all(x > 0 for x in v) and bl <= min(bo, bc) and bh >= max(bo, bc) and al <= min(ao, ac)
                  and ah >= max(ao, ac) and bo <= ao and bc <= ac and bl <= al and bh <= ah)
            if not ok:
                bad += 1; continue
            if last_ts is not None:
                if ts < last_ts:
                    ooo += 1; continue
                if ts == last_ts:
                    dup += 1; continue
            last_ts = ts
            bars.append(BidAskBar(ts, ts + timedelta(seconds=tf_s), bo, bh, bl, bc, ao, ah, al, ac,
                                  int(row["ticks"]) if row.get("ticks") else 0))
    return bars, bar_report(bars, pair, bad, dup, ooo, gap_threshold_s)


def bar_report(bars: Sequence[BidAskBar], pair: str, bad=0, dup=0, ooo=0, gap_threshold_s=300) -> DatasetReport:
    sp = [float((b.ask_close - b.bid_close) / ((b.ask_close + b.bid_close) / 2) * 100) for b in bars]
    gaps, closures = _gaps([b.start_ts for b in bars], gap_threshold_s)
    return DatasetReport(pair, "BAR_BID_ASK_OHLC", len(bars), bars[0].start_ts if bars else None,
                         bars[-1].end_ts if bars else None, statistics.fmean(sp) if sp else None,
                         statistics.median(sp) if sp else None, max(sp) if sp else None, bad, dup, ooo, gaps,
                         closures, gap_threshold_s,
                         _hash(f"{b.start_ts.isoformat()},{b.bid_open},{b.bid_high},{b.bid_low},{b.bid_close},"
                               f"{b.ask_open},{b.ask_high},{b.ask_low},{b.ask_close}" for b in bars), _BAR_LIMITS)


def merge_bid_ask_csv(bid_path: str, ask_path: str, out_path: str) -> Tuple[int, int, int]:
    """Merge separately downloaded BID and ASK bar files (columns ts,open,high,low,close) into the canonical
    9-column format. Returns (written, only_in_bid, only_in_ask). Unmatched bars are dropped, never filled."""
    def read(p):
        with open(p, newline="") as f:
            return {parse_ts(r["ts"]): r for r in csv.DictReader(f)}
    b, a = read(bid_path), read(ask_path)
    common = sorted(set(b) & set(a))
    with open(out_path, "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["ts"] + _BAR_COLS)
        for ts in common:
            rb, ra = b[ts], a[ts]
            w.writerow([ts.isoformat()] + [rb[k] for k in ("open", "high", "low", "close")]
                       + [ra[k] for k in ("open", "high", "low", "close")])
    return len(common), len(set(b) - set(a)), len(set(a) - set(b))


def expand_bar(bar: BidAskBar, pair: str, adverse: Optional[Side], path: str = "adverse_first") -> List[Quote]:
    """Executable quote path for one bar. Points: open, the four extremes, close. For an open LONG the adverse
    extreme is the lowest BID, for an open SHORT the highest ASK. path='adverse_first' visits the adverse extreme
    first (pessimistic for stops); 'favourable_first' reverses it (stress test). Intrabar order is NOT knowable."""
    s = max(bar.ask_open - bar.bid_open, Decimal(0))
    A = (bar.bid_low, bar.bid_low + s)             # lowest bid
    B = (bar.bid_high, bar.bid_high + s)           # highest bid
    C = (bar.ask_low - s, bar.ask_low)             # lowest ask
    D = (bar.ask_high - s, bar.ask_high)           # highest ask
    if adverse is Side.SHORT:
        mid_pts = [D, C, A, B]
    else:                                          # LONG or flat
        mid_pts = [A, B, C, D]
    if path == "favourable_first":
        mid_pts = mid_pts[1:2] + mid_pts[0:1] + mid_pts[3:4] + mid_pts[2:3]
    pts = [(bar.bid_open, bar.ask_open)] + mid_pts + [(bar.bid_close, bar.ask_close)]
    span = max((bar.end_ts - bar.start_ts).total_seconds() - 1, 0)
    out = []
    for i, (bid, ask) in enumerate(pts):
        t = bar.start_ts + timedelta(seconds=span * i / (len(pts) - 1))
        bid, ask = (bid, ask) if bid <= ask else (ask, bid)
        out.append(Quote(pair, bid, ask, t, t))
    return out
