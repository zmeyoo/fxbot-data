"""Parameter sweeps. Axes are named "pair.<PairConfig field>", "engine.<EmaTrendParams field>", "global.<GlobalConfig field>" or
"bt.<BacktestSettings field>"; the special axis "pair.min_net_profit_pct" (None => profit-taking OFF, i.e.
trailing-only; a number => profit-taking ON with that % of notional as the minimum net profit).
Selection prefers ROBUST regions: a variant's score is the mean expectancy of itself and its grid neighbours."""
from __future__ import annotations

import itertools
import math
from dataclasses import dataclass, replace
from datetime import datetime, timedelta
from decimal import Decimal
from typing import Any, Callable, Dict, List, Mapping, Optional, Sequence

from ..config.schema import MinNetProfit, MinNetProfitMode
from ..core.types import FxBotError
from ..reporting.metrics import summarise
from .data import BidAskBar
from .engine import BacktestResult, BacktestSettings, run_backtest


@dataclass(frozen=True)
class Variant:
    name: str
    coords: Mapping[str, int]
    values: Mapping[str, Any]

    def get(self, axis: str, default=None):
        return self.values.get(axis, default)


@dataclass(frozen=True)
class ParamGrid:
    axes: Mapping[str, Sequence[Any]]

    def variants(self) -> List[Variant]:
        keys = list(self.axes)
        out = []
        for combo in itertools.product(*(list(enumerate(self.axes[k])) for k in keys)):
            coords = {k: i for k, (i, _) in zip(keys, combo)}
            vals = {k: v for k, (_, v) in zip(keys, combo)}
            out.append(Variant("|".join(f"{k.split('.', 1)[1]}={vals[k]}" for k in keys) or "base", coords, vals))
        return out


def _coerce_like(current: Any, v: Any) -> Any:
    if v is None or isinstance(v, (bool, str)) and not isinstance(current, Decimal):
        return v
    if isinstance(current, Decimal) or current is None:
        return Decimal(str(v))
    return type(current)(v)


def apply_variant(base: BacktestSettings, v: Variant) -> BacktestSettings:
    pair_kw, eng_kw, bt_kw, g_kw = {}, {}, {}, {}
    cfg, params = base.cfg, base.engine_params
    for axis, val in v.values.items():
        scope, field_ = axis.split(".", 1)
        if axis == "pair.min_net_profit_pct":
            if val is None:
                pair_kw["profit_taking_enabled"], pair_kw["min_net_profit"] = False, None
            else:
                pair_kw["profit_taking_enabled"] = True
                pair_kw["min_net_profit"] = MinNetProfit(MinNetProfitMode.PCT_NOTIONAL, Decimal(str(val)))
        elif scope == "pair":
            if not hasattr(cfg, field_):
                raise FxBotError(f"unknown pair parameter {field_}")
            pair_kw[field_] = _coerce_like(getattr(cfg, field_), val)
        elif scope == "engine":
            if not hasattr(params, field_):
                raise FxBotError(f"unknown engine parameter {field_}")
            eng_kw[field_] = val
        elif scope == "global":
            if not hasattr(base.gcfg, field_):
                raise FxBotError(f"unknown global parameter {field_}")
            cur = getattr(base.gcfg, field_)
            g_kw[field_] = val if isinstance(val, (bool, str)) or val is None else (
                int(val) if isinstance(val, int) or isinstance(cur, int) else Decimal(str(val)))
        elif scope == "bt":
            if not hasattr(base, field_):
                raise FxBotError(f"unknown backtest setting {field_}")
            bt_kw[field_] = _coerce_like(getattr(base, field_), val)
        else:
            raise FxBotError(f"bad axis {axis!r}")
    return replace(base, cfg=replace(cfg, **pair_kw), engine_params=replace(params, **eng_kw),
                   gcfg=replace(base.gcfg, **g_kw) if g_kw else base.gcfg, **bt_kw)


@dataclass
class VariantResult:
    variant: Variant
    result: BacktestResult

    @property
    def summary(self):
        return summarise(self.result.trades, self.result.equity0_base)


def slice_source(source: Sequence, start: datetime, end: datetime) -> List:
    """Records with start <= ts < end. Uses binary search with a key function: only O(log n) timestamps are read, and
    records outside the window are never copied or inspected."""
    import bisect
    key = (lambda r: r.start_ts) if source and isinstance(source[0], BidAskBar) else (lambda r: r.market_ts)
    lo = bisect.bisect_left(source, start, key=key)
    hi = bisect.bisect_left(source, end, lo=lo, key=key)
    return list(source[lo:hi])


def run_variants(source: Sequence, base: BacktestSettings, variants: Sequence[Variant], trade_from: datetime,
                 trade_until: datetime, warmup: timedelta) -> List[VariantResult]:
    data = slice_source(source, trade_from - warmup, trade_until)
    out = []
    for v in variants:
        s = replace(apply_variant(base, v), trade_from=trade_from, trade_until=trade_until)
        out.append(VariantResult(v, run_backtest(data, s)))
    return out


def _neighbours(v: Variant, all_v: Sequence[Variant]) -> List[Variant]:
    out = []
    for o in all_v:
        diff = [k for k in v.coords if v.coords[k] != o.coords[k]]
        if len(diff) == 1 and abs(v.coords[diff[0]] - o.coords[diff[0]]) == 1:
            out.append(o)
    return out


def robust_scores(results: Sequence[VariantResult], min_trades: int,
                  metric: Optional[Callable[[VariantResult], Optional[float]]] = None) -> Dict[str, Optional[float]]:
    """score = mean(metric(self), metric(neighbours with enough trades)); None if the variant itself has too few trades."""
    def m(r: VariantResult) -> Optional[float]:
        if r.summary.n < min_trades:
            return None
        x = metric(r) if metric else (None if r.summary.expectancy_base is None else float(r.summary.expectancy_base))
        return x
    own = {r.variant.name: m(r) for r in results}
    by_name = {r.variant.name: r for r in results}
    allv = [r.variant for r in results]
    scores: Dict[str, Optional[float]] = {}
    for r in results:
        if own[r.variant.name] is None:
            scores[r.variant.name] = None
            continue
        vals = [own[r.variant.name]] + [own[n.name] for n in _neighbours(r.variant, allv) if own[n.name] is not None]
        scores[r.variant.name] = sum(vals) / len(vals)
    return scores


def select_best(results: Sequence[VariantResult], min_trades: int) -> Optional[VariantResult]:
    sc = robust_scores(results, min_trades)
    ok = [(s, r.variant.name, r) for r in results for s in [sc[r.variant.name]] if s is not None]
    if not ok:
        return None
    ok.sort(key=lambda t: (-t[0], t[1]))
    return ok[0][2]
