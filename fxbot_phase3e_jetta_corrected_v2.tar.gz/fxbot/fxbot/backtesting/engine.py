"""Event-driven backtester over bid/ask quotes. It drives the SAME pure core as live trading:
bars (closed only) -> ema_trend engine -> PairStrategy gate -> evaluate_entry (data, news, sizing, cost, funding,
exposure, risk) -> Position state machine -> evaluate_exit. Only the broker is simulated.

Realism rules
* Decisions use CLOSED bars: a bar is closed by the first quote of the next bucket and the decision is taken as of
  the bar end time, using the LAST quote before it. The closing quote's price is never used for the decision.
* Orders fill at the first quote with market_ts >= order time + latency, on the executable side
  (BUY at ask, SELL at bid) plus slippage, rounded to the tick in the adverse direction. Stops are software
  stops evaluated on every quote and filled the same way, so gaps fill at the gapped price.
* Commission from the configured (unverified-flagged) schedule. Financing is only counted if rates are supplied.
* No economic calendar unless a provider is passed. The result reports it.
Limitations are returned in BacktestResult.notes.
"""
from __future__ import annotations

import hashlib
import json
import re
from collections import Counter, deque
from dataclasses import dataclass, field, fields
from datetime import datetime, timedelta, timezone
from decimal import ROUND_CEILING, ROUND_FLOOR, Decimal
from typing import Any, Deque, Dict, List, Mapping, Optional, Sequence, Union

from ..config.schema import GlobalConfig, PairConfig
from ..core.sessions import Session, SessionCalendar
from ..core.types import HUNDRED, ZERO, FxBotError, Quote, Side
from ..costs.model import CostContext
from ..instruments.spec import PairSpec
from ..market_data.bars import Bar, BarAggregator, BarBuilder
from ..position_manager.exits import ExitPolicy, evaluate_exit
from ..position_manager.pnl import estimate_open_pnl
from ..position_manager.position import ExitReason, Fill, Position, PositionState as PS, StopParams, TradeRecord
from ..risk.currency import CurrencyLedger, action_for, balance_effect
from ..risk.governor import RiskGovernor
from ..signals.ema_trend import EmaTrendEngine, EmaTrendParams, SignalInputs
from ..signals.news import NewsProvider, NullNewsProvider
from ..strategy.entry import evaluate_entry
from ..strategy.pair_state import PairStrategy
from .data import BidAskBar, expand_bar


class BacktestConfigError(FxBotError):
    pass


@dataclass(frozen=True)
class BacktestSettings:
    spec: PairSpec
    cfg: PairConfig
    gcfg: GlobalConfig
    ctx: CostContext
    engine_params: EmaTrendParams
    initial_balances: Mapping[str, Decimal]                # own cash per currency (LONGs need QUOTE-currency cash)
    equity0_base: Optional[Decimal] = None                 # default: balances converted to base
    fx_margin_rate_pct: Optional[Decimal] = None           # needed for SHORTs (margin what-if); None => shorts rejected
    latency_s: Decimal = Decimal("1")                      # decision/trigger -> fill delay (sweep it)
    trade_from: Optional[datetime] = None                  # entries only inside [trade_from, trade_until)
    trade_until: Optional[datetime] = None
    realised_slippage_multiplier: Decimal = Decimal("1")   # stress: realised vs the estimate used by the gate
    realised_commission_multiplier: Decimal = Decimal("1")
    bar_path: str = "adverse_first"                        # only for bar data
    news: Any = field(default_factory=NullNewsProvider)
    strategy_version: str = "bt-0"
    window_1m: int = 120
    window_5m: int = 600
    window_15m: int = 400

    def validate(self) -> None:
        miss = self.cfg.blockers() + self.gcfg.blockers()
        if self.gcfg.eod_cutoff_minutes_before_rollover is None and self.gcfg.eod_cutoff_utc is None:
            miss.append("eod_cutoff_minutes_before_rollover not configured")
        if miss:
            raise BacktestConfigError("backtest refuses to run with unset limits: " + "; ".join(sorted(set(miss))))
        need = EmaTrendEngine(self.engine_params).min_history()
        if self.window_15m < need["15m"] or self.window_5m < need["5m"] or self.window_1m < need["1m"] + 30:
            raise BacktestConfigError(f"indicator windows too small for the engine: need {need}")

    def fingerprint(self) -> str:
        def ser(o):
            if hasattr(o, "__dataclass_fields__"):
                return {f.name: ser(getattr(o, f.name)) for f in fields(o)}
            if isinstance(o, Mapping):
                return {str(k): ser(v) for k, v in sorted(o.items())}
            if isinstance(o, FxRatesLike):
                return {k: str(v) for k, v in sorted(o._m.items())}
            return str(o)
        parts = {f.name: ser(getattr(self, f.name)) for f in fields(self) if f.name not in ("trade_from", "trade_until", "news")}
        parts["news"] = type(self.news).__name__
        return hashlib.sha256(json.dumps(parts, sort_keys=True, default=str).encode()).hexdigest()


from ..core.money import FxRates as FxRatesLike  # noqa: E402  (isinstance helper for fingerprinting)


@dataclass
class BacktestResult:
    pair: str
    trades: List[TradeRecord]
    meta: Dict[str, Dict[str, Any]]
    equity0_base: Decimal
    settings_fp: str
    trade_from: Optional[datetime]
    trade_until: Optional[datetime]
    n_quotes: int
    counters: Dict[str, int]
    rejections: Dict[str, int]
    blocked: Dict[str, int]
    notes: List[str]
    first_ts: Optional[datetime] = None
    last_ts: Optional[datetime] = None
    settings: Optional[BacktestSettings] = None


def cutoff_for(g: GlobalConfig, sess: Session) -> datetime:
    """End-of-session flatten time. Preferred: N minutes before the 17:00 New York rollover (DST-correct). Legacy
    `eod_cutoff_utc` (HH:MM UTC) is supported but drifts with DST: first such instant after the session start."""
    if g.eod_cutoff_minutes_before_rollover is not None:
        return sess.end_utc - timedelta(minutes=g.eod_cutoff_minutes_before_rollover)
    h, m = g.eod_cutoff_utc.split(":")
    cand = datetime(sess.start_utc.year, sess.start_utc.month, sess.start_utc.day, int(h), int(m), tzinfo=timezone.utc)
    while cand <= sess.start_utc:
        cand += timedelta(days=1)
    return min(cand, sess.end_utc)


def _round_tick(px: Decimal, tick: Decimal, up: bool) -> Decimal:
    return (px / tick).to_integral_value(rounding=ROUND_CEILING if up else ROUND_FLOOR) * tick


_norm = re.compile(r"[-+]?\d+(\.\d+)?")


class _Run:
    def __init__(self, s: BacktestSettings):
        s.validate()
        self.s, self.spec, self.cfg, self.g, self.ctx = s, s.spec, s.cfg, s.gcfg, s.ctx
        self.base = self.g.base_currency
        self.fp = s.fingerprint()
        bal = {k: Decimal(v) for k, v in s.initial_balances.items()}
        self.ledger = CurrencyLedger(dict(bal))
        self.equity0 = s.equity0_base if s.equity0_base is not None else sum(
            (self.ctx.rates.convert(v, k, self.base) for k, v in bal.items()), ZERO)
        if self.equity0 <= 0:
            raise BacktestConfigError("starting equity must be > 0")
        self.engine = EmaTrendEngine(s.engine_params, memoize=True)
        self.strategy = PairStrategy(s.cfg)
        self.gov = RiskGovernor(s.gcfg)
        self.bb1, self.agg5, self.agg15 = BarBuilder(60), BarAggregator(300), BarAggregator(900)
        self.w1: Deque[Bar] = deque(maxlen=s.window_1m)
        self.w5: Deque[Bar] = deque(maxlen=s.window_5m)
        self.w15: Deque[Bar] = deque(maxlen=s.window_15m)
        self.calendar = SessionCalendar(s.gcfg.session_timezone, s.gcfg.session_start_local)
        self.sid: Optional[int] = None
        self.cutoff_dt: Optional[datetime] = None
        self.last_q: Optional[Quote] = None
        self.pos: Optional[Position] = None
        self.pending_entry: Optional[dict] = None
        self.pending_exit: Optional[dict] = None
        self.realised_base = ZERO
        self.trades: List[TradeRecord] = []
        self.meta: Dict[str, Dict[str, Any]] = {}
        self.cnt: Counter = Counter()
        self.rej: Counter = Counter()
        self.blocked: Counter = Counter()
        self.seq = 0
        self.cur_est_exit = None
        self.max_age = s.gcfg.market_data_max_age_seconds
        self.lat = timedelta(seconds=float(s.latency_s))

    # ---------------------------------------------------------------- helpers
    def equity_now(self) -> Decimal:
        eq = self.equity0 + self.realised_base
        if self.pos is not None and self.pos.open_qty > 0 and self.last_q is not None and self.pos.entry_mid is not None:
            eq += estimate_open_pnl(self.pos, self.last_q, self.ctx).expected_net_pnl_base
        return eq

    def adverse_side(self) -> Optional[Side]:
        return self.pos.side if self.pos is not None and self.pos.is_open else None

    def entries_allowed(self, now: datetime) -> bool:
        s = self.s
        return ((s.trade_from is None or now >= s.trade_from) and (s.trade_until is None or now < s.trade_until)
                and self.cutoff_dt is not None and now < self.cutoff_dt)

    # ------------------------------------------------------------------ main
    def process(self, q: Quote) -> bool:
        """Returns False when the run is finished (trade_until passed and everything is flat)."""
        now = q.market_ts
        self.cnt["quotes"] += 1
        self._session(q)
        s = self.s
        if s.trade_until is not None and now >= s.trade_until and self.pos is None and self.pending_entry is None:
            return False
        closed = self.bb1.on_quote(q)
        if closed is not None:
            self._on_bar(closed)
        self._pending(q)
        self._manage_position(q)
        self.strategy.on_quote(q, now, self.max_age)
        self.last_q = q
        return True

    def _session(self, q: Quote) -> None:
        sess = self.calendar.session_of(q.market_ts)
        sid, cutoff = sess.label, cutoff_for(self.g, sess)
        if self.sid != sid:
            if self.pos is not None and self.pos.is_open and self.pending_exit is None and self.pos.state is not PS.PENDING_EXIT:
                self._request_exit(ExitReason.END_OF_DAY, q.market_ts, "session roll with open position")
            first = self.sid is None
            self.sid, self.cutoff_dt = sid, cutoff
            self.gov.start_session(self.equity_now())
            if self.strategy.state.value == "IDLE":
                self.strategy.start(q.market_ts)
            elif self.strategy.state.value not in ("ENTRY_PENDING", "POSITION_OPEN"):
                self.strategy.new_session(q.market_ts)
            if not first:
                self.cnt["sessions"] += 1

    # ------------------------------------------------------------- bar logic
    def _on_bar(self, bar: Bar) -> None:
        self.cnt["bars"] += 1
        self.w1.append(bar)
        for b5 in self.agg5.on_bar(bar):
            self.w5.append(b5)
        for b15 in self.agg15.on_bar(bar):
            self.w15.append(b15)
        as_of = bar.end_ts
        self.gov.update_equity(self.equity_now())
        if self.pos is not None or self.pending_entry is not None:
            return
        if not self.entries_allowed(as_of) or self.last_q is None:
            return
        if self.strategy.state.value not in ("ANALYSING", "WAIT_FOR_REENTRY_CONFIRMATION"):
            return
        res = self.engine.evaluate(SignalInputs(self.spec.symbol, as_of, list(self.w1), list(self.w5),
                                                list(self.w15), self.max_age))
        if res.blocked:
            for b in res.blocked:
                self.blocked[_norm.sub("#", b)] += 1
            return
        self.cnt["bars_evaluated"] += 1
        if res.signal is None:
            return
        sig = res.signal
        self.cnt["signals"] += 1
        eq = self.equity_now()
        rate = self.s.fx_margin_rate_pct
        margin_fn = None
        if rate is not None:
            margin_fn = lambda qty, px: self.ctx.rates.convert(qty * px, self.spec.quote, self.base) * rate / HUNDRED / eq * HUNDRED
        d = evaluate_entry(strategy=self.strategy, signal=sig, quote=self.last_q, spec=self.spec, cfg=self.cfg,
                           gcfg=self.g, ctx=self.ctx, ledger=self.ledger, open_positions=[], governor=self.gov,
                           equity_base=eq, news=self.s.news, now=as_of, margin_util_fn=margin_fn)
        if not d.approved:
            self.cnt["rejected"] += 1
            for r in d.reasons:
                self.rej[_norm.sub("#", r)[:110]] += 1
            return
        self.cnt["approved"] += 1
        self.seq += 1
        pos = Position(position_id=f"BT-{self.spec.symbol}-{self.seq}", spec=self.spec, side=sig.direction,
                       target_qty=d.sizing.qty, created_ts=as_of, config_hash=self.fp,
                       strategy_version=self.s.strategy_version, signal_ts=sig.signal_ts,
                       params=StopParams(self.cfg.initial_stop_pct, self.cfg.trailing_activation_pct,
                                         self.cfg.trailing_distance_pct),
                       est_entry_costs=d.cost.entry_costs)
        self.strategy.on_entry_requested(as_of)
        diag = dict(sig.diagnostics)
        self.pos = pos
        self.pending_entry = {"activate": as_of + self.lat, "decision": d, "order_ts": as_of}
        self.meta[pos.id] = {
            "adx15": float(diag["adx_15m"]), "atr5_pct": float(diag["atr_5m_pct"]), "macd_mode": diag["macd_mode"],
            "signal_reasons": list(sig.reasons), "same_direction_reentry": d.is_same_direction_reentry,
            "reversal": d.is_reversal, "reentry_move_pct": None if d.gate.directional_move_pct is None else str(d.gate.directional_move_pct),
            "est_entry_costs": str(d.cost.entry_costs.total), "est_exit_costs": str(d.cost.exit_costs.total),
            "sizing": list(d.sizing.explanation)[-1:], "warnings": list(d.warnings)[:3]}

    # --------------------------------------------------------------- fills
    def _pending(self, q: Quote) -> None:
        now = q.market_ts
        pe = self.pending_entry
        if pe is not None and now >= pe["activate"]:
            self.pending_entry = None
            self._fill_entry(q, pe)
        px = self.pending_exit
        if px is not None and now >= px["activate"]:
            self.pending_exit = None
            self._fill_exit(q, px)

    def _fill_entry(self, q: Quote, pe: dict) -> None:
        pos, d = self.pos, pe["decision"]
        spread_pct = q.spread / q.mid * HUNDRED
        if spread_pct > self.cfg.max_spread_pct:                     # re-check at the moment of execution
            pos.complete_entry(q.market_ts)
            self.strategy.on_entry_failed(q.market_ts)
            self.cnt["entry_cancelled_spread"] += 1
            self.pos = None
            return
        sgn = Decimal(pos.side.sign)
        slip = self.ctx.slippage_pct * self.s.realised_slippage_multiplier / HUNDRED
        buy = pos.side is Side.LONG
        px = _round_tick(q.entry_price(pos.side) * (1 + sgn * slip), self.spec.tick_size, up=buy)
        comm = self.ctx.commission_quote(pos.target_qty, px, self.spec.quote) * self.s.realised_commission_multiplier
        pos.on_entry_fill(Fill(f"{pos.id}-E", pos.target_qty, px, pe["order_ts"], q.market_ts, q, comm))
        pos.complete_entry(q.market_ts)
        pos.confirm_protection("SIM-STOP", pos.desired_stop, pos.open_qty, q.market_ts)
        self.strategy.on_position_opened(q.market_ts)
        risk_base = self.ctx.to_base(d.sizing.worst_case_loss_quote, self.spec.quote)
        self.gov.register_open(pos.id, self.spec.symbol, risk_base, d.is_reversal)
        self._apply_ledger(pos.side, closing=False, qty=pos.target_qty, px=px, commission=comm)
        self.cur_est_exit = d.cost.exit_costs
        self.cnt["entries_filled"] += 1
        self.meta[pos.id]["entry_delay_s"] = (q.market_ts - pe["order_ts"]).total_seconds()
        self.meta[pos.id]["initial_risk_quote"] = str(abs(pos.avg_entry - pos.desired_stop) * pos.target_qty)

    def _fill_exit(self, q: Quote, pe: dict) -> None:
        pos = self.pos
        sgn = Decimal(pos.side.sign)
        slip = self.ctx.slippage_pct * self.s.realised_slippage_multiplier / HUNDRED
        sell = pos.side is Side.LONG
        px = _round_tick(q.exit_price(pos.side) * (1 - sgn * slip), self.spec.tick_size, up=not sell)
        qty = pos.open_qty
        comm = self.ctx.commission_quote(qty, px, self.spec.quote) * self.s.realised_commission_multiplier
        pos.on_exit_fill(Fill(f"{pos.id}-X", qty, px, pe["order_ts"], q.market_ts, q, comm))
        self._apply_ledger(pos.side, closing=True, qty=qty, px=px, commission=comm)
        rec = pos.to_trade_record(self.ctx.rates.rate(self.spec.quote, self.base))
        self.trades.append(rec)
        self.realised_base += rec.net_pnl_base
        self.meta[pos.id]["exit_delay_s"] = (q.market_ts - pe["order_ts"]).total_seconds()
        self.meta[pos.id]["exit_detail"] = pe["detail"]
        self.meta[pos.id]["forced_window_end"] = pe.get("forced", False)
        self.strategy.on_position_closed(pos.side, q.market_ts)
        self.gov.on_trade_closed(rec, q.market_ts)
        self.pos = None

    def _apply_ledger(self, side: Side, closing: bool, qty: Decimal, px: Decimal, commission: Decimal) -> None:
        for c, a in balance_effect(self.spec, action_for(side, closing), qty, px).items():
            self.ledger.balances[c] = self.ledger.bal(c) + a
        self.ledger.balances[self.spec.quote] = self.ledger.bal(self.spec.quote) - commission
        if side is Side.SHORT:                                        # short-sale proceeds are never free cash
            lk = self.ledger.locked_short_proceeds
            lk[self.spec.quote] = max(ZERO, lk.get(self.spec.quote, ZERO) + (-1 if closing else 1) * qty * px)

    # ----------------------------------------------------------- exits
    def _request_exit(self, reason: ExitReason, now: datetime, detail: str, forced: bool = False) -> None:
        pos = self.pos
        pos.request_exit(reason, now, est_exit_costs=self.cur_est_exit)
        self.pending_exit = {"activate": now + self.lat, "order_ts": now, "detail": detail, "forced": forced}
        self.cnt[f"exit_{reason.value}"] += 1

    def _manage_position(self, q: Quote) -> None:
        pos = self.pos
        if pos is None or pos.state in (PS.PENDING_ENTRY, PS.PENDING_EXIT, PS.CLOSED) or self.pending_exit is not None:
            return
        now, s = q.market_ts, self.s
        if s.trade_until is not None and now >= s.trade_until:
            self._request_exit(ExitReason.MANUAL, now, "backtest window end", forced=True)
            return
        pol = ExitPolicy(self.cfg.max_hold_minutes * 60, self.max_age, self.cutoff_dt, self.cfg.profit_taking_enabled,
                         self.cfg.min_net_profit)
        ev = evaluate_exit(pos, q, now, pol, self.ctx if self.cfg.profit_taking_enabled else None)
        if ev.stop_tightened:
            pos.confirm_protection("SIM-STOP", pos.desired_stop, pos.open_qty, now)
            pos.mark_trailing_if_protected(now)
        if ev.exit is not None:
            self._request_exit(ev.exit.reason, now, ev.exit.detail)


def run_backtest(source: Union[Sequence[Quote], Sequence[BidAskBar]], settings: BacktestSettings) -> BacktestResult:
    run = _Run(settings)
    first = last = None
    n_in = 0

    def quotes():
        if len(source) and isinstance(source[0], BidAskBar):
            for bar in source:
                for q in expand_bar(bar, settings.spec.symbol, run.adverse_side(), settings.bar_path):
                    yield q
        else:
            yield from source

    for q in quotes():
        first = first or q.market_ts
        last = q.market_ts
        if not run.process(q):
            break
    notes = ["no economic-calendar provider" if isinstance(settings.news, NullNewsProvider)
             else f"news policy: {type(settings.news).__name__}",
             "commission schedule verified: " + str(getattr(getattr(settings.ctx.schedule, "verification", None), "verified", False)),
             "financing: " + ("modelled" if settings.ctx.financing else "NOT modelled (no rates supplied; intraday, flat before cutoff)"),
             f"latency {settings.latency_s}s; slippage x{settings.realised_slippage_multiplier}; commission x{settings.realised_commission_multiplier}",
             f"sessions: {settings.gcfg.session_start_local} {settings.gcfg.session_timezone} (DST-aware); EOD cutoff: " + (
                 f"{settings.gcfg.eod_cutoff_minutes_before_rollover} min before rollover" if settings.gcfg.eod_cutoff_minutes_before_rollover is not None
                 else f"LEGACY {settings.gcfg.eod_cutoff_utc} UTC (drifts with DST)"),
             f"post-close reference reset: {settings.cfg.reentry_reference_reset}"
             + (f", max age {settings.cfg.reentry_reference_max_age_minutes} min" if settings.cfg.reentry_reference_max_age_minutes else ""),
             "SHORT margin model: " + ("fx_margin_rate_pct=%s%%" % settings.fx_margin_rate_pct if settings.fx_margin_rate_pct is not None
                                       else "none supplied - SHORT entries that borrow are rejected")]
    return BacktestResult(settings.spec.symbol, run.trades, run.meta, run.equity0, run.fp, settings.trade_from,
                          settings.trade_until, run.cnt["quotes"], dict(run.cnt), dict(run.rej), dict(run.blocked),
                          notes, first, last, settings)
