"""Walk-forward validation: select on the TRAIN window only (robust neighbourhood score), evaluate the chosen
variant on the following TEST window. The pooled test trades are the walk-forward out-of-sample result."""
from __future__ import annotations

from dataclasses import dataclass, field
from decimal import Decimal
from typing import Callable, Dict, List, Mapping, Optional, Sequence

from ..core.types import FxBotError
from ..position_manager.position import TradeRecord
from .engine import BacktestResult, BacktestSettings
from .splits import Fold, ResearchSession
from .sweeps import Variant, VariantResult, robust_scores, select_best


@dataclass
class FoldResult:
    fold: Fold
    train: List[VariantResult]
    train_scores: Dict[str, Optional[float]]
    chosen: Optional[Variant]
    test: Optional[BacktestResult]


@dataclass
class WalkForwardResult:
    pair: str
    folds: List[FoldResult]
    label: str = ""

    @property
    def oos_trades(self) -> List[TradeRecord]:
        return [t for f in self.folds if f.test for t in f.test.trades]

    @property
    def oos_meta(self) -> Dict[str, dict]:
        out: Dict[str, dict] = {}
        for f in self.folds:
            if f.test:
                out.update(f.test.meta)
        return out

    @property
    def chosen_names(self) -> List[Optional[str]]:
        return [f.chosen.name if f.chosen else None for f in self.folds]


def walk_forward(session: ResearchSession, base: BacktestSettings, variants: Sequence[Variant],
                 min_trades_train: int = 30, label: str = "") -> WalkForwardResult:
    folds = session.plan.folds()
    if not folds:
        raise FxBotError("split plan yields no walk-forward folds (data too short)")
    out: List[FoldResult] = []
    for f in folds:
        train = session.run_dev(base, variants, f.train_start, f.train_end)      # selection data ONLY
        scores = robust_scores(train, min_trades_train)
        best = select_best(train, min_trades_train)
        test = None
        if best is not None:                                                     # no valid train variant => stay flat
            test = session.run_dev(base, [best.variant], f.test_start, f.test_end)[0].result
        out.append(FoldResult(f, train, scores, best.variant if best else None, test))
    return WalkForwardResult(base.spec.symbol, out, label)


def walk_forward_by_axis(session: ResearchSession, base: BacktestSettings, variants: Sequence[Variant], axis: str,
                         min_trades_train: int = 30) -> Dict[str, WalkForwardResult]:
    """Independent walk-forward per value of `axis` (e.g. engine.macd_mode = line vs histogram, or
    pair.min_net_profit_pct None vs values): same methodology, separately reported, no cross-contamination."""
    groups: Dict[str, List[Variant]] = {}
    for v in variants:
        groups.setdefault(str(v.values.get(axis)), []).append(v)
    return {k: walk_forward(session, base, vs, min_trades_train, label=f"{axis}={k}") for k, vs in groups.items()}
