"""Markdown / CSV reporting for backtests and walk-forward runs. Every section states its evidence status;
nothing is called validated unless the locked criteria say so (INSUFFICIENT_EVIDENCE is a first-class outcome)."""
from __future__ import annotations

import csv
import statistics
from decimal import Decimal
from typing import Callable, Dict, Iterable, List, Mapping, Optional, Sequence, Tuple

from ..core.types import Side
from ..position_manager.position import TradeRecord
from ..reporting.exit_analysis import estimated_vs_realised, exit_reason_breakdown, trailing_gross_breakeven_report
from ..reporting.metrics import Summary, daily_returns_from_trades, summarise
from ..reporting.readiness import ReadinessCriteria, evaluate_strategy_evidence
from .data import DatasetReport
from .engine import BacktestResult
from .walkforward import WalkForwardResult

HEAD = ("| segment | n | net P&L (base) | expectancy | win % | PF | max DD % | avg hold min | costs % of gross | "
        "max consec. losses |\n|---|---|---|---|---|---|---|---|---|---|")


def _f(x, nd=2, pct=False):
    if x is None:
        return "n/a"
    return f"{float(x):.{nd}f}" + ("%" if pct else "")


def row(label: str, s: Summary) -> str:
    hold = None if s.avg_hold_seconds is None else s.avg_hold_seconds / 60
    return (f"| {label} | {s.n} | {_f(s.net_pnl_base)} | {_f(s.expectancy_base)} | {_f(s.win_rate, 1)} | "
            f"{_f(s.profit_factor)} | {_f(s.max_drawdown_pct)} | {_f(hold, 1)} | "
            f"{_f(s.costs_pct_of_gross_profit, 1)} | {s.max_consecutive_losses} |")


def table(rows: Sequence[Tuple[str, Sequence[TradeRecord]]], equity0: Optional[Decimal]) -> str:
    return "\n".join([HEAD] + [row(l, summarise(t, equity0)) for l, t in rows])


def data_section(reports: Sequence[DatasetReport]) -> str:
    lines = ["## Data used"]
    for r in reports:
        lines += [f"- " + x for x in r.summary_lines()]
    return "\n".join(lines)


def run_section(res: BacktestResult) -> str:
    c = res.counters
    lines = [f"### Run diagnostics - {res.pair} (settings {res.settings_fp[:12]})",
             f"- window {res.trade_from} .. {res.trade_until}; quotes {res.n_quotes}; bars evaluated {c.get('bars_evaluated', 0)}; "
             f"signals {c.get('signals', 0)}; approved {c.get('approved', 0)}; filled {c.get('entries_filled', 0)}; "
             f"cancelled at fill (spread) {c.get('entry_cancelled_spread', 0)}",
             "- exits: " + ", ".join(f"{k[5:]} {v}" for k, v in sorted(c.items()) if k.startswith("exit_"))]
    if res.rejections:
        lines.append("- top rejection reasons: " + "; ".join(f"{k} x{v}" for k, v in sorted(res.rejections.items(), key=lambda x: -x[1])[:5]))
    if res.blocked:
        lines.append("- data-quality blocks: " + "; ".join(f"{k} x{v}" for k, v in sorted(res.blocked.items(), key=lambda x: -x[1])[:3]))
    lines += [f"- NOTE: {n}" for n in res.notes]
    return "\n".join(lines)


def avg_r(trades: Sequence[TradeRecord], meta: Mapping[str, dict]) -> Optional[float]:
    """Mean net P&L as a multiple of the initial risk (entry-to-initial-stop distance x quantity). Normalises for
    the LONG/SHORT size asymmetry (LONG is capped by own quote-currency cash, SHORT by the borrow room)."""
    rs = []
    for t in trades:
        r0 = meta.get(t.position_id, {}).get("initial_risk_quote")
        if r0 and Decimal(r0) > 0:
            rs.append(float(t.net_pnl / Decimal(r0)))
    return statistics.fmean(rs) if rs else None


def r_multiple_section(trades: Sequence[TradeRecord], meta: Mapping[str, dict]) -> str:
    rows = ["### Average net R-multiple (net P&L / initial risk) - comparable across LONG and SHORT sizes",
            "| segment | n | avg net R |", "|---|---|---|"]
    segs = [("ALL", list(trades))] + [(sd.value, [t for t in trades if t.side is sd]) for sd in Side]
    for lab, ts in segs:
        a = avg_r(ts, meta)
        rows.append(f"| {lab} | {len(ts)} | {'n/a' if a is None else f'{a:.3f}'} |")
    return "\n".join(rows)


def pair_side_section(trades: Sequence[TradeRecord], equity0: Optional[Decimal]) -> str:
    pairs = sorted({t.pair for t in trades})
    rows: List[Tuple[str, List[TradeRecord]]] = [("ALL", list(trades))]
    for p in pairs:
        rows.append((p, [t for t in trades if t.pair == p]))
        for sd in Side:
            rows.append((f"{p} {sd.value}", [t for t in trades if t.pair == p and t.side is sd]))
    for sd in Side:
        rows.append((f"ALL {sd.value}", [t for t in trades if t.side is sd]))
    return "### Per pair and direction\n" + table(rows, equity0)


def regime_section(trades: Sequence[TradeRecord], meta: Mapping[str, dict], equity0: Optional[Decimal]) -> str:
    def adx_band(t):
        a = meta.get(t.position_id, {}).get("adx15")
        return "adx n/a" if a is None else ("ADX 20-25" if a < 25 else "ADX 25-35" if a < 35 else "ADX >=35")
    atrs = sorted(m["atr5_pct"] for t in trades for m in [meta.get(t.position_id, {})] if "atr5_pct" in m)
    cuts = (atrs[len(atrs) // 3], atrs[2 * len(atrs) // 3]) if len(atrs) >= 6 else None

    def vol(t):
        a = meta.get(t.position_id, {}).get("atr5_pct")
        if a is None or cuts is None:
            return "vol n/a"
        return "low vol" if a < cuts[0] else "mid vol" if a < cuts[1] else "high vol"
    def reentry(t):
        m = meta.get(t.position_id, {})
        return "same-direction re-entry" if m.get("same_direction_reentry") else "reversal" if m.get("reversal") else "first entry"
    out = ["### Market regimes (descriptive; ATR terciles are computed from these trades)"]
    for title, fn in (("ADX band at entry", adx_band), ("5m ATR% tercile at entry", vol), ("entry type", reentry)):
        groups: Dict[str, List[TradeRecord]] = {}
        for t in trades:
            groups.setdefault(fn(t), []).append(t)
        out += [f"**{title}**", table(sorted(groups.items()), equity0), ""]
    return "\n".join(out)


def exit_section(trades: Sequence[TradeRecord]) -> str:
    out = ["### Exits and costs"]
    br = exit_reason_breakdown(trades)
    out += ["| exit reason | n | expectancy | net P&L |", "|---|---|---|---|"]
    out += [f"| {k} | {s.n} | {_f(s.expectancy_base)} | {_f(s.net_pnl_base)} |" for k, s in sorted(br.items())]
    g = trailing_gross_breakeven_report(trades)
    out.append(f"\nTrailing exits {g.trailing_exits}; at the gross-breakeven protected level {g.at_gross_breakeven_level}; "
               f"of those with NEGATIVE net P&L {g.of_which_negative_net}"
               + ("" if g.share_negative_net is None else f" ({float(g.share_negative_net) * 100:.0f}%)")
               + f"; their total net loss {_f(g.total_net_loss_base)} (base).")
    ev = estimated_vs_realised(trades)
    if ev:
        out += ["\nEstimated (at entry) vs realised costs, base currency:", "| component | estimated | realised | variance |", "|---|---|---|---|"]
        out += [f"| {k} | {_f(v['estimated'])} | {_f(v['realised'])} | {_f(v['variance'])} |" for k, v in ev.items()]
    return "\n".join(out)


def evidence_section(trades: Sequence[TradeRecord], equity0: Decimal, pairs: Sequence[str],
                     criteria: ReadinessCriteria = ReadinessCriteria()) -> str:
    ev = evaluate_strategy_evidence(criteria, trades, daily_returns_from_trades(trades, equity0), equity0, pairs)
    lines = [f"### Evidence status vs the locked criteria (fingerprint {ev.criteria_fingerprint[:12]})",
             f"**{ev.status.value}**  - Sharpe {_f(ev.sharpe)}; validated pairs: {ev.validated_pairs or 'none'}"]
    lines += [f"- {r}" for r in ev.reasons] or ["- all strategy criteria met (paper-trading/operational criteria are separate)"]
    lines.append("- Criteria were fixed before results were examined; this is evidence, not proof of future profitability.")
    return "\n".join(lines)


def comparison_section(title: str, labelled: Mapping[str, Sequence[TradeRecord]], equity0: Optional[Decimal]) -> str:
    return f"### {title}\n(each row is an independent run/selection with identical methodology; no mode is assumed superior)\n" + \
        table(list(labelled.items()), equity0)


def walk_forward_section(wf: WalkForwardResult, equity0: Optional[Decimal]) -> str:
    out = [f"### Walk-forward {wf.label or ''} - {wf.pair}", "| fold | train window | test window | chosen variant | train score | test n | test net |", "|---|---|---|---|---|---|---|"]
    for i, f in enumerate(wf.folds):
        sc = f.train_scores.get(f.chosen.name) if f.chosen else None
        n = len(f.test.trades) if f.test else 0
        net = sum((t.net_pnl_base for t in f.test.trades), Decimal(0)) if f.test else None
        out.append(f"| {i} | {f.fold.train_start:%Y-%m-%d}..{f.fold.train_end:%Y-%m-%d} | {f.fold.test_start:%Y-%m-%d}..{f.fold.test_end:%Y-%m-%d} | "
                   f"{f.chosen.name if f.chosen else 'none (stayed flat)'} | {_f(sc)} | {n} | {_f(net)} |")
    distinct = len({n for n in wf.chosen_names if n})
    out.append(f"\nDistinct variants chosen across folds: {distinct} (many different choices = unstable optimum).")
    return "\n".join(out)


def sweep_section(results, min_trades: int) -> str:
    from .sweeps import robust_scores
    sc = robust_scores(results, min_trades)
    rows = sorted(results, key=lambda r: (sc[r.variant.name] is None, -(sc[r.variant.name] or 0)))
    out = ["### Parameter sweep (development data only)", "| variant | n | expectancy | PF | robust score | max DD % |", "|---|---|---|---|---|---|"]
    for r in rows:
        s = r.summary
        out.append(f"| {r.variant.name} | {s.n} | {_f(s.expectancy_base)} | {_f(s.profit_factor)} | {_f(sc[r.variant.name])} | {_f(s.max_drawdown_pct)} |")
    out.append("\nRobust score = mean expectancy of the variant and its grid neighbours; n/a = fewer than the minimum trades. "
               "Prefer plateaus, not isolated peaks.")
    return "\n".join(out)


def full_report(title: str, datasets: Sequence[DatasetReport], sections: Sequence[str]) -> str:
    banner = ("> **Backtests are not evidence of future profit.** Results depend on data resolution, cost assumptions "
              "and the unverified items listed under Data and Run diagnostics. Live trading remains disabled.")
    return "\n\n".join([f"# {title}", banner, data_section(datasets)] + list(sections)) + "\n"


def export_trades_csv(path: str, trades: Sequence[TradeRecord], meta: Mapping[str, dict]) -> None:
    cols = ["position_id", "pair", "side", "qty", "entry_avg", "exit_avg", "opened_ts", "closed_ts", "exit_reason",
            "gross_pnl", "costs_total", "net_pnl", "fx_to_base", "net_pnl_base", "exit_move_pct", "max_favourable_pct",
            "trail_protected_pct_at_exit", "adx15", "atr5_pct", "macd_mode", "same_direction_reentry", "reversal"]
    with open(path, "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(cols)
        for t in trades:
            m = meta.get(t.position_id, {})
            w.writerow([t.position_id, t.pair, t.side.value, t.qty, t.entry_avg, t.exit_avg, t.opened_ts.isoformat(),
                        t.closed_ts.isoformat(), t.exit_reason.value, t.gross_pnl, t.costs.total, t.net_pnl, t.fx_to_base,
                        t.net_pnl_base, t.exit_move_pct, t.max_favourable_pct, t.trail_protected_pct_at_exit,
                        m.get("adx15"), m.get("atr5_pct"), m.get("macd_mode"), m.get("same_direction_reentry"), m.get("reversal")])


def frequency_section(groups: Mapping[str, WalkForwardResult]) -> str:
    """Trade-frequency view for mode comparisons (e.g. post-close reference reset): trades per trading session, entry types,
    and how often the movement threshold was the reason for a rejection."""
    from ..core.sessions import SessionCalendar
    cal = SessionCalendar()
    out = ["### Trade frequency and entry types (out-of-sample)",
           "| group | OOS trading sessions | trades | trades / session | first entries | same-direction re-entries | reversals | movement-threshold rejections |",
           "|---|---|---|---|---|---|---|---|"]
    for label, wf in groups.items():
        tests = [f.test for f in wf.folds if f.test is not None]
        if not tests:
            out.append(f"| {label} | 0 | 0 | n/a | - | - | - | - |"); continue
        labels = set()
        for f in wf.folds:
            d = f.fold.test_start
            while d < f.fold.test_end:
                sess = cal.session_of(d)
                if sess.is_trading_day:
                    labels.add(sess.label)
                d = sess.end_utc
        meta = wf.oos_meta
        trades = wf.oos_trades
        same = sum(1 for t in trades if meta.get(t.position_id, {}).get("same_direction_reentry"))
        rev = sum(1 for t in trades if meta.get(t.position_id, {}).get("reversal"))
        mv = sum(v for tr in tests for k, v in tr.rejections.items() if "move #" in k or "direction move" in k)
        n = len(trades)
        out.append(f"| {label} | {len(labels)} | {n} | {n / len(labels):.2f} | {n - same - rev} | {same} | {rev} | {mv} |")
    return "\n".join(out)
