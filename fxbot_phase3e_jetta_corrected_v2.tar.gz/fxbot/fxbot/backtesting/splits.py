"""Out-of-sample discipline ENFORCED IN CODE.
* All tuning (sweeps, walk-forward selection) can only read data strictly before `holdout_start`
  (HoldoutAccessError otherwise).
* The final holdout can be evaluated ONCE per (dataset hash, split plan), by a candidate that was frozen from
  development evidence; the registry file records the use BEFORE the run, so a crash does not grant a retry.
* Walk-forward folds are rolling (or anchored) with an embargo between train and test, all inside development."""
from __future__ import annotations

import hashlib
import json
import os
from dataclasses import dataclass, replace
from datetime import datetime, timedelta, timezone
from decimal import Decimal
from typing import Any, Dict, List, Optional, Sequence

from ..core.types import FxBotError
from .data import BidAskBar
from .engine import BacktestResult, BacktestSettings, run_backtest
from .sweeps import Variant, VariantResult, apply_variant, slice_source


class HoldoutAccessError(FxBotError):
    pass


class HoldoutAlreadyUsed(FxBotError):
    pass


@dataclass(frozen=True)
class Fold:
    train_start: datetime
    train_end: datetime
    test_start: datetime
    test_end: datetime


@dataclass(frozen=True)
class SplitPlan:
    data_start: datetime
    data_end: datetime
    holdout_fraction: float = 0.2
    wf_train_days: int = 20
    wf_test_days: int = 5
    wf_step_days: int = 5
    embargo_minutes: int = 180            # >= max holding time: nothing from train can still be open in test
    anchored: bool = False
    warmup_minutes: int = 3600            # indicator history before a window (past data only)
    max_folds: Optional[int] = None       # cap (quick runs); None = as many as fit

    def __post_init__(self):
        if not 0 < self.holdout_fraction < 1:
            raise FxBotError("holdout_fraction must be in (0,1)")
        if self.wf_step_days < self.wf_test_days:
            raise FxBotError("wf_step_days must be >= wf_test_days (overlapping test windows would double count trades)")

    @property
    def holdout_start(self) -> datetime:
        t = self.data_end - (self.data_end - self.data_start) * self.holdout_fraction
        return datetime(t.year, t.month, t.day, tzinfo=timezone.utc)

    @property
    def warmup(self) -> timedelta:
        return timedelta(minutes=self.warmup_minutes)

    def folds(self) -> List[Fold]:
        out, k = [], 0
        while True:
            train_start = self.data_start if self.anchored else self.data_start + timedelta(days=k * self.wf_step_days)
            train_end = self.data_start + timedelta(days=self.wf_train_days + k * self.wf_step_days)
            test_start = train_end + timedelta(minutes=self.embargo_minutes)
            test_end = test_start + timedelta(days=self.wf_test_days)
            if test_end > self.holdout_start or (self.max_folds is not None and len(out) >= self.max_folds):
                return out
            out.append(Fold(train_start, train_end, test_start, test_end))
            k += 1

    def fingerprint(self) -> str:
        return hashlib.sha256(json.dumps(self.__dict__, sort_keys=True, default=str).encode()).hexdigest()[:16]

    def holdout_fingerprint(self) -> str:
        """Identity of the HOLDOUT only: data span and boundary. Walk-forward settings (train/test/step/embargo/anchoring)
        deliberately do NOT change it, otherwise changing the methodology would hand out a fresh single look."""
        return hashlib.sha256(json.dumps({"s": self.data_start.isoformat(), "e": self.data_end.isoformat(),
                                          "h": self.holdout_start.isoformat()}, sort_keys=True).encode()).hexdigest()[:16]


@dataclass(frozen=True)
class FrozenCandidate:
    variant: Variant
    selected_from: str          # fingerprint of the development evidence
    frozen_at: datetime

    def fingerprint(self) -> str:
        return hashlib.sha256(json.dumps({"n": self.variant.name, "v": {k: str(v) for k, v in self.variant.values.items()},
                                          "from": self.selected_from}, sort_keys=True).encode()).hexdigest()[:16]


class ResearchSession:
    def __init__(self, source: Sequence, plan: SplitPlan, dataset_sha256: str, registry_path: str):
        self._source, self.plan, self.dataset_sha256, self.registry_path = source, plan, dataset_sha256, registry_path

    # ---- development access (never the holdout)
    def dev_slice(self, start: datetime, end: datetime) -> List:
        if end > self.plan.holdout_start:
            raise HoldoutAccessError(f"requested data up to {end} but development data ends at {self.plan.holdout_start}")
        return slice_source(self._source, start, end)

    def run_dev(self, base: BacktestSettings, variants: Sequence[Variant], trade_from: datetime, trade_until: datetime
                ) -> List[VariantResult]:
        if trade_until > self.plan.holdout_start:
            raise HoldoutAccessError("development runs must end before holdout_start")
        data = self.dev_slice(trade_from - self.plan.warmup, trade_until)
        return [VariantResult(v, run_backtest(data, replace(apply_variant(base, v), trade_from=trade_from, trade_until=trade_until)))
                for v in variants]

    # ---- freezing and the single holdout evaluation
    def freeze(self, variant: Variant, evidence: Sequence[VariantResult]) -> FrozenCandidate:
        if not evidence:
            raise FxBotError("a candidate can only be frozen from development evidence")
        for e in evidence:
            tu = e.result.trade_until
            if tu is None or tu > self.plan.holdout_start:
                raise HoldoutAccessError("evidence includes results that touched the holdout")
        fp = hashlib.sha256("|".join(sorted(f"{e.variant.name}:{e.result.settings_fp}:{len(e.result.trades)}" for e in evidence)).encode()).hexdigest()[:16]
        return FrozenCandidate(variant, fp, datetime.now(timezone.utc))

    def _registry(self) -> Dict[str, Any]:
        if os.path.exists(self.registry_path):
            with open(self.registry_path) as f:
                return json.load(f)
        return {"entries": []}

    def holdout_uses(self) -> List[Dict[str, Any]]:
        return [e for e in self._registry()["entries"]
                if e["dataset_sha256"] == self.dataset_sha256 and e["plan"] == self.plan.holdout_fingerprint()]

    def run_holdout_once(self, candidate: FrozenCandidate, base: BacktestSettings) -> BacktestResult:
        prior = self.holdout_uses()
        if prior:
            raise HoldoutAlreadyUsed(f"holdout already evaluated by candidate {prior[0]['candidate']} on {prior[0]['ts']}; "
                                     "a second look would make it a development set")
        reg = self._registry()
        reg["entries"].append({"dataset_sha256": self.dataset_sha256, "plan": self.plan.holdout_fingerprint(),
                               "candidate": candidate.fingerprint(), "name": candidate.variant.name,
                               "ts": datetime.now(timezone.utc).isoformat()})
        tmp = self.registry_path + ".tmp"
        with open(tmp, "w") as f:
            json.dump(reg, f, indent=1)
        os.replace(tmp, self.registry_path)                      # recorded BEFORE running
        start, end = self.plan.holdout_start, self.plan.data_end
        data = slice_source(self._source, start - self.plan.warmup, end + timedelta(seconds=1))
        return run_backtest(data, replace(apply_variant(base, candidate.variant), trade_from=start, trade_until=end))
