"""Initial entry hypothesis `ema_trend_v0` (testable, NOT proven). Multi-timeframe, closed candles only.

LONG (SHORT is the exact mirror):
  1. 15m  EMA(fast) > EMA(slow)                                  main trend
  2. 5m   close > EMA(fast)                                      trend confirmation
  3. 5m   MACD (line, or histogram: macd_mode) > 0 AND RSI >= rsi_long_min   momentum (correlated - sweep)
  4. 15m  ADX >= adx_min                                         trend strength
  5. 1m   slow-stochastic %K crossed above %D within the last N bars, %K still > %D and < overbought
  optional: 15m close > EMA200 (regime filter), 5m ATR% bounds, quote-activity proxy (all OFF by default)
Spread / costs / news / risk limits are NOT part of the engine: strategy/entry.py applies them.
Threshold defaults are PROPOSED starting values (A-17) to be swept in backtests, not tuned optima.
"""
from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass, fields
from datetime import datetime
from typing import Dict, List, Mapping, Optional, Sequence, Tuple

from ..core.types import FxBotError, Side
from ..indicators.core import activity_ratio, adx, atr, ema, macd, rsi, stochastic
from ..market_data.bars import Bar
from ..market_data.staleness import find_bar_gaps
from .base import Signal


class LookAheadError(FxBotError):
    pass


@dataclass(frozen=True)
class EmaTrendParams:
    ema_fast: int = 20
    ema_slow: int = 50
    ema_long: int = 200
    use_ema200_filter: bool = False
    rsi_period: int = 14
    rsi_long_min: float = 50.0
    rsi_short_max: float = 50.0
    macd_fast: int = 12
    macd_slow: int = 26
    macd_signal: int = 9
    macd_mode: str = "line"                      # "line": MACD line vs 0 | "histogram": histogram vs 0 (A-17)
    adx_period: int = 14
    adx_min: float = 20.0
    stoch_k: int = 14
    stoch_d: int = 3
    stoch_smooth: int = 3
    stoch_trigger_lookback: int = 3
    stoch_overbought: float = 80.0
    stoch_oversold: float = 20.0
    atr_period: int = 14
    min_atr_pct: Optional[float] = None          # 5m ATR as % of price; None = filter not applied
    max_atr_pct: Optional[float] = None
    use_activity_proxy: bool = False             # tick-count proxy, NOT volume
    activity_min_ratio: Optional[float] = None
    max_gap_bars: int = 5

    @staticmethod
    def from_mapping(m: Mapping[str, str]) -> "EmaTrendParams":
        d, kw = EmaTrendParams(), {}
        for k, v in m.items():
            if not hasattr(d, k):
                raise ValueError(f"unknown signal parameter {k!r}")
            default = getattr(d, k)
            if isinstance(default, bool):
                kw[k] = str(v).lower() in ("1", "true", "yes")
            elif isinstance(default, str):
                kw[k] = str(v)
            elif isinstance(default, int):
                kw[k] = int(v)
            else:
                kw[k] = None if str(v).lower() == "none" else float(v)
        return EmaTrendParams(**kw)

    def fingerprint(self) -> str:
        return hashlib.sha256(json.dumps({f.name: getattr(self, f.name) for f in fields(self)},
                                         sort_keys=True).encode()).hexdigest()[:16]


@dataclass(frozen=True)
class SignalInputs:
    pair: str
    as_of: datetime                  # decision time; every bar must have end_ts <= as_of
    bars_1m: Sequence[Bar]
    bars_5m: Sequence[Bar]
    bars_15m: Sequence[Bar]
    max_age_s: Optional[int]         # freshness limit for the newest 1m bar (global market_data_max_age_seconds)


@dataclass(frozen=True)
class DirectionEval:
    side: Side
    satisfied: Tuple[str, ...]
    failed: Tuple[str, ...]
    flags: Tuple[bool, ...] = ()          # pass/fail per condition, in evaluation order

    @property
    def valid(self) -> bool:
        return not self.failed


@dataclass(frozen=True)
class SignalResult:
    signal: Optional[Signal]
    long: Optional[DirectionEval]
    short: Optional[DirectionEval]
    blocked: Tuple[str, ...]                    # data-quality problems: engine produced nothing
    diagnostics: Tuple[Tuple[str, str], ...] = ()


def _last(s: Sequence[Optional[float]]) -> Optional[float]:
    return s[-1] if s else None


class EmaTrendEngine:
    name = "ema_trend_v0"

    def __init__(self, params: EmaTrendParams = EmaTrendParams(), memoize: bool = False):
        """memoize=True (backtester): the 5m/15m indicator values are recomputed only when a higher-timeframe
        bar changes. Results are identical to memoize=False (tested); the key is a cheap fingerprint of the bars."""
        self.p = params
        self.memoize = memoize
        self._memo = None

    @staticmethod
    def _fp(bars):
        f, l = bars[0], bars[-1]
        return (len(bars), f.start_ts, l.end_ts, f.close, l.close, l.high, l.low, l.ticks)

    def _htf(self, b5, b15):
        key = (self._fp(b5), self._fp(b15))
        if self.memoize and self._memo is not None and self._memo[0] == key:
            return self._memo[1]
        p = self.p
        c15 = [b.close for b in b15]
        h15, l15 = [b.high for b in b15], [b.low for b in b15]
        h5, l5, c5 = ([getattr(b, a) for b in b5] for a in ("high", "low", "close"))
        macd_line, _, hist = macd(c5, p.macd_fast, p.macd_slow, p.macd_signal)
        v = {"e_fast15": _last(ema(c15, p.ema_fast)), "e_slow15": _last(ema(c15, p.ema_slow)),
             "e_fast5": _last(ema(c5, p.ema_fast)), "line5": _last(macd_line), "hist5": _last(hist),
             "rsi5": _last(rsi(c5, p.rsi_period)), "adx_v": _last(adx(h15, l15, c15, p.adx_period)[0]),
             "atr5": _last(atr(h5, l5, c5, p.atr_period)), "px5": c5[-1], "px15": c15[-1],
             "e200": _last(ema(c15, p.ema_long)) if p.use_ema200_filter else None,
             "act": _last(activity_ratio([b.ticks for b in b5], 20)) if p.use_activity_proxy else None}
        if self.memoize:
            self._memo = (key, v)
        return v

    def min_history(self) -> Dict[str, int]:
        p = self.p
        return {"15m": max(p.ema_slow, 2 * p.adx_period, p.ema_long if p.use_ema200_filter else 0),
                "5m": max(p.macd_slow + p.macd_signal - 1, p.rsi_period + 1, p.ema_fast, p.atr_period),
                "1m": p.stoch_k + p.stoch_smooth + p.stoch_d + p.stoch_trigger_lookback}

    def evaluate(self, inp: SignalInputs) -> SignalResult:
        p = self.p
        for name, bars in (("1m", inp.bars_1m), ("5m", inp.bars_5m), ("15m", inp.bars_15m)):
            for b in bars:
                if b.end_ts > inp.as_of:
                    raise LookAheadError(f"{name} bar ending {b.end_ts} is not closed as of {inp.as_of}")
        blocked: List[str] = []
        need = self.min_history()
        for name, bars in (("15m", inp.bars_15m), ("5m", inp.bars_5m), ("1m", inp.bars_1m)):
            if len(bars) < need[name]:
                blocked.append(f"insufficient {name} history: {len(bars)} < {need[name]}")
        if inp.max_age_s is None:
            blocked.append("market_data_max_age_seconds not configured")
        elif inp.bars_1m and (inp.as_of - inp.bars_1m[-1].end_ts).total_seconds() > inp.max_age_s:
            blocked.append("stale data: newest 1m bar older than the freshness limit")
        elif not inp.bars_1m:
            blocked.append("no 1m bars")
        if inp.bars_1m and find_bar_gaps([b.start_ts for b in inp.bars_1m[-30:]], 60, p.max_gap_bars):
            blocked.append(f"data gap > {p.max_gap_bars} consecutive 1m bars in the last 30")
        if blocked:
            return SignalResult(None, None, None, tuple(blocked))

        if p.macd_mode not in ("line", "histogram"):
            raise ValueError("macd_mode must be 'line' or 'histogram'")
        # the slow stochastic has FINITE memory (k + smooth + d - 2 bars): only the trailing slice matters
        # (identical result, far cheaper), keep L extra bars for the cross look-back
        tail = inp.bars_1m[-(p.stoch_k + p.stoch_smooth + p.stoch_d + p.stoch_trigger_lookback + 2):]
        h1, l1, c1 = ([getattr(b, a) for b in tail] for a in ("high", "low", "close"))
        hv = self._htf(inp.bars_5m, inp.bars_15m)
        e_fast15, e_slow15, e_fast5 = hv["e_fast15"], hv["e_slow15"], hv["e_fast5"]
        line5, hist5, rsi5, adx_v, atr5 = hv["line5"], hv["hist5"], hv["rsi5"], hv["adx_v"], hv["atr5"]
        px5, px15, e200, act = hv["px5"], hv["px15"], hv["e200"], hv["act"]
        mom5 = line5 if p.macd_mode == "line" else hist5
        k, d = stochastic(h1, l1, c1, p.stoch_k, p.stoch_d, p.stoch_smooth)
        needed = {"ema15": e_fast15, "ema15s": e_slow15, "ema5": e_fast5, "macd_hist5": hist5, "macd_line5": line5,
                  "rsi5": rsi5, "adx15": adx_v, "stoch_k": _last(k), "stoch_d": _last(d), "atr5": atr5}
        missing = [n for n, v in needed.items() if v is None]
        if missing:
            return SignalResult(None, None, None, (f"indicators not available: {missing}",))
        L = p.stoch_trigger_lookback
        cross_up = any(k[j - 1] is not None and d[j - 1] is not None and k[j - 1] <= d[j - 1] and k[j] > d[j]
                       for j in range(len(k) - L, len(k)))
        cross_dn = any(k[j - 1] is not None and d[j - 1] is not None and k[j - 1] >= d[j - 1] and k[j] < d[j]
                       for j in range(len(k) - L, len(k)))
        atr_pct = atr5 / px5 * 100.0
        diag = [("engine", self.name), ("params", p.fingerprint()),
                ("ema_fast_15m", f"{e_fast15:.6f}"), ("ema_slow_15m", f"{e_slow15:.6f}"),
                ("close_5m", f"{px5:.6f}"), ("ema_fast_5m", f"{e_fast5:.6f}"),
                ("macd_line_5m", f"{line5:.8f}"), ("macd_hist_5m", f"{hist5:.8f}"), ("macd_mode", p.macd_mode), ("rsi_5m", f"{rsi5:.2f}"), ("adx_15m", f"{adx_v:.2f}"),
                ("stoch_k_1m", f"{k[-1]:.2f}"), ("stoch_d_1m", f"{d[-1]:.2f}"), ("atr_5m_pct", f"{atr_pct:.5f}"),
                ("volume_proxy", "tick-activity ratio (not true volume): " + ("n/a" if act is None else f"{act:.2f}"))]

        def side_eval(side: Side) -> DirectionEval:
            up = side is Side.LONG
            conds: List[Tuple[str, bool]] = [
                (f"15m EMA{p.ema_fast} {'>' if up else '<'} EMA{p.ema_slow}", (e_fast15 > e_slow15) if up else (e_fast15 < e_slow15)),
                (f"5m close {'>' if up else '<'} EMA{p.ema_fast}", (px5 > e_fast5) if up else (px5 < e_fast5)),
                (f"5m MACD {p.macd_mode} {'>' if up else '<'} 0", (mom5 > 0) if up else (mom5 < 0)),
                (f"5m RSI {'>=' if up else '<='} {p.rsi_long_min if up else p.rsi_short_max}",
                 (rsi5 >= p.rsi_long_min) if up else (rsi5 <= p.rsi_short_max)),
                (f"15m ADX >= {p.adx_min}", adx_v >= p.adx_min),
                (f"1m stochastic %K crossed {'above' if up else 'below'} %D within {L} bars",
                 (cross_up and k[-1] > d[-1]) if up else (cross_dn and k[-1] < d[-1])),
                (f"1m %K {'<' if up else '>'} {p.stoch_overbought if up else p.stoch_oversold} (not overextended)",
                 (k[-1] < p.stoch_overbought) if up else (k[-1] > p.stoch_oversold)),
            ]
            if p.use_ema200_filter:
                conds.append((f"15m close {'>' if up else '<'} EMA{p.ema_long}", (px15 > e200) if up else (px15 < e200)))
            if p.min_atr_pct is not None:
                conds.append((f"5m ATR% >= {p.min_atr_pct} (not too quiet)", atr_pct >= p.min_atr_pct))
            if p.max_atr_pct is not None:
                conds.append((f"5m ATR% <= {p.max_atr_pct} (not too volatile)", atr_pct <= p.max_atr_pct))
            if p.use_activity_proxy and p.activity_min_ratio is not None:
                conds.append((f"tick-activity proxy >= {p.activity_min_ratio}", act is not None and act >= p.activity_min_ratio))
            return DirectionEval(side, tuple(n for n, ok in conds if ok), tuple(n for n, ok in conds if not ok),
                                 tuple(bool(ok) for _, ok in conds))

        lg, sh = side_eval(Side.LONG), side_eval(Side.SHORT)
        sig = None
        for ev in (lg, sh):
            if ev.valid:
                sig = Signal(inp.pair, ev.side, inp.as_of, inp.bars_1m[-1].end_ts, True, ev.satisfied, (), tuple(diag))
        return SignalResult(sig, lg, sh, (), tuple(diag))
