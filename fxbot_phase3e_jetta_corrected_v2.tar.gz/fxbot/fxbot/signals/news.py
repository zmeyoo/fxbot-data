"""News-filter interface. A missing provider is NEVER reported as a working filter."""
from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from typing import Protocol, Sequence, Tuple


@dataclass(frozen=True)
class NewsStatus:
    blocked: bool
    protection_active: bool       # False => no real news protection exists
    reason: str


class NewsProvider(Protocol):
    def status(self, pair: str, now: datetime) -> NewsStatus: ...


class NullNewsProvider:
    def status(self, pair: str, now: datetime) -> NewsStatus:
        return NewsStatus(False, False, "no economic-calendar provider connected: NO news protection")


@dataclass(frozen=True)
class ManualBlackoutProvider:
    """Operator-defined blackout windows: (start, end, currencies). Not a calendar feed."""
    windows: Tuple[Tuple[datetime, datetime, Tuple[str, ...]], ...]

    def status(self, pair: str, now: datetime) -> NewsStatus:
        ccys = {pair[:3], pair[3:]}
        for s, e, cs in self.windows:
            if s <= now < e and ccys & set(cs):
                return NewsStatus(True, True, f"manual blackout {s.isoformat()}..{e.isoformat()}")
        return NewsStatus(False, True, "manual blackout policy: no active window")
