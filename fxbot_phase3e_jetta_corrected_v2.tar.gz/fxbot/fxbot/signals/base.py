from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from typing import Tuple

from ..core.types import Side


@dataclass(frozen=True)
class Signal:
    """Output of an entry engine. Built from CLOSED candles only.
    signal_ts  = when the engine decided; market_ts = end time of the newest bar used.
    reasons    = conditions that were satisfied; failed = conditions that were not (explainability).
    diagnostics = indicator values / parameters snapshot as strings (audit)."""
    pair: str
    direction: Side
    signal_ts: datetime
    market_ts: datetime
    valid: bool = True
    reasons: Tuple[str, ...] = ()
    failed: Tuple[str, ...] = ()
    diagnostics: Tuple[Tuple[str, str], ...] = ()
