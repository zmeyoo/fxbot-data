from __future__ import annotations

from dataclasses import dataclass
from decimal import Decimal
from typing import Mapping

from .types import D, FxBotError


class MissingRate(FxBotError):
    pass


@dataclass(frozen=True)
class Money:
    amount: Decimal
    ccy: str


class FxRates:
    """Mid-rate table keyed by pair symbol, e.g. {"EURUSD": 1.1} means 1 EUR = 1.1 USD.
    Resolves direct, inverse, then one-leg triangulation. Never silently returns 1."""

    def __init__(self, mids: Mapping[str, Decimal]):
        self._m = {k: D(v) for k, v in mids.items()}
        if any(v <= 0 for v in self._m.values()):
            raise FxBotError("non-positive FX rate")

    def _direct(self, frm: str, to: str) -> Decimal:
        if frm + to in self._m:
            return self._m[frm + to]
        if to + frm in self._m:
            return Decimal(1) / self._m[to + frm]
        raise MissingRate(f"{frm}->{to}")

    def rate(self, frm: str, to: str) -> Decimal:
        """Units of `to` per 1 unit of `frm`."""
        if frm == to:
            return Decimal(1)
        try:
            return self._direct(frm, to)
        except MissingRate:
            pass
        ccys = {k[:3] for k in self._m} | {k[3:] for k in self._m}
        for mid in sorted(ccys - {frm, to}):
            try:
                return self._direct(frm, mid) * self._direct(mid, to)
            except MissingRate:
                continue
        raise MissingRate(f"no FX rate path {frm}->{to}")

    def convert(self, amount: Decimal, frm: str, to: str) -> Decimal:
        return amount * self.rate(frm, to)
