"""Core value types. Pure: no broker, database or network imports.

Timestamp discipline (spec requirement 10) - distinct clocks, never mixed:
  market_ts   when the venue/IBKR stamped the quote or bar
  received_ts when this process received it
  signal_ts   when the signal engine emitted a decision (CLOSED candles only)
  order_ts    when we submitted an order
  exec_ts     when the broker reports the fill
"""
from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timezone
from decimal import Decimal, getcontext
from enum import Enum

getcontext().prec = 28
ZERO = Decimal(0)
HUNDRED = Decimal(100)


class FxBotError(Exception):
    pass


class InvalidQuote(FxBotError):
    pass


def D(x) -> Decimal:
    """Strict Decimal conversion. Floats are rejected on purpose: money, prices and
    quantities must enter the system as str/int/Decimal."""
    if isinstance(x, Decimal):
        return x
    if isinstance(x, (bool, float)):
        raise TypeError(f"floats/bools are not accepted for money/price values: {x!r}")
    return Decimal(x)


def require_utc(ts: datetime, name: str = "timestamp") -> datetime:
    if ts.tzinfo is None or ts.utcoffset() is None:
        raise FxBotError(f"{name} must be timezone-aware (UTC)")
    return ts.astimezone(timezone.utc)


class Side(str, Enum):
    LONG = "LONG"
    SHORT = "SHORT"

    @property
    def sign(self) -> int:
        return 1 if self is Side.LONG else -1

    @property
    def opposite(self) -> "Side":
        return Side.SHORT if self is Side.LONG else Side.LONG


@dataclass(frozen=True)
class Quote:
    pair: str
    bid: Decimal
    ask: Decimal
    market_ts: datetime
    received_ts: datetime

    def __post_init__(self):
        require_utc(self.market_ts, "market_ts")
        require_utc(self.received_ts, "received_ts")
        if self.bid <= 0 or self.ask <= 0:
            raise InvalidQuote(f"{self.pair}: non-positive price")
        if self.bid > self.ask:
            raise InvalidQuote(f"{self.pair}: crossed quote bid={self.bid} ask={self.ask}")

    @property
    def mid(self) -> Decimal:
        return (self.bid + self.ask) / 2

    @property
    def spread(self) -> Decimal:
        return self.ask - self.bid

    def entry_price(self, side: Side) -> Decimal:
        """Executable price when OPENING: LONG buys the ask, SHORT sells the bid."""
        return self.ask if side is Side.LONG else self.bid

    def exit_price(self, side: Side) -> Decimal:
        """Executable price when CLOSING: LONG sells the bid, SHORT buys the ask."""
        return self.bid if side is Side.LONG else self.ask
