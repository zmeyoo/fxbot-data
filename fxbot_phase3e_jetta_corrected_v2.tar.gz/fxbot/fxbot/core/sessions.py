"""Forex trading-session calendar.

DEFINITION (documented in docs/SESSIONS.md)
  A session starts at 17:00 America/New_York and ends at the next calendar day's 17:00 America/New_York.
  The boundaries are computed in LOCAL time and converted to UTC, so daylight-saving transitions are handled by the
  tz database: 22:00 UTC during EST (winter), 21:00 UTC during EDT (summer). A session that contains a DST change is
  23 h or 25 h long (this only happens on the closed weekend, Sat 17:00 -> Sun 17:00 New York).
  A session is LABELLED by the New York calendar date on which it ENDS (the "NY close" date): the session that opens on
  Sunday 17:00 and closes Monday 17:00 is "Monday". Business sessions are therefore labelled Mon-Fri; the sessions
  labelled Saturday and Sunday contain no trading (market closed Fri 17:00 -> Sun 17:00 New York).
  Nothing here is hard-coded in UTC.
"""
from __future__ import annotations

from dataclasses import dataclass
from datetime import date, datetime, time, timedelta, timezone
from typing import Optional
from zoneinfo import ZoneInfo

from .types import FxBotError, require_utc


@dataclass(frozen=True)
class Session:
    label: date              # NY calendar date on which the session ENDS
    start_utc: datetime
    end_utc: datetime

    @property
    def length(self) -> timedelta:
        return self.end_utc - self.start_utc

    @property
    def is_trading_day(self) -> bool:
        return self.label.weekday() < 5       # Mon-Fri; Sat/Sun sessions are the closed weekend


@dataclass(frozen=True)
class SessionCalendar:
    timezone: str = "America/New_York"
    start_local: str = "17:00"

    def _tz(self) -> ZoneInfo:
        return ZoneInfo(self.timezone)

    def _start_time(self) -> time:
        try:
            h, m = self.start_local.split(":")
            return time(int(h), int(m))
        except Exception as e:
            raise FxBotError(f"bad session start {self.start_local!r}") from e

    def _boundary(self, d: date) -> datetime:
        """UTC instant of the session boundary on local calendar date d (local wall-clock start time)."""
        loc = datetime.combine(d, self._start_time(), tzinfo=self._tz())
        back = loc.astimezone(timezone.utc).astimezone(self._tz())
        if back.replace(tzinfo=None) != loc.replace(tzinfo=None):
            raise FxBotError(f"{self.start_local} does not exist on {d} in {self.timezone} (DST gap); choose another start")
        return loc.astimezone(timezone.utc)

    def session_of(self, ts: datetime) -> Session:
        ts = require_utc(ts, "ts")
        local = ts.astimezone(self._tz())
        d = local.date()
        start_today = self._boundary(d)
        if ts >= start_today:                       # at/after today's boundary: session ends tomorrow
            start, end, label = start_today, self._boundary(d + timedelta(days=1)), d + timedelta(days=1)
        else:
            start, end, label = self._boundary(d - timedelta(days=1)), start_today, d
        return Session(label, start, end)

    def eod_cutoff(self, session: Session, minutes_before_end: int) -> datetime:
        return session.end_utc - timedelta(minutes=minutes_before_end)

    def closure_contains(self, ts: datetime) -> bool:
        """True while the weekly closure (Fri 17:00 -> Sun 17:00 New York) is in force."""
        s = self.session_of(ts)
        return s.label.weekday() in (5, 6)          # sessions labelled Saturday / Sunday

    def next_session_start(self, ts: datetime) -> datetime:
        return self.session_of(ts).end_utc
