"""Cross-check of our indicators against TA-Lib (run where TA-Lib is installed).

We do NOT alter our definitions to force a match. Differences are measured and reported in three
zones: (1) alignment of the first defined index, (2) the warm-up/seed zone, (3) after warm-up, where
smoothed indicators with different seeds must converge. See docs/INDICATOR_CONVENTIONS.md.
"""
from __future__ import annotations

import math
import random
from dataclasses import dataclass
from typing import Callable, Dict, List, Optional, Sequence

from . import core


@dataclass(frozen=True)
class Diff:
    name: str
    first_index_mine: Optional[int]
    first_index_ref: Optional[int]
    max_abs_warmup: Optional[float]        # |diff| over indices before `warmup`
    max_abs_after: Optional[float]         # |diff| over indices >= `warmup`
    warmup: int
    tolerance: float
    defined_mismatch_after: int            # positions after warm-up where only one side is defined

    @property
    def ok(self) -> bool:
        return (self.defined_mismatch_after == 0 and self.max_abs_after is not None
                and self.max_abs_after <= self.tolerance)


def _clean(x) -> List[Optional[float]]:
    return [None if (v is None or (isinstance(v, float) and math.isnan(v))) else float(v) for v in x]


def compare(name: str, mine: Sequence[Optional[float]], ref, warmup: int, tolerance: float) -> Diff:
    ref = _clean(ref)
    fm = next((i for i, v in enumerate(mine) if v is not None), None)
    fr = next((i for i, v in enumerate(ref) if v is not None), None)
    wu, af, mism = [], [], 0
    for i, (a, b) in enumerate(zip(mine, ref)):
        if a is None and b is None:
            continue
        if a is None or b is None:
            if i >= warmup:
                mism += 1
            continue
        (wu if i < warmup else af).append(abs(a - b))
    return Diff(name, fm, fr, max(wu) if wu else None, max(af) if af else None, warmup, tolerance, mism)


def random_ohlc(n: int = 2000, seed: int = 1, base: float = 1.1, step: float = 0.0003):
    rnd, px = random.Random(seed), base
    h, l, c = [], [], []
    for _ in range(n):
        o = px
        px += rnd.uniform(-step, step)
        c.append(px); h.append(max(o, px) + rnd.uniform(0, step / 2)); l.append(min(o, px) - rnd.uniform(0, step / 2))
    return h, l, c


def run_crosscheck(talib, h: Sequence[float], l: Sequence[float], c: Sequence[float]) -> List[Diff]:
    import numpy as np
    H, L, C = (np.asarray(x, dtype="float64") for x in (h, l, c))
    out: List[Diff] = []
    out.append(compare("EMA(20)", core.ema(c, 20), talib.EMA(C, 20), 200, 1e-9))
    out.append(compare("SMA(20)", core.sma(c, 20), talib.SMA(C, 20), 20, 1e-12))
    out.append(compare("RSI(14)", core.rsi(c, 14), talib.RSI(C, 14), 140, 1e-6))
    out.append(compare("ATR(14)", core.atr(h, l, c, 14), talib.ATR(H, L, C, 14), 140, 1e-9))
    a, pdi, mdi = core.adx(h, l, c, 14)
    out.append(compare("ADX(14)", a, talib.ADX(H, L, C, 14), 280, 1e-4))
    out.append(compare("+DI(14)", pdi, talib.PLUS_DI(H, L, C, 14), 140, 1e-4))
    out.append(compare("-DI(14)", mdi, talib.MINUS_DI(H, L, C, 14), 140, 1e-4))
    k, d = core.stochastic(h, l, c, 14, 3, 3)
    sk, sd = talib.STOCH(H, L, C, fastk_period=14, slowk_period=3, slowk_matype=0, slowd_period=3, slowd_matype=0)
    out.append(compare("Stoch %K (14,3,3)", k, sk, 20, 1e-6))
    out.append(compare("Stoch %D (14,3,3)", d, sd, 20, 1e-6))
    m, s, hi = core.macd(c, 12, 26, 9)
    tm, ts, th = talib.MACD(C, fastperiod=12, slowperiod=26, signalperiod=9)
    out.append(compare("MACD line", m, tm, 260, 1e-8))
    out.append(compare("MACD signal", s, ts, 300, 1e-8))
    out.append(compare("MACD histogram", hi, th, 300, 1e-8))
    return out


def render_markdown(diffs: Sequence[Diff]) -> str:
    rows = ["| indicator | first idx (ours / TA-Lib) | max abs diff in warm-up | max abs diff after warm-up | "
            "warm-up | tol | defined-mismatch after | OK |", "|---|---|---|---|---|---|---|---|"]
    f = lambda x: "-" if x is None else f"{x:.3e}"
    for d in diffs:
        rows.append(f"| {d.name} | {d.first_index_mine} / {d.first_index_ref} | {f(d.max_abs_warmup)} | "
                    f"{f(d.max_abs_after)} | {d.warmup} | {d.tolerance:g} | {d.defined_mismatch_after} | "
                    f"{'yes' if d.ok else '**NO - investigate**'} |")
    return "\n".join(rows)


def edge_cases(talib) -> Dict[str, str]:
    """Report (not assert) how each side treats degenerate inputs."""
    import numpy as np
    flat = np.ones(60)
    res = {}
    r = talib.RSI(flat, 14)[-1]
    res["RSI on a perfectly flat series (ours = 50.0)"] = f"TA-Lib {r}"
    k, _ = talib.STOCH(flat, flat, flat, 14, 3, 0, 3, 0)
    res["Stochastic %K with zero high-low range (ours = 50.0)"] = f"TA-Lib {k[-1]}"
    return res
