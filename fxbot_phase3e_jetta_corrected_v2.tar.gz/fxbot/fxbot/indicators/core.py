"""Technical indicators: pure, deterministic, CAUSAL functions on float sequences.

* Output has the same length as the input; warm-up positions are None.
* out[i] depends only on inputs[:i+1] (no look-ahead). Tests assert truncation invariance.
* Conventions (Wilder for RSI/ATR/ADX; EMA seeded with the SMA of the first n values).
* Floats are used here on purpose (indicator maths); money/prices in the position and cost
  layers stay Decimal. Signals convert at the boundary.
"""
from __future__ import annotations

from typing import List, Optional, Sequence, Tuple

Series = List[Optional[float]]


def _check(n: int, name: str = "period") -> None:
    if n < 1:
        raise ValueError(f"{name} must be >= 1")


def sma(values: Sequence[Optional[float]], n: int) -> Series:
    _check(n)
    out: Series = [None] * len(values)
    run = 0                                       # consecutive non-None values ending at i
    for i, v in enumerate(values):
        run = 0 if v is None else run + 1
        if run >= n:
            out[i] = sum(values[i - n + 1:i + 1]) / n      # type: ignore[arg-type]
    return out


def ema(values: Sequence[Optional[float]], n: int) -> Series:
    """EMA with alpha = 2/(n+1); first value = SMA of the first n non-None values."""
    _check(n)
    out: Series = [None] * len(values)
    alpha = 2.0 / (n + 1)
    first = next((i for i, v in enumerate(values) if v is not None), None)
    if first is None or first + n > len(values):
        return out
    seed_idx = first + n - 1
    prev = sum(values[first:first + n]) / n            # type: ignore[arg-type]
    out[seed_idx] = prev
    for i in range(seed_idx + 1, len(values)):
        prev = alpha * values[i] + (1 - alpha) * prev  # type: ignore[operator]
        out[i] = prev
    return out


def rsi(closes: Sequence[float], n: int = 14) -> Series:
    """Wilder RSI. avg_loss == 0: 100 if there were gains, else 50 (flat)."""
    _check(n)
    out: Series = [None] * len(closes)
    if len(closes) <= n:
        return out
    gains = [max(closes[i] - closes[i - 1], 0.0) for i in range(1, len(closes))]
    losses = [max(closes[i - 1] - closes[i], 0.0) for i in range(1, len(closes))]
    ag, al = sum(gains[:n]) / n, sum(losses[:n]) / n

    def val(g: float, l: float) -> float:
        if l == 0:
            return 100.0 if g > 0 else 50.0
        return 100.0 - 100.0 / (1.0 + g / l)

    out[n] = val(ag, al)
    for i in range(n + 1, len(closes)):
        ag = (ag * (n - 1) + gains[i - 1]) / n
        al = (al * (n - 1) + losses[i - 1]) / n
        out[i] = val(ag, al)
    return out


def macd(closes: Sequence[float], fast: int = 12, slow: int = 26, signal: int = 9
         ) -> Tuple[Series, Series, Series]:
    """(macd line, signal line, histogram)."""
    if fast >= slow:
        raise ValueError("fast must be < slow")
    ef, es = ema(closes, fast), ema(closes, slow)
    line: Series = [None if a is None or b is None else a - b for a, b in zip(ef, es)]
    sig = ema(line, signal)
    hist: Series = [None if m is None or s is None else m - s for m, s in zip(line, sig)]
    return line, sig, hist


def true_range(highs: Sequence[float], lows: Sequence[float], closes: Sequence[float]) -> Series:
    out: Series = [None] * len(closes)
    for i in range(len(closes)):
        if i == 0:
            out[i] = highs[0] - lows[0]
        else:
            out[i] = max(highs[i] - lows[i], abs(highs[i] - closes[i - 1]), abs(lows[i] - closes[i - 1]))
    return out


def atr(highs: Sequence[float], lows: Sequence[float], closes: Sequence[float], n: int = 14) -> Series:
    """Wilder ATR: first value = mean of the first n true ranges (index n-1), then Wilder smoothing."""
    _check(n)
    tr = true_range(highs, lows, closes)
    out: Series = [None] * len(closes)
    if len(closes) < n:
        return out
    prev = sum(tr[:n]) / n                              # type: ignore[arg-type]
    out[n - 1] = prev
    for i in range(n, len(closes)):
        prev = (prev * (n - 1) + tr[i]) / n             # type: ignore[operator]
        out[i] = prev
    return out


def adx(highs: Sequence[float], lows: Sequence[float], closes: Sequence[float], n: int = 14
        ) -> Tuple[Series, Series, Series]:
    """Wilder ADX. Returns (adx, +DI, -DI). First DI at index n, first ADX at index 2n-1."""
    _check(n)
    m = len(closes)
    adx_o: Series = [None] * m
    pdi_o: Series = [None] * m
    mdi_o: Series = [None] * m
    if m < 2 * n:
        return adx_o, pdi_o, mdi_o
    tr = true_range(highs, lows, closes)
    pdm, mdm = [0.0] * m, [0.0] * m
    for i in range(1, m):
        up, dn = highs[i] - highs[i - 1], lows[i - 1] - lows[i]
        pdm[i] = up if (up > dn and up > 0) else 0.0
        mdm[i] = dn if (dn > up and dn > 0) else 0.0
    s_tr = sum(tr[1:n + 1])                             # type: ignore[arg-type]
    s_p, s_m = sum(pdm[1:n + 1]), sum(mdm[1:n + 1])
    dx: List[float] = []

    def di(i_tr: float, i_p: float, i_m: float) -> Tuple[float, float, float]:
        if i_tr == 0:
            return 0.0, 0.0, 0.0
        p, q = 100.0 * i_p / i_tr, 100.0 * i_m / i_tr
        d = 0.0 if p + q == 0 else 100.0 * abs(p - q) / (p + q)
        return p, q, d

    p, q, d = di(s_tr, s_p, s_m)
    pdi_o[n], mdi_o[n] = p, q
    dx.append(d)
    for i in range(n + 1, m):
        s_tr = s_tr - s_tr / n + tr[i]                  # type: ignore[operator]
        s_p = s_p - s_p / n + pdm[i]
        s_m = s_m - s_m / n + mdm[i]
        p, q, d = di(s_tr, s_p, s_m)
        pdi_o[i], mdi_o[i] = p, q
        dx.append(d)
        if len(dx) == n:
            adx_o[i] = sum(dx) / n
        elif len(dx) > n:
            adx_o[i] = (adx_o[i - 1] * (n - 1) + d) / n  # type: ignore[operator]
    return adx_o, pdi_o, mdi_o


def stochastic(highs: Sequence[float], lows: Sequence[float], closes: Sequence[float],
               k: int = 14, d: int = 3, smooth: int = 3) -> Tuple[Series, Series]:
    """Slow stochastic: %K = SMA(raw %K, smooth), %D = SMA(%K, d). Zero range => raw %K = 50."""
    raw: Series = [None] * len(closes)
    for i in range(k - 1, len(closes)):
        hh, ll = max(highs[i - k + 1:i + 1]), min(lows[i - k + 1:i + 1])
        raw[i] = 50.0 if hh == ll else 100.0 * (closes[i] - ll) / (hh - ll)
    slow_k = sma(raw, smooth) if smooth > 1 else raw
    return slow_k, sma(slow_k, d)


def activity_ratio(tick_counts: Sequence[float], n: int = 20) -> Series:
    """QUOTE-ACTIVITY PROXY, NOT TRUE VOLUME (spot FX is OTC; no centralised volume).
    Ratio of this bar's tick count to its trailing n-bar average. Optional and off by default."""
    avg = sma(tick_counts, n)
    return [None if a is None or a == 0 else t / a for t, a in zip(tick_counts, avg)]
