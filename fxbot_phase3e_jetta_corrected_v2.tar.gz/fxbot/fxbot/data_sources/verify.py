"""Independent verification of the BI5 decoder assumptions on a LIVE download, before the bulk download starts.

Each assumption is tested separately, with evidence, by code that does NOT reuse decode_bi5():
  1 LZMA container: independent decompressors agree, stream ends cleanly, declared size (if any) equals the real size
  2 20-byte big-endian record structure: size multiple of 20 AND field plausibility (misaligned data is garbage)
  3 price point scaling: generic band + an independent reference level (operator-supplied range and/or the published sample)
  4 BID/ASK field order: field 2 >= field 3 on (almost) every record, spread small and positive
  5 timestamp offsets: ms since hour start, inside the hour, non-decreasing
  6 hour files are UTC and the market closure aligns with Fri 17:00 / Sun 17:00 New York (DST-aware) - catches a timezone shift
  7 volume: interpretation is NOT verifiable from the data; reported as UNCERTAIN with statistics
  8 published two-row sample: exact match is supporting evidence; a mismatch is reported as inconclusive
Any FAIL => stop and report (exit code 5). The decoder is never adjusted to make prices look plausible.
"""
from __future__ import annotations

import json
import lzma
import math
import os
import statistics
import struct
from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone
from decimal import Decimal
from typing import Any, Dict, List, Optional, Sequence, Tuple

from ..core.sessions import SessionCalendar
from .dukascopy import (POINT_VALUES, PRICE_BANDS, DownloadManager, RawStore, f32_text, hour_url, hours_between, pip_size,
                        price_text, sha256_bytes)

THRESH = 0.999                         # fraction of records that must satisfy each structural/plausibility test
BOUNDARY_TOLERANCE_MS = 600_000        # vendor may stop/start up to 10 minutes away from the exact boundary
BOUNDARY_MAX_STRAY_TICKS = 50          # ticks tolerated inside an hour that should be (almost) empty
SAMPLE_HOUR = datetime(2020, 3, 30, 0, tzinfo=timezone.utc)


@dataclass(frozen=True)
class Finding:
    assumption: str
    status: str                        # PASS | FAIL | UNCERTAIN | INFO
    evidence: str


@dataclass
class DecoderVerification:
    findings: List[Finding] = field(default_factory=list)
    hours: List[Dict[str, Any]] = field(default_factory=list)
    cannot_verify: Optional[str] = None

    @property
    def passed(self) -> bool:
        return self.cannot_verify is None and not any(f.status == "FAIL" for f in self.findings)


def plan_verification_hours(start: datetime, end: datetime, cal: Optional[SessionCalendar] = None) -> Dict[str, List[datetime]]:
    cal = cal or SessionCalendar()
    out: Dict[str, List[datetime]] = {"active": [], "closure": [], "reopen": []}
    d = start.replace(hour=0)
    while d < end:                                                        # first Tue-Thu inside the range: three tick-density regimes
        if d.weekday() in (1, 2, 3):
            out["active"] = [d + timedelta(hours=h) for h in (3, 8, 14)]
            break
        d += timedelta(days=1)
    d = start.replace(hour=0)
    while d < end:                                                        # first Friday whose weekend boundary lies inside the range
        if d.weekday() == 4:
            cs = cal.session_of(d + timedelta(hours=12)).end_utc          # Friday 17:00 New York in UTC
            ro = cs
            while cal.closure_contains(ro):
                ro += timedelta(hours=1)
            hs = [cs + timedelta(hours=k) for k in (-1, 0, 1)] + [ro + timedelta(hours=k) for k in (-1, 0, 1)]
            if all(start <= h < end for h in hs):
                out["closure"] = [cs + timedelta(hours=k) for k in (-1, 0, 1)]
                out["reopen"] = [ro + timedelta(hours=k) for k in (-1, 0, 1)]
                break
        d += timedelta(days=1)
    return out


def analyze_raw(raw: bytes, instrument: str) -> Dict[str, Any]:
    """Independent re-parse of one hour file. Never raises: problems are returned as facts."""
    r: Dict[str, Any] = {"bytes": len(raw), "sha256": sha256_bytes(raw)}
    if not raw:
        r["empty"] = True
        return r
    pv = POINT_VALUES[instrument]
    r["header_hex"] = raw[:13].hex()
    if raw[:6] == b"\xfd7zXZ\x00":
        fmt, declared, expl_fmt = "xz", None, lzma.FORMAT_XZ
    else:
        fmt, expl_fmt = "lzma-alone", lzma.FORMAT_ALONE
        r["props_byte"], r["dict_size"] = raw[0], struct.unpack("<I", raw[1:5])[0] if len(raw) >= 5 else None
        declared = struct.unpack("<q", raw[5:13])[0] if len(raw) >= 13 else None
    r["container"], r["declared_size"] = fmt, declared
    try:
        auto = lzma.LZMADecompressor(format=lzma.FORMAT_AUTO)
        data = auto.decompress(raw)
        explicit = lzma.LZMADecompressor(format=expl_fmt)
        data2 = explicit.decompress(raw)
    except lzma.LZMAError as e:
        r["lzma_error"] = str(e)
        return r
    r["lzma_eof"] = bool(auto.eof) and bool(explicit.eof)
    r["decompressors_identical"] = data == data2
    r["decompressed_bytes"] = len(data)
    r["declared_size_ok"] = declared in (None, -1) or declared == len(data)
    r["remainder"] = len(data) % 20
    n = len(data) // 20
    recs = list(struct.iter_unpack(">IIIff", data[: n * 20]))
    r["records"] = n
    if not n:
        return r
    lo, hi = PRICE_BANDS.get(instrument, (Decimal(0), Decimal(10 ** 9)))
    lo, hi = float(lo), float(hi)
    off_ok = sum(1 for t in recs if t[0] < 3_600_000)
    mono = sum(1 for a, b in zip(recs, recs[1:]) if b[0] >= a[0])
    mids = [(t[1] + t[2]) / 2 / pv for t in recs]
    band_ok = sum(1 for m in mids if lo <= m <= hi)
    order_ok = sum(1 for t in recs if t[1] >= t[2])
    spreads = [(t[1] - t[2]) for t in recs]
    vols = [v for t in recs for v in (t[3], t[4])]
    vol_ok = sum(1 for v in vols if math.isfinite(v) and v >= 0)
    r.update({"offset_in_hour_frac": off_ok / n, "monotone_frac": mono / max(n - 1, 1), "price_in_band_frac": band_ok / n,
              "ask_ge_bid_frac": order_ok / n, "median_spread_points": statistics.median(spreads),
              "median_mid": statistics.median(mids), "min_mid": min(mids), "max_mid": max(mids),
              "volume_valid_frac": vol_ok / len(vols), "first_ms": recs[0][0], "last_ms": recs[-1][0],
              "first_ticks": recs[:2], "volume_min": min(vols), "volume_median": statistics.median(vols), "volume_max": max(vols),
              "volume_texts": [f32_text(v) for v in vols[:6]], "volumes_two_decimals_frac": sum(1 for v in vols if len(f32_text(v).split('.')[1]) <= 2) / len(vols)})
    return r


def _frac(xs, key):
    return min((x[key] for x in xs if key in x), default=None)


def verify_decoder(out_dir: str, fetcher, instrument: str, start: datetime, end: datetime, sample_csv: Optional[str] = None,
                   reference_range: Optional[Tuple[float, float]] = None, retries: int = 3, delay_s: float = 0.2,
                   sleep=None, now=None, log=print) -> DecoderVerification:
    import csv, time
    sleep = sleep or time.sleep
    now = now or (lambda: datetime.now(timezone.utc))
    res = DecoderVerification()
    store = RawStore(os.path.join(out_dir, "raw"))
    vstore = RawStore(os.path.join(out_dir, "verify_raw"))
    plan = plan_verification_hours(start, end)
    needed = [h for k in ("active", "closure", "reopen") for h in plan[k]]
    if not plan["active"]:
        res.cannot_verify = "the date range contains no Tuesday-Thursday to sample active hours from"
        return res
    mgr = DownloadManager(fetcher, store, instrument, retries=retries, delay_s=delay_s, sleep=sleep, now=now, log=log)
    for h in sorted(set(needed)):
        s = mgr.run(h, h + timedelta(hours=1))
        if s.aborted or s.errors:
            res.cannot_verify = f"could not download {h:%Y-%m-%d %Hh}: {s.abort_reason or 'request errors'} (nothing was substituted)"
            return res
    info: Dict[datetime, Dict[str, Any]] = {}
    for h in sorted(set(needed)):
        m = store.meta(instrument, h)
        raw = store.read(instrument, h) if m["outcome"] == "ok" else b""
        a = analyze_raw(raw, instrument)
        a["outcome"] = m["outcome"]
        info[h] = a
        res.hours.append({"hour_utc": h.isoformat(), "outcome": m["outcome"], "bytes": a["bytes"], "sha256": a["sha256"] if raw else None,
                          "records": a.get("records")})
    act = [info[h] for h in plan["active"]]
    missing_active = [h for h in plan["active"] if info[h]["outcome"] != "ok"]
    if missing_active:
        res.cannot_verify = f"active hours have no data: {[f'{h:%Y-%m-%d %Hh}' for h in missing_active]} ({[info[h]['outcome'] for h in missing_active]})"
        return res
    add = lambda a, s, e: res.findings.append(Finding(a, s, e))

    # 1. LZMA
    files = [x for x in info.values() if x["bytes"]]
    bad = [x for x in files if "lzma_error" in x or not x.get("lzma_eof") or not x.get("decompressors_identical") or not x.get("declared_size_ok")]
    h0 = act[0]
    add("LZMA container decompresses correctly", "PASS" if not bad else "FAIL",
        f"{len(files)} non-empty files: container {h0.get('container')}, header {h0.get('header_hex')} (props {h0.get('props_byte')}, dict {h0.get('dict_size')}, declared size {h0.get('declared_size')}); "
        f"auto vs explicit decompressor identical, stream ended cleanly, declared size matches real size: "
        f"{'all files' if not bad else f'FAILED on {len(bad)} file(s): ' + str([{k: x.get(k) for k in ('lzma_error', 'lzma_eof', 'decompressors_identical', 'declared_size_ok')} for x in bad][:2])}")
    if any("lzma_error" in x or "remainder" not in x or "median_mid" not in x for x in act):
        why = "not evaluated: an active-hour file did not decompress / contained no records (see the container finding)"
        for name in ("20-byte big-endian record structure", "Price point scaling", "BID/ASK field order", "Timestamp offsets (ms since hour start) and ordering",
                     "Hour files are UTC; closure aligns with Fri 17:00 / Sun 17:00 New York (DST-aware)"):
            add(name, "FAIL", why)
        return res
    # 2. record structure
    rem = [x["remainder"] for x in act]
    s_ok = all(r == 0 for r in rem) and all(x["records"] > 0 for x in act) and (_frac(act, "offset_in_hour_frac") or 0) >= THRESH and (_frac(act, "volume_valid_frac") or 0) >= THRESH
    add("20-byte big-endian record structure (uint32 ms, uint32 ask, uint32 bid, float32 ask vol, float32 bid vol)", "PASS" if s_ok else "FAIL",
        f"active hours: records {[x['records'] for x in act]}, decompressed size mod 20 = {rem}; fraction of records with ms offset inside the hour >= {_frac(act, 'offset_in_hour_frac'):.4f}, "
        f"finite non-negative volumes >= {_frac(act, 'volume_valid_frac'):.4f} (misaligned data would give garbage here); threshold {THRESH}")
    # 3. price scale
    pv = POINT_VALUES[instrument]
    band = PRICE_BANDS.get(instrument)
    band_ok = (_frac(act, "price_in_band_frac") or 0) >= THRESH
    med = statistics.median([x["median_mid"] for x in act])
    ref_ok = None if reference_range is None else (reference_range[0] <= med <= reference_range[1])
    sample_hit = None
    sample_note = "published sample hour not requested"
    samp = _sample_check(vstore, fetcher, instrument, sample_csv, retries, delay_s, sleep, now, log)
    sample_hit, sample_note = samp
    if not band_ok or ref_ok is False:
        st = "FAIL"
    elif ref_ok is True or sample_hit is True:
        st = "PASS"
    else:
        st = "UNCERTAIN"
    add(f"Price point scaling (point value {pv}, {len(str(pv)) - 1} decimals)", st,
        f"decoded median mid {med:.5f} (min {min(x['min_mid'] for x in act):.5f}, max {max(x['max_mid'] for x in act):.5f}); generic band {band}: "
        f"{'ok' if band_ok else 'VIOLATED'}; operator reference range {reference_range}: {'not supplied' if ref_ok is None else ('inside' if ref_ok else 'OUTSIDE')}; {sample_note}"
        + ("; only the generic band could be checked - supply --reference-range from a chart you trust" if st == "UNCERTAIN" else ""))
    # 4. bid/ask order
    ord_ok = (_frac(act, "ask_ge_bid_frac") or 0) >= THRESH and all(0 < x["median_spread_points"] <= 50 for x in act)
    add("BID/ASK field order (field 2 = ask, field 3 = bid)", "PASS" if ord_ok else "FAIL",
        f"fraction of records with field2 >= field3: {[round(x['ask_ge_bid_frac'], 5) for x in act]}; median spread {[x['median_spread_points'] for x in act]} points "
        f"(= {[round(x['median_spread_points'] / pv / float(pip_size(instrument)), 2) for x in act]} pips); threshold {THRESH}")
    # 5. timestamps
    ts_ok = (_frac(act, "offset_in_hour_frac") or 0) >= THRESH and (_frac(act, "monotone_frac") or 0) >= THRESH
    add("Timestamp offsets (ms since hour start) and ordering", "PASS" if ts_ok else "FAIL",
        f"offset inside hour {[round(x['offset_in_hour_frac'], 5) for x in act]}; non-decreasing {[round(x['monotone_frac'], 5) for x in act]}; "
        f"first/last offsets (ms) {[(x['first_ms'], x['last_ms']) for x in act]}")
    # 6. UTC + closure alignment
    if plan["closure"] and plan["reopen"]:
        a0, a1, a2 = (info[h] for h in plan["closure"])
        b0, b1, b2 = (info[h] for h in plan["reopen"])
        stray = lambda x: x.get("records", 0)
        c1 = a0["outcome"] == "ok" and "lzma_error" not in a0 and a0.get("last_ms", 0) >= 3_600_000 - BOUNDARY_TOLERANCE_MS
        c2 = stray(a1) <= BOUNDARY_MAX_STRAY_TICKS and stray(a2) <= BOUNDARY_MAX_STRAY_TICKS
        c3 = stray(b0) <= BOUNDARY_MAX_STRAY_TICKS
        c4 = b1["outcome"] == "ok" and "lzma_error" not in b1 and b1.get("first_ms", 10 ** 9) <= BOUNDARY_TOLERANCE_MS
        add("Hour files are UTC; closure aligns with Fri 17:00 / Sun 17:00 New York (DST-aware)", "PASS" if (c1 and c2 and c3 and c4) else "FAIL",
            f"Friday close {plan['closure'][1]:%Y-%m-%d %H:%M}Z: hour before has ticks until offset {a0.get('last_ms')} ms (need >= {3_600_000 - BOUNDARY_TOLERANCE_MS}): {c1}; "
            f"ticks in the closed hours {stray(a1)}/{stray(a2)} (max {BOUNDARY_MAX_STRAY_TICKS}): {c2}. Sunday reopen {plan['reopen'][1]:%Y-%m-%d %H:%M}Z: ticks in the hour before {stray(b0)}: {c3}; "
            f"first tick of the reopen hour at offset {b1.get('first_ms')} ms (need <= {BOUNDARY_TOLERANCE_MS}): {c4}. A timezone/DST mistake would shift these by whole hours.")
    else:
        add("Hour files are UTC; closure aligns with Fri 17:00 / Sun 17:00 New York (DST-aware)", "UNCERTAIN",
            "the date range does not contain a full Friday-close / Sunday-reopen pair with the neighbouring hours; not checked")
    # 7. volume
    add("Volume interpretation", "UNCERTAIN",
        f"values are finite non-negative float32 (min {min(x['volume_min'] for x in act)}, median {statistics.median([x['volume_median'] for x in act])}, max {max(x['volume_max'] for x in act)}); "
        f"{100 * min(x['volumes_two_decimals_frac'] for x in act):.0f}% have <= 2 decimals; example texts {act[0]['volume_texts']}. UNITS ARE NOT VERIFIABLE from the data "
        "(commonly described as millions of base-currency units, unconfirmed). Volumes are stored as published and are NOT used by the strategy.")
    # 8. sample
    add("Published two-row sample reproduced", "PASS" if sample_hit else "INFO", sample_note)
    return res


def _sample_check(vstore, fetcher, instrument, sample_csv, retries, delay_s, sleep, now, log):
    import csv
    if instrument != "EURUSD" or not sample_csv or not os.path.exists(sample_csv):
        return None, "published sample not requested"
    mgr = DownloadManager(fetcher, vstore, instrument, retries=retries, delay_s=0, sleep=sleep, now=now, log=log)
    s = mgr.run(SAMPLE_HOUR, SAMPLE_HOUR + timedelta(hours=1))
    m = vstore.meta(instrument, SAMPLE_HOUR)
    if s.aborted or s.errors or m is None or m["outcome"] != "ok":
        return None, f"published sample hour (2020-03-30 00h) unavailable (outcome {m['outcome'] if m else 'none'}): no sample comparison"
    a = analyze_raw(vstore.read(instrument, SAMPLE_HOUR), instrument)
    base = int(SAMPLE_HOUR.timestamp() * 1000)
    got = [(base + t[0], price_text(t[1], 100000), price_text(t[2], 100000), f32_text(t[3]), f32_text(t[4])) for t in a.get("first_ticks", [])]
    with open(sample_csv, newline="") as f:
        exp = [(int(r["timestamp"]), r["askPrice"], r["bidPrice"], r["askVolume"], r["bidVolume"]) for r in csv.DictReader(f)]
    if got == exp:
        return True, f"first two ticks of the 2020-03-30 00h file equal the two published records exactly: {exp}"
    return False, f"INCONCLUSIVE: decoded first ticks {got} differ from the published sample {exp} (the sample may come from a different hour/feed; other checks decide)"


def render(res: DecoderVerification, instrument: str, start: datetime, end: datetime, command: str = "") -> str:
    out = [f"# Decoder verification - {instrument} {start:%Y-%m-%d}..{end:%Y-%m-%d}", "",
           "Independent checks of the BI5 decoder assumptions on a live download. **Any FAIL means: stop and report. The decoder is never adapted to make prices look plausible.**", ""]
    if res.cannot_verify:
        out += [f"**VERDICT: CANNOT VERIFY** - {res.cannot_verify}", ""]
    else:
        out += [f"**VERDICT: {'PASSED (UNCERTAIN items remain, see below)' if any(f.status == 'UNCERTAIN' for f in res.findings) else 'PASSED'}**"
                if res.passed else "**VERDICT: FAILED - do not use this data; the decoder assumptions are not confirmed**", ""]
    out += ["| assumption | status | evidence |", "|---|---|---|"]
    out += [f"| {f.assumption} | **{f.status}** | {f.evidence} |" for f in res.findings]
    out += ["", "## Hour files used", "| hour (UTC) | outcome | bytes | records | sha256 |", "|---|---|---|---|---|"]
    out += [f"| {h['hour_utc']} | {h['outcome']} | {h['bytes']} | {h['records']} | {(h['sha256'] or '')[:16]} |" for h in res.hours]
    if command:
        out += ["", f"command: `{command}`"]
    return "\n".join(out) + "\n"


def write_outputs(out_dir: str, res: DecoderVerification, md: str) -> None:
    with open(os.path.join(out_dir, "DECODER_VERIFICATION.md"), "w") as f:
        f.write(md)
    with open(os.path.join(out_dir, "decoder_verification.json"), "w") as f:
        json.dump({"passed": res.passed, "cannot_verify": res.cannot_verify,
                   "findings": [{"assumption": x.assumption, "status": x.status, "evidence": x.evidence} for x in res.findings],
                   "hours": res.hours}, f, indent=1)
