"""Streaming data-quality analysis for a normalised tick CSV (constant memory: works for hundreds of millions of rows).
Everything is computed from the data; thresholds used for PASS/WARN/FAIL are printed in the report."""
from __future__ import annotations

import csv
import heapq
from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone
from decimal import Decimal
from typing import Dict, Iterator, List, Optional, Tuple

from ..backtesting.data import classify_gap
from ..core.sessions import SessionCalendar
from .dukascopy import _EPOCH, pip_size

SPREAD_BIN_PIPS = 0.05
SPREAD_NBINS = 400                     # 0 .. 20 pips; last bin = overflow
IA_EDGES_MS = (0, 10, 50, 100, 250, 500, 1000, 2000, 5000, 10000, 30000, 60000, 120000)


def _dt(ms: int) -> datetime:
    return _EPOCH + timedelta(milliseconds=ms)


@dataclass
class QualityStats:
    instrument: str
    n: int = 0
    first_ms: Optional[int] = None
    last_ms: Optional[int] = None
    crossed: int = 0
    zero_spread: int = 0
    exact_duplicates: int = 0
    order_violations: int = 0
    unchanged_quotes: int = 0
    whole_second_ticks: int = 0
    max_same_ts: int = 0
    closure_quotes: int = 0
    price_min: Optional[Decimal] = None
    price_max: Optional[Decimal] = None
    spread_hist: List[int] = field(default_factory=lambda: [0] * (SPREAD_NBINS + 1))
    spread_sum_pips: float = 0.0
    top_spreads: List[Tuple[float, int]] = field(default_factory=list)
    ia_hist: List[int] = field(default_factory=lambda: [0] * len(IA_EDGES_MS))
    gaps: List[Tuple[int, int, str]] = field(default_factory=list)          # (start_ms, end_ms, class) beyond threshold
    gap_classes: Dict[str, int] = field(default_factory=dict)
    ticks_per_hour: Dict[int, int] = field(default_factory=dict)             # UTC hour index -> ticks
    session_counts: Dict[object, int] = field(default_factory=dict)
    ny_hour_hist: Dict[int, List[int]] = field(default_factory=dict)
    gap_threshold_s: int = 120

    # ---- derived
    def spread_pct(self, q: float) -> Optional[float]:
        tot = sum(self.spread_hist)
        if not tot:
            return None
        target, c = q * tot, 0
        for i, v in enumerate(self.spread_hist):
            c += v
            if c >= target:
                return (i + 0.5) * SPREAD_BIN_PIPS if i < SPREAD_NBINS else float("inf")
        return None


class StreamingQuality:
    def __init__(self, instrument: str, gap_threshold_s: int = 120, calendar: Optional[SessionCalendar] = None):
        self.s = QualityStats(instrument, gap_threshold_s=gap_threshold_s)
        self.cal = calendar or SessionCalendar()
        self.pip = pip_size(instrument)
        self._hour_cache: Dict[int, Tuple[int, object, bool]] = {}
        self._prev: Optional[Tuple[int, Decimal, Decimal]] = None
        self._same_run = 1

    def _hour_info(self, hidx: int) -> Tuple[int, object, bool]:
        v = self._hour_cache.get(hidx)
        if v is None:
            t = _EPOCH + timedelta(hours=hidx)
            v = (t.astimezone(self.cal._tz()).hour, self.cal.session_of(t).label, self.cal.closure_contains(t))
            self._hour_cache[hidx] = v
        return v

    def feed(self, ts: int, ask: Decimal, bid: Decimal) -> None:
        s = self.s
        s.n += 1
        if s.first_ms is None:
            s.first_ms = ts
        s.last_ms = ts if s.last_ms is None or ts > s.last_ms else s.last_ms
        spread = ask - bid
        if spread < 0:
            s.crossed += 1
        else:
            if spread == 0:
                s.zero_spread += 1
            pips = float(spread / self.pip)
            s.spread_sum_pips += pips
            b = min(int(pips / SPREAD_BIN_PIPS), SPREAD_NBINS)
            s.spread_hist[b] += 1
            if len(s.top_spreads) < 5:
                heapq.heappush(s.top_spreads, (pips, ts))
            elif pips > s.top_spreads[0][0]:
                heapq.heapreplace(s.top_spreads, (pips, ts))
        mid = (ask + bid) / 2
        s.price_min = mid if s.price_min is None or mid < s.price_min else s.price_min
        s.price_max = mid if s.price_max is None or mid > s.price_max else s.price_max
        if ts % 1000 == 0:
            s.whole_second_ticks += 1
        hidx = ts // 3_600_000
        ny_h, label, closed = self._hour_info(hidx)
        s.ticks_per_hour[hidx] = s.ticks_per_hour.get(hidx, 0) + 1
        s.session_counts[label] = s.session_counts.get(label, 0) + 1
        if closed:
            s.closure_quotes += 1
        if spread >= 0:
            h = s.ny_hour_hist.setdefault(ny_h, [0] * (SPREAD_NBINS + 1))
            h[min(int(float(spread / self.pip) / SPREAD_BIN_PIPS), SPREAD_NBINS)] += 1
        if self._prev is not None:
            pts, pask, pbid = self._prev
            dt = ts - pts
            if dt < 0:
                s.order_violations += 1
            elif dt == 0:
                self._same_run += 1
                s.max_same_ts = max(s.max_same_ts, self._same_run)
                if (ask, bid) == (pask, pbid):
                    s.exact_duplicates += 1
            else:
                self._same_run = 1
                if (ask, bid) == (pask, pbid):
                    s.unchanged_quotes += 1
                if dt > s.gap_threshold_s * 1000:
                    cls = classify_gap(_dt(pts), _dt(ts), self.cal)
                    s.gap_classes[cls] = s.gap_classes.get(cls, 0) + 1
                    s.gaps.append((pts, ts, cls))
                else:
                    k = max(i for i, e in enumerate(IA_EDGES_MS) if dt >= e)
                    s.ia_hist[k] += 1
        else:
            s.max_same_ts = 1
        self._prev = (ts, ask, bid)


def analyze_csv(path: str, instrument: str, gap_threshold_s: int = 120) -> QualityStats:
    sq = StreamingQuality(instrument, gap_threshold_s)
    with open(path, newline="") as f:
        rd = csv.DictReader(f)
        for r in rd:
            sq.feed(int(r["timestamp"]), Decimal(r["askPrice"]), Decimal(r["bidPrice"]))
    return sq.s


def ny_hour_median(hist: List[int]) -> Optional[float]:
    tot = sum(hist)
    if not tot:
        return None
    c = 0
    for i, v in enumerate(hist):
        c += v
        if c >= tot / 2:
            return (i + 0.5) * SPREAD_BIN_PIPS if i < SPREAD_NBINS else float("inf")
    return None


def render_stats(s: QualityStats) -> str:
    f = lambda x: "n/a" if x is None else ("> 20" if x == float("inf") else f"{x:.2f}")
    mean = s.spread_sum_pips / max(sum(s.spread_hist), 1)
    out = [f"### Spread distribution (pips; percentiles from {SPREAD_BIN_PIPS}-pip bins, so +-{SPREAD_BIN_PIPS / 2} pip)",
           f"mean {mean:.3f} | p1 {f(s.spread_pct(.01))} | p5 {f(s.spread_pct(.05))} | p25 {f(s.spread_pct(.25))} | median {f(s.spread_pct(.5))} | "
           f"p75 {f(s.spread_pct(.75))} | p95 {f(s.spread_pct(.95))} | p99 {f(s.spread_pct(.99))} | p99.9 {f(s.spread_pct(.999))}",
           f"zero-spread quotes {s.zero_spread}; crossed (ask < bid) {s.crossed}; widest 5 spreads (pips @ UTC): "
           + ", ".join(f"{p:.1f} @ {_dt(t):%Y-%m-%d %H:%M:%S}" for p, t in sorted(s.top_spreads, reverse=True)),
           "", "Median spread by New York hour (look for widening around the 17:00 rollover):", "",
           "| NY hour | " + " | ".join(f"{h:02d}" for h in range(24)) + " |", "|---|" + "---|" * 24,
           "| median pips | " + " | ".join(f(ny_hour_median(s.ny_hour_hist.get(h, []))) if h in s.ny_hour_hist else "-" for h in range(24)) + " |",
           "", "### Timestamps and arrival rate",
           f"quotes {s.n}; first {_dt(s.first_ms) if s.first_ms is not None else None}; last {_dt(s.last_ms) if s.last_ms is not None else None}",
           f"timestamp resolution: milliseconds ({s.whole_second_ticks} of {s.n} stamps fall on a whole second = {100 * s.whole_second_ticks / max(s.n, 1):.1f}%; "
           f"~0.1% expected if truly millisecond-resolution); max quotes sharing one timestamp {s.max_same_ts}",
           f"exact duplicates (same ts, ask, bid) {s.exact_duplicates}; out-of-order {s.order_violations}; unchanged re-quotes (same prices, newer ts) {s.unchanged_quotes}",
           "", "Inter-arrival time between consecutive quotes (ms), excluding gaps > threshold:", "",
           "| bin (ms) | " + " | ".join(f"{a}+" for a in IA_EDGES_MS) + " |", "|---|" + "---|" * len(IA_EDGES_MS),
           "| count | " + " | ".join(str(c) for c in s.ia_hist) + " |", "",
           f"### Gaps longer than {s.gap_threshold_s}s",
           "classes: " + (", ".join(f"{k} {v}" for k, v in sorted(s.gap_classes.items())) or "none"), ""]
    longest = sorted(s.gaps, key=lambda g: g[0] - g[1])[:15]
    if longest:
        out += ["| start (UTC) | end (UTC) | duration | class |", "|---|---|---|---|"]
        out += [f"| {_dt(a):%Y-%m-%d %H:%M:%S} | {_dt(b):%Y-%m-%d %H:%M:%S} | {timedelta(milliseconds=b - a)} | {c} |" for a, b, c in longest]
    out += ["", "### Sessions (17:00 America/New_York; label = closing date)", "| session | quotes |", "|---|---|"]
    out += [f"| {k} | {v} |" for k, v in sorted(s.session_counts.items())]
    out.append(f"\nquotes stamped inside the weekly closure (Fri 17:00 - Sun 17:00 New York): {s.closure_quotes}")
    return "\n".join(out)
