"""Command line for the Dukascopy pipeline.   python tools/dukascopy.py <command> ...
Exit codes: 0 ok | 1 dataset FAILED validation | 2 usage / environment not ready | 3 download aborted/incomplete or cannot verify | 4 sample mismatch | 5 decoder assumption FAILED"""
from __future__ import annotations

import argparse
import json
import os
import shlex
import sys
import time
from datetime import datetime, timedelta, timezone
from typing import Callable, List, Optional, Sequence

from .dataset import DATASET_JSON, REPORT_MD, FULL_VALIDATOR_ROW_LIMIT, finalize_dataset, read_manifest
from .dukascopy import (BASE_URL, JETTA_BASE_URL, DownloadManager, NetworkUnavailable, POINT_VALUES, PRICE_BANDS,
                        RawStore, UrllibFetcher, decode_bi5, decode_jetta, expected_closed_hour, f32_text,
                        hour_url, jetta_hour_url, hours_between, merge_normalised_csvs, price_text)

MEASURED_BYTES_PER_QUOTE_IN_MEMORY = 369      # measured in this project's sandbox (Quote with Decimal prices, UTC datetimes)
MEASURED_US_PER_QUOTE_DENSE = 19              # measured on 1-second synthetic quotes, single run, no sweep (indicative only)


def _date(s: str) -> datetime:
    return datetime.strptime(s, "%Y-%m-%d").replace(tzinfo=timezone.utc)


def env_check(fetcher=None, out=print, source="jetta") -> int:
    import lzma, platform
    out(f"python {platform.python_version()} | lzma module: {'available' if lzma else 'MISSING'}")
    f = fetcher or UrllibFetcher(timeout=15)
    url = (jetta_hour_url("EURUSD", datetime(2024, 3, 4, 12, tzinfo=timezone.utc)) if source == "jetta"
           else hour_url("EURUSD", datetime(2020, 3, 30, 0, tzinfo=timezone.utc)))
    try:
        r = f.fetch(url)
    except NetworkUnavailable as e:
        out(f"NOT READY: cannot reach {JETTA_BASE_URL if source == 'jetta' else BASE_URL}\n  exact error: {e}\n  Nothing can be downloaded from this machine. "
            "See docs/DUKASCOPY_RUNBOOK.md for options that do not need a local computer. No data was created or substituted.")
        return 2
    out(f"GET {url} -> HTTP {r.status} (content-length {r.headers.get('content-length')}, content-type {r.headers.get('content-type')}, waf={r.headers.get('x-amzn-waf-action', 'none')})")
    if r.status in (200, 404, 405):
        out(f"READY: {source} endpoint is reachable from this machine.")
        return 0
    if r.status == 202 or "challenge" in r.headers.get("x-amzn-waf-action", "").lower():
        out("NOT READY: Dukascopy AWS WAF returned a challenge (HTTP 202). Check the browser User-Agent, Referer and Origin headers; no data was downloaded.")
    else:
        out(f"NOT READY: unexpected HTTP status {r.status}")
    return 2


def plan(instrument: str, start: datetime, end: datetime, delay_s: float, calibrate: Optional[str], out=print, source="bi5") -> int:
    hours = hours_between(start, end)
    open_h = sum(1 for h in hours if not expected_closed_hour(h))
    out(f"{instrument}: {start:%Y-%m-%d} .. {end:%Y-%m-%d} (end exclusive) = {len(hours)} hourly files, of which {open_h} are in open-market time "
        f"({len(hours) - open_h} expected closed: Fri 17:00 - Sun 17:00 New York)")
    out(f"requests: {len(hours)} (all hours are requested so closures are verified, not assumed); request delay {delay_s}s -> at least {len(hours) * delay_s / 60:.0f} min "
        "of pure waiting plus transfer time (unknown until measured)")
    if calibrate:
        m = read_manifest(calibrate)
        d = os.path.join(calibrate, "raw")
        raw_ext = ".json" if source == "jetta" else ".bi5"
        raw_bytes = sum(os.path.getsize(os.path.join(dp, f)) for dp, _, fs in os.walk(d) for f in fs if f.endswith(raw_ext))
        csv_bytes = os.path.getsize(os.path.join(calibrate, m["normalised"]["path"]))
        ok_hours = m["download"]["hour_outcomes"]["ok"]
        rows = m["normalised"]["rows"]
        if ok_hours:
            rows_h, raw_h, csv_row = rows / ok_hours, raw_bytes / ok_hours, csv_bytes / max(rows, 1)
            R = rows_h * open_h
            out(f"calibration from {calibrate}: {rows_h:,.0f} quotes / ok hour, {raw_h / 1e3:,.0f} kB raw / ok hour, {csv_row:.1f} bytes / CSV row")
            out(f"estimate for this range: ~{R:,.0f} quotes, raw ~{raw_h * open_h / 1e9:.2f} GB, CSV ~{R * csv_row / 1e9:.2f} GB")
            out(f"in-memory research load: ~{R * MEASURED_BYTES_PER_QUOTE_IN_MEMORY / 1e9:.1f} GB (measured {MEASURED_BYTES_PER_QUOTE_IN_MEMORY} bytes/quote); "
                f"one backtest run ~{R * MEASURED_US_PER_QUOTE_DENSE / 1e6 / 60:.0f} min (indicative {MEASURED_US_PER_QUOTE_DENSE} us/quote); "
                f"validator in-memory limit {FULL_VALIDATOR_ROW_LIMIT:,} rows (larger files are sampled)")
            if R * MEASURED_BYTES_PER_QUOTE_IN_MEMORY > 8e9:
                out("WARNING: this range will NOT fit the current in-memory research loader and parameter sweeps would take days. Streaming from disk is "
                    "approved but NOT yet implemented: do not start a large download until the streaming milestone's acceptance tests pass "
                    "(docs/STREAMING_DESIGN.md). Raw data is always kept, so nothing is lost either way.")
    else:
        out("size unknown until a pilot dataset is measured: run the pilot, then `plan --calibrate <pilot dir>` extrapolates quotes, GB, memory and run time")
    return 0


def run_download(args, out=print) -> int:
    start, end = _date(args.start), _date(args.end)
    store = RawStore(os.path.join(args.out, "raw"), source=args.source)
    mgr = DownloadManager(UrllibFetcher(args.timeout), store, args.instrument, retries=args.retries, delay_s=args.sleep, log=out)
    s = mgr.run(start, end, retry_missing=args.retry_missing, max_hours=args.max_hours)
    out(f"download: requested {s.requested_hours}; skipped (already complete) {s.skipped_complete}; fetched {s.fetched}: ok {s.ok}, empty {s.empty}, "
        f"not_found {s.not_found}, errors {s.errors}; corrupt files re-fetched {s.refetched_corrupt}")
    if s.aborted:
        out("ABORTED: " + s.abort_reason)
        return 3
    if s.stopped_by_max_hours:
        out("stopped by --max-hours; re-run the same command to continue (resumable)")
        return 3
    return 3 if s.errors else 0


def run_build(args, out=print) -> int:
    start, end = _date(args.start), _date(args.end)
    argv = getattr(args, "_argv", sys.argv[1:])
    cmd = " ".join(shlex.quote(a) for a in (["python", "tools/dukascopy.py"] + list(argv))) if args.record_command is None else args.record_command
    m = finalize_dataset(args.out, args.instrument, start, end, cmd, gap_threshold_s=args.gap_threshold, source=args.source)
    v = m["validation"]
    out(f"dataset {m['dataset_id']}: {m['normalised']['rows']} rows, CSV SHA-256 {m['normalised']['sha256']}")
    out(f"validation: {v['status']}  ({sum(1 for c in v['checks'] if c['status'] == 'FAIL')} FAIL, {sum(1 for c in v['checks'] if c['status'] == 'WARN')} WARN)")
    for c in v["checks"]:
        if c["status"] in ("FAIL", "WARN"):
            out(f"  {c['status']}: {c['name']}: {c['detail']}")
    out(f"report: {os.path.join(args.out, REPORT_MD)}\nmanifest: {os.path.join(args.out, DATASET_JSON)}")
    return 0 if v["passed"] else 1


def verify_sample(args, sample_csv: str, out=print) -> int:
    """Downloads ONE hour (2020-03-30 00:00 UTC) and compares the first ticks with the published sample records supplied earlier."""
    import csv
    h = datetime(2020, 3, 30, 0, tzinfo=timezone.utc)
    store = RawStore(os.path.join(args.out, "raw_verify"))
    mgr = DownloadManager(UrllibFetcher(args.timeout), store, "EURUSD", retries=args.retries, delay_s=0, log=out)
    s = mgr.run(h, h + timedelta(hours=1))
    if s.aborted or s.errors or s.ok != 1:
        out(f"cannot verify: {s.abort_reason or 'the hour file was not downloaded'} (ok={s.ok}, errors={s.errors}, not_found={s.not_found}, empty={s.empty})")
        return 3
    dec = decode_bi5(store.read("EURUSD", h))
    got = [(h.timestamp() * 1000 + t[0], price_text(t[1], 100000), price_text(t[2], 100000), f32_text(t[3]), f32_text(t[4])) for t in dec.ticks[:2]]
    got = [(int(a), b, c, d, e) for a, b, c, d, e in got]
    with open(sample_csv, newline="") as f:
        exp = [(int(r["timestamp"]), r["askPrice"], r["bidPrice"], r["askVolume"], r["bidVolume"]) for r in csv.DictReader(f)]
    out(f"ticks in the hour file: {len(dec.ticks)}")
    out(f"decoded first two : {got}")
    out(f"published sample  : {exp}")
    if got == exp:
        out("MATCH: URL layout, LZMA/record layout, ask/bid order, point value and volume text all reproduce the published sample.")
        return 0
    out("MISMATCH: the sample may come from a different hour/feed OR the decoder assumptions are wrong. Check that decoded prices are plausible "
        "(~1.11) and spreads small before drawing conclusions; do not use the dataset until this is understood.")
    return 4


def run_verify_decoder(a, out=print) -> int:
    from .verify import render, verify_decoder, write_outputs
    start, end = _date(a.start), _date(a.end)
    rr = None
    if a.reference_range:
        lo, hi = a.reference_range.split(":")
        rr = (float(lo), float(hi))
    os.makedirs(a.out, exist_ok=True)
    res = verify_decoder(a.out, UrllibFetcher(a.timeout), a.instrument, start, end, a.sample, rr, a.retries, a.sleep, log=out)
    cmd = " ".join(shlex.quote(x) for x in ["python", "tools/dukascopy.py"] + list(getattr(a, "_argv", sys.argv[1:])))
    md = render(res, a.instrument, start, end, cmd)
    write_outputs(a.out, res, md)
    out(md)
    if res.cannot_verify:
        out("CANNOT VERIFY: " + res.cannot_verify)
        return 3
    if not res.passed:
        out("STOP: at least one decoder assumption FAILED. Nothing was adapted. Report this and do not download further.")
        return 5
    return 0


def _verify_jetta_checks(a, out=print) -> int:
    """Smoke-test JETTA on several weekdays and cross-check the known BI5 anchor hour."""
    from decimal import Decimal
    start, end = _date(a.start), _date(a.end)
    fetcher = UrllibFetcher(a.timeout)
    candidates = []
    days = []
    d = start.date()
    while d < end.date():
        if d.weekday() < 5:
            days.append(d)
        d += timedelta(days=1)
    if not days:
        out("CANNOT VERIFY: requested range contains no weekdays")
        return 3
    for idx in sorted(set((0, len(days) // 2, len(days) - 1))):
        candidates.append(datetime(days[idx].year, days[idx].month, days[idx].day, 12, tzinfo=timezone.utc))
    # The diagnostic's independently checked hour is a fixed regression anchor.
    anchor = datetime(2024, 3, 4, 12, tzinfo=timezone.utc)
    if start <= anchor < end and anchor not in candidates:
        candidates.append(anchor)
    lo, hi = PRICE_BANDS[a.instrument]
    for hour in candidates:
        url = jetta_hour_url(a.instrument, hour)
        try:
            response = fetcher.fetch(url)
        except Exception as e:
            out(f"FAIL {hour:%Y-%m-%d %H}Z: {e}")
            return 3
        if response.status != 200:
            out(f"FAIL {hour:%Y-%m-%d %H}Z: HTTP {response.status}")
            return 3
        try:
            dec = decode_jetta(response.body, a.instrument)
        except Exception as e:
            out(f"FAIL {hour:%Y-%m-%d %H}Z: JETTA response failed schema/decoder checks: {e}")
            return 5
        if not dec.ticks:
            out(f"FAIL {hour:%Y-%m-%d %H}Z: no ticks returned for a weekday noon hour")
            return 3
        offsets = [t[0] for t in dec.ticks]
        prices = [Decimal(t[1]).scaleb(-(len(str(POINT_VALUES[a.instrument])) - 1)) for t in dec.ticks]
        prices += [Decimal(t[2]).scaleb(-(len(str(POINT_VALUES[a.instrument])) - 1)) for t in dec.ticks]
        if offsets != sorted(offsets) or offsets[0] < 0 or offsets[-1] >= 3_600_000:
            out(f"FAIL {hour:%Y-%m-%d %H}Z: timestamp deltas are not ordered or escape the requested hour")
            return 5
        if any(t[1] < t[2] or t[1] <= 0 or t[2] <= 0 for t in dec.ticks):
            out(f"FAIL {hour:%Y-%m-%d %H}Z: crossed or non-positive quotes")
            return 5
        if min(prices) < lo or max(prices) > hi:
            out(f"FAIL {hour:%Y-%m-%d %H}Z: prices {min(prices)}..{max(prices)} outside {lo}..{hi}")
            return 5
        out(f"PASS {hour:%Y-%m-%d %H}Z: {len(dec.ticks)} ticks; price range {min(prices)}..{max(prices)}")

    # Cross-source parity for the EURUSD anchor hour. BI5 is fetched from the
    # www host because the legacy datafeed host may be unreachable from runners.
    if a.instrument == "EURUSD":
        url = "https://www.dukascopy.com/datafeed/EURUSD/2024/02/04/12h_ticks.bi5"
        try:
            jres = fetcher.fetch(jetta_hour_url("EURUSD", anchor))
            bres = fetcher.fetch(url)
            if jres.status == 200 and bres.status == 200:
                jd = decode_jetta(jres.body, "EURUSD")
                bd = decode_bi5(bres.body)
                base = int(anchor.timestamp() * 1000)
                jrows = [(base + t[0], price_text(t[1], 100000), price_text(t[2], 100000), f32_text(t[3]), f32_text(t[4])) for t in jd.ticks]
                brows = [(base + t[0], price_text(t[1], 100000), price_text(t[2], 100000), f32_text(t[3]), f32_text(t[4])) for t in bd.ticks]
                if jrows != brows:
                    out(f"FAIL cross-source parity: JETTA {len(jrows)} vs BI5 {len(brows)}; first mismatch is not accepted")
                    return 5
                out(f"PASS cross-source parity: all {len(jrows)} EURUSD ticks match BI5 exactly (timestamp, BID, ASK, volume)")
            else:
                out(f"WARN cross-source parity unavailable: JETTA HTTP {jres.status}, www BI5 HTTP {bres.status}; JETTA structural checks passed")
        except Exception as e:
            out(f"WARN cross-source parity unavailable: {e}; JETTA structural checks passed")
    out("JETTA verification passed. This is a source/decoder check, not a claim that the requested full dataset is complete.")
    return 0


def verify_jetta(a, out=print) -> int:
    messages = []
    rc = _verify_jetta_checks(a, messages.append)
    for line in messages:
        out(line)
    if a.out:
        os.makedirs(a.out, exist_ok=True)
        payload = {"provider": "jetta", "passed": rc == 0, "exit_code": rc,
                   "instrument": a.instrument, "range_utc": {"start": a.start, "end_exclusive": a.end},
                   "findings": messages}
        with open(os.path.join(a.out, "decoder_verification.json"), "w") as f:
            json.dump(payload, f, indent=2)
        with open(os.path.join(a.out, "DECODER_VERIFICATION.md"), "w") as f:
            f.write("# JETTA decoder verification\n\n")
            f.write("Verdict: **PASSED**\n\n" if rc == 0 else "Verdict: **FAILED / NOT VERIFIED**\n\n")
            f.write("This report checks representative live JETTA hours, timestamp/price structure, plausible instrument price bands, "
                    "and exact BI5 parity for the EURUSD reference hour when both endpoints are reachable.\n\n")
            f.write("\n".join(f"- {m}" for m in messages) + "\n")
    return rc


def main(argv: Optional[Sequence[str]] = None, out=print) -> int:
    ap = argparse.ArgumentParser(prog="dukascopy", description="Reproducible Dukascopy tick downloader + validator")
    sub = ap.add_subparsers(dest="cmd", required=True)

    def common(p, need_dates=True):
        p.add_argument("--instrument", default="EURUSD", choices=sorted(POINT_VALUES))
        if need_dates:
            p.add_argument("--start", required=True, help="UTC date YYYY-MM-DD (inclusive)")
            p.add_argument("--end", required=True, help="UTC date YYYY-MM-DD (exclusive)")
    p = sub.add_parser("env-check"); p.add_argument("--source", choices=("bi5", "jetta"), default="jetta")
    p = sub.add_parser("plan"); common(p); p.add_argument("--source", choices=("bi5", "jetta"), default="bi5"); p.add_argument("--sleep", type=float, default=0.2); p.add_argument("--calibrate")
    for name in ("download", "build", "run"):
        p = sub.add_parser(name); common(p); p.add_argument("--out", required=True)
        p.add_argument("--source", choices=("bi5", "jetta"), default="bi5")
        p.add_argument("--sleep", type=float, default=0.2); p.add_argument("--retries", type=int, default=4); p.add_argument("--timeout", type=float, default=30)
        p.add_argument("--retry-missing", action="store_true", help="re-request hours previously answered 404"); p.add_argument("--max-hours", type=int)
        p.add_argument("--gap-threshold", type=int, default=120); p.add_argument("--record-command", default=None)
    p = sub.add_parser("verify-sample"); p.add_argument("--out", required=True); p.add_argument("--timeout", type=float, default=30); p.add_argument("--retries", type=int, default=3)
    p.add_argument("--sample", default=os.path.join(os.path.dirname(__file__), "..", "..", "tests", "data", "eurusd_dukascopy_published_sample_ticks.csv"))
    p = sub.add_parser("verify-decoder"); common(p); p.add_argument("--out", required=True)
    p.add_argument("--reference-range", help="LO:HI independent price level you trust for this period, e.g. 1.05:1.12")
    p.add_argument("--sample", default=os.path.join(os.path.dirname(__file__), "..", "..", "tests", "data", "eurusd_dukascopy_published_sample_ticks.csv"))
    p.add_argument("--sleep", type=float, default=0.2); p.add_argument("--retries", type=int, default=3); p.add_argument("--timeout", type=float, default=30)
    p = sub.add_parser("verify-jetta"); common(p); p.add_argument("--out", required=False); p.add_argument("--timeout", type=float, default=30)
    p = sub.add_parser("merge"); p.add_argument("--inputs", nargs="+", required=True); p.add_argument("--out", required=True)
    a = ap.parse_args(argv)
    a._argv = list(argv if argv is not None else sys.argv[1:])

    if a.cmd == "env-check":
        return env_check(out=out, source=a.source)
    if a.cmd == "plan":
        return plan(a.instrument, _date(a.start), _date(a.end), a.sleep, a.calibrate, out, source=a.source)
    if a.cmd == "verify-sample":
        return verify_sample(a, a.sample, out)
    if a.cmd == "verify-decoder":
        return run_verify_decoder(a, out)
    if a.cmd == "verify-jetta":
        return verify_jetta(a, out)
    if a.cmd == "merge":
        n, d = merge_normalised_csvs(a.inputs, a.out)
        out(f"merged {len(a.inputs)} files -> {a.out}: {n} rows, {d} exact duplicates dropped")
        return 0
    if a.cmd == "download":
        return run_download(a, out)
    if a.cmd == "build":
        return run_build(a, out)
    rc = run_download(a, out)                         # run = download + build + validate
    if rc != 0:
        out("not building: the download is incomplete. Fix the cause and re-run (it resumes).")
        return rc
    return run_build(a, out)
