"""Forex cash-balance and currency-exposure controls (decision 1A).

IBKR FX positions are currency balances. BUY EURUSD: +EUR, -USD. SELL EURUSD: -EUR, +USD.
Strategy positions (ours) are NOT the same thing as broker balances: this module only
reasons about balances, and reconciliation compares them with what the broker reports.

Classification of an order that OPENS exposure:
  FUNDED_LONG              quote-currency cash covers notional + buffer + commission
  SHORT_FROM_HOLDINGS      SELL covered by base currency actually held
  AUTHORISED_SHORT_BORROW  SELL that makes the base balance negative, inside the explicit floor
  REJECTED                 anything else (incl. an unfunded LONG = unintended borrowing)
Closing orders are reduce-only and never blocked by funding rules.
Short-sale proceeds are tracked as LOCKED and never counted as available cash.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from decimal import Decimal
from enum import Enum
from typing import Dict, Iterable, List, Mapping, Optional, Tuple

from ..config.schema import GlobalConfig
from ..core.money import FxRates
from ..core.types import HUNDRED, ZERO, Side
from ..instruments.spec import PairSpec


class OrderClass(str, Enum):
    CLOSING = "CLOSING"
    FUNDED_LONG = "FUNDED_LONG"
    SHORT_FROM_HOLDINGS = "SHORT_FROM_HOLDINGS"
    AUTHORISED_SHORT_BORROW = "AUTHORISED_SHORT_BORROW"
    REJECTED = "REJECTED"


def action_for(side: Side, closing: bool) -> str:
    buy = (side is Side.LONG) != closing
    return "BUY" if buy else "SELL"


def balance_effect(spec: PairSpec, action: str, qty: Decimal, price: Decimal) -> Dict[str, Decimal]:
    s = Decimal(1) if action == "BUY" else Decimal(-1)
    return {spec.base: s * qty, spec.quote: -s * qty * price}


@dataclass
class CurrencyLedger:
    balances: Dict[str, Decimal] = field(default_factory=dict)          # actual broker cash by ccy
    locked_short_proceeds: Dict[str, Decimal] = field(default_factory=dict)

    def bal(self, ccy: str) -> Decimal:
        return self.balances.get(ccy, ZERO)

    def available_cash(self, ccy: str) -> Decimal:
        """Own cash that may fund a LONG: balance minus locked short proceeds, never negative."""
        return max(ZERO, self.bal(ccy) - self.locked_short_proceeds.get(ccy, ZERO))


@dataclass(frozen=True)
class FundingDecision:
    allowed: bool
    classification: OrderClass
    reasons: Tuple[str, ...]
    projected_balances: Mapping[str, Decimal]
    notes: Tuple[str, ...] = ()


def check_order_funding(*, spec: PairSpec, side: Side, qty: Decimal, price: Decimal, closing: bool,
                        ledger: CurrencyLedger, gcfg: GlobalConfig, commission_quote: Decimal,
                        rates: FxRates, current_short_notional_base: Decimal = ZERO,
                        margin_util_after_pct: Optional[Decimal] = None,
                        financing_estimate_quote: Optional[Decimal] = None) -> FundingDecision:
    action = action_for(side, closing)
    eff = balance_effect(spec, action, qty, price)
    projected = {c: ledger.bal(c) + eff.get(c, ZERO) for c in set(ledger.balances) | set(eff)}
    notes: List[str] = []
    if closing:
        return FundingDecision(True, OrderClass.CLOSING, (), projected, ("reduce-only order",))
    reasons: List[str] = []
    if gcfg.allow_auto_conversion:
        reasons.append("allow_auto_conversion is not implemented in v1 and must stay disabled")

    if side is Side.LONG:
        if gcfg.min_cash_buffer_pct is None:
            reasons.append("min_cash_buffer_pct not configured")
        else:
            need = qty * price * (1 + gcfg.min_cash_buffer_pct / HUNDRED) + commission_quote
            have = ledger.available_cash(spec.quote)
            if have < need:
                reasons.append(f"UNINTENDED BORROWING: LONG needs {need:.2f} {spec.quote} of own cash "
                               f"(incl. buffer+commission), available {have:.2f}")
        cls = OrderClass.FUNDED_LONG
    else:
        if not gcfg.shorts_enabled:
            reasons.append("shorts disabled in configuration")
        base_after = projected[spec.base]
        floor = gcfg.currency_floors.get(spec.base, ZERO)
        if base_after < floor:
            reasons.append(f"{spec.base} balance after order {base_after:.2f} below floor {floor}")
        borrowing = base_after < 0
        cls = OrderClass.AUTHORISED_SHORT_BORROW if borrowing else OrderClass.SHORT_FROM_HOLDINGS
        if borrowing:
            if gcfg.max_short_notional_base is None:
                reasons.append("max_short_notional_base not configured")
            else:
                new_notional = rates.convert(qty, spec.base, gcfg.base_currency)
                if current_short_notional_base + new_notional > gcfg.max_short_notional_base:
                    reasons.append("max short notional exceeded")
            if gcfg.max_margin_utilisation_pct is None:
                reasons.append("max_margin_utilisation_pct not configured")
            elif margin_util_after_pct is None:
                reasons.append("margin what-if result unavailable; cannot verify margin utilisation")
            elif margin_util_after_pct > gcfg.max_margin_utilisation_pct:
                reasons.append(f"margin utilisation after order {margin_util_after_pct}% > "
                               f"{gcfg.max_margin_utilisation_pct}%")
            notes.append(f"creates negative {spec.base} balance {base_after:.2f}: borrowing + financing apply")
            notes.append("estimated financing: " + (f"{financing_estimate_quote:.2f} {spec.quote}"
                         if financing_estimate_quote is not None else "unavailable (no reliable rates)"))
    # every touched currency must stay above its floor (default floor 0 => no implicit borrowing)
    for ccy, bal in projected.items():
        if ccy in eff and eff[ccy] < 0:
            fl = gcfg.currency_floors.get(ccy, ZERO)
            if bal < fl and not (side is Side.SHORT and ccy == spec.base):  # base floor handled above
                reasons.append(f"{ccy} projected balance {bal:.2f} below floor {fl}")
    ok = not reasons
    return FundingDecision(ok, cls if ok else OrderClass.REJECTED, tuple(reasons), projected, tuple(notes))


# --------------------------------------------------------- per-currency exposure
Pos = Tuple[PairSpec, Side, Decimal, Decimal]      # (spec, side, qty_base_units, price)


def net_exposure_by_ccy(positions: Iterable[Pos], rates: FxRates, base_ccy: str) -> Dict[str, Decimal]:
    out: Dict[str, Decimal] = {}
    for spec, side, qty, px in positions:
        s = Decimal(side.sign)
        out[spec.base] = out.get(spec.base, ZERO) + s * rates.convert(qty, spec.base, base_ccy)
        out[spec.quote] = out.get(spec.quote, ZERO) - s * rates.convert(qty * px, spec.quote, base_ccy)
    return out


def check_currency_exposure(current: Iterable[Pos], new: Pos, rates: FxRates,
                            gcfg: GlobalConfig) -> List[str]:
    """Absolute NET exposure per currency (base-equivalent) after the new position must stay
    within the per-currency limit. Missing limit => reject."""
    after = net_exposure_by_ccy([*current, new], rates, gcfg.base_currency)
    out = []
    for ccy in (new[0].base, new[0].quote):
        lim = gcfg.max_currency_exposure_base.get(ccy)
        if lim is None:
            out.append(f"max_currency_exposure_base[{ccy}] not configured")
        elif abs(after.get(ccy, ZERO)) > lim:
            out.append(f"{ccy} net exposure {abs(after[ccy]):.0f} > limit {lim}")
    return out


# --------------------------------------------------------- balance reconciliation
@dataclass(frozen=True)
class Discrepancy:
    ccy: str
    expected: Decimal
    actual: Decimal

    @property
    def diff(self) -> Decimal:
        return self.actual - self.expected


class ExpectedBalances:
    """Balances the bot expects, built from a trusted snapshot plus every fill, commission,
    financing item and cash movement it knows about."""

    def __init__(self, snapshot: Mapping[str, Decimal]):
        self._b: Dict[str, Decimal] = dict(snapshot)

    def _add(self, ccy: str, amt: Decimal) -> None:
        self._b[ccy] = self._b.get(ccy, ZERO) + amt

    def apply_fill(self, spec: PairSpec, action: str, qty: Decimal, price: Decimal,
                   commission: Decimal = ZERO, commission_ccy: Optional[str] = None) -> None:
        for c, a in balance_effect(spec, action, qty, price).items():
            self._add(c, a)
        if commission:
            self._add(commission_ccy or spec.quote, -commission)

    def apply_cash(self, ccy: str, amount: Decimal) -> None:      # financing, deposits, fees
        self._add(ccy, amount)

    def expected(self) -> Dict[str, Decimal]:
        return dict(self._b)


def detect_discrepancies(expected: Mapping[str, Decimal], actual: Mapping[str, Decimal],
                         tolerance: Mapping[str, Decimal], default_tolerance: Decimal) -> List[Discrepancy]:
    out = []
    for ccy in sorted(set(expected) | set(actual)):
        e, a = expected.get(ccy, ZERO), actual.get(ccy, ZERO)
        if abs(a - e) > tolerance.get(ccy, default_tolerance):
            out.append(Discrepancy(ccy, e, a))
    return out
