"""Account-level risk governor. It can VETO entries; it never creates orders and has no
function that increases size after losses."""
from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timedelta
from decimal import Decimal
from typing import Dict, List, Optional, Tuple

from ..config.schema import GlobalConfig, PairConfig
from ..core.types import HUNDRED, ZERO
from ..position_manager.position import TradeRecord


@dataclass(frozen=True)
class RiskDecision:
    allowed: bool
    reasons: Tuple[str, ...]


@dataclass
class RiskGovernor:
    gcfg: GlobalConfig
    session_start_equity: Decimal = ZERO
    peak_equity: Decimal = ZERO
    realised_today_base: Decimal = ZERO
    consecutive_losses: int = 0
    loss_cooldown_until: Optional[datetime] = None
    trades_by_pair: Dict[str, int] = field(default_factory=dict)
    reversals_by_pair: Dict[str, int] = field(default_factory=dict)
    open_risk_base: Dict[str, Decimal] = field(default_factory=dict)       # position id -> risk
    open_pairs: Dict[str, str] = field(default_factory=dict)               # pair -> position id
    kill_switch: bool = False
    lockout_reason: Optional[str] = None

    def start_session(self, equity_base: Decimal) -> None:
        self.session_start_equity = self.peak_equity = equity_base
        self.realised_today_base = ZERO
        self.consecutive_losses = 0
        self.loss_cooldown_until = None
        self.trades_by_pair.clear(); self.reversals_by_pair.clear()
        self.lockout_reason = None

    # ---- state feeds
    def register_open(self, position_id: str, pair: str, risk_base: Decimal, is_reversal: bool) -> None:
        self.open_risk_base[position_id] = risk_base
        self.open_pairs[pair] = position_id
        self.trades_by_pair[pair] = self.trades_by_pair.get(pair, 0) + 1
        if is_reversal:
            self.reversals_by_pair[pair] = self.reversals_by_pair.get(pair, 0) + 1

    def on_trade_closed(self, rec: TradeRecord, now: datetime) -> None:
        self.open_risk_base.pop(rec.position_id, None)
        if self.open_pairs.get(rec.pair) == rec.position_id:
            del self.open_pairs[rec.pair]
        self.realised_today_base += rec.net_pnl_base
        if rec.net_pnl_base < 0:
            self.consecutive_losses += 1
            if self.consecutive_losses >= self.gcfg.max_consecutive_losses \
                    and self.gcfg.loss_streak_cooldown_minutes is not None:
                self.loss_cooldown_until = now + timedelta(minutes=self.gcfg.loss_streak_cooldown_minutes)
        else:
            self.consecutive_losses = 0

    def update_equity(self, equity_base: Decimal) -> None:
        """Feed current equity (includes unrealised P&L). Sets a sticky lockout on breach."""
        self.peak_equity = max(self.peak_equity, equity_base)
        if self.lockout_reason:
            return
        loss_pct = (self.session_start_equity - equity_base) / self.session_start_equity * HUNDRED
        if loss_pct >= self.gcfg.max_daily_loss_pct:
            self.lockout_reason = f"daily loss {loss_pct:.2f}% >= {self.gcfg.max_daily_loss_pct}%"
        elif self.gcfg.max_daily_drawdown_pct is not None:
            dd = (self.peak_equity - equity_base) / self.peak_equity * HUNDRED
            if dd >= self.gcfg.max_daily_drawdown_pct:
                self.lockout_reason = f"daily drawdown {dd:.2f}% >= {self.gcfg.max_daily_drawdown_pct}%"

    # ---- veto
    def check_new_entry(self, pair: str, cfg: PairConfig, risk_base: Decimal, equity_base: Decimal,
                        now: datetime, is_reversal: bool) -> RiskDecision:
        r: List[str] = []
        g = self.gcfg
        if self.kill_switch:
            r.append("emergency stop active")
        if self.lockout_reason:
            r.append(f"risk lockout: {self.lockout_reason}")
        if self.consecutive_losses >= g.max_consecutive_losses:
            if self.loss_cooldown_until is None:
                r.append("max consecutive losses reached and no cooldown configured")
            elif now < self.loss_cooldown_until:
                r.append(f"loss-streak cooldown until {self.loss_cooldown_until.isoformat()}")
        if pair in self.open_pairs:
            r.append(f"{pair} already has an open strategy position (v1: one per pair)")
        if g.max_open_positions is None:
            r.append("max_open_positions not configured")
        elif len(self.open_pairs) >= g.max_open_positions:
            r.append("max simultaneous positions reached")
        if g.max_total_open_risk_pct is None:
            r.append("max_total_open_risk_pct not configured")
        else:
            total = sum(self.open_risk_base.values(), ZERO) + risk_base
            if total > equity_base * g.max_total_open_risk_pct / HUNDRED:
                r.append("total open risk limit exceeded")
        if cfg.max_trades_session is not None and self.trades_by_pair.get(pair, 0) >= cfg.max_trades_session:
            r.append(f"{pair}: max trades per session reached")
        if is_reversal and self.reversals_by_pair.get(pair, 0) >= cfg.max_reversals_session:
            r.append(f"{pair}: max reversals per session reached")
        return RiskDecision(not r, tuple(r))
