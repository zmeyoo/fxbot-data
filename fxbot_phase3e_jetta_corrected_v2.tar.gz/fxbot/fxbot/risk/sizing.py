from __future__ import annotations

from dataclasses import dataclass
from decimal import Decimal
from typing import List, Optional, Tuple

from ..config.schema import PairConfig
from ..core.types import HUNDRED, ZERO, Quote, Side
from ..costs.model import CostContext
from ..instruments.spec import PairSpec


@dataclass(frozen=True)
class SizingResult:
    qty: Decimal
    approved: bool
    reasons: Tuple[str, ...]
    explanation: Tuple[str, ...]
    risk_budget_quote: Decimal = ZERO
    worst_case_loss_quote: Decimal = ZERO


def size_position(*, side: Side, quote: Quote, spec: PairSpec, cfg: PairConfig, ctx: CostContext,
                  equity_base: Decimal, remaining_total_risk_base: Optional[Decimal] = None,
                  long_cash_quote: Optional[Decimal] = None,
                  cash_buffer_pct: Optional[Decimal] = None,
                  short_qty_cap: Optional[Decimal] = None) -> SizingResult:
    """Risk-based size. Worst case at the stop = stop distance + exit slippage + both commissions
    (entry spread/slippage are already inside the expected fill price). Gaps can exceed this:
    a stop is not a guaranteed maximum loss. Margin buying power is never used to enlarge size."""
    ex: List[str] = []
    for n in ("risk_per_trade_pct", "est_slippage_pct", "max_notional_base"):
        if getattr(cfg, n) is None:
            return SizingResult(ZERO, False, (f"{cfg.symbol}.{n} not configured",), ())
    sgn = Decimal(side.sign)
    slip = cfg.est_slippage_pct
    p0 = quote.entry_price(side) * (1 + sgn * slip / HUNDRED)
    budget_base = equity_base * cfg.risk_per_trade_pct / HUNDRED
    if remaining_total_risk_base is not None:
        budget_base = min(budget_base, max(ZERO, remaining_total_risk_base))
    budget = ctx.rates.convert(budget_base, ctx.base_ccy, spec.quote)
    ex.append(f"equity {equity_base} {ctx.base_ccy} x {cfg.risk_per_trade_pct}% (capped by remaining "
              f"open-risk budget) = {budget_base:.2f} {ctx.base_ccy} = {budget:.2f} {spec.quote}")
    per_unit = p0 * (cfg.initial_stop_pct + slip) / HUNDRED
    ex.append(f"loss per unit at stop = P0 {p0:.5f} x (stop {cfg.initial_stop_pct}% + exit slippage {slip}%)"
              f" = {per_unit:.8f}")

    def worst(q: Decimal) -> Decimal:
        return q * per_unit + 2 * ctx.commission_quote(q, p0, spec.quote)

    qty = spec.floor_qty(budget / per_unit)
    for _ in range(60):
        if qty <= 0:
            break
        w = worst(qty)
        if w <= budget:
            break
        nq = spec.floor_qty(qty * budget / w)
        qty = nq if nq < qty else spec.floor_qty(qty - spec.qty_step)
    ex.append(f"after commissions (minimums included) quantity = {qty}")
    caps = []
    notional_cap = spec.floor_qty(ctx.rates.convert(cfg.max_notional_base, ctx.base_ccy, spec.quote) / p0)
    caps.append(("max_notional cap", notional_cap))
    if side is Side.LONG and long_cash_quote is not None and cash_buffer_pct is not None:
        c = long_cash_quote / (p0 * (1 + cash_buffer_pct / HUNDRED))
        c = spec.floor_qty(c - (2 * ctx.commission_quote(max(qty, spec.min_qty), p0, spec.quote)) / p0)
        caps.append(("own-cash cap (LONG)", c))
    if side is Side.SHORT and short_qty_cap is not None:
        caps.append(("authorised short-borrow cap (currency floor / short notional)", spec.floor_qty(short_qty_cap)))
    for name, cap in caps:
        if cap < qty:
            ex.append(f"{name} reduces quantity {qty} -> {cap}")
            qty = cap
    if qty < spec.min_qty or qty <= 0:
        return SizingResult(ZERO, False, ("risk budget/caps too small for the minimum order size",),
                            tuple(ex), budget, ZERO)
    w = worst(qty)
    ex.append(f"final quantity {qty}; worst-case loss at stop {w:.2f} {spec.quote} <= budget {budget:.2f}")
    return SizingResult(qty, True, (), tuple(ex), budget, w)
