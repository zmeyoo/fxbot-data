"""Closed-candle bar building. A bar is emitted ONLY when it is closed (next bucket started, or
flush(now) after its end). Signals never see a forming candle.

Bars are built from the MID of bid/ask for signal purposes (A-16); execution, stops and costs always
use the executable bid/ask. `ticks` is a quote-activity count (a proxy, not true FX volume).
"""
from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from typing import List, Optional, Sequence

from ..core.types import FxBotError, Quote, require_utc

_EPOCH = datetime(1970, 1, 1, tzinfo=timezone.utc)


@dataclass(frozen=True)
class Bar:
    start_ts: datetime
    end_ts: datetime          # exclusive end; the bar is only knowable at/after this time
    open: float
    high: float
    low: float
    close: float
    ticks: int = 0
    n_source: int = 1         # number of lower-timeframe bars / ticks aggregated


def bucket_start(ts: datetime, tf_s: int) -> datetime:
    secs = int((require_utc(ts) - _EPOCH).total_seconds())
    return _EPOCH + timedelta(seconds=secs - secs % tf_s)


class BarBuilder:
    def __init__(self, timeframe_s: int):
        if timeframe_s < 1:
            raise FxBotError("timeframe must be >= 1s")
        self.tf = timeframe_s
        self._cur: Optional[dict] = None
        self.late_ticks = 0

    def _emit(self) -> Bar:
        c = self._cur
        return Bar(c["s"], c["s"] + timedelta(seconds=self.tf), c["o"], c["h"], c["l"], c["c"], c["n"], c["n"])

    def on_quote(self, q: Quote) -> Optional[Bar]:
        """Returns the bar that this quote CLOSED (if any)."""
        s, px = bucket_start(q.market_ts, self.tf), float(q.mid)
        if self._cur is None:
            self._cur = {"s": s, "o": px, "h": px, "l": px, "c": px, "n": 1}
            return None
        if s == self._cur["s"]:
            c = self._cur
            c["h"], c["l"], c["c"], c["n"] = max(c["h"], px), min(c["l"], px), px, c["n"] + 1
            return None
        if s < self._cur["s"]:
            self.late_ticks += 1                       # out-of-order quote: ignored, counted
            return None
        closed = self._emit()
        self._cur = {"s": s, "o": px, "h": px, "l": px, "c": px, "n": 1}
        return closed

    def flush(self, now: datetime) -> Optional[Bar]:
        """Close the forming bar if `now` is at/after its end (call on a timer so quiet minutes close)."""
        if self._cur is not None and now >= self._cur["s"] + timedelta(seconds=self.tf):
            b = self._emit()
            self._cur = None
            return b
        return None


def aggregate(bars: Sequence[Bar], tf_s: int, as_of: datetime) -> List[Bar]:
    """Resample closed lower-timeframe bars into CLOSED higher-timeframe bars. A bucket is returned
    only if its end <= as_of; the forming bucket is never included."""
    out: List[Bar] = []
    cur: Optional[dict] = None
    for b in bars:
        if b.end_ts > as_of:
            break                                      # not closed as of `as_of`
        s = bucket_start(b.start_ts, tf_s)
        if cur is None or s != cur["s"]:
            if cur is not None and cur["s"] + timedelta(seconds=tf_s) <= as_of:
                out.append(_mk(cur, tf_s))
            cur = {"s": s, "o": b.open, "h": b.high, "l": b.low, "c": b.close, "n": b.ticks, "k": 1}
        else:
            cur["h"], cur["l"], cur["c"] = max(cur["h"], b.high), min(cur["l"], b.low), b.close
            cur["n"] += b.ticks
            cur["k"] += 1
    if cur is not None and cur["s"] + timedelta(seconds=tf_s) <= as_of:
        out.append(_mk(cur, tf_s))
    return out


def _mk(c: dict, tf_s: int) -> Bar:
    return Bar(c["s"], c["s"] + timedelta(seconds=tf_s), c["o"], c["h"], c["l"], c["c"], c["n"], c["k"])


class BarAggregator:
    """Incremental higher-timeframe builder fed with CLOSED lower-timeframe bars (backtester/live).
    A bucket closes when the bar that completes it arrives, or lazily when a bar of a later bucket
    arrives. Equivalent to aggregate(bars_so_far, tf, as_of=newest bar end) - property-tested."""

    def __init__(self, tf_s: int):
        self.tf = tf_s
        self._cur: Optional[dict] = None

    def on_bar(self, b: Bar) -> List[Bar]:
        out: List[Bar] = []
        s = bucket_start(b.start_ts, self.tf)
        if self._cur is not None and s != self._cur["s"]:
            out.append(_mk(self._cur, self.tf))
            self._cur = None
        if self._cur is None:
            self._cur = {"s": s, "o": b.open, "h": b.high, "l": b.low, "c": b.close, "n": b.ticks, "k": 1}
        else:
            c = self._cur
            c["h"], c["l"], c["c"] = max(c["h"], b.high), min(c["l"], b.low), b.close
            c["n"] += b.ticks
            c["k"] += 1
        if b.end_ts >= s + timedelta(seconds=self.tf):
            out.append(_mk(self._cur, self.tf))
            self._cur = None
        return out
