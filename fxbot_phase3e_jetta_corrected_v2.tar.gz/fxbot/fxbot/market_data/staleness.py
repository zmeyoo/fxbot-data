"""Stale / incomplete market-data guards (spec requirement 8). Pure functions."""
from __future__ import annotations

from datetime import datetime, timedelta
from typing import List, Optional, Sequence

from ..core.types import Quote


def quote_problems(quote: Optional[Quote], now: datetime, max_age_s: Optional[int],
                   max_future_skew_s: int = 5) -> List[str]:
    """Empty list == usable. Unknown max age (None) is itself a problem: no silent default."""
    if quote is None:
        return ["no quote"]
    if max_age_s is None:
        return ["market_data_max_age_seconds not configured"]
    out = []
    if (now - quote.market_ts).total_seconds() > max_age_s:
        out.append(f"stale market timestamp (> {max_age_s}s)")
    if (now - quote.received_ts).total_seconds() > max_age_s:
        out.append(f"stale feed (nothing received for > {max_age_s}s)")
    if (quote.market_ts - now).total_seconds() > max_future_skew_s:
        out.append("market timestamp in the future")
    return out


def find_bar_gaps(bar_starts: Sequence[datetime], timeframe_s: int, max_gap_bars: int = 1) -> List[datetime]:
    """Start times after which more than `max_gap_bars` consecutive bars are missing.
    Session breaks (weekend/holiday) must be filtered by the caller using the trading calendar."""
    gaps = []
    for a, b in zip(bar_starts, bar_starts[1:]):
        if (b - a) > timedelta(seconds=timeframe_s * (max_gap_bars + 1) - 0):
            gaps.append(a)
    return gaps
