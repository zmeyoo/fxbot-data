"""Configuration schema (stdlib dataclasses; pydantic is used only at the API edge later).

Design rules
* Values the spec fixed (0.10% stop / activation, 0.10pp trail distance, 3h max hold,
  3 losing trades, 2% daily loss, 3 reversals) have defaults.
* Values the spec did NOT fix (spread cap, slippage, cooldown, risk per trade, ...) are
  None and are reported by `trading_blockers()`. The engine refuses to trade until the
  operator sets them. Nothing is silently invented.
* Floats are rejected; use strings/ints in JSON ("0.10").
"""
from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass, field, fields
from decimal import Decimal
from enum import Enum
from typing import Any, Dict, List, Mapping, Optional

from ..core.types import FxBotError

UNIVERSE = ("EURUSD", "GBPUSD", "USDJPY", "USDCHF", "AUDUSD", "NZDUSD", "USDCAD")


class ConfigError(FxBotError):
    pass


class LiveTradingNotAuthorised(ConfigError):
    pass


class TradingMode(str, Enum):
    BACKTEST = "BACKTEST"
    PAPER = "PAPER"
    LIVE = "LIVE"


class OperatingMode(str, Enum):
    MANUAL_APPROVAL = "MANUAL_APPROVAL"
    SEMI_AUTOMATIC = "SEMI_AUTOMATIC"
    AUTONOMOUS = "AUTONOMOUS"


class NewsPolicy(str, Enum):
    NONE = "NONE"                      # no news protection (must be reported as such)
    PROVIDER = "PROVIDER"              # economic-calendar provider connected
    MANUAL_BLACKOUT = "MANUAL_BLACKOUT"


class MinNetProfitMode(str, Enum):
    PCT_NOTIONAL = "pct_notional"      # % of initial nominal position value
    ABSOLUTE_BASE = "absolute_base"    # amount in account base currency


def _dec(v: Any, name: str) -> Decimal:
    if isinstance(v, (float, bool)):
        raise ConfigError(f"{name}: floats/bools not allowed, use a string such as \"0.10\"")
    try:
        return Decimal(v)
    except Exception as e:
        raise ConfigError(f"{name}: not a decimal: {v!r}") from e


def _opt_dec(v: Any, name: str) -> Optional[Decimal]:
    return None if v is None else _dec(v, name)


@dataclass(frozen=True)
class MinNetProfit:
    mode: MinNetProfitMode
    value: Decimal

    def __post_init__(self):
        if self.value <= 0:
            raise ConfigError("min_net_profit.value must be > 0")


@dataclass(frozen=True)
class PairConfig:
    symbol: str
    enabled: bool = True
    # --- stop / trailing: ALL are % of the position's own average entry price P0 ---
    initial_stop_pct: Decimal = Decimal("0.10")
    trailing_activation_pct: Decimal = Decimal("0.10")     # trailing starts at +this % favourable
    trailing_distance_pct: Decimal = Decimal("0.10")       # PERCENTAGE POINTS of P0, measured from
                                                           # the best favourable executable price
    # --- re-entry (independent of the trailing parameters; starting values, not optima) ---
    # Reference = post-close EXTREME only (LONG: lowest ASK since the close; SHORT: highest BID since the
    # close). The previous entry/exit price is never used as a reference. Threshold per pair AND direction.
    same_direction_reentry_min_move_pct: Decimal = Decimal("0.10")
    opposite_direction_reentry_min_move_pct: Decimal = Decimal("0.10")
    # When is the post-close reference extreme discarded besides (a) every new close and (b) a data gap?
    #   "new_session": also at the start of each new session (current behaviour, NOT an approved rule - under comparison)
    #   "next_close":  never at a session boundary; only at the next close / data gap / optional max age below
    reentry_reference_reset: str = "new_session"
    reentry_reference_max_age_minutes: Optional[int] = None
    # --- profit-taking (independent of trailing; can be switched off for A/B tests) ---
    profit_taking_enabled: bool = False
    min_net_profit: Optional[MinNetProfit] = None
    # --- entry cost gates (None => trading blocked until set) ---
    max_spread_pct: Optional[Decimal] = None
    est_slippage_pct: Optional[Decimal] = None          # per side, % of price
    max_cost_to_stop_ratio: Optional[Decimal] = None
    max_cost_to_reward_ratio: Optional[Decimal] = None  # reward = move to trail activation
    # --- timing / limits ---
    max_hold_minutes: int = 180
    cooldown_minutes: Optional[int] = None
    max_trades_session: Optional[int] = None
    max_reversals_session: int = 3
    allow_same_direction_reentry: bool = True   # enabled in V1 (decision 2026-11-07); see A-1
    # --- sizing / risk ---
    risk_per_trade_pct: Optional[Decimal] = None        # % of account equity (base ccy)
    max_notional_base: Optional[Decimal] = None         # in base ccy
    auto_sizing: bool = False                           # False => manual approval of size
    # --- signals (consumed by the signal phase) ---
    entry_engine: str = "ema_trend_v0"
    signal_params: Mapping[str, str] = field(default_factory=dict)

    def __post_init__(self):
        if len(self.symbol) != 6:
            raise ConfigError(f"bad symbol {self.symbol!r}")
        for n in ("initial_stop_pct", "trailing_activation_pct", "trailing_distance_pct"):
            if getattr(self, n) <= 0:
                raise ConfigError(f"{self.symbol}.{n} must be > 0")
        for n in ("same_direction_reentry_min_move_pct", "opposite_direction_reentry_min_move_pct"):
            if getattr(self, n) < 0:
                raise ConfigError(f"{self.symbol}.{n} must be >= 0 (0 disables the movement check)")
        if self.initial_stop_pct >= 100:
            raise ConfigError("initial_stop_pct must be < 100")
        for n in ("max_spread_pct", "est_slippage_pct", "max_cost_to_stop_ratio",
                  "max_cost_to_reward_ratio", "risk_per_trade_pct", "max_notional_base"):
            v = getattr(self, n)
            if v is not None and v < 0:
                raise ConfigError(f"{self.symbol}.{n} must be >= 0")
        if self.risk_per_trade_pct is not None and self.risk_per_trade_pct > 100:
            raise ConfigError("risk_per_trade_pct > 100")
        if self.reentry_reference_reset not in ("new_session", "next_close"):
            raise ConfigError("reentry_reference_reset must be 'new_session' or 'next_close'")
        if self.reentry_reference_max_age_minutes is not None and self.reentry_reference_max_age_minutes < 1:
            raise ConfigError("reentry_reference_max_age_minutes must be >= 1 or None")
        if self.max_hold_minutes <= 0:
            raise ConfigError("max_hold_minutes must be > 0")
        for n in ("cooldown_minutes", "max_trades_session"):
            v = getattr(self, n)
            if v is not None and v < 0:
                raise ConfigError(f"{self.symbol}.{n} must be >= 0")
        if self.max_reversals_session < 0:
            raise ConfigError("max_reversals_session must be >= 0")
        if self.profit_taking_enabled and self.min_net_profit is None:
            raise ConfigError(f"{self.symbol}: profit_taking_enabled requires min_net_profit")

    def blockers(self) -> List[str]:
        req = ["max_spread_pct", "est_slippage_pct", "max_cost_to_stop_ratio",
               "max_cost_to_reward_ratio", "cooldown_minutes", "max_trades_session",
               "risk_per_trade_pct", "max_notional_base"]
        return [f"{self.symbol}.{n} not configured" for n in req if getattr(self, n) is None]


@dataclass(frozen=True)
class GlobalConfig:
    base_currency: str = "EUR"
    mode: TradingMode = TradingMode.PAPER
    live_enabled: bool = False                    # must be False unless explicitly authorised
    operating_mode: OperatingMode = OperatingMode.MANUAL_APPROVAL
    # --- account-level risk ---
    max_daily_loss_pct: Decimal = Decimal("2")
    max_consecutive_losses: int = 3
    max_daily_drawdown_pct: Optional[Decimal] = None
    max_open_positions: Optional[int] = None
    max_total_open_risk_pct: Optional[Decimal] = None
    loss_streak_cooldown_minutes: Optional[int] = None
    # --- Forex cash / borrowing controls (decision 1A) ---
    min_cash_buffer_pct: Optional[Decimal] = None     # buffer on LONG funding, % of notional
    allow_auto_conversion: bool = False               # never convert other ccys to fund a LONG
    shorts_enabled: bool = True
    max_short_notional_base: Optional[Decimal] = None
    max_margin_utilisation_pct: Optional[Decimal] = None
    # projected-balance floors per currency. Missing currency => floor 0 (no borrowing).
    # A negative floor is the explicit authorisation to be short that currency down to it.
    currency_floors: Mapping[str, Decimal] = field(default_factory=dict)
    # max absolute net exposure per currency, in base-currency equivalent
    max_currency_exposure_base: Mapping[str, Decimal] = field(default_factory=dict)
    # --- data / protection ---
    market_data_max_age_seconds: Optional[int] = None
    unprotected_timeout_seconds: Optional[int] = None
    eod_cutoff_minutes_before_rollover: Optional[int] = None   # flat this many minutes before the 17:00 NY rollover
    session_timezone: str = "America/New_York"        # sessions: see core/sessions.py (not hard-coded in UTC)
    session_start_local: str = "17:00"
    eod_cutoff_utc: Optional[str] = None              # DEPRECATED legacy "HH:MM" UTC cutoff (drifts with DST)
    news_policy: NewsPolicy = NewsPolicy.NONE
    news_provider_verified: bool = False
    news_manual_blackout_configured: bool = False

    def __post_init__(self):
        if len(self.base_currency) != 3:
            raise ConfigError("base_currency must be a 3-letter code")
        if self.max_daily_loss_pct <= 0 or self.max_daily_loss_pct > 100:
            raise ConfigError("max_daily_loss_pct out of range")
        if self.max_consecutive_losses < 1:
            raise ConfigError("max_consecutive_losses must be >= 1")
        if self.live_enabled and self.mode is not TradingMode.LIVE:
            raise ConfigError("live_enabled requires mode == LIVE")
        if self.mode is TradingMode.LIVE and not self.live_enabled:
            raise ConfigError("mode LIVE requires live_enabled (explicit authorisation)")
        if self.eod_cutoff_minutes_before_rollover is not None and not (0 <= self.eod_cutoff_minutes_before_rollover < 1440):
            raise ConfigError("eod_cutoff_minutes_before_rollover must be in [0, 1440)")
        try:
            from ..core.sessions import SessionCalendar
            SessionCalendar(self.session_timezone, self.session_start_local).session_of(__import__("datetime").datetime(2026, 1, 5, tzinfo=__import__("datetime").timezone.utc))
        except Exception as e:
            raise ConfigError(f"bad session definition: {e}") from e
        if self.eod_cutoff_utc is not None:
            try:
                hh, mm = self.eod_cutoff_utc.split(":")
                assert 0 <= int(hh) < 24 and 0 <= int(mm) < 60
            except Exception as e:
                raise ConfigError("eod_cutoff_utc must be HH:MM") from e

    def blockers(self) -> List[str]:
        req = ["market_data_max_age_seconds", "unprotected_timeout_seconds",
               "max_open_positions", "max_total_open_risk_pct", "min_cash_buffer_pct",
               "max_short_notional_base", "max_margin_utilisation_pct",
               "loss_streak_cooldown_minutes", "max_daily_drawdown_pct"]
        out = [f"{n} not configured" for n in req if getattr(self, n) is None]
        if self.eod_cutoff_minutes_before_rollover is None and self.eod_cutoff_utc is None:
            out.append("eod_cutoff_minutes_before_rollover not configured")
        return out


@dataclass(frozen=True)
class AppConfig:
    global_: GlobalConfig
    pairs: Mapping[str, PairConfig]

    @staticmethod
    def default_universe() -> "AppConfig":
        return AppConfig(GlobalConfig(), {s: PairConfig(symbol=s) for s in UNIVERSE})

    # ---- readiness ----
    def trading_blockers(self) -> List[str]:
        out = self.global_.blockers()
        for p in self.pairs.values():
            if p.enabled:
                out += p.blockers()
                for ccy in (p.symbol[:3], p.symbol[3:]):
                    if ccy not in self.global_.max_currency_exposure_base:
                        out.append(f"max_currency_exposure_base[{ccy}] not configured")
        return sorted(set(out))

    def live_blockers(self, commission_schedule_verified: bool) -> List[str]:
        """Extra conditions that must hold before AUTONOMOUS live trading (decision 1F)."""
        g, out = self.global_, []
        if not commission_schedule_verified:
            out.append("commission schedule not verified against the connected account")
        if g.operating_mode is OperatingMode.AUTONOMOUS:
            ok = ((g.news_policy is NewsPolicy.PROVIDER and g.news_provider_verified) or
                  (g.news_policy is NewsPolicy.MANUAL_BLACKOUT and g.news_manual_blackout_configured))
            if not ok:
                out.append("autonomous live needs a verified news provider or a configured "
                           "manual blackout policy; a missing provider is NOT a news filter")
        return out + self.trading_blockers()

    # ---- (de)serialisation ----
    def to_dict(self) -> Dict[str, Any]:
        return {"global": _ser(self.global_), "pairs": {k: _ser(v) for k, v in sorted(self.pairs.items())}}

    @staticmethod
    def from_dict(d: Mapping[str, Any]) -> "AppConfig":
        g = _build(GlobalConfig, d.get("global", {}))
        pairs = {}
        for sym, pd in d.get("pairs", {}).items():
            pairs[sym] = _build(PairConfig, {**pd, "symbol": sym})
        return AppConfig(g, pairs)

    def hash(self) -> str:
        blob = json.dumps(self.to_dict(), sort_keys=True, separators=(",", ":"))
        return hashlib.sha256(blob.encode()).hexdigest()


# ---------------------------------------------------------------- helpers
def _canon(d: Decimal) -> str:
    s = format(d.normalize(), "f")
    return s


def _ser(o: Any) -> Any:
    if isinstance(o, Decimal):
        return _canon(o)
    if isinstance(o, Enum):
        return o.value
    if isinstance(o, MinNetProfit):
        return {"mode": o.mode.value, "value": _canon(o.value)}
    if hasattr(o, "__dataclass_fields__"):
        return {f.name.rstrip("_"): _ser(getattr(o, f.name)) for f in fields(o)}
    if isinstance(o, Mapping):
        return {str(k): _ser(v) for k, v in sorted(o.items())}
    return o


_DEC = {"initial_stop_pct", "trailing_activation_pct", "trailing_distance_pct", "max_spread_pct",
        "same_direction_reentry_min_move_pct", "opposite_direction_reentry_min_move_pct",
        "est_slippage_pct", "max_cost_to_stop_ratio", "max_cost_to_reward_ratio",
        "risk_per_trade_pct", "max_notional_base", "max_daily_loss_pct", "max_daily_drawdown_pct",
        "max_total_open_risk_pct", "min_cash_buffer_pct", "max_short_notional_base",
        "max_margin_utilisation_pct"}
_DEC_MAPS = {"currency_floors", "max_currency_exposure_base"}
_ENUMS = {"mode": TradingMode, "operating_mode": OperatingMode, "news_policy": NewsPolicy}


def _build(cls, raw: Mapping[str, Any]):
    known = {f.name for f in fields(cls)}
    kw: Dict[str, Any] = {}
    for k, v in raw.items():
        k2 = "global_" if k == "global" else k
        if k2 not in known:
            raise ConfigError(f"unknown config key {cls.__name__}.{k}")
        if k in _DEC:
            v = _opt_dec(v, k)
        elif k in _DEC_MAPS:
            v = {str(a): _dec(b, f"{k}.{a}") for a, b in v.items()}
        elif k in _ENUMS:
            try:
                v = _ENUMS[k](v)
            except ValueError as e:
                raise ConfigError(f"bad value for {k}: {v!r}") from e
        elif k == "min_net_profit" and v is not None:
            v = MinNetProfit(MinNetProfitMode(v["mode"]), _dec(v["value"], "min_net_profit.value"))
        kw[k2] = v
    return cls(**kw)
