from __future__ import annotations

import copy
from dataclasses import dataclass
from datetime import datetime
from typing import Any, List

from ..core.types import require_utc
from .schema import AppConfig, ConfigError, LiveTradingNotAuthorised


@dataclass(frozen=True)
class ConfigAuditRecord:
    ts: datetime
    actor: str               # user id or process name
    path: str
    old_value: Any
    new_value: Any
    old_hash: str
    new_hash: str


class ConfigStore:
    """The only way configuration changes. Every change is validated as a whole, hashed,
    and appended to an audit log (old value, new value, actor, timestamp). A rejected
    change leaves the config untouched. Trades store `config.hash()` as their snapshot id."""

    def __init__(self, config: AppConfig):
        self._config = config
        self.audit: List[ConfigAuditRecord] = []

    @property
    def config(self) -> AppConfig:
        return self._config

    def set(self, path: str, value: Any, actor: str, ts: datetime, *,
            explicit_live_authorisation: bool = False) -> ConfigAuditRecord:
        require_utc(ts, "ts")
        if not actor:
            raise ConfigError("actor is required for every config change")
        parts = path.split(".")
        # Live trading can never be switched on implicitly.
        if parts == ["global", "mode"] and str(getattr(value, "value", value)) == "LIVE" \
                or parts == ["global", "live_enabled"] and value is True:
            if not explicit_live_authorisation:
                raise LiveTradingNotAuthorised("switching to LIVE requires explicit authorisation")
        d = copy.deepcopy(self._config.to_dict())
        node = d
        for p in parts[:-1]:
            if not isinstance(node, dict) or p not in node:
                raise ConfigError(f"unknown config path {path!r}")
            node = node[p]
        if not isinstance(node, dict) or (parts[-1] not in node):
            raise ConfigError(f"unknown config path {path!r}")
        old = node[parts[-1]]
        node[parts[-1]] = getattr(value, "value", value)
        new_cfg = AppConfig.from_dict(d)      # full validation before commit
        rec = ConfigAuditRecord(ts, actor, path, old, node[parts[-1]],
                                self._config.hash(), new_cfg.hash())
        self._config = new_cfg
        self.audit.append(rec)
        return rec
