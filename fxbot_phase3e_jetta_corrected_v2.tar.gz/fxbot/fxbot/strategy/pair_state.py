"""Per-pair strategy state machine and the (re-)entry confirmation gate.

After ANY close the pair enters WAIT_FOR_REENTRY_CONFIRMATION (A-2). A new entry - in the SAME or the
OPPOSITE direction (same-direction enabled in V1, A-1) - is admitted only if ALL hold:
  * a FRESH valid signal: signal_ts and market_ts strictly after the close (a signal that was valid
    before the exit never counts, so there is no automatic re-entry because a position closed);
    the signal engine has re-checked every configured trend/entry condition;
  * the directional price movement since the close meets the per-pair threshold
    (same_direction_reentry_min_move_pct / opposite_direction_reentry_min_move_pct, A-15);
  * the per-pair cooldown has elapsed.
Spread / cost / exposure / risk filters and the one-position-per-pair rule are enforced by
strategy/entry.py and risk/governor.py. LONG and SHORT are treated symmetrically.
"""
from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timedelta
from decimal import Decimal
from enum import Enum
from typing import Any, Dict, List, Optional, Tuple

from ..config.schema import PairConfig
from ..market_data.staleness import quote_problems
from ..core.types import HUNDRED, FxBotError, Quote, Side, require_utc
from ..signals.base import Signal  # re-exported for backwards compatibility

__all__ = ["PairState", "PairStrategy", "Signal", "GateDecision", "PostCloseTracker", "reentry_move_pct"]


class PairState(str, Enum):
    IDLE = "IDLE"
    ANALYSING = "ANALYSING"
    ENTRY_PENDING = "ENTRY_PENDING"
    POSITION_OPEN = "POSITION_OPEN"
    WAIT_FOR_REENTRY_CONFIRMATION = "WAIT_FOR_REENTRY_CONFIRMATION"
    WAIT_FOR_REVERSE_CONFIRMATION = "WAIT_FOR_REENTRY_CONFIRMATION"   # deprecated alias (old name)
    COOLDOWN = "COOLDOWN"
    RISK_LOCKOUT = "RISK_LOCKOUT"
    EMERGENCY_STOP = "EMERGENCY_STOP"


P = PairState
_W = P.WAIT_FOR_REENTRY_CONFIRMATION
_ALLOWED = {
    P.IDLE: {P.ANALYSING, P.EMERGENCY_STOP, P.RISK_LOCKOUT},
    P.ANALYSING: {P.ENTRY_PENDING, P.COOLDOWN, P.RISK_LOCKOUT, P.EMERGENCY_STOP, P.IDLE},
    P.ENTRY_PENDING: {P.POSITION_OPEN, P.ANALYSING, _W, P.RISK_LOCKOUT, P.EMERGENCY_STOP},
    P.POSITION_OPEN: {_W, P.RISK_LOCKOUT, P.EMERGENCY_STOP},
    _W: {P.ENTRY_PENDING, P.COOLDOWN, P.ANALYSING, P.IDLE, P.RISK_LOCKOUT, P.EMERGENCY_STOP},
    P.COOLDOWN: {P.ANALYSING, _W, P.RISK_LOCKOUT, P.EMERGENCY_STOP},
    P.RISK_LOCKOUT: {P.IDLE, P.EMERGENCY_STOP},          # leaving needs explicit release
    P.EMERGENCY_STOP: {P.IDLE},
}


@dataclass
class PostCloseTracker:
    """Executable-price extremes since the CONFIRMED close (LONG re-enters on ASK, SHORT on BID).
    A fresh tracker is created on every close (reset); it starts empty and only quotes with
    market_ts >= closed_ts are observed. The previous entry/exit price is never a reference.
    Stale quotes are ignored. If the feed has a gap longer than max_age_s the extremes of the gap are
    unknown, so the reference restarts from the first good quote afterwards (conservative: it can only
    UNDERSTATE the movement, never trigger a re-entry from missing data)."""
    closed_ts: datetime
    low_ask: Optional[Decimal] = None
    high_bid: Optional[Decimal] = None
    last_ts: Optional[datetime] = None
    gaps: int = 0
    ignored_stale: int = 0
    observed: int = 0
    ref_started_ts: Optional[datetime] = None      # when the current reference began (close, gap restart or age restart)
    age_resets: int = 0

    def __post_init__(self):
        if self.ref_started_ts is None:
            self.ref_started_ts = self.closed_ts

    def observe(self, q: Quote, now: Optional[datetime] = None, max_age_s: Optional[int] = None,
                ref_max_age_s: Optional[int] = None) -> bool:
        if q.market_ts < self.closed_ts:
            return False
        if max_age_s is not None and now is not None and quote_problems(q, now, max_age_s):
            self.ignored_stale += 1
            return False
        ref = self.last_ts or self.closed_ts
        if max_age_s is not None and (q.market_ts - ref).total_seconds() > max_age_s:
            self.gaps += 1
            self.low_ask, self.high_bid = q.ask, q.bid          # restart the reference after a data gap
            self.ref_started_ts = q.market_ts
        elif ref_max_age_s is not None and (q.market_ts - self.ref_started_ts).total_seconds() > ref_max_age_s:
            self.age_resets += 1                                 # configured maximum age of the reference reached
            self.low_ask, self.high_bid = q.ask, q.bid
            self.ref_started_ts = q.market_ts
        else:
            self.low_ask = q.ask if self.low_ask is None else min(self.low_ask, q.ask)
            self.high_bid = q.bid if self.high_bid is None else max(self.high_bid, q.bid)
        self.last_ts = q.market_ts
        self.observed += 1
        return True


def reentry_move_pct(new_side: Side, tr: Optional[PostCloseTracker], quote: Quote) -> Optional[Decimal]:
    """Directional movement from the post-close extreme, in % of that extreme, in the direction of the
    NEW trade. LONG: (ask - lowest ask)/lowest ask. SHORT: (highest bid - bid)/highest bid. Mirror images."""
    if tr is None:
        return None
    if new_side is Side.LONG:
        low = quote.ask if tr.low_ask is None else min(tr.low_ask, quote.ask)
        return (quote.ask - low) / low * HUNDRED
    high = quote.bid if tr.high_bid is None else max(tr.high_bid, quote.bid)
    return (high - quote.bid) / high * HUNDRED


@dataclass(frozen=True)
class GateDecision:
    allowed: bool
    is_reversal: bool                     # opposite direction to the previous position (allowed only)
    reasons: Tuple[str, ...]
    is_same_direction_reentry: bool = False
    directional_move_pct: Optional[Decimal] = None
    required_move_pct: Optional[Decimal] = None


class PairStrategy:
    def __init__(self, cfg: PairConfig):
        self.cfg = cfg
        self.pair = cfg.symbol
        self.state = P.IDLE
        self.last_closed_side: Optional[Side] = None
        self.closed_ts: Optional[datetime] = None
        self.cooldown_until: Optional[datetime] = None
        self.post_close: Optional[PostCloseTracker] = None
        self.history: List[Tuple[datetime, PairState, PairState, str]] = []

    def _go(self, to: PairState, ts: datetime, why: str) -> None:
        if to not in _ALLOWED[self.state]:
            raise FxBotError(f"{self.pair}: illegal strategy transition {self.state.value}->{to.value}")
        self.history.append((ts, self.state, to, why))
        self.state = to

    def start(self, ts: datetime) -> None:
        self._go(P.ANALYSING, ts, "session start")

    def on_quote(self, quote: Quote, now: Optional[datetime] = None, max_age_s: Optional[int] = None) -> None:
        """Feed every quote while waiting; builds the post-close extremes used by the movement check."""
        if self.post_close is not None:
            age = self.cfg.reentry_reference_max_age_minutes
            self.post_close.observe(quote, now, max_age_s, None if age is None else age * 60)

    def gate(self, sig: Signal, now: datetime, quote: Optional[Quote] = None,
             max_age_s: Optional[int] = None) -> GateDecision:
        r: List[str] = []
        if self.state in (P.EMERGENCY_STOP, P.RISK_LOCKOUT, P.IDLE, P.ENTRY_PENDING, P.POSITION_OPEN):
            r.append(f"state {self.state.value} does not accept entries")
        if not self.cfg.enabled:
            r.append("pair paused/disabled")
        if sig.pair != self.pair or not sig.valid:
            r.append("signal invalid or for another pair")
        if self.cfg.cooldown_minutes is None:
            r.append("cooldown_minutes not configured")
        if self.cooldown_until is not None and now < self.cooldown_until:
            r.append(f"cooldown until {self.cooldown_until.isoformat()}")
        same = opposite = False
        mv = req = None
        if quote is not None and max_age_s is not None:
            r += [f"market data: {p}" for p in quote_problems(quote, now, max_age_s)]
        if self.closed_ts is not None:
            # re-entry ALWAYS needs a current, fresh quote: stale or missing data can never trigger it
            if quote is None or max_age_s is None:
                r += [f"market data: {p}" for p in quote_problems(quote, now, max_age_s)]
            if sig.signal_ts <= self.closed_ts or sig.market_ts <= self.closed_ts:
                r.append("signal predates the close; a fresh confirmed signal is required")
            same = sig.direction is self.last_closed_side
            opposite = not same
            if same and not self.cfg.allow_same_direction_reentry:
                r.append("same-direction re-entry disabled by configuration")
            req = (self.cfg.same_direction_reentry_min_move_pct if same
                   else self.cfg.opposite_direction_reentry_min_move_pct)
            if req > 0:
                if quote is None or quote.pair != self.pair:
                    r.append("no current quote for the directional-movement check")
                else:
                    tr = self.post_close
                    age = self.cfg.reentry_reference_max_age_minutes
                    if tr is not None and age is not None and (now - tr.ref_started_ts).total_seconds() > age * 60:
                        tr = PostCloseTracker(self.closed_ts)       # reference expired: no usable extreme yet
                    mv = reentry_move_pct(sig.direction, tr, quote)
                    if mv is None:
                        r.append("post-close reference extreme unknown")
                    elif mv < req:
                        kind = "same" if same else "opposite"
                        r.append(f"{kind}-direction move {mv:.4f}% < required {req}%")
        ok = not r
        return GateDecision(ok, opposite and ok, tuple(r), same and ok, mv, req)

    def on_entry_requested(self, ts: datetime) -> None:
        self._go(P.ENTRY_PENDING, ts, "entry order requested")

    def on_entry_failed(self, ts: datetime) -> None:
        self._go(_W if self.closed_ts else P.ANALYSING, ts, "entry failed/cancelled")

    def on_position_opened(self, ts: datetime) -> None:
        self._go(P.POSITION_OPEN, ts, "position open")

    def on_position_closed(self, closed_side: Side, ts: datetime) -> None:
        """Confirmed close: resets the reference extreme and starts tracking from this moment."""
        require_utc(ts, "ts")
        self.last_closed_side, self.closed_ts = closed_side, ts
        cd = self.cfg.cooldown_minutes
        self.cooldown_until = ts + timedelta(minutes=cd) if cd is not None else None
        self.post_close = PostCloseTracker(ts)
        self._go(_W, ts, "position closed")

    def new_session(self, ts: datetime) -> None:
        """Start of a trading session: drops the post-close reference and any wait/cooldown so the first entry
        of the session follows first-entry rules (A-19). Not allowed with an entry pending or position open."""
        if self.state in (P.ENTRY_PENDING, P.POSITION_OPEN):
            raise FxBotError(f"{self.pair}: cannot start a new session while {self.state.value}")
        if self.state in (P.RISK_LOCKOUT, P.EMERGENCY_STOP):
            return                                  # only an explicit named release leaves these
        if self.cfg.reentry_reference_reset == "next_close" and self.state is _W:
            return                                  # preserve: reference/cooldown/state survive the session boundary
        self.closed_ts = self.last_closed_side = self.cooldown_until = self.post_close = None
        if self.state is P.IDLE:
            self._go(P.ANALYSING, ts, "new session")
        elif self.state is not P.ANALYSING:
            self._go(P.ANALYSING, ts, "new session")

    def risk_lockout(self, ts: datetime, why: str) -> None:
        self._go(P.RISK_LOCKOUT, ts, why)

    def emergency_stop(self, ts: datetime) -> None:
        if self.state is not P.EMERGENCY_STOP:
            self._go(P.EMERGENCY_STOP, ts, "emergency stop")

    def release(self, ts: datetime, who: str) -> None:
        """Explicit human release of lockout / emergency stop; returns to IDLE."""
        self._go(P.IDLE, ts, f"released by {who}")
        self.closed_ts = self.last_closed_side = self.cooldown_until = self.post_close = None

    # ---- persistence (restart-safe)
    def snapshot(self) -> Dict[str, Any]:
        t = lambda x: None if x is None else x.isoformat()
        d = lambda x: None if x is None else str(x)
        pc = self.post_close
        return {"v": 1, "pair": self.pair, "state": self.state.value,
                "last_closed_side": None if self.last_closed_side is None else self.last_closed_side.value,
                "closed_ts": t(self.closed_ts), "cooldown_until": t(self.cooldown_until),
                "post_close": None if pc is None else {
                    "closed_ts": t(pc.closed_ts), "low_ask": d(pc.low_ask), "high_bid": d(pc.high_bid),
                    "last_ts": t(pc.last_ts), "gaps": pc.gaps, "ignored_stale": pc.ignored_stale,
                    "observed": pc.observed, "ref_started_ts": t(pc.ref_started_ts), "age_resets": pc.age_resets}}

    @classmethod
    def from_snapshot(cls, d: Dict[str, Any], cfg: PairConfig) -> "PairStrategy":
        if d.get("v") != 1 or d["pair"] != cfg.symbol:
            raise FxBotError("strategy snapshot mismatch")
        T_ = lambda x: None if x is None else datetime.fromisoformat(x)
        D_ = lambda x: None if x is None else Decimal(x)
        st = cls(cfg)
        st.state = PairState(d["state"])
        st.last_closed_side = None if d["last_closed_side"] is None else Side(d["last_closed_side"])
        st.closed_ts, st.cooldown_until = T_(d["closed_ts"]), T_(d["cooldown_until"])
        pc = d["post_close"]
        st.post_close = None if pc is None else PostCloseTracker(
            T_(pc["closed_ts"]), D_(pc["low_ask"]), D_(pc["high_bid"]), T_(pc["last_ts"]),
            pc["gaps"], pc["ignored_stale"], pc["observed"], T_(pc.get("ref_started_ts")), pc.get("age_resets", 0))
        return st
