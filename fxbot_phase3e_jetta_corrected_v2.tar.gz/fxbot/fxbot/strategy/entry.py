"""Entry decision: composes the strategy gate with EVERY filter. An entry (including a same-direction
re-entry) is approved only if all of them pass; all failing reasons are returned (explainability).

  data freshness -> news -> gate (fresh signal, direction, movement, cooldown) -> sizing ->
  cost gate (spread / cost ratios) -> funding (own cash / authorised short) -> per-currency exposure ->
  risk governor (limits, lockout, one position per pair, kill switch)
"""
from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from decimal import Decimal
from typing import Callable, List, Optional, Sequence, Tuple

from ..config.schema import GlobalConfig, PairConfig
from ..core.types import HUNDRED, ZERO, Quote, Side
from ..costs.model import CostContext, EntryCostAssessment, assess_entry_costs
from ..instruments.spec import PairSpec
from ..market_data.staleness import quote_problems
from ..risk.currency import CurrencyLedger, FundingDecision, check_currency_exposure, check_order_funding
from ..risk.governor import RiskGovernor
from ..risk.sizing import SizingResult, size_position
from ..signals.base import Signal
from ..signals.news import NewsProvider, NewsStatus
from .pair_state import GateDecision, PairStrategy


@dataclass(frozen=True)
class EntryDecision:
    approved: bool
    side: Optional[Side]
    reasons: Tuple[str, ...]
    warnings: Tuple[str, ...]
    gate: GateDecision
    news: NewsStatus
    sizing: Optional[SizingResult] = None
    cost: Optional[EntryCostAssessment] = None
    funding: Optional[FundingDecision] = None
    is_same_direction_reentry: bool = False
    is_reversal: bool = False


def evaluate_entry(*, strategy: PairStrategy, signal: Signal, quote: Quote, spec: PairSpec,
                   cfg: PairConfig, gcfg: GlobalConfig, ctx: CostContext, ledger: CurrencyLedger,
                   open_positions: Sequence[Tuple[PairSpec, Side, Decimal, Decimal]],
                   governor: RiskGovernor, equity_base: Decimal, news: NewsProvider, now: datetime,
                   margin_util_after_pct: Optional[Decimal] = None,
                   margin_util_fn: Optional[Callable[[Decimal, Decimal], Optional[Decimal]]] = None,
                   current_short_notional_base: Decimal = ZERO) -> EntryDecision:
    reasons: List[str] = []
    warnings: List[str] = []
    reasons += [f"data: {p}" for p in quote_problems(quote, now, gcfg.market_data_max_age_seconds)]
    ns = news.status(spec.symbol, now)
    if ns.blocked:
        reasons.append(f"news: {ns.reason}")
    if not ns.protection_active:
        warnings.append(f"news filter: {ns.reason}")
    gate = strategy.gate(signal, now, quote, gcfg.market_data_max_age_seconds)
    reasons += [f"gate: {r}" for r in gate.reasons]
    side = signal.direction
    sizing = cost = funding = None
    if not [r for r in reasons if r.startswith("data:")]:
        rem = None
        if gcfg.max_total_open_risk_pct is not None:
            rem = equity_base * gcfg.max_total_open_risk_pct / HUNDRED - sum(governor.open_risk_base.values(), ZERO)
        short_cap = None
        if side is Side.SHORT:                      # size only inside the authorised borrow room
            room = ledger.bal(spec.base) - gcfg.currency_floors.get(spec.base, ZERO)
            caps = [max(ZERO, room)]
            if gcfg.max_short_notional_base is not None:
                per_unit = ctx.rates.convert(Decimal(1), spec.base, gcfg.base_currency)
                caps.append(max(ZERO, (gcfg.max_short_notional_base - current_short_notional_base) / per_unit))
            short_cap = min(caps)
        sizing = size_position(side=side, short_qty_cap=short_cap, quote=quote, spec=spec, cfg=cfg, ctx=ctx, equity_base=equity_base,
                               remaining_total_risk_base=rem, cash_buffer_pct=gcfg.min_cash_buffer_pct,
                               long_cash_quote=ledger.available_cash(spec.quote) if side is Side.LONG else None)
        reasons += [f"sizing: {r}" for r in sizing.reasons]
        if sizing.approved:
            cost = assess_entry_costs(side=side, quote=quote, qty=sizing.qty, cfg=cfg, ctx=ctx,
                                      base=spec.base, quote_ccy=spec.quote)
            reasons += [f"cost: {r}" for r in cost.reasons]
            warnings += list(cost.warnings)
            if cost.expected_entry_price is not None:
                px = cost.expected_entry_price
                if margin_util_fn is not None:           # margin what-if needs the sized quantity and price
                    margin_util_after_pct = margin_util_fn(sizing.qty, px)
                funding = check_order_funding(
                    spec=spec, side=side, qty=sizing.qty, price=px, closing=False, ledger=ledger, gcfg=gcfg,
                    commission_quote=cost.entry_costs.commission, rates=ctx.rates,
                    current_short_notional_base=current_short_notional_base,
                    margin_util_after_pct=margin_util_after_pct,
                    financing_estimate_quote=cost.exit_costs.financing if ctx.financing else None)
                reasons += [f"funding: {r}" for r in funding.reasons]
                warnings += list(funding.notes)
                reasons += [f"exposure: {r}" for r in check_currency_exposure(
                    open_positions, (spec, side, sizing.qty, px), ctx.rates, gcfg)]
                risk_base = ctx.to_base(sizing.worst_case_loss_quote, spec.quote)
                rd = governor.check_new_entry(spec.symbol, cfg, risk_base, equity_base, now, gate.is_reversal)
                reasons += [f"risk: {r}" for r in rd.reasons]
    return EntryDecision(not reasons, side, tuple(reasons), tuple(warnings), gate, ns, sizing, cost, funding,
                         gate.is_same_direction_reentry, gate.is_reversal)
