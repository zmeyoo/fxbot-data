"""Pure planner for the broker-side protective order (execution layer carries it out in Phase 4).

Rules (previously agreed, now explicit):
* The broker-confirmed protective order is the primary protection where supported; the internal
  `desired_stop` check in the exit engine is the independent software backstop.
* The stop is only ever TIGHTENED. A broker stop that is already as tight is left alone.
* Never leave a position uncovered: MODIFY in place if the broker supports it; otherwise place the
  new stop FIRST and cancel the old one only after the new one is acknowledged.
* On an un-acked modify/submit (timeout) query broker state by client order id before any retry.
"""
from __future__ import annotations

from dataclasses import dataclass
from decimal import Decimal
from enum import Enum
from typing import Optional, Tuple

from .position import Position, PositionState as S
from .trailing import is_tighter


class StopAction(str, Enum):
    NONE = "NONE"
    PLACE_NEW = "PLACE_NEW"
    MODIFY_IN_PLACE = "MODIFY_IN_PLACE"
    REPLACE_NEW_THEN_CANCEL_OLD = "REPLACE_NEW_THEN_CANCEL_OLD"


@dataclass(frozen=True)
class StopPlan:
    action: StopAction
    price: Optional[Decimal]
    qty: Optional[Decimal]
    cancel_order_id: Optional[str]
    steps: Tuple[str, ...]
    reason: str


_PLACE = ("SUBMIT_STOP", "AWAIT_BROKER_ACK", "CONFIRM_PROTECTION")
_MODIFY = ("MODIFY_STOP", "AWAIT_BROKER_ACK", "CONFIRM_PROTECTION",
           "ON_TIMEOUT: QUERY_BROKER_BY_CLIENT_ID_BEFORE_RETRY")
_REPLACE = ("SUBMIT_NEW_STOP", "AWAIT_ACK_NEW", "CONFIRM_PROTECTION", "CANCEL_OLD_STOP", "AWAIT_CANCEL_ACK",
            "ON_TIMEOUT: QUERY_BROKER_BY_CLIENT_ID_BEFORE_RETRY")


def plan_stop_update(pos: Position, supports_modify: bool) -> StopPlan:
    none = lambda why: StopPlan(StopAction.NONE, None, None, None, (), why)
    if pos.state not in (S.OPEN_UNPROTECTED, S.OPEN_PROTECTED, S.TRAILING_ACTIVE) or pos.open_qty <= 0:
        return none("no open position needing a stop")
    price, qty = pos.protection_target()
    bs = pos.broker_stop
    if bs is None:
        return StopPlan(StopAction.PLACE_NEW, price, qty, None, _PLACE, "no confirmed broker stop")
    under_covered = bs.qty < qty
    lagging = is_tighter(pos.side, price, bs.price)       # desired strictly tighter than broker's
    if not under_covered and not lagging:
        return none("broker stop already at least as tight and covers the quantity")
    # never loosen: keep the tighter of the two prices when only coverage is the problem
    new_price = price if lagging else bs.price
    why = "stop tightened by trailing" if lagging else "quantity not fully covered"
    if supports_modify:
        return StopPlan(StopAction.MODIFY_IN_PLACE, new_price, qty, bs.order_id, _MODIFY, why)
    return StopPlan(StopAction.REPLACE_NEW_THEN_CANCEL_OLD, new_price, qty, bs.order_id, _REPLACE, why)
