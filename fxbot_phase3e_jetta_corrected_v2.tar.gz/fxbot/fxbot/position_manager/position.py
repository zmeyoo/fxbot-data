"""Position lifecycle state machine (one strategy position = one internal id).

PENDING_ENTRY -> OPEN_UNPROTECTED -> OPEN_PROTECTED -> TRAILING_ACTIVE -> PENDING_EXIT -> CLOSED
any non-terminal -> ERROR_REQUIRES_RECONCILIATION
Every transition is validated and appended to an immutable event list (event sourcing).
The class is broker-agnostic: the execution layer feeds it fills / confirmations.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from decimal import Decimal
from enum import Enum
from typing import Any, Dict, List, Optional, Sequence, Set, Tuple

from ..core.types import HUNDRED, ZERO, FxBotError, Quote, Side, require_utc
from ..costs.model import CostBreakdown
from ..instruments.spec import PairSpec
from .trailing import (best_price, favourable_move_pct, initial_stop_price, is_tighter,
                       protected_level_pct, trailing_stop_price)


class IllegalTransition(FxBotError):
    pass


class PositionState(str, Enum):
    PENDING_ENTRY = "PENDING_ENTRY"
    OPEN_UNPROTECTED = "OPEN_UNPROTECTED"
    OPEN_PROTECTED = "OPEN_PROTECTED"
    TRAILING_ACTIVE = "TRAILING_ACTIVE"
    PENDING_EXIT = "PENDING_EXIT"
    CLOSED = "CLOSED"
    ERROR_REQUIRES_RECONCILIATION = "ERROR_REQUIRES_RECONCILIATION"


S = PositionState
_OPEN_STATES = (S.OPEN_UNPROTECTED, S.OPEN_PROTECTED, S.TRAILING_ACTIVE)
ALLOWED: Dict[PositionState, Set[PositionState]] = {
    S.PENDING_ENTRY: {S.OPEN_UNPROTECTED, S.CLOSED, S.ERROR_REQUIRES_RECONCILIATION},
    S.OPEN_UNPROTECTED: {S.OPEN_PROTECTED, S.TRAILING_ACTIVE, S.PENDING_EXIT, S.ERROR_REQUIRES_RECONCILIATION},
    S.OPEN_PROTECTED: {S.TRAILING_ACTIVE, S.OPEN_UNPROTECTED, S.PENDING_EXIT, S.ERROR_REQUIRES_RECONCILIATION},
    S.TRAILING_ACTIVE: {S.OPEN_UNPROTECTED, S.PENDING_EXIT, S.ERROR_REQUIRES_RECONCILIATION},
    S.PENDING_EXIT: {S.CLOSED, S.OPEN_UNPROTECTED, S.OPEN_PROTECTED, S.TRAILING_ACTIVE,
                     S.ERROR_REQUIRES_RECONCILIATION},
    S.ERROR_REQUIRES_RECONCILIATION: {S.OPEN_UNPROTECTED, S.CLOSED},   # conservative resume
    S.CLOSED: set(),
}


class ExitReason(str, Enum):
    INITIAL_STOP = "INITIAL_STOP"          # protective
    TRAILING_STOP = "TRAILING_STOP"        # protective
    PROFIT_TARGET = "PROFIT_TARGET"        # cost-aware profit taking
    MAX_HOLD_TIME = "MAX_HOLD_TIME"        # time based
    END_OF_DAY = "END_OF_DAY"              # time based
    MANUAL = "MANUAL"
    EMERGENCY = "EMERGENCY"
    ENTRY_CANCELLED = "ENTRY_CANCELLED"

    @property
    def protective(self) -> bool:
        return self in (ExitReason.INITIAL_STOP, ExitReason.TRAILING_STOP)


@dataclass(frozen=True)
class StopParams:
    """Snapshot of stop settings taken at entry; later config edits never alter a live trade."""
    initial_stop_pct: Decimal
    trailing_activation_pct: Decimal
    trailing_distance_pct: Decimal


@dataclass(frozen=True)
class Fill:
    exec_id: str                 # broker execution id; duplicates are ignored (idempotent)
    qty: Decimal
    price: Decimal
    order_ts: datetime
    exec_ts: datetime
    ref_quote: Quote             # touch prices when the fill happened (for spread/slippage split)
    commission: Decimal = ZERO   # in quote currency, from the execution report

    def __post_init__(self):
        require_utc(self.order_ts, "order_ts"); require_utc(self.exec_ts, "exec_ts")
        if self.qty <= 0 or self.price <= 0:
            raise FxBotError("fill qty/price must be > 0")


@dataclass(frozen=True)
class BrokerStop:
    order_id: str
    price: Decimal
    qty: Decimal
    confirmed_ts: datetime


@dataclass(frozen=True)
class PositionEvent:
    ts: datetime
    from_state: Optional[PositionState]
    to_state: PositionState
    reason: str
    details: Tuple[Tuple[str, str], ...] = ()


@dataclass(frozen=True)
class TradeRecord:
    position_id: str
    pair: str
    side: Side
    quote_ccy: str
    qty: Decimal
    entry_avg: Decimal
    exit_avg: Decimal
    opened_ts: datetime
    closed_ts: datetime
    exit_reason: ExitReason
    gross_pnl: Decimal
    costs: CostBreakdown
    net_pnl: Decimal
    fx_to_base: Decimal
    exit_move_pct: Decimal               # executable movement at exit vs P0 (signed, +=favourable)
    max_favourable_pct: Decimal
    max_adverse_pct: Decimal
    trail_protected_pct_at_exit: Optional[Decimal]
    est_entry_costs: Optional[CostBreakdown]
    est_exit_costs: Optional[CostBreakdown]
    config_hash: str
    strategy_version: str
    signal_ts: Optional[datetime]

    @property
    def net_pnl_base(self) -> Decimal:
        return self.net_pnl * self.fx_to_base

    @property
    def gross_pnl_base(self) -> Decimal:
        return self.gross_pnl * self.fx_to_base

    @property
    def costs_base(self) -> Decimal:
        return self.costs.total * self.fx_to_base

    @property
    def hold_seconds(self) -> int:
        return int((self.closed_ts - self.opened_ts).total_seconds())


def _cb_dump(c: CostBreakdown) -> Dict[str, str]:
    return {k: str(getattr(c, k)) for k in ("commission", "spread", "slippage", "financing", "other")}


def _cb_load(d: Dict[str, str]) -> CostBreakdown:
    return CostBreakdown(**{k: Decimal(v) for k, v in d.items()})


class Position:
    def __init__(self, *, position_id: str, spec: PairSpec, side: Side, target_qty: Decimal,
                 params: StopParams, created_ts: datetime, config_hash: str,
                 strategy_version: str, signal_ts: Optional[datetime] = None,
                 est_entry_costs: Optional[CostBreakdown] = None):
        require_utc(created_ts, "created_ts")
        self.id, self.spec, self.side, self.params = position_id, spec, side, params
        self.pair, self.quote_ccy = spec.symbol, spec.quote
        self.target_qty = target_qty
        self.created_ts, self.signal_ts = created_ts, signal_ts
        self.config_hash, self.strategy_version = config_hash, strategy_version
        self.state = S.PENDING_ENTRY
        self.entry_working = True
        self.events: List[PositionEvent] = [PositionEvent(created_ts, None, S.PENDING_ENTRY, "created")]
        # quantities and prices
        self.entry_qty_total = ZERO
        self.open_qty = ZERO
        self.avg_entry: Optional[Decimal] = None
        self.entry_mid: Optional[Decimal] = None
        self.opened_ts: Optional[datetime] = None
        self.closed_ts: Optional[datetime] = None
        # costs attributable to the still-open quantity (released pro rata on exits)
        self.entry_costs_open = CostBreakdown()
        self.financing_open = ZERO
        self.est_entry_costs, self.est_exit_costs = est_entry_costs, None
        # extremes (never reset)
        self.p_best: Optional[Decimal] = None
        self.p_worst: Optional[Decimal] = None
        # stops
        self.desired_stop: Optional[Decimal] = None
        self.stop_basis = "initial"
        self.trailing_engaged = False
        self.broker_stop: Optional[BrokerStop] = None
        self.unprotected_since: Optional[datetime] = None
        # exits / realised
        self.exit_reason: Optional[ExitReason] = None
        self.exit_snapshot: Dict[str, Any] = {}
        self.realised_gross = ZERO
        self.realised_costs = CostBreakdown()
        self.exit_qty = ZERO
        self.exit_notional = ZERO
        self.last_exit_quote: Optional[Quote] = None
        self._seen: Set[str] = set()

    # ------------------------------------------------------------- transitions
    def _go(self, to: PositionState, ts: datetime, reason: str, **details: Any) -> None:
        if to not in ALLOWED[self.state]:
            raise IllegalTransition(f"{self.id}: {self.state.value} -> {to.value} ({reason})")
        if to is S.OPEN_UNPROTECTED and self.state is not S.OPEN_UNPROTECTED:
            self.unprotected_since = ts
        if to in (S.OPEN_PROTECTED, S.TRAILING_ACTIVE):
            self.unprotected_since = None
        self.events.append(PositionEvent(ts, self.state, to, reason,
                                         tuple((k, str(v)) for k, v in details.items())))
        self.state = to

    def _protected_state(self) -> PositionState:
        return S.TRAILING_ACTIVE if self.trailing_engaged else S.OPEN_PROTECTED

    @property
    def is_open(self) -> bool:
        return self.state in _OPEN_STATES or self.state is S.PENDING_EXIT

    @property
    def is_protected(self) -> bool:
        return self.state in (S.OPEN_PROTECTED, S.TRAILING_ACTIVE) or (
            self.state is S.PENDING_EXIT and self.broker_stop is not None
            and self.broker_stop.qty >= self.open_qty)

    # --------------------------------------------------------------- entry
    def on_entry_fill(self, fill: Fill) -> bool:
        """Returns False if this execution id was already applied (duplicate ack)."""
        if fill.exec_id in self._seen:
            return False
        if self.state not in (S.PENDING_ENTRY, *_OPEN_STATES) or not self.entry_working:
            raise IllegalTransition(f"{self.id}: entry fill not accepted in {self.state.value}")
        if self.entry_qty_total + fill.qty > self.target_qty:
            raise FxBotError(f"{self.id}: overfill {self.entry_qty_total + fill.qty} > {self.target_qty}")
        self._seen.add(fill.exec_id)
        ref, sgn = fill.ref_quote, Decimal(self.side.sign)
        touch = ref.entry_price(self.side)
        tot = self.entry_qty_total + fill.qty
        self.avg_entry = fill.price if self.avg_entry is None else (self.avg_entry * self.entry_qty_total + fill.price * fill.qty) / tot
        self.entry_mid = ref.mid if self.entry_mid is None else (self.entry_mid * self.entry_qty_total + ref.mid * fill.qty) / tot
        self.entry_qty_total = tot
        self.open_qty += fill.qty
        self.entry_costs_open += CostBreakdown(
            commission=fill.commission,
            spread=abs(touch - ref.mid) * fill.qty,
            slippage=sgn * (fill.price - touch) * fill.qty)
        if self.opened_ts is None:
            self.opened_ts = fill.exec_ts
            self._go(S.OPEN_UNPROTECTED, fill.exec_ts, "first entry fill", qty=fill.qty, price=fill.price)
        elif self.state is not S.OPEN_UNPROTECTED and (
                self.broker_stop is None or self.broker_stop.qty < self.open_qty):
            self._go(S.OPEN_UNPROTECTED, fill.exec_ts, "additional fill not covered by stop")
        self._refresh_stop(ref.exit_price(self.side))
        return True

    def complete_entry(self, ts: datetime) -> None:
        """Entry order finished (filled, or remainder cancelled). No more entry fills accepted."""
        self.entry_working = False
        if self.open_qty == 0 and self.state is S.PENDING_ENTRY:
            self.exit_reason = ExitReason.ENTRY_CANCELLED
            self.closed_ts = ts
            self._go(S.CLOSED, ts, "entry cancelled with no fills")

    # ---------------------------------------------------------- protection
    def confirm_protection(self, order_id: str, price: Decimal, qty: Decimal, ts: datetime) -> None:
        if self.state not in (*_OPEN_STATES, S.PENDING_EXIT):
            raise IllegalTransition(f"{self.id}: cannot confirm protection in {self.state.value}")
        self.broker_stop = BrokerStop(order_id, price, qty, ts)
        if self.state is S.OPEN_UNPROTECTED and qty >= self.open_qty:
            self._go(self._protected_state(), ts, "protection confirmed by broker", order=order_id)

    def protection_lost(self, ts: datetime, reason: str) -> None:
        self.broker_stop = None
        if self.state in (S.OPEN_PROTECTED, S.TRAILING_ACTIVE):
            self._go(S.OPEN_UNPROTECTED, ts, f"protection lost: {reason}")

    def mark_error(self, ts: datetime, reason: str) -> None:
        if self.state is not S.CLOSED:
            self._go(S.ERROR_REQUIRES_RECONCILIATION, ts, reason)

    def resume_after_reconciliation(self, ts: datetime, open_qty: Decimal) -> None:
        """Conservative: after reconciliation a position is UNPROTECTED until the broker stop is re-confirmed."""
        if open_qty <= 0:
            self.open_qty = ZERO
            self.closed_ts = ts
            self._go(S.CLOSED, ts, "reconciliation: no broker position")
        else:
            self.open_qty = open_qty
            self.broker_stop = None
            self._go(S.OPEN_UNPROTECTED, ts, "reconciled; protection must be re-confirmed")

    # --------------------------------------------------------------- market
    def update_market(self, quote: Quote) -> bool:
        """Advance extremes and ratchet the stop. Returns True if the desired stop tightened."""
        if self.state not in (*_OPEN_STATES, S.PENDING_EXIT) or self.open_qty <= 0:
            return False
        return self._refresh_stop(quote.exit_price(self.side))

    def _refresh_stop(self, px: Decimal) -> bool:
        side, p0 = self.side, self.avg_entry
        self.p_best = best_price(side, self.p_best if self.p_best is not None else p0, px)
        worst_fn = min if side is Side.LONG else max
        self.p_worst = worst_fn(self.p_worst if self.p_worst is not None else p0, px)
        cand = self.spec.round_stop(side, initial_stop_price(side, p0, self.params.initial_stop_pct))
        basis = "initial"
        tr = trailing_stop_price(side, p0, self.p_best, self.params.trailing_activation_pct,
                                 self.params.trailing_distance_pct)
        if tr is not None:
            self.trailing_engaged = True
            tr = self.spec.round_stop(side, tr)
            if is_tighter(side, tr, cand):
                cand, basis = tr, "trailing"
        if self.desired_stop is None or is_tighter(side, cand, self.desired_stop):
            self.desired_stop, self.stop_basis = cand, basis      # ratchet: tightens only
            return True
        return False

    def mark_trailing_if_protected(self, ts: datetime) -> None:
        """Move OPEN_PROTECTED -> TRAILING_ACTIVE once trailing has engaged."""
        if self.state is S.OPEN_PROTECTED and self.trailing_engaged:
            self._go(S.TRAILING_ACTIVE, ts, "trailing activated")

    @property
    def max_favourable_pct(self) -> Decimal:
        return favourable_move_pct(self.side, self.avg_entry, self.p_best) if self.p_best is not None else ZERO

    @property
    def max_adverse_pct(self) -> Decimal:
        return favourable_move_pct(self.side, self.avg_entry, self.p_worst) if self.p_worst is not None else ZERO

    @property
    def trail_protected_pct(self) -> Optional[Decimal]:
        if self.p_best is None:
            return None
        return protected_level_pct(self.side, self.avg_entry, self.p_best,
                                   self.params.trailing_activation_pct, self.params.trailing_distance_pct)

    def add_financing(self, amount: Decimal) -> None:
        """Actual (broker-reported) or estimated financing attributable to the open quantity."""
        self.financing_open += amount

    # ---------------------------------------------------------------- exit
    def request_exit(self, reason: ExitReason, ts: datetime, *, est_exit_costs: Optional[CostBreakdown] = None,
                     snapshot: Optional[Dict[str, Any]] = None) -> bool:
        """False if an exit is already pending (prevents duplicate close orders)."""
        if self.state is S.PENDING_EXIT:
            return False
        self.exit_reason = reason
        self.est_exit_costs = est_exit_costs
        self.exit_snapshot = {"protected_pct": self.trail_protected_pct, **(snapshot or {})}
        self._go(S.PENDING_EXIT, ts, f"exit requested: {reason.value}")
        return True

    def on_exit_fill(self, fill: Fill, reason: Optional[ExitReason] = None) -> bool:
        if fill.exec_id in self._seen:
            return False
        if self.state is S.PENDING_ENTRY or self.state is S.CLOSED:
            raise IllegalTransition(f"{self.id}: exit fill in {self.state.value}")
        if fill.qty > self.open_qty:
            raise FxBotError(f"{self.id}: exit fill {fill.qty} > open {self.open_qty}")
        if self.state is not S.PENDING_EXIT:      # e.g. the resting broker stop filled by itself
            self.request_exit(reason or (ExitReason.TRAILING_STOP if self.stop_basis == "trailing"
                                         else ExitReason.INITIAL_STOP), fill.exec_ts,
                              snapshot={"source": "broker-side fill"})
        self._seen.add(fill.exec_id)
        ref, sgn, q = fill.ref_quote, Decimal(self.side.sign), fill.qty
        frac = q / self.open_qty
        touch = ref.exit_price(self.side)
        gross = sgn * (ref.mid - self.entry_mid) * q
        exit_c = CostBreakdown(commission=fill.commission, spread=abs(ref.mid - touch) * q,
                               slippage=sgn * (touch - fill.price) * q)
        released = self.entry_costs_open.scaled(frac)
        fin = self.financing_open * frac
        self.entry_costs_open = self.entry_costs_open - released
        self.financing_open -= fin
        self.realised_gross += gross
        self.realised_costs = self.realised_costs + released + exit_c + CostBreakdown(financing=fin)
        self.exit_qty += q
        self.exit_notional += q * fill.price
        self.open_qty -= q
        self.last_exit_quote = ref
        if self.open_qty == 0:
            self.closed_ts = fill.exec_ts
            self._go(S.CLOSED, fill.exec_ts, "fully exited", exit_reason=self.exit_reason.value)
        return True

    def on_exit_aborted(self, ts: datetime, protection_confirmed: bool) -> None:
        """Exit order rejected/cancelled. Never assume protection survived: caller states it."""
        if protection_confirmed and self.broker_stop is not None and self.broker_stop.qty >= self.open_qty:
            self._go(self._protected_state(), ts, "exit aborted; protection intact")
        else:
            self._go(S.OPEN_UNPROTECTED, ts, "exit aborted; protection NOT confirmed")
        self.exit_reason = None

    # ----------------------------------------------------------- persistence
    def protection_target(self) -> Tuple[Decimal, Decimal]:
        """(stop price, quantity) the execution layer must have confirmed at the broker. After a
        restart this is the RATCHETED level (trailing if active), never the initial stop."""
        return self.desired_stop, self.open_qty

    def snapshot(self) -> Dict[str, Any]:
        """JSON-safe full state (trailing extreme, stop level, trailing flag, broker stop, costs,
        seen execution ids, event log). Persist after every change; see from_snapshot."""
        d = lambda x: None if x is None else str(x)
        t = lambda x: None if x is None else x.isoformat()
        bs = self.broker_stop
        return {
            "v": 1, "id": self.id, "pair": self.pair, "side": self.side.value,
            "target_qty": d(self.target_qty),
            "params": {"initial_stop_pct": d(self.params.initial_stop_pct),
                       "trailing_activation_pct": d(self.params.trailing_activation_pct),
                       "trailing_distance_pct": d(self.params.trailing_distance_pct)},
            "created_ts": t(self.created_ts), "signal_ts": t(self.signal_ts),
            "config_hash": self.config_hash, "strategy_version": self.strategy_version,
            "state": self.state.value, "entry_working": self.entry_working,
            "entry_qty_total": d(self.entry_qty_total), "open_qty": d(self.open_qty),
            "avg_entry": d(self.avg_entry), "entry_mid": d(self.entry_mid),
            "opened_ts": t(self.opened_ts), "closed_ts": t(self.closed_ts),
            "entry_costs_open": _cb_dump(self.entry_costs_open), "financing_open": d(self.financing_open),
            "est_entry_costs": None if self.est_entry_costs is None else _cb_dump(self.est_entry_costs),
            "est_exit_costs": None if self.est_exit_costs is None else _cb_dump(self.est_exit_costs),
            "p_best": d(self.p_best), "p_worst": d(self.p_worst), "desired_stop": d(self.desired_stop),
            "stop_basis": self.stop_basis, "trailing_engaged": self.trailing_engaged,
            "broker_stop": None if bs is None else {"order_id": bs.order_id, "price": d(bs.price),
                                                    "qty": d(bs.qty), "confirmed_ts": t(bs.confirmed_ts)},
            "unprotected_since": t(self.unprotected_since),
            "exit_reason": None if self.exit_reason is None else self.exit_reason.value,
            "exit_snapshot": {k: (None if v is None else str(v)) for k, v in self.exit_snapshot.items()},
            "realised_gross": d(self.realised_gross), "realised_costs": _cb_dump(self.realised_costs),
            "exit_qty": d(self.exit_qty), "exit_notional": d(self.exit_notional),
            "seen": sorted(self._seen),
            "events": [[t(e.ts), None if e.from_state is None else e.from_state.value, e.to_state.value,
                        e.reason, [list(x) for x in e.details]] for e in self.events],
        }

    @classmethod
    def from_snapshot(cls, d: Dict[str, Any], spec: PairSpec) -> "Position":
        """Exact restore of a persisted position. The caller must then reconcile with the broker
        (mark_error -> resume_after_reconciliation), which keeps p_best / stop level / trailing flag."""
        if d.get("v") != 1 or d["pair"] != spec.symbol:
            raise FxBotError("snapshot version/pair mismatch")
        D_ = lambda x: None if x is None else Decimal(x)
        T_ = lambda x: None if x is None else datetime.fromisoformat(x)
        p = d["params"]
        pos = cls(position_id=d["id"], spec=spec, side=Side(d["side"]), target_qty=Decimal(d["target_qty"]),
                  params=StopParams(Decimal(p["initial_stop_pct"]), Decimal(p["trailing_activation_pct"]),
                                    Decimal(p["trailing_distance_pct"])),
                  created_ts=T_(d["created_ts"]), config_hash=d["config_hash"],
                  strategy_version=d["strategy_version"], signal_ts=T_(d["signal_ts"]))
        pos.state = PositionState(d["state"]); pos.entry_working = d["entry_working"]
        pos.entry_qty_total, pos.open_qty = Decimal(d["entry_qty_total"]), Decimal(d["open_qty"])
        pos.avg_entry, pos.entry_mid = D_(d["avg_entry"]), D_(d["entry_mid"])
        pos.opened_ts, pos.closed_ts = T_(d["opened_ts"]), T_(d["closed_ts"])
        pos.entry_costs_open = _cb_load(d["entry_costs_open"]); pos.financing_open = Decimal(d["financing_open"])
        pos.est_entry_costs = None if d["est_entry_costs"] is None else _cb_load(d["est_entry_costs"])
        pos.est_exit_costs = None if d["est_exit_costs"] is None else _cb_load(d["est_exit_costs"])
        pos.p_best, pos.p_worst, pos.desired_stop = D_(d["p_best"]), D_(d["p_worst"]), D_(d["desired_stop"])
        pos.stop_basis, pos.trailing_engaged = d["stop_basis"], d["trailing_engaged"]
        b = d["broker_stop"]
        pos.broker_stop = None if b is None else BrokerStop(b["order_id"], Decimal(b["price"]),
                                                            Decimal(b["qty"]), T_(b["confirmed_ts"]))
        pos.unprotected_since = T_(d["unprotected_since"])
        pos.exit_reason = None if d["exit_reason"] is None else ExitReason(d["exit_reason"])
        pos.exit_snapshot = {k: (Decimal(v) if k == "protected_pct" and v is not None else v)
                             for k, v in d["exit_snapshot"].items()}
        pos.realised_gross, pos.realised_costs = Decimal(d["realised_gross"]), _cb_load(d["realised_costs"])
        pos.exit_qty, pos.exit_notional = Decimal(d["exit_qty"]), Decimal(d["exit_notional"])
        pos._seen = set(d["seen"])
        pos.events = [PositionEvent(T_(e[0]), None if e[1] is None else PositionState(e[1]),
                                    PositionState(e[2]), e[3], tuple(tuple(x) for x in e[4]))
                      for e in d["events"]]
        return pos

    # -------------------------------------------------------------- results
    @property
    def realised_net(self) -> Decimal:
        return self.realised_gross - self.realised_costs.total

    @property
    def exit_avg(self) -> Optional[Decimal]:
        return self.exit_notional / self.exit_qty if self.exit_qty else None

    def to_trade_record(self, fx_to_base: Decimal) -> TradeRecord:
        if self.state is not S.CLOSED or self.exit_qty == 0:
            raise FxBotError("trade record requires a closed position with exits")
        move = favourable_move_pct(self.side, self.avg_entry, self.exit_avg)
        return TradeRecord(
            position_id=self.id, pair=self.pair, side=self.side, quote_ccy=self.quote_ccy,
            qty=self.exit_qty, entry_avg=self.avg_entry, exit_avg=self.exit_avg,
            opened_ts=self.opened_ts, closed_ts=self.closed_ts, exit_reason=self.exit_reason,
            gross_pnl=self.realised_gross, costs=self.realised_costs, net_pnl=self.realised_net,
            fx_to_base=fx_to_base, exit_move_pct=move,
            max_favourable_pct=self.max_favourable_pct, max_adverse_pct=self.max_adverse_pct,
            trail_protected_pct_at_exit=self.exit_snapshot.get("protected_pct"),
            est_entry_costs=self.est_entry_costs, est_exit_costs=self.est_exit_costs,
            config_hash=self.config_hash, strategy_version=self.strategy_version,
            signal_ts=self.signal_ts)


def unprotected_positions(positions: Sequence[Position], now: datetime, timeout_s: int) -> List[Position]:
    """Positions that are open without confirmed protection for longer than the timeout,
    plus any open position in ERROR (unknown protection). Drives the emergency policy."""
    out = []
    for p in positions:
        if p.state is S.OPEN_UNPROTECTED and p.unprotected_since is not None \
                and (now - p.unprotected_since).total_seconds() > timeout_s:
            out.append(p)
        elif p.state is S.ERROR_REQUIRES_RECONCILIATION and p.open_qty > 0:
            out.append(p)
    return out
