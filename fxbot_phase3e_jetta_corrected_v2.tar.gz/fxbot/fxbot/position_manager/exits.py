"""Exit engine. Two independent mechanisms plus time exits, evaluated in strict priority:

 1. PROTECTIVE  initial stop / trailing stop  - always fires, ignores costs and net P&L
 2. TIME        end-of-day cutoff, max holding time - clock only, works on stale data
 3. PROFIT      cost-aware profit taking (expected net >= min net profit) - optional

Protective logic is evaluated first and is never gated by profit-taking settings.
Price-based decisions are NOT taken from stale/invalid quotes (the resting broker stop
remains the protection); that condition is reported as a warning.
"""
from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from typing import Optional, Tuple

from ..config.schema import MinNetProfit, PairConfig
from ..costs.model import CostContext
from ..core.types import Quote
from ..market_data.staleness import quote_problems
from .pnl import PnLEstimate, estimate_open_pnl
from .position import ExitReason, Position, PositionState
from .trailing import is_stop_hit


@dataclass(frozen=True)
class ExitPolicy:
    max_hold_seconds: int
    max_quote_age_s: Optional[int]
    eod_cutoff: Optional[datetime] = None
    profit_taking_enabled: bool = False
    min_net_profit: Optional[MinNetProfit] = None

    @staticmethod
    def from_config(cfg: PairConfig, max_quote_age_s: Optional[int],
                    eod_cutoff: Optional[datetime]) -> "ExitPolicy":
        return ExitPolicy(cfg.max_hold_minutes * 60, max_quote_age_s, eod_cutoff,
                          cfg.profit_taking_enabled, cfg.min_net_profit)


@dataclass(frozen=True)
class ExitDecision:
    reason: ExitReason
    trigger_price: Optional[object]
    detail: str
    pnl: Optional[PnLEstimate] = None

    @property
    def protective(self) -> bool:
        return self.reason.protective


@dataclass(frozen=True)
class Evaluation:
    exit: Optional[ExitDecision]
    stop_tightened: bool
    warnings: Tuple[str, ...]
    pnl: Optional[PnLEstimate]


def evaluate_exit(pos: Position, quote: Optional[Quote], now: datetime, policy: ExitPolicy,
                  ctx: Optional[CostContext]) -> Evaluation:
    if pos.state not in (PositionState.OPEN_UNPROTECTED, PositionState.OPEN_PROTECTED,
                         PositionState.TRAILING_ACTIVE) or pos.open_qty <= 0:
        return Evaluation(None, False, (), None)       # nothing to do / exit already pending
    problems = quote_problems(quote, now, policy.max_quote_age_s)
    warnings = tuple(f"data: {p}" for p in problems)
    pnl: Optional[PnLEstimate] = None
    tightened = False
    if not problems:
        tightened = pos.update_market(quote)
        if ctx is not None:
            pnl = estimate_open_pnl(pos, quote, ctx, policy.min_net_profit)
        # 1. protective
        if is_stop_hit(pos.side, pos.desired_stop, quote):
            reason = ExitReason.TRAILING_STOP if pos.stop_basis == "trailing" else ExitReason.INITIAL_STOP
            return Evaluation(ExitDecision(reason, pos.desired_stop,
                                           f"{pos.side.value} stop {pos.desired_stop} hit at "
                                           f"bid={quote.bid} ask={quote.ask}", pnl),
                              tightened, warnings, pnl)
    # 2. time based (clock only)
    if policy.eod_cutoff is not None and now >= policy.eod_cutoff:
        return Evaluation(ExitDecision(ExitReason.END_OF_DAY, None, "end-of-day cutoff", pnl),
                          tightened, warnings, pnl)
    if pos.opened_ts is not None and (now - pos.opened_ts).total_seconds() >= policy.max_hold_seconds:
        return Evaluation(ExitDecision(ExitReason.MAX_HOLD_TIME, None,
                                       f"held >= {policy.max_hold_seconds}s", pnl),
                          tightened, warnings, pnl)
    # 3. cost-aware profit taking (separate, optional)
    if (not problems and policy.profit_taking_enabled and policy.min_net_profit is not None
            and pnl is not None and pnl.min_net_profit_target is not None
            and pnl.expected_net_pnl >= pnl.min_net_profit_target):
        return Evaluation(ExitDecision(ExitReason.PROFIT_TARGET, pnl.profit_target_price,
                                       f"expected net {pnl.expected_net_pnl} >= target "
                                       f"{pnl.min_net_profit_target}", pnl),
                          tightened, warnings, pnl)
    return Evaluation(None, tightened, warnings, pnl)
