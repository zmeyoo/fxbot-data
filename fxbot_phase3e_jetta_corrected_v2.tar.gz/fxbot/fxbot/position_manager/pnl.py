from __future__ import annotations

from dataclasses import dataclass
from decimal import Decimal
from typing import Optional

from ..config.schema import MinNetProfit
from ..core.types import ZERO, Quote
from ..costs.model import CostBreakdown, CostContext, resolve_min_net_profit
from .position import Position
from .trailing import favourable_move_pct


@dataclass(frozen=True)
class PnLEstimate:
    """Everything the dashboard must show, for the still-open quantity (quote ccy)."""
    price_movement_pct: Decimal         # executable movement vs P0 (what trailing uses)
    gross_pnl: Decimal                  # mid-to-mid
    est_entry_costs: CostBreakdown      # actual entry costs attributable to open qty
    est_exit_costs: CostBreakdown       # commission + current half-spread + slippage est
    financing: Decimal
    expected_net_pnl: Decimal
    realised_net_so_far: Decimal        # from partial exits already closed
    cost_breakeven_price: Decimal       # executable exit price giving expected net == 0
    min_net_profit_target: Optional[Decimal]
    profit_target_price: Optional[Decimal]
    expected_net_pnl_base: Decimal
    gross_pnl_base: Decimal


def estimate_open_pnl(pos: Position, quote: Quote, ctx: CostContext,
                      min_net: Optional[MinNetProfit] = None) -> PnLEstimate:
    side, q, ccy = pos.side, pos.open_qty, pos.quote_ccy
    sgn = Decimal(side.sign)
    exit_px = quote.exit_price(side)
    gross = sgn * (quote.mid - pos.entry_mid) * q
    exit_comm = ctx.commission_quote(q, exit_px, ccy)
    exit_c = CostBreakdown(commission=exit_comm, spread=abs(quote.mid - exit_px) * q,
                           slippage=ctx.slip_price(exit_px) * q)
    ent = pos.entry_costs_open
    net = gross - ent.total - exit_c.total - pos.financing_open
    fixed = ent.commission + ent.other + exit_comm + exit_c.slippage + pos.financing_open
    be = pos.avg_entry + sgn * fixed / q
    target = tprice = None
    if min_net is not None:
        # absolute amounts scale with the fraction of the original size still open
        target = resolve_min_net_profit(min_net, ctx, q, pos.avg_entry, ccy)
        if min_net.mode.value == "absolute_base":
            target = target * q / pos.entry_qty_total
        tprice = be + sgn * target / q
    return PnLEstimate(
        price_movement_pct=favourable_move_pct(side, pos.avg_entry, exit_px),
        gross_pnl=gross, est_entry_costs=ent, est_exit_costs=exit_c,
        financing=pos.financing_open, expected_net_pnl=net, realised_net_so_far=pos.realised_net,
        cost_breakeven_price=be, min_net_profit_target=target, profit_target_price=tprice,
        expected_net_pnl_base=ctx.to_base(net, ccy), gross_pnl_base=ctx.to_base(gross, ccy))
