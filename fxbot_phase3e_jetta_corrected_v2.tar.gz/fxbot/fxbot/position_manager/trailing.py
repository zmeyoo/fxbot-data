"""Pure stop / trailing mathematics (direction-aware, symmetric).

Definitions (all percentages are of the position's OWN average entry price P0, never of equity,
margin or accumulated profit; the distance is measured from the BEST FAVOURABLE EXECUTABLE price):

  extreme   LONG: highest executable BID since entry      SHORT: lowest executable ASK since entry
  active    sign*(extreme - P0) >= P0*activation_pct/100            (price form: no division)
  distance  P0 * trailing_distance_pct / 100                        (a fixed price amount per position)
  threshold LONG: extreme - distance      SHORT: extreme + distance  ==  extreme - sign*distance
  exit      LONG: executable BID <= threshold      SHORT: executable ASK >= threshold

Equivalent spec form: protected level = Rmax - distance_pct  (percentage points of P0), i.e.
threshold = P0*(1 + sign*(Rmax - distance_pct)/100). Example: P0=100, extreme=101, distance 0.10
-> threshold 100.90 (LONG) / extreme 99 -> 99.10 (SHORT). Tests assert both forms agree.
"""
from __future__ import annotations

from decimal import Decimal
from typing import Optional

from ..core.types import HUNDRED, Quote, Side


def initial_stop_price(side: Side, p0: Decimal, stop_pct: Decimal) -> Decimal:
    # LONG: P0*(1-pct/100)   SHORT: P0*(1+pct/100)
    return p0 * (1 - side.sign * stop_pct / HUNDRED)


def favourable_move_pct(side: Side, p0: Decimal, price: Decimal) -> Decimal:
    """Signed favourable movement in % of P0 (negative = adverse)."""
    return side.sign * (price - p0) / p0 * HUNDRED


def best_price(side: Side, current_best: Optional[Decimal], price: Decimal) -> Decimal:
    """Monotonic extreme: highest for LONG, lowest for SHORT. Never resets."""
    if current_best is None:
        return price
    return max(current_best, price) if side is Side.LONG else min(current_best, price)


def trailing_active(side: Side, p0: Decimal, extreme: Decimal, activation_pct: Decimal) -> bool:
    return side.sign * (extreme - p0) >= p0 * activation_pct / HUNDRED


def trailing_distance_price(p0: Decimal, distance_pct: Decimal) -> Decimal:
    return p0 * distance_pct / HUNDRED


def trailing_threshold_from_extreme(side: Side, p0: Decimal, extreme: Decimal,
                                    distance_pct: Decimal) -> Decimal:
    """extreme - sign*distance  (LONG: extreme - d; SHORT: extreme + d)."""
    return extreme - side.sign * trailing_distance_price(p0, distance_pct)


def trailing_stop_price(side: Side, p0: Decimal, p_best: Decimal,
                        activation_pct: Decimal, distance_pct: Decimal) -> Optional[Decimal]:
    if not trailing_active(side, p0, p_best, activation_pct):
        return None
    return trailing_threshold_from_extreme(side, p0, p_best, distance_pct)


def protected_level_pct(side: Side, p0: Decimal, p_best: Decimal,
                        activation_pct: Decimal, distance_pct: Decimal) -> Optional[Decimal]:
    """Protected movement in % of P0 (Rmax - distance); None while trailing is not active."""
    if not trailing_active(side, p0, p_best, activation_pct):
        return None
    return favourable_move_pct(side, p0, p_best) - distance_pct


def is_tighter(side: Side, a: Decimal, b: Decimal) -> bool:
    """True if stop `a` is strictly tighter (less risk) than stop `b`."""
    return a > b if side is Side.LONG else a < b


def tighter_of(side: Side, a: Optional[Decimal], b: Optional[Decimal]) -> Optional[Decimal]:
    if a is None:
        return b
    if b is None:
        return a
    return a if is_tighter(side, a, b) else b


def is_stop_hit(side: Side, stop: Decimal, quote: Quote) -> bool:
    """Triggered when the executable side reaches or crosses the stop."""
    return quote.bid <= stop if side is Side.LONG else quote.ask >= stop
