# Tick data validation report

- file: `tests/data/eurusd_dukascopy_published_sample_ticks.csv`
- format: **dukascopy_csv** (ts=`timestamp` [ms], bid=`bidPrice`, ask=`askPrice`)
- records kept: 2; span 2020-03-30 00:00:00.104000+00:00 .. 2020-03-30 00:00:00.256000+00:00
- overall: **NO FAILED CHECKS**

| check | status | detail |
|---|---|---|
| Timestamp parsing / timezone | **PASS** | unit=ms; all UTC-aware=True; non-decreasing=True; exact epoch round-trip mismatches=0; resolution=sub-second; max quotes sharing one timestamp=1 |
| BID/ASK field mapping + executable side | **PASS** | mapped by NAME: bid<-'bidPrice', ask<-'askPrice'; rows where parsed != raw column: 0; bid<=ask on all kept rows: True; crossed fraction in file: 0.000; LONG enters at ASK and exits at BID, SHORT enters at BID and exits at ASK: True |
| Duplicate / out-of-order / stale quotes | **NOT TESTABLE** | dropped: 0 exact duplicates, 0 out-of-order, 0 crossed/invalid; unchanged-price re-quotes kept: 0; inter-arrival s median/p95/p99/max = 0.152/0.152/0.152/0.152; intervals >10s/30s/60s: ((10, 0), (30, 0), (60, 0))  [only 2 records: code paths are covered by synthetic-file unit tests, the statistics here say nothing about the feed] |
| Bid/ask spread calculation | **PASS** | spread=ask-bid, mid=(ask+bid)/2 recomputed from the raw text with exact Decimals; mismatches vs loader: 0; mean/median/max spread % = 0.00808/0.00808/0.00898 |
| Data gaps and session boundaries | **NOT TESTABLE** | unexpected gaps (> 120s, outside the weekly closure): 0; weekend closures: 0; quotes stamped inside the Fri-17:00/Sun-17:00 New York closure: 0; sessions seen: 2020-03-30: 2 quotes 2020-03-30T00:00:00.104000+00:00..2020-03-30T00:00:00.256000+00:00; first quote falls in session '2020-03-30' = 2020-03-29T21:00:00+00:00 .. 2020-03-30T21:00:00+00:00 |
| Original quote precision preserved | **PASS** | prices stored as exact Decimal (no float); text of every price identical after parsing (rows changed: 0); decimal places seen: (5,) |
| Dataset fingerprint | **INFO** | sha256 of canonical (ts,bid,ask) = c735de132121017099ba4648f9c23a5591afbe6516f50eaf6100604d7e2cf36e |

## Sample rows (raw text -> parsed)

**Row 1** raw: `{'timestamp': '1585526400104', 'askPrice': '1.11369', 'bidPrice': '1.11361', 'askVolume': '0.75', 'bidVolume': '0.75'}`
- UTC `2020-03-30T00:00:00.104000+00:00`  |  New York `2020-03-29T20:00:00.104000-04:00`  |  session `2020-03-30` (2020-03-29T21:00:00+00:00 .. 2020-03-30T21:00:00+00:00)
- bid `1.11361`  ask `1.11369`  spread `0.00008` (0.8 pips, 0.00718%)  mid `1.11365`

**Row 2** raw: `{'timestamp': '1585526400256', 'askPrice': '1.11371', 'bidPrice': '1.11361', 'askVolume': '0.94', 'bidVolume': '1.5'}`
- UTC `2020-03-30T00:00:00.256000+00:00`  |  New York `2020-03-29T20:00:00.256000-04:00`  |  session `2020-03-30` (2020-03-29T21:00:00+00:00 .. 2020-03-30T21:00:00+00:00)
- bid `1.11361`  ask `1.11371`  spread `0.00010` (1.0 pips, 0.00898%)  mid `1.11366`

## Limitations
- Tick data: stop/trailing fills are simulated at the first quote after the trigger plus latency; quote timestamps have the source's granularity (IBKR ticks are not guaranteed to be every quote).
- Financing/rollover is not modelled unless rates are supplied; positions are flat before the EOD cutoff.
- No economic calendar is connected: the backtest has NO news protection.
