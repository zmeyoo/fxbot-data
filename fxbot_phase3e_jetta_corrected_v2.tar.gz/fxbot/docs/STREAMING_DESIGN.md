# Streaming research engine - DESIGN ONLY (Milestone 2; nothing here is implemented yet)

Status: **design for your approval.** Milestone 1 (pilot download) and Milestone 2 (streaming engine) are separate. No 6-12 month download starts until the
acceptance tests in section 7 pass and their results are reviewed. Strategy rules, costs and results semantics do not change.

## 1. Goal
Run the existing backtester over tick files of any size with **memory independent of dataset size** and **results identical** to the current in-memory engine.
Raw data stays full resolution. No decimation, no sampling.

## 2. What is and is not streaming today (inventory)
| component | today | change needed |
|---|---|---|
| `_Run.process(quote)` (bars, signals, gate, position, exits) | processes one quote at a time; state is bounded (three fixed bar windows, tracker, position, governor) | none |
| `run_backtest(source)` | needs `len(source)` and `source[0]` (type detection), iterates once | accept any iterable; explicit `kind="ticks"|"bars"` |
| `load_ticks_csv` | builds a list of all quotes (369 bytes each) | stays for small data; shared row-acceptance logic extracted |
| `slice_source` / `ResearchSession` / `walk_forward` / sweeps | copy list slices for every window and variant | operate on a re-iterable `QuoteStream` view |
| `validate_dataset` / `analyze_csv` | already streaming (hour slices, constant-memory statistics) | none |
| reports / trade lists | small (one record per trade) | none |

## 3. Interface
```python
class QuoteStream(Protocol):
    def __iter__(self) -> Iterator[Quote]: ...          # re-iterable: every call starts a fresh pass
    def window(self, start, end) -> "QuoteStream": ...  # lazy view, start <= market_ts < end, no data read yet
    @property
    def fingerprint(self) -> str: ...                   # dataset SHA-256 from dataset.json (+ window)
    stats: StreamStats                                   # rows read, dropped_crossed / duplicate / out_of_order (same counters as DatasetReport)

class ListQuoteStream(QuoteStream): ...                  # wraps today's list: used for the equivalence tests and small data
class CsvQuoteStream(QuoteStream): ...                   # reads the normalised CSV in bounded blocks, parses rows lazily
```
* **One implementation of row acceptance** (parse, drop crossed/non-positive, drop out-of-order, drop exact duplicates) shared by `load_ticks_csv` and `CsvQuoteStream`,
  so semantics cannot diverge. Duplicate detection uses only the previous accepted key (O(1)).
* `run_backtest(stream, settings)` consumes the iterator; nothing else changes.
* **Time index sidecar** (`<csv>.idx`, built in one O(1)-memory pass, hash recorded in `dataset.json`): per UTC hour -> (byte offset, row number, first timestamp).
  `window()` seeks to the hour at or before `start` and stops at the first row `>= end`. Bytes beyond the end hour are **not read** (reads are bounded by the index),
  which is how a development window stays physically unable to touch the holdout (the `HoldoutAccessError` check happens before any file is opened).
* **Single-pass multi-variant option** (`run_many(stream, [settings...])`): one parse, K independent engines, memory O(K). Decide after measuring parse throughput.

## 4. Chunk boundaries, state continuity, sessions, duplicates
* The engine state lives in one `_Run` for the whole pass, so "state continuity" means the engine must be indifferent to how the source delivers quotes. Reads happen in blocks
  of arbitrary size; a block may end mid-line, mid-timestamp-group or between a duplicate pair.
* Session boundaries are engine logic (17:00 New York, DST-aware) driven by quote timestamps only; the stream never needs session awareness. Windows are cut at hour boundaries
  by the index; warm-up (`trade_from - warmup`) is just an earlier window start.
* Optional later: `_Run.snapshot()/restore()` so long runs can checkpoint. Not required for equivalence.

## 5. Known risk: parse throughput
Streaming fixes memory, not CPU. Parsing (`Decimal` + aware datetime) will likely cost several microseconds per row, on top of the measured ~19 us/quote engine cost. For ~10^8 rows a
single pass would take tens of minutes, and a 100-variant sweep days. Mitigations to measure (not assume): single-pass fan-out, multiprocessing over variants, a *derived* compact binary
cache (integer points + epoch ms) with an exact round-trip test against the CSV. The raw files and CSV remain the master data in every case.

## 6. Non-goals
No change to strategy rules, signals, costs, risk, session logic, or reported metrics. No sampled/decimated research file. No live-trading or broker work.

## 7. Acceptance tests (Milestone 2 is done only when all pass and the numbers are reported to you)
1. **Equivalence:** `run_backtest(list)` vs `run_backtest(CsvQuoteStream)` give identical trades, metadata, counters, rejection counts and data-quality blocks on (a) 10+ synthetic days, (b) every
   latency in {0.5, 1, 2, 5}, (c) both reset modes, (d) the real pilot dataset once validated (a slice small enough for the list engine); walk-forward folds likewise.
2. **Chunk boundaries:** identical results for read-block sizes of 1 byte, 7 bytes, one line, 4 KiB and 1 MiB; blocks ending inside a line and inside a same-timestamp group; windows starting/ending exactly on hour boundaries.
3. **Trailing state continuity:** an open bar, 5m/15m aggregator, indicator windows, post-close tracker, cooldown, open position and pending orders survive arbitrary delivery patterns (generator yielding random-sized batches) with identical outcomes.
4. **Sessions:** files spanning many sessions, a DST change, weekend closures and a mid-week gap: identical results, and the first quote of a session handled identically.
5. **Duplicates / dirty rows:** exact duplicates, out-of-order and crossed rows placed on block boundaries: identical accepted rows and identical drop counters in loader and stream.
6. **Memory independent of size:** peak memory (tracemalloc and process RSS) measured on CSVs of N, 2N, 10N rows (up to several million, generated deterministically for the test): peak must not grow with N (budget: a few tens of MB above baseline). The numbers go into `STREAMING_RESULTS.md`.
7. **Holdout isolation:** a window ending at the holdout boundary never reads bytes past it (verified with an instrumented file object); poisoning data after the boundary changes nothing.
8. **Throughput report:** parse + engine microseconds per row, single pass and fan-out, measured, with an extrapolation to the pilot and to 6/12 months.
