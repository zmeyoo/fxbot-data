-- PostgreSQL 15+. NOT yet executed (Alembic migrations + SQLAlchemy models follow in Phase 4).
-- Money/prices are NUMERIC (never float). Event tables are append-only (trigger below).
CREATE TABLE config_versions (hash TEXT PRIMARY KEY, body JSONB NOT NULL, created_at TIMESTAMPTZ NOT NULL);
CREATE TABLE config_audit (id BIGSERIAL PRIMARY KEY, ts TIMESTAMPTZ NOT NULL, actor TEXT NOT NULL, path TEXT NOT NULL,
  old_value JSONB, new_value JSONB, old_hash TEXT NOT NULL, new_hash TEXT NOT NULL REFERENCES config_versions(hash));
CREATE TABLE signals (id UUID PRIMARY KEY, pair TEXT NOT NULL, direction TEXT NOT NULL, signal_ts TIMESTAMPTZ NOT NULL,
  market_ts TIMESTAMPTZ NOT NULL, valid BOOLEAN NOT NULL, reasons JSONB NOT NULL, config_hash TEXT NOT NULL, strategy_version TEXT NOT NULL);
CREATE TABLE strategy_positions (id TEXT PRIMARY KEY, pair TEXT NOT NULL, side TEXT NOT NULL, state TEXT NOT NULL,
  target_qty NUMERIC NOT NULL, open_qty NUMERIC NOT NULL, avg_entry NUMERIC, entry_mid NUMERIC, p_best NUMERIC, p_worst NUMERIC,
  desired_stop NUMERIC, stop_basis TEXT, params JSONB NOT NULL, config_hash TEXT NOT NULL, strategy_version TEXT NOT NULL,
  signal_id UUID REFERENCES signals(id), signal_ts TIMESTAMPTZ, created_ts TIMESTAMPTZ NOT NULL, opened_ts TIMESTAMPTZ,
  closed_ts TIMESTAMPTZ, exit_reason TEXT, sizing_explanation JSONB);
CREATE UNIQUE INDEX one_open_position_per_pair_v1 ON strategy_positions(pair)
  WHERE state NOT IN ('CLOSED');                                  -- v1 rule; drop to enable multi-position
CREATE TABLE position_snapshots (position_id TEXT NOT NULL REFERENCES strategy_positions(id), ts TIMESTAMPTZ NOT NULL,
  snapshot JSONB NOT NULL, PRIMARY KEY (position_id, ts));        -- Position.snapshot(); latest row restores trailing state
CREATE TABLE pair_strategy_state (pair TEXT PRIMARY KEY, ts TIMESTAMPTZ NOT NULL, snapshot JSONB NOT NULL);  -- PairStrategy.snapshot()
CREATE TABLE position_events (id BIGSERIAL PRIMARY KEY, position_id TEXT NOT NULL REFERENCES strategy_positions(id),
  ts TIMESTAMPTZ NOT NULL, from_state TEXT, to_state TEXT NOT NULL, reason TEXT NOT NULL, details JSONB);
CREATE TABLE orders (client_order_id TEXT PRIMARY KEY,           -- deterministic, persisted BEFORE sending
  broker_order_id TEXT, position_id TEXT REFERENCES strategy_positions(id), role TEXT NOT NULL,  -- ENTRY|STOP|EXIT
  action TEXT NOT NULL, order_type TEXT NOT NULL, qty NUMERIC NOT NULL, price NUMERIC, status TEXT NOT NULL,
  order_ts TIMESTAMPTZ NOT NULL, updated_ts TIMESTAMPTZ NOT NULL);
CREATE TABLE executions (exec_id TEXT PRIMARY KEY, client_order_id TEXT REFERENCES orders(client_order_id),
  position_id TEXT REFERENCES strategy_positions(id), qty NUMERIC NOT NULL, price NUMERIC NOT NULL,
  ref_bid NUMERIC NOT NULL, ref_ask NUMERIC NOT NULL, order_ts TIMESTAMPTZ NOT NULL, exec_ts TIMESTAMPTZ NOT NULL,
  commission NUMERIC NOT NULL, commission_ccy TEXT NOT NULL);
CREATE TABLE cost_records (id BIGSERIAL PRIMARY KEY, position_id TEXT NOT NULL REFERENCES strategy_positions(id),
  phase TEXT NOT NULL, kind TEXT NOT NULL,                        -- ESTIMATED|REALISED
  commission NUMERIC, spread NUMERIC, slippage NUMERIC, financing NUMERIC, other NUMERIC, ccy TEXT NOT NULL);
CREATE TABLE trades (position_id TEXT PRIMARY KEY REFERENCES strategy_positions(id), pair TEXT NOT NULL, side TEXT NOT NULL,
  qty NUMERIC NOT NULL, entry_avg NUMERIC NOT NULL, exit_avg NUMERIC NOT NULL, gross_pnl NUMERIC NOT NULL, net_pnl NUMERIC NOT NULL,
  quote_ccy TEXT NOT NULL, fx_to_base NUMERIC NOT NULL, exit_reason TEXT NOT NULL, exit_move_pct NUMERIC,
  max_favourable_pct NUMERIC, max_adverse_pct NUMERIC, trail_protected_pct NUMERIC, opened_ts TIMESTAMPTZ NOT NULL,
  closed_ts TIMESTAMPTZ NOT NULL, config_hash TEXT NOT NULL, strategy_version TEXT NOT NULL);
CREATE TABLE currency_balances (id BIGSERIAL PRIMARY KEY, ts TIMESTAMPTZ NOT NULL, source TEXT NOT NULL,  -- BROKER|EXPECTED
  ccy TEXT NOT NULL, balance NUMERIC NOT NULL);
CREATE TABLE balance_discrepancies (id BIGSERIAL PRIMARY KEY, ts TIMESTAMPTZ NOT NULL, ccy TEXT NOT NULL,
  expected NUMERIC NOT NULL, actual NUMERIC NOT NULL, resolved_ts TIMESTAMPTZ, resolution TEXT);
CREATE TABLE reconciliation_runs (id BIGSERIAL PRIMARY KEY, ts TIMESTAMPTZ NOT NULL, ok BOOLEAN NOT NULL, details JSONB NOT NULL);
CREATE TABLE alerts (id BIGSERIAL PRIMARY KEY, ts TIMESTAMPTZ NOT NULL, kind TEXT NOT NULL, pair TEXT, position_id TEXT,
  prices JSONB, message TEXT NOT NULL);
CREATE TABLE audit_log (id BIGSERIAL PRIMARY KEY, ts TIMESTAMPTZ NOT NULL, actor TEXT NOT NULL, action TEXT NOT NULL, details JSONB);

CREATE FUNCTION forbid_mutation() RETURNS trigger AS $$ BEGIN RAISE EXCEPTION 'append-only table'; END $$ LANGUAGE plpgsql;
CREATE TRIGGER position_events_immutable BEFORE UPDATE OR DELETE ON position_events FOR EACH ROW EXECUTE FUNCTION forbid_mutation();
CREATE TRIGGER audit_log_immutable BEFORE UPDATE OR DELETE ON audit_log FOR EACH ROW EXECUTE FUNCTION forbid_mutation();
CREATE TRIGGER config_audit_immutable BEFORE UPDATE OR DELETE ON config_audit FOR EACH ROW EXECUTE FUNCTION forbid_mutation();
