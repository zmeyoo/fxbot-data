# State machines (implemented and tested)

## Position (`position_manager/position.py`)
```
PENDING_ENTRY -> OPEN_UNPROTECTED -> OPEN_PROTECTED -> TRAILING_ACTIVE -> PENDING_EXIT -> CLOSED
PENDING_ENTRY -> CLOSED                (only when nothing was filled)
OPEN_PROTECTED/TRAILING_ACTIVE -> OPEN_UNPROTECTED   (new fill not covered, or protection lost)
PENDING_EXIT -> OPEN_*                 (exit rejected/cancelled; caller states if protection is intact)
any non-terminal -> ERROR_REQUIRES_RECONCILIATION -> OPEN_UNPROTECTED | CLOSED   (conservative resume)
```
Protected = broker-confirmed stop whose quantity covers the open quantity. `unprotected_positions()` flags
OPEN_UNPROTECTED older than `unprotected_timeout_seconds` and any open ERROR position; the emergency policy
(flatten + alert) is executed by the execution layer in Phase 4.
Duplicate execution ids are ignored; overfills raise; every transition is an immutable `PositionEvent`.
Persistence: `snapshot()/from_snapshot()` (JSON-safe) keep the favourable extreme, ratcheted stop, trailing flag and broker stop;
after restart reconcile -> OPEN_UNPROTECTED -> re-protect at `protection_target()` (the ratcheted level).
Stop replacement is planned by `stop_orders.plan_stop_update` (modify in place, or place-new -> ack -> cancel-old).

## Pair strategy (`strategy/pair_state.py`)
IDLE -> ANALYSING -> ENTRY_PENDING -> POSITION_OPEN -> WAIT_FOR_REENTRY_CONFIRMATION -> ENTRY_PENDING ...
(`WAIT_FOR_REVERSE_CONFIRMATION` is a deprecated alias of the same state.) RISK_LOCKOUT and EMERGENCY_STOP are
reachable from anywhere and left only by an explicit named release.
Entry gate after a close (same OR opposite direction): signal valid + signal_ts and market_ts strictly after the
close + directional movement >= the per-pair threshold for that direction + cooldown elapsed.
`on_quote(quote, now, max_age_s)` feeds the post-close tracker (fresh tracker on every close, starts at the confirmed close, ignores stale quotes,
restarts after a data gap); `snapshot()/from_snapshot()` persist the tracker; `new_session()` drops it at a new trading session.
Risk vetoes (one position per pair, limits, lockout, kill switch) live in `risk/governor.py`;
`strategy/entry.py` combines gate + all filters.

## Time stamps (requirement 10)
`Quote.market_ts / received_ts`, `Signal.signal_ts / market_ts`, `Fill.order_ts / exec_ts`; all must be UTC-aware.
