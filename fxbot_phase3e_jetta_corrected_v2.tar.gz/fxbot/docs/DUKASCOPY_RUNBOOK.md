# Dukascopy pilot dataset - runbook (Milestone 1)

## 1. Status
* The pilot is **approved**: EURUSD, **2024-03-04 inclusive to 2024-03-18 exclusive** (336 hourly files, 241 in open-market time; contains the US daylight-saving change of 10 Mar 2024). Full-resolution original tick files are kept (no decimation).
* **No bulk pilot dataset has been downloaded yet.** One diagnostic hour (2024-03-04 12:00 UTC) was retrieved from JETTA and the alternate BI5 host; all 2,670 ticks matched exactly. The authoring sandbox has no outbound network, so the full pilot download happens in GitHub Actions (section 4) or on another machine with internet. No data is generated or substituted.
* No strategy research is run. Strategy rules unchanged. Live trading disabled. Streaming engine = Milestone 2, separate (`STREAMING_DESIGN.md`).

## 2. What the pipeline does, in order (`tools/ci_run.sh`; each stage stops the run on failure)
1. **Offline unit tests** of the pipeline (about 45 s).
2. **`env-check --source jetta`** - checks the JETTA tick API at `jetta.dukascopy.com` (the old `datafeed.dukascopy.com` host timed out in the observed GitHub run).
3. **`verify-jetta`** - downloads representative weekday noon hours across the requested date range; checks JSON schema, array lengths, cumulative timestamps, instrument-specific price scale, quote order and price bands. For EURUSD it also compares the known 2024-03-04 12:00 UTC hour with the alternate BI5 host `www.dukascopy.com/datafeed`. The diagnostic artifact showed exact parity for all 2,670 ticks (timestamp, BID, ASK and volume). If the alternate BI5 host is unavailable, parity is reported as WARN; JETTA structural checks remain mandatory. Volume conversion uses the observed 1,000,000 divisor; this reproduces the BI5 float32 volume values for the reference hour, but the API volume units are not formally documented and remain **UNCERTAIN**.
   **A structural or price/quote failure stops the bulk download (exit code 5).**
4. **`run`** - download all hours (byte-exact, hashed, resumable) -> normalised CSV -> manifest -> automatic validation (existing validator on every UTC-hour slice, constant-memory quality statistics, gates) -> `DATA_QUALITY_REPORT.md`.
5. **`ci_verdict.py`** - one verdict: **PASSED** only if every stage succeeded, decoder verification passed, validation PASSED and the CSV matches its manifest SHA-256. Anything else is **NOT VALIDATED** with the reason.

Outputs: `review-pack` (always; small: VERDICT, reports, logs, per-hour metadata, SHA256SUMS), and **only when validated** `dataset-normalised` (CSV + manifest + reports) and `dataset-raw-original` (byte-exact `.json` JETTA responses + metadata).

## 3. Review of the GitHub Actions workflow (what I checked and changed)
| question | finding / fix |
|---|---|
| repository structure and import paths | The archive has a wrapper folder `fxbot/` and the workflow must sit at `.github/workflows/` in the repo root. **Changed:** the repo needs only two items (the archive + the workflow file); the job unpacks the archive to `work/fxbot`, runs everything from there with `PYTHONPATH=.`, and refuses to run unless exactly one archive is present. Control flow is unit-tested with a stub `python`. |
| workflow file validity | **A real bug found by a test:** an unquoted step name containing `: ` made the YAML invalid (GitHub would have rejected it). All step names are now quoted, the file is parsed in a test, and a test enforces the quoting. |
| uploads even when validation fails | `Verdict` and `Upload the review pack` use `if: always()`, so reports, logs, hashes and per-hour metadata are attached to failed runs too (a failing step, even a crash, cannot skip them). |
| failed/incomplete data mistaken for validated | (1) one verdict function with explicit statuses (TESTS_FAILED, NETWORK_UNAVAILABLE, DECODER_ASSUMPTION_FAILED, DECODER_NOT_VERIFIED, DOWNLOAD_INCOMPLETE, VALIDATION_FAILED, INTEGRITY_FAILED, PIPELINE_CRASHED); (2) the dataset artifacts are uploaded **only** when validated and their names end in `-VALIDATED`; (3) the review-pack name carries the status; (4) the final step fails the run (red) unless validated; (5) `VERDICT.txt` says "NOT VALIDATED. DO NOT USE ANY DATA FROM THIS RUN". Tested for incomplete, failed-validation, tampered CSV and failed-decoder cases. |
| security | Inputs are passed through environment variables and validated by regular expressions; they are never pasted into shell code. Read-only token permissions. |
| memory | **A real defect found in review:** for large files my validator loaded every CSV row into a list (could exhaust the 7 GB runner on a multi-million-tick pilot). Now it validates per UTC-hour slice with bounded memory and complete coverage. |
| decoder assumptions | New live verification stage before the bulk download (section 2, stage 3). |
| artifact size and retention (limits to check, from GitHub documentation and community write-ups I consulted; verify under Settings and Billing) | Retention is configurable per artifact (1-90 days; I use 30 for the review pack and 14 for datasets). **GitHub Free gives about 500 MB of shared storage for Actions artifacts and packages**, and private repositories get a monthly allowance of Actions minutes (commonly stated as 2,000). When storage is exhausted uploads can fail. The pilot's size is **unknown until measured** (I estimate tens to a few hundred MB; unverified), so the dataset is split into two artifacts (raw = master, CSV = derived and regenerable from raw by `build`), the review pack stays small, and the verdict summary prints the dataset size. A single oversized artifact may also hit per-artifact limits; sources disagree, so treat the quota as the binding constraint. Delete old artifacts in the run page after downloading them. |
| not verifiable here | The original workflow has not yet run with the JETTA adapter. The next GitHub run is the end-to-end test of this implementation. Its first run is its test; if a step fails for a reason I could not foresee, the review pack and summary will say where. |

## 4. Run it from an Android phone (browser only)
Use Chrome. GitHub's mobile layout hides some menus: if you cannot see something named below, open Chrome menu (three dots) and turn on **Desktop site**.
**Update the existing repository `zmeyoo/fxbot-data`**
1. Download the new `fxbot_phase3e_jetta.tar.gz` archive and the updated `dukascopy_dataset.yml` file from this chat.
2. In the repository root, delete the old `fxbot_phase3e.tar.gz` archive. The workflow deliberately requires exactly one project archive.
3. Upload `fxbot_phase3e_jetta.tar.gz` to the repository root and commit it.
4. Open `.github/workflows/dukascopy_dataset.yml` in GitHub, tap the pencil (Edit), replace the entire contents with the updated YAML file's contents, then commit the change to `main`.
5. Open **Actions**. If GitHub asks to enable workflows, approve it.
**Each run**
7. Actions -> in the left list tap **Dukascopy dataset** -> **Run workflow**. The defaults are the approved pilot (EURUSD, 2024-03-04 to 2024-03-18, sleep 0.3). Leave them and tap the green **Run workflow**.
8. Pull to refresh; tap the new run (title "Dukascopy EURUSD 2024-03-04 to 2024-03-18"). Wait for the job to finish (duration unknown until the first run; the job limit is 300 minutes).
9. Tap **Summary**: the verdict, the decoder verification table and the data-quality report are shown right on the page (no download needed). A red X with "NOT VALIDATED" means do not use the data.
10. Scroll to **Artifacts** at the bottom of the Summary page. Tap `review-pack-...` to download it (small zip) and attach it to this chat. The two `dataset-...-VALIDATED` artifacts (large) stay on GitHub until I need them; do not delete them before the review.
**If something fails:** the run page shows which step failed; open the Summary and the review pack and send them to me. If step "Unpack the project archive" fails, the repository must contain exactly one `.tar.gz`/`.tgz`/`.tar` in its root (delete older archives).
**Running again later** (for example after a network failure) starts from scratch; the workflow does not cache downloads.

## 5. Same commands on any machine with Python 3.12 and internet (stdlib only)
    python tools/dukascopy.py env-check --source jetta
    python tools/dukascopy.py verify-jetta --instrument EURUSD --start 2024-03-04 --end 2024-03-18 --out data/pilot
    python tools/dukascopy.py run --instrument EURUSD --source jetta --start 2024-03-04 --end 2024-03-18 --out data/pilot
    python tools/dukascopy.py plan --instrument EURUSD --source jetta --start 2025-01-01 --end 2025-07-01 --calibrate data/pilot
`run` exit codes: 0 validated, 1 validation FAILED, 2 environment not ready, 3 incomplete/aborted (or cannot verify), 4 sample mismatch, 5 JETTA schema/decoder assumption FAILED.
The BI5 format remains available with `--source bi5` for comparison/fallback. The CI workflow explicitly selects `--source jetta`; direct CLI download commands should also include `--source jetta` to use the new adapter.
Check Dukascopy's terms of use for research use; I have not verified them.

## 6. Larger dataset
Not to be started until Milestone 2 (streaming engine) passes its acceptance tests (`STREAMING_DESIGN.md`) and you have reviewed the pilot. `plan --calibrate <pilot dir>` then gives the measured size, memory and run-time estimate.
