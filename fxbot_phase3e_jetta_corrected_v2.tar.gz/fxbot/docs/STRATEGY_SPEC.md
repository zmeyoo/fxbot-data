# Strategy specification (amended 2026-11-07, decisions confirmed 2026-11-08)

Supersedes the corresponding parts of the original spec. Unchanged: stop/trailing maths, executable-side
rules, cost accounting, risk rules, no live trading by default. All values are STARTING defaults, evaluated
per pair by backtest and parameter sweep, never assumed optimal.

## 1. Per-pair parameters (independent; never conflated)
| Parameter | Default | Meaning |
|---|---|---|
| `initial_stop_pct` | 0.10 | initial stop distance, % of the position's entry price P0 |
| `trailing_activation_pct` | 0.10 | trailing starts once the best favourable executable price is >= +this % from P0 |
| `trailing_distance_pct` | 0.10 | distance in PERCENTAGE POINTS of P0, measured from the best favourable executable price |
| `same_direction_reentry_min_move_pct` | 0.10 | minimum directional move required before a same-direction re-entry |
| `opposite_direction_reentry_min_move_pct` | 0.10 | same, for an opposite-direction entry |
| `allow_same_direction_reentry` | **true** (V1) | switch for same-direction re-entry |
| `min_net_profit` / `profit_taking_enabled` | unset / false | separate cost-aware profit-taking exit |
Each can be changed per pair through `ConfigStore` (validated, hashed, audited with old/new value and actor).

## 2. Trailing stop (clarified; the implemented maths already matched)
* LONG: extreme = highest executable **BID** since entry. SHORT: extreme = lowest executable **ASK**. Never mid/last.
* Active when `sign*(extreme - P0) >= P0*trailing_activation_pct/100`.
* Threshold = `extreme - sign*(P0*trailing_distance_pct/100)`: LONG `extreme - d`, SHORT `extreme + d`.
  Equivalent to protected level `Rmax - trailing_distance_pct` percentage points of P0.
* Exit: LONG when BID <= threshold; SHORT when ASK >= threshold.
* Confirmed 2026-11-08: the distance is anchored to the ENTRY price and is a fixed price amount for the life of the position
  (not a percentage of the extreme and not of accumulated profit). Worked example (tested): LONG P0=100.00, extreme 101.00, distance 0.10 -> threshold 100.90 (+0.90%); stays
  open above it, exits at 100.90. SHORT mirror: extreme 99.00 -> 99.10.
* The distance is a fixed price amount from the extreme: it is not measured from the entry price and not a
  share of accumulated profit. At +1.00% the retained gross movement is about +0.90%, before spread, commission, slippage.
* The stop only tightens (ratchet), never loosens, is per position, symmetric for LONG/SHORT, rounded to the
  tick grid in the tighter direction, snapshotted at entry (A-3).
* Before activation the initial stop applies; after activation the tighter of the two applies.

## 3. Exit priority
1. Protective (initial/trailing) - always first, never delayed by costs.  2. Time (end-of-day, max hold).
3. Cost-aware profit-taking (`min_net_profit`), optional and separately switchable.

## 4. Re-entry (same OR opposite direction) - reference confirmed
After any close the pair waits in `WAIT_FOR_REENTRY_CONFIRMATION`. A new entry needs ALL of:
1. a FRESH valid signal (signal_ts and market_ts strictly after the close) from the configured entry engine - reaching the
   price-movement threshold ALONE never triggers an order (the gate cannot be called without a signal);
2. the directional move from the POST-CLOSE EXTREME >= the per-pair, per-direction threshold:
   LONG: ASK >= m% above the lowest executable ASK since the confirmed close; SHORT: BID >= m% below the highest executable
   BID. The previous entry or exit price is never used as a reference (the option was removed from the code);
3. cooldown elapsed; 4. one open position per pair; 5. current, fresh market data (a stale or missing quote can never
   trigger a re-entry, even with a zero threshold); 6. spread, cost, funding, per-currency exposure, news and risk filters.
Reference tracking: a fresh tracker is created on EVERY close (reset) and starts at the confirmed close (quotes with
market_ts >= close time); stale quotes are ignored; after a data gap longer than the freshness limit the reference restarts
from the first good quote (this can only understate the move). The reference is persisted and restored with the pair state.
Sessions are 17:00 America/New_York (docs/SESSIONS.md). Whether a new session also drops the reference is configurable per pair:
`reentry_reference_reset` = `new_session` (current default - NOT an approved rule, under comparison) or `next_close` (preserve until the next
close, a data gap, or the optional `reentry_reference_max_age_minutes`). Both modes are compared out-of-sample on development data;
neither is chosen from holdout data. Threshold 0 disables only the movement
check. The first entry of a session is not subject to it.

## 5. Entry engine `ema_trend_v0` (hypothesis; closed candles only; bars built from mid, A-16)
LONG (SHORT is the exact mirror, tested): 15m EMA20 > EMA50; 5m close > EMA20; 5m MACD (`macd_mode`: line or
histogram) > 0 and RSI14 >= 50; 15m ADX14 >= 20; 1m slow-stochastic(14,3,3) %K crossed above %D within the last
3 bars, still above, and < 80. Optional, off by default: 15m close > EMA200, 5m ATR% bounds, tick-activity proxy
(labelled "not true volume"). Data-quality blocks: insufficient history, stale newest bar, gaps, missing config.
Thresholds (ADX 20, RSI 50, stochastic 14/3/3, cross within 3 bars, 80/20, `macd_mode=line`) are APPROVED initial defaults and remain
sweep parameters; `line` vs `histogram` are compared separately by walk-forward. Not proven profitable.

## 6. Persistence and broker protection
`Position.snapshot()/from_snapshot()` and `PairStrategy.snapshot()/from_snapshot()` persist extremes, stop level,
trailing flag, broker stop, costs, seen execution ids and post-close extremes. Restart: restore -> reconcile with
the broker -> position is OPEN_UNPROTECTED -> `protection_target()` returns the RATCHETED stop -> `plan_stop_update`.
Planner: modify in place if supported, otherwise place new stop, await ack, THEN cancel the old one; on timeout
query broker by client order id before retrying; never loosen. The internal stop check stays as software backstop.
(Execution against IBKR is Phase 4; the planner and state handling are done and tested.)
