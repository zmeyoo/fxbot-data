# Backtesting and research methodology

Goal: find out whether the COMPLETE strategy (entry engine + re-entry + trailing/stop + optional profit-taking +
risk/funding rules) has a robust positive net expectancy after realistic costs. Not to find a pretty equity curve.

## What is simulated
The backtester drives the same pure code as live trading (bars -> `ema_trend_v0` -> pair gate -> `evaluate_entry`
-> `Position` -> `evaluate_exit`); only the broker is simulated (`backtesting/engine.py`).
* Decisions use CLOSED 1m bars (5m/15m built incrementally, closed only). The decision is as of the bar end, using the
  last quote BEFORE it; the quote that closes the bar is never used for the decision.
* Orders fill at the first quote with `market_ts >= order time + latency_s` on the executable side (BUY ask, SELL bid)
  plus slippage, rounded to the tick against us. Stops are software stops checked on every quote and filled the same
  way, so gaps fill at the gapped price (tested: loss several times the nominal stop).
* The spread is re-checked at the fill; commission from the schedule you supply; financing only if you supply rates.
* LONG needs own QUOTE-currency cash (e.g. USD for EURUSD); SHORT is capped by the currency floor, the short-notional cap and
  an assumed margin rate (`fx_margin_rate_pct`; without it borrowing shorts are rejected and reported).
* One position per pair; cooldown; re-entry gate with the post-close extreme reference and the per-direction thresholds.
* Sessions: 17:00 America/New_York to 17:00 next day, DST-aware (`docs/SESSIONS.md`); flat `eod_cutoff_minutes_before_rollover` before
  the session end; a new session resets the daily risk counters; whether it also resets the post-close reference is the configurable
  `reentry_reference_reset` (`new_session` | `next_close`), compared in the dev report (trade frequency and performance).

## Data (`backtesting/data.py`) - never silently downgraded
* TICK csv, columns mapped BY NAME via `TickFormat` (`canonical` ts,bid,ask | `dukascopy_csv` | `ibkr_ticks_provisional`); epoch unit
  s/ms/us/ns detected or given and parsed exactly; a swapped bid/ask mapping is rejected. Best resolution. Validate every new file with
  `python tools/validate_ticks.py` first (report: `docs/DATA_VALIDATION_REPORT.md`).
* BAR csv with full bid AND ask OHLC (download IBKR BID and ASK bar series separately and merge with `merge_bid_ask_csv`).
  Mid-only / last-price data is rejected. The dataset report states resolution, spread statistics, dropped records,
  unexpected gaps vs weekend closures, a content hash, and LIMITATIONS.
* BAR data cannot give the intrabar order of extremes. Paths are adverse-first (or favourable-first as a stress test);
  stop/trailing execution on bars is approximate and must be validated against tick data. The report says so.
* The IBKR combined `BID_ASK` BAR type is not supported as a bar format: as I understand it (to be verified against the TWS API
  documentation) it does not carry separate OHLC for both sides. Use tick BID_ASK or separate BID and ASK bars.
* I have NO real IBKR data here: the engine has only been exercised on synthetic data (see "What the tests prove").

## Data gate
`tools/run_research.py --dataset <dir>` reads only datasets whose `dataset.json` says PASSED and whose CSV still matches its SHA-256; a bare file needs `--allow-unvalidated` and every report then carries an UNVALIDATED banner. Nothing is reported on a dataset before validation.

## Research integrity enforced in code (`splits.py`, `walkforward.py`)
1. Development data = everything before `holdout_start` (last 20% by default, floored to midnight). `dev_slice/run_dev`
   raise `HoldoutAccessError` for anything later; a test proves that rewriting the holdout data changes no development result.
2. Walk-forward: rolling (or anchored) train windows, embargo >= max holding time, test windows never overlap; each fold
   selects on TRAIN only and is evaluated on the next TEST window; pooled test trades = the OOS result.
3. Selection score = mean expectancy of a variant and its grid neighbours (needs >= min trades): prefers plateaus over spikes.
4. The holdout can be run ONCE per (dataset hash, split plan) by an operator-named, frozen candidate; the registry file is
   written BEFORE the run. Freezing requires development evidence that never touched the holdout.
5. `walk_forward_by_axis` runs an independent walk-forward per value of an axis: MACD line vs histogram, trailing-only
   (`pair.min_net_profit_pct = null`) vs trailing + each minimum-net-profit target. Same methodology, reported separately.
6. Latency study (automatic in the dev report): 0.5 / 1 / 2 / 5 s on the same data and settings; 1 s is only an initial default and must be
   calibrated against measured paper-trading latency. With coarse quotes (gap > latency) the settings are not distinguishable and the
   report says so.
7. Walk-forward methodology comparison: 20-day baseline vs 60 and 120-day training windows (`compare_train_days`), each on development
   data only, with a like-for-like comparison on the OOS period they all cover. The single-look holdout key depends only on the data and
   the holdout boundary, so changing any walk-forward setting never grants a new look (tested).
8. Cost stress: `bt.realised_slippage_multiplier`, `bt.realised_commission_multiplier`, `bt.latency_s`, `bt.bar_path`.

## Reports (`backtesting/report.py`)
Per pair and per direction (LONG/SHORT) tables; average net R-multiple (comparable despite different LONG/SHORT sizes);
ADX / ATR / entry-type regimes; exit reasons; trailing exits at the gross-breakeven level with negative net P&L; estimated
vs realised costs; walk-forward fold table (how often the chosen variant changes = stability); evidence status against the
LOCKED criteria (`INSUFFICIENT_EVIDENCE` is a first-class outcome; a failing pair cannot be hidden by a strong one).

## How to run
    python tools/run_research.py dev --config research.json --ticks ticks.csv --out out/
    python tools/run_research.py holdout --config research.json --ticks ticks.csv --out out/ \
        --variant "<exact variant name from the dev report>" --confirm-single-look
`docs/research.example.json` shows the format (placeholder numbers only). A run refuses to start if limits are unset.

## What the tests prove (and do not)
* **Null (no-edge) study** on driftless random-walk data (40 seeds x 10 days, 1,466 trades; cost inputs are the TEST-FIXTURE values:
  commission 0.2 bp with 2 USD minimum, slippage 0.001% per side, ~0.8 pip spread - illustrative, not IBKR rates). Unit: **EUR per trade**;
  every mean is the **pooled mean over all 1,466 trades** (not a mean of seed means); "+-" is **one standard error** = stdev/sqrt(N) assuming
  independent trades (a by-seed cluster SE gives the same picture):
  | quantity | mean (EUR/trade) | SE naive | SE by seed | z | 95% CI |
  |---|---|---|---|---|---|
  | gross (mid-to-mid, before costs) | +9.18 | 6.84 | 7.08 | 1.34 (p = 0.18) | [-4.2, +22.6] |
  | costs (commission + spread + slippage) | 30.28 | 0.40 | 0.67 | - | [29.5, 31.1] |
  | net = gross - costs | -21.10 | 6.83 | 7.03 | -3.09 | [-34.5, -7.7] |
  Reading: the gross point estimate is positive but **not distinguishable from zero** (the earlier wording "statistically zero" meant this,
  and was imprecise); the study can only detect a gross edge larger than about 14 EUR/trade, so it is a coarse check. Net is clearly
  negative because even the upper end of the gross interval (+22.6) is below the average cost (30.3). The earlier message quoted only the
  gross figure for this run; the net figure above had not been shown for it. `backtesting/nullcheck.py` reproduces these statistics.
* **Planted-edge test:** with an artificial trending regime the engine reports a large positive expectancy -> it can detect an edge.
* **Exact no-look-ahead property** (stronger than the null study): trades closed before a cut are identical whether the future exists, is
  missing, or is garbage.
* They do NOT say anything about real FX profitability. That needs real tick/bid-ask data, a verified commission schedule, and the
  out-of-sample procedure above.

## Known limitations
Static FX rates for base-currency conversion; no financing/rollover unless rates supplied; no economic calendar; the first
quote after the latency is assumed fillable at its touch price (no depth, no partial fills, no rejects); software stops
instead of broker-held stops (live behaviour is verified in Phase 4); results on bar data are approximate; one pair per run
(portfolio-level exposure interaction is not simulated yet); sizing asymmetry LONG (own cash) vs SHORT (borrow room) is real,
so compare directions in R-multiples.
