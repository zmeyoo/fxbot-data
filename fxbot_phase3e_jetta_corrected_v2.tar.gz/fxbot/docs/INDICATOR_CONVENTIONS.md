# Indicator conventions and TA-Lib cross-check

**Status: the cross-check has NOT been executed.** TA-Lib is not installable in the authoring sandbox (no network).
`tools/crosscheck_talib.py` and `tests/test_talib_crosscheck.py` are ready (the latter skips itself without TA-Lib).
Everything under "possible differences" is a hypothesis from my reading of TA-Lib's documented behaviour, to be
CONFIRMED OR REFUTED by running the tool. Indicator definitions are never changed to force a match: a mismatch is
investigated, explained here, and the chosen convention stays tested.

Run: `pip install TA-Lib && python tools/crosscheck_talib.py --seeds 1 2 3 [--csv real_mid_bars.csv]`
(real FX bars are preferable to random walks). The report has three zones per indicator: first defined index,
warm-up zone, after-warm-up zone (tolerance applies after warm-up, where different seeds must converge).

## Our conventions (all causal; out[i] uses inputs[:i+1]; verified by truncation-invariance tests)
| Indicator | Definition | First defined index |
|---|---|---|
| SMA(n) | simple mean of the last n | n-1 |
| EMA(n) | alpha=2/(n+1); seed = SMA of the first n values; then recursion | n-1 |
| RSI(n) | Wilder: first avg gain/loss = simple mean of the first n changes, then (prev*(n-1)+x)/n. avg_loss=0: 100 if gains else **50** (flat) | n |
| ATR(n) | TR[0] = high-low, TR[i] = max(h-l, |h-prevC|, |l-prevC|); seed = mean of TR[0..n-1]; Wilder smoothing | n-1 |
| ADX(n), +DI, -DI | Wilder sums of TR, +DM, -DM seeded with the first n values from index 1; DX; first ADX = mean of first n DX, then Wilder | DI: n; ADX: 2n-1 |
| Stochastic (k,d,smooth) | raw %K over k bars; slow %K = SMA(raw, smooth); %D = SMA(slow %K, d); zero range => raw %K = **50** | k+smooth-2 / +d-1 |
| MACD (f,s,g) | line = EMA_f - EMA_s (each seeded at its own n-1); signal = EMA of the line seeded with SMA of its first g values; histogram = line - signal | s-1 / s+g-2 |
| Tick-activity ratio | ticks / SMA(ticks, n) - a QUOTE-ACTIVITY PROXY, not volume | n-1 |
Floats (IEEE double) are used inside indicators; no rounding is applied. Signals compare against thresholds unrounded.

## Possible differences to expect from TA-Lib (UNVERIFIED hypotheses)
1. **ATR seed / alignment.** TA-Lib's ATR starts at index n using TR[1..n] (TR[0] is undefined without a previous
   close); ours seeds at n-1 including TR[0]. Wilder smoothing carries the seed difference forward, decaying like
   ((n-1)/n)^k. Expect a decaying offset, same limit.
2. **MACD fast-EMA seed.** Our fast EMA is seeded at index f-1 and recursed; I believe TA-Lib seeds the fast EMA at
   the slow EMA's start (SMA of the preceding f values) so the lines align. Expect early differences decaying like
   (1-2/(f+1))^k.
3. **Degenerate inputs.** Flat series: our RSI = 50 and zero-range stochastic = 50; I believe TA-Lib returns 0 for both
   (edge-case output is printed by the tool). Irrelevant for real FX data but documented.
4. **Missing data / candle boundaries.** Indicators here never see NaN/None inside the input (data gaps block the
   signal instead). Bars are aligned to UTC epoch multiples of the timeframe and built from the MID of bid/ask,
   so values will differ from broker charts that use trade prices or session-anchored buckets.
5. **Precision.** Both sides use float64; summation order may produce ~1e-15 relative differences, far below tolerances.
6. **Window length.** Wilder/EMA values depend on the history length (infinite memory). The backtester and live
   engine therefore use the SAME fixed trailing windows (1m: 120, 5m: 600, 15m: 400 bars). A test shows the
   effect of truncating to these windows on the final value is negligible compared with threshold granularity.
