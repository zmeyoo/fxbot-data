# Assumptions register (updated 2026-11-08, data-validation stage)

**Strategy rules are unchanged in this stage.** The mechanical/definitional changes made are listed first; nothing that alters when or
how the strategy trades was introduced.

## Changed in this stage (mechanics, not strategy)
| change | why |
|---|---|
| Sessions defined as 17:00 America/New_York -> 17:00 next day, DST-aware (`docs/SESSIONS.md`); the hard-coded 22:00 UTC is gone | your request |
| EOD flatten is now `eod_cutoff_minutes_before_rollover` (YOU choose the value; unset blocks trading). Legacy fixed-UTC `eod_cutoff_utc` still works but is deprecated (drifts with DST) | follows from the session definition |
| Tick loader: columns by name via `TickFormat`; exact epoch parsing (s/ms/us/ns); swapped bid/ask rejected; precision preserved | found by the real sample (ms epoch, ask-before-bid) |
| Single-look holdout key = data span + holdout boundary only (walk-forward settings no longer change it) | closes a loophole: varying the methodology would have given a fresh look |
| Development slicing reads O(log n) timestamps and never copies holdout records | "completely untouched" |

## Your clarifications, as implemented
1. **Latency:** 1 s stays the initial default, fully configurable (`bt.latency_s`); a sensitivity study at **0.5, 1, 2 and 5 s** runs on development
   data in every dev report (tested to shift entry and exit fills by exactly the latency on dense quotes). 1 s is NOT assumed representative;
   calibrate against measured paper-trading latency. With quotes sparser than the latency the settings are indistinguishable (reported).
2. **Walk-forward:** 20-day train / 5-day test remains the baseline; **60 and 120-day** training windows are compared (`compare_train_days`) on development
   data only, with a like-for-like table on the OOS period all of them cover (longer windows start OOS later and have fewer folds).
   The holdout stays untouched during all development, selection and methodology comparisons (poisoning test + registry-key test).
3. **Session:** 17:00 America/New_York (above).
4. **Post-close reference reset:** configurable per pair - `reentry_reference_reset = new_session | next_close` (+ optional
   `reentry_reference_max_age_minutes`). **Default stays `new_session` only because it is the current behaviour; it is not an approved rule.**
   Both are compared out-of-sample on development data (trade frequency, entry types, movement-threshold rejections, performance). The choice
   will be made by you from those development results, never from holdout data.
5. **Random-walk figure:** explained in `BACKTESTING.md` (gross, EUR per trade, pooled over 1,466 trades, one standard error); net was -21.1 +- 6.8.
6. **Real-data validation:** `DATA_VALIDATION_REPORT.md`. The supplied file is a Dukascopy-format sample with 2 rows, not IBKR data.

## Decisions received (provisional, not final)
| # | decision |
|---|----------|
| D-1 | `eod_cutoff_minutes_before_rollover = 30` as the initial value; 15 / 30 / 60 are compared on development data in every dev report (`eod_cutoff_study`); never selected from holdout |
| D-2 | `reentry_reference_reset = new_session` as the initial default (also drops the cooldown at a new session); `next_close` stays configurable and is compared in the dev report |
| D-3 | 20-day training window is the baseline; 60 and 120 days are compared; final window not selected until development results are seen. Latency 1 s provisional; 0.5/1/2/5 s sensitivity continues; to be calibrated from IBKR paper-trading measurements |

## Decisions received (this stage)
* **Pilot period approved:** EURUSD, 2024-03-04 inclusive to 2024-03-18 exclusive; full-resolution original ticks kept.
* **Streaming from disk approved in principle** for larger data; design in `STREAMING_DESIGN.md`; **not implemented**. Milestones are separate: M1 pilot delivery -> M2 streaming engine with acceptance tests -> M3 large download -> M4 research. No 6-12 month download before M2 passes.
* **Decoder assumptions are verified live, independently**, before the bulk download; any failed assumption stops the run and is reported; the decoder is never adapted.
* No strategy research until the pilot dataset and its validation report are delivered and reviewed.

## Open decisions for you
| # | Item |
|---|------|
| D-4 | Earlier proposals still unapproved: >=30 trades per pair/side for readiness (A-5), Sharpe convention (A-6), recovery drills (A-7), selection score = neighbourhood mean expectancy with >=30 train trades (B-4), indicator windows 1m:120/5m:600/15m:400 (B-8) |
| D-7 | Approve `STREAMING_DESIGN.md` (interface, acceptance tests) and say when to start Milestone 2 (I propose after the pilot report is in hand) |
| D-8 | The reference price range for the live decoder check (default 1.05:1.12 for March 2024) - narrow it if you have a trusted chart |

## Dukascopy data assumptions (JETTA adapter; broader date coverage still to be proven)
The active CI pipeline now uses `jetta.dukascopy.com/v1/ticks/{BASE-QUOTE}/{YYYY}/{MM}/{DD}/{HH}` (calendar month is one-based), with browser-style Dukascopy Referer/Origin headers. JETTA returns delta-encoded JSON: timestamp is the epoch-ms base; `times`, `bids`, and `asks` are cumulative deltas; price multiplier must match the instrument's native point value. For EURUSD on 2024-03-04 12:00 UTC, the JETTA response was compared against the alternate BI5 host: all 2,670 timestamps, BID/ASK prices and volumes matched exactly after the 1,000,000 volume divisor. The unit meaning of the volume fields is still not formally documented, so volumes are preserved but not used by the strategy. The legacy BI5 downloader remains available with `--source bi5`. This single-hour parity test does not yet establish completeness or consistency across all dates/instruments. Dukascopy's terms of use have not been checked.

## Standing assumptions (unchanged)
A-2 wait state after every close. A-3 stop parameters snapshotted at entry. A-4 gross P&L is mid-to-mid; spread and slippage are separate cost
lines. A-8 profit-taking off by default. A-9 unspecified parameters are `None` and block trading. A-10 stops rounded to the tighter tick.
A-11 exit priority protective > time > profit-taking; no price decisions on stale data. A-12 `p_best` starts at P0. A-13 LONG funding = own
quote-currency cash; negative floor authorises a short. A-16 signal bars from mid. B-2 decisions on closed bars, fills on the next quote.
B-6 SHORT margin model is operator-supplied. B-7 spread re-check at fill. B-9 window-end forced closes labelled MANUAL. B-10 static FX rates.

## Not verified against IBKR yet
Commission schedule and minimums; IDEALPRO minimum sizes and tick sizes; server-side vs simulated FX stops; stop vs stop-limit in gaps;
`outsideRth`; borrow/financing rates; margin what-if output; IBKR tick file format and timestamp resolution (believed 1 s - to be confirmed
from your sample); semantics of IBKR's combined BID_ASK bar type. An unverified commission schedule blocks live trading.

## Known limitations
* Stop is not a guaranteed loss cap. No real historical data has been run yet; the backtester is validated on synthetic data only.
* Indicators not yet cross-checked against TA-Lib (harness ready, TA-Lib not installable offline).
* Bar-resolution backtests are approximate for stops/trailing; single pair per run; static FX; no financing/calendar/depth/partial fills.
* LONG vs SHORT sizing differs by construction (own cash vs borrow room): compare directions in R-multiples.
* No real historical data has been obtained yet: this environment has no outbound network (see `DUKASCOPY_RUNBOOK.md`). Broker/execution, database code and dashboard do not exist yet. Live trading is disabled.
* The full test suite takes about two minutes (backtester tests dominate); property tests use seeded `random` (add Hypothesis).
