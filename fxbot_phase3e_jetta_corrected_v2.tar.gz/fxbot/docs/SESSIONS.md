# Trading session definition

**A session starts at 17:00 America/New_York and ends at the next calendar day's 17:00 America/New_York.**
Boundaries are computed in local New York wall-clock time and converted to UTC with the IANA tz database (`zoneinfo`), so daylight
saving is handled by the database, not by code. Nothing is hard-coded in UTC (`core/sessions.py`, `GlobalConfig.session_timezone`,
`GlobalConfig.session_start_local`).

| New York time zone | session start (UTC) | session end (UTC) | typical dates |
|---|---|---|---|
| EST (UTC-5), winter | 22:00 | 22:00 next day | early Nov - mid Mar |
| EDT (UTC-4), summer | 21:00 | 21:00 next day | mid Mar - early Nov |

* **Label:** a session is labelled by the New York calendar date on which it ENDS (the "NY close" date). The session that opens
  Sunday 17:00 and closes Monday 17:00 is "Monday". Business sessions are labelled Mon-Fri; sessions labelled Saturday/Sunday are the
  closed weekend (market closed Friday 17:00 -> Sunday 17:00 New York).
* **DST changes** happen at 02:00 local on a Sunday, inside the closed weekend, so no trading session is shortened or lengthened:
  the session labelled Sunday 8 Mar 2026 runs 22:00Z (Sat) -> 21:00Z (Sun) = 23 h; Sunday 1 Nov 2026 runs 21:00Z -> 22:00Z = 25 h
  (both tested, with the 24 h Monday session after them).
* **End-of-day flatten:** `eod_cutoff_minutes_before_rollover` minutes before the session end (the value is YOURS to choose; unset blocks
  trading). The old `eod_cutoff_utc` (fixed UTC clock time) still works but is deprecated because it drifts by one hour relative to the
  rollover when DST changes; a run states which one it used.
* **What a new session does:** resets the daily risk counters (daily loss, drawdown, trades/reversals per session, loss streak) and,
  depending on `reentry_reference_reset`, the post-close reference (see STRATEGY_SPEC.md section 4).
* **Daily returns / Sharpe** are grouped by this session label, not by UTC date.
* Not supported: a session start that does not exist on a DST-change date (e.g. 02:30 New York); the calendar raises an error.
