# Data validation report - tick loader vs the supplied sample

## 1. What was supplied
`eurusd_dukascopy_published_sample_ticks.csv` - **a Dukascopy-format file, not IBKR data**, with **2 records**:
`timestamp,askPrice,bidPrice,askVolume,bidVolume` (epoch **milliseconds**, **ask column before bid**). It therefore validates the generic
loader (column mapping, timestamp conversion, precision, basic checks) but says nothing about IBKR's own tick format. The IBKR-specific
items still to be confirmed from a real IBKR sample are listed in section 5. This file was used for no backtest and no performance statement.

## 2. What the real file exposed (fixed)
* The previous loader could not read it at all (expected `ts,bid,ask`; failed safely with a column error).
* The previous timestamp parser read any number as epoch **seconds** and used floating point: milliseconds would have been refused
  (year ~52000) and fractional seconds could carry float rounding. Now: explicit/detected unit (`s|ms|us|ns`), exact integer/Decimal
  arithmetic, and the result must fall in 2000-2100 or the file is refused (the unit is never guessed silently).
* Columns are mapped **by name** through a `TickFormat` (presets: `canonical`, `dukascopy_csv`, `ibkr_ticks_provisional`), never by position.
* A file whose bid/ask mapping is wrong way round (>= 50% crossed rows) is rejected with an explicit message instead of silently dropping
  every row.

## 3. Generated validation report (tools/validate_ticks.py, run on the sample)

- file: `tests/data/eurusd_dukascopy_published_sample_ticks.csv`
- format: **dukascopy_csv** (ts=`timestamp` [ms], bid=`bidPrice`, ask=`askPrice`)
- records kept: 2; span 2020-03-30 00:00:00.104000+00:00 .. 2020-03-30 00:00:00.256000+00:00
- overall: **NO FAILED CHECKS**

| check | status | detail |
|---|---|---|
| Timestamp parsing / timezone | **PASS** | unit=ms; all UTC-aware=True; non-decreasing=True; exact epoch round-trip mismatches=0; resolution=sub-second; max quotes sharing one timestamp=1 |
| BID/ASK field mapping + executable side | **PASS** | mapped by NAME: bid<-'bidPrice', ask<-'askPrice'; rows where parsed != raw column: 0; bid<=ask on all kept rows: True; crossed fraction in file: 0.000; LONG enters at ASK and exits at BID, SHORT enters at BID and exits at ASK: True |
| Duplicate / out-of-order / stale quotes | **NOT TESTABLE** | dropped: 0 exact duplicates, 0 out-of-order, 0 crossed/invalid; unchanged-price re-quotes kept: 0; inter-arrival s median/p95/p99/max = 0.152/0.152/0.152/0.152; intervals >10s/30s/60s: ((10, 0), (30, 0), (60, 0))  [only 2 records: code paths are covered by synthetic-file unit tests, the statistics here say nothing about the feed] |
| Bid/ask spread calculation | **PASS** | spread=ask-bid, mid=(ask+bid)/2 recomputed from the raw text with exact Decimals; mismatches vs loader: 0; mean/median/max spread % = 0.00808/0.00808/0.00898 |
| Data gaps and session boundaries | **NOT TESTABLE** | unexpected gaps (> 120s, outside the weekly closure): 0; weekend closures: 0; quotes stamped inside the Fri-17:00/Sun-17:00 New York closure: 0; sessions seen: 2020-03-30: 2 quotes 2020-03-30T00:00:00.104000+00:00..2020-03-30T00:00:00.256000+00:00; first quote falls in session '2020-03-30' = 2020-03-29T21:00:00+00:00 .. 2020-03-30T21:00:00+00:00 |
| Original quote precision preserved | **PASS** | prices stored as exact Decimal (no float); text of every price identical after parsing (rows changed: 0); decimal places seen: (5,) |
| Dataset fingerprint | **INFO** | sha256 of canonical (ts,bid,ask) = c735de132121017099ba4648f9c23a5591afbe6516f50eaf6100604d7e2cf36e |

## Sample rows (raw text -> parsed)

**Row 1** raw: `{'timestamp': '1585526400104', 'askPrice': '1.11369', 'bidPrice': '1.11361', 'askVolume': '0.75', 'bidVolume': '0.75'}`
- UTC `2020-03-30T00:00:00.104000+00:00`  |  New York `2020-03-29T20:00:00.104000-04:00`  |  session `2020-03-30` (2020-03-29T21:00:00+00:00 .. 2020-03-30T21:00:00+00:00)
- bid `1.11361`  ask `1.11369`  spread `0.00008` (0.8 pips, 0.00718%)  mid `1.11365`

**Row 2** raw: `{'timestamp': '1585526400256', 'askPrice': '1.11371', 'bidPrice': '1.11361', 'askVolume': '0.94', 'bidVolume': '1.5'}`
- UTC `2020-03-30T00:00:00.256000+00:00`  |  New York `2020-03-29T20:00:00.256000-04:00`  |  session `2020-03-30` (2020-03-29T21:00:00+00:00 .. 2020-03-30T21:00:00+00:00)
- bid `1.11361`  ask `1.11371`  spread `0.00010` (1.0 pips, 0.00898%)  mid `1.11366`

## Limitations
- Tick data: stop/trailing fills are simulated at the first quote after the trigger plus latency; quote timestamps have the source's granularity (IBKR ticks are not guaranteed to be every quote).
- Financing/rollover is not modelled unless rates are supplied; positions are flat before the EOD cutoff.
- No economic calendar is connected: the backtest has NO news protection.

## 4. Test results (tests/test_data_validation.py: Ran 15 tests in 0.027s)
Real sample (exact parsed values, DST-correct New York time and session, honest NOT TESTABLE statuses) and synthetic files in
Dukascopy-style and IBKR-style layouts to exercise the paths a 2-row file cannot:
- `test_multiple_quotes_per_second_kept_in_order_with_resolution_reported` - ok
- `test_mapping_is_by_name_not_position` - ok
- `test_missing_columns_and_mid_only_rejected` - ok
- `test_swapped_mapping_is_detected_instead_of_silently_dropping_everything` - ok
- `test_property_price_text_round_trips_exactly` - ok
- `test_duplicates_unchanged_quotes_and_staleness_metrics` - ok
- `test_gap_classification_around_weekend_rollover_and_dst` - ok
- `test_report_separates_closures_from_unexpected_gaps_and_flags_closure_quotes` - ok
- `test_validation_runs_on_a_large_synthetic_file_and_marks_stats_testable` - ok
- `test_exact_values_of_the_published_sample` - ok
- `test_timezone_and_session_of_the_sample_are_dst_correct` - ok
- `test_validation_report_statuses_are_honest_for_two_rows` - ok
- `test_epoch_units_are_exact_not_float` - ok
- `test_iso_timestamps_need_an_explicit_timezone_and_convert_to_utc` - ok
- `test_wrong_unit_is_refused_not_guessed` - ok

Mapping of your six points to evidence:
| point | evidence |
|---|---|
| timestamp parsing + timezone | exact ms round trip on the sample; unit tests for s/ms/us/ns, wrong-unit refusal, ISO with offset -> UTC, naive timestamp refused; 2020-03-30 00:00:00.104Z = Sun 20:00 EDT, session "2020-03-30" |
| BID/ASK mapping + executable side | mapped by name; ask-first column order handled; deliberately swapped mapping is rejected; LONG enters ASK / exits BID, SHORT enters BID / exits ASK asserted on the sample |
| duplicates, missing, stale, out-of-order | synthetic files: exact duplicates dropped, out-of-order dropped, crossed dropped, unchanged re-quotes counted and kept, inter-arrival percentiles and >10/30/60 s counts, gap classification |
| spread calculation | sample: 0.00008 (0.8 pip, 0.00718 %) and 0.00010 (1.0 pip, 0.00898 %), recomputed independently from the raw text |
| gaps and session boundaries | weekend closure recognised in winter and summer (vendor stopping early / resuming late still a closure), rollover and intra-session gaps, a 28 h mid-week outage is NOT a closure, quotes inside the closure are flagged |
| precision | prices kept as exact Decimal; text identical after parsing (incl. trailing zeros, 4-6 decimals, property test over 300 random rows) |

## 5. Still to confirm with a real IBKR sample (I have not seen one)
1. Column names / order and timestamp unit of the file (our downloader will write `ts,bid,ask,bid_size,ask_size`; the format is marked PROVISIONAL).
2. Timestamp resolution: I believe IBKR historical ticks are stamped at **1-second** resolution, so several quotes share a timestamp.
   The loader keeps them in file order (tested) and the report prints the resolution and the maximum quotes per timestamp.
3. Whether quotes are every change or throttled, the typical inter-arrival times (this sets `market_data_max_age_seconds`), and whether
   weekend/holiday closures match the Friday 17:00 - Sunday 17:00 New York definition.
4. Price decimal places for each pair (this sets `tick_size`) and the vendor's behaviour around the 17:00 rollover.
Run `python tools/validate_ticks.py <file> --format ibkr_ticks_provisional` and send the report.
