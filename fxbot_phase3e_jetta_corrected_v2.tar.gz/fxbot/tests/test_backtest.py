import csv
import json
import os
import random
import statistics
import tempfile
import unittest
from dataclasses import replace
from datetime import datetime, timedelta, timezone
from decimal import ROUND_CEILING, ROUND_FLOOR, Decimal as Dc

from fxbot.backtesting import report as R
from fxbot.backtesting.data import (BidAskBar, DataError, expand_bar, load_bars_csv, load_ticks_csv,
                                    merge_bid_ask_csv, parse_ts, quote_report)
from fxbot.backtesting.engine import BacktestConfigError, cutoff_for, run_backtest
from fxbot.core.sessions import SessionCalendar
from fxbot.backtesting.research import run_dev_research, run_holdout
from fxbot.backtesting.splits import (FrozenCandidate, HoldoutAccessError, HoldoutAlreadyUsed, ResearchSession, SplitPlan)
from fxbot.backtesting.sweeps import ParamGrid, Variant, VariantResult, apply_variant, robust_scores, select_best
from fxbot.backtesting.synth import MONDAY, synth_ticks, trending_regime
from fxbot.backtesting.walkforward import walk_forward, walk_forward_by_axis
from fxbot.core.types import Quote, Side
from fxbot.market_data.bars import BarAggregator, aggregate
from fxbot.position_manager.position import ExitReason
from fxbot.reporting.metrics import summarise
from fxbot.signals.ema_trend import EmaTrendEngine, EmaTrendParams
from tests.bt_helpers import settings
from tests.bt_scenarios import crash_scenario, long_scenario, ticks_from_closes
from tests.fixtures import *
from tests.signal_helpers import START, bars_from_closes

UTC_ = timezone.utc


# ================================================================= data layer
class TestData(unittest.TestCase):
    def write(self, name, rows, header):
        p = os.path.join(self.tmp, name)
        with open(p, "w", newline="") as f:
            w = csv.writer(f); w.writerow(header); w.writerows(rows)
        return p

    def setUp(self):
        self.tmpdir = tempfile.TemporaryDirectory(); self.tmp = self.tmpdir.name

    def tearDown(self):
        self.tmpdir.cleanup()

    def test_tick_loader_validates_and_reports(self):
        p = self.write("t.csv", [["2026-01-05T10:00:00Z", "1.1000", "1.1001"], ["2026-01-05T10:00:01Z", "1.1002", "1.1001"],
                                 ["2026-01-05T10:00:02Z", "1.1000", "1.1001"], ["2026-01-05T10:00:02Z", "1.1000", "1.1001"],
                                 ["2026-01-05T09:59:00Z", "1.1", "1.1001"], ["2026-01-05T10:10:00Z", "1.1003", "1.1004"]],
                       ["ts", "bid", "ask"])
        q, r = load_ticks_csv(p, "EURUSD", gap_threshold_s=120)
        self.assertEqual((r.n_records, r.dropped_crossed_or_invalid, r.dropped_out_of_order), (3, 1, 1))
        self.assertEqual(r.dropped_duplicate, 1)
        self.assertEqual(len(r.gaps), 1)                                         # 10:00:02 -> 10:10:00
        self.assertEqual(r.resolution, "TICK")
        self.assertTrue(any("NO news protection" in x for x in r.limitations))
        self.assertEqual(len(r.sha256), 64)
        _, r2 = load_ticks_csv(p, "EURUSD")
        self.assertEqual(r.sha256, r2.sha256)                                    # reproducible data hash

    def test_mid_or_last_only_data_is_rejected(self):
        p = self.write("m.csv", [["2026-01-05T10:00:00Z", "1.1000"]], ["ts", "mid"])
        with self.assertRaises(DataError): load_ticks_csv(p, "EURUSD")
        p2 = self.write("b.csv", [["2026-01-05T10:00:00Z", "1.1", "1.1", "1.1", "1.1"]], ["ts", "open", "high", "low", "close"])
        with self.assertRaises(DataError): load_bars_csv(p2, "EURUSD")           # no mid-bar substitution
        with self.assertRaises(DataError): parse_ts("2026-01-05 10:00:00")        # naive timestamp

    def test_bar_loader_merge_and_resolution_warning(self):
        hdr = ["ts", "open", "high", "low", "close"]
        bid = self.write("bid.csv", [["2026-01-05T10:00:00Z", "1.1000", "1.1010", "1.0995", "1.1005"],
                                     ["2026-01-05T10:01:00Z", "1.1005", "1.1008", "1.1000", "1.1002"]], hdr)
        ask = self.write("ask.csv", [["2026-01-05T10:00:00Z", "1.1001", "1.1011", "1.0996", "1.1006"],
                                     ["2026-01-05T10:02:00Z", "1.1", "1.1", "1.1", "1.1"]], hdr)
        out = os.path.join(self.tmp, "m.csv")
        self.assertEqual(merge_bid_ask_csv(bid, ask, out), (1, 1, 1))             # unmatched dropped, never filled
        bars, rep = load_bars_csv(out, "EURUSD")
        self.assertEqual(len(bars), 1)
        self.assertEqual(rep.resolution, "BAR_BID_ASK_OHLC")
        self.assertTrue(any("intrabar" in x or "order of the bid/ask extremes" in x for x in rep.limitations))

    def test_bar_expansion_orders_adverse_extreme_first_and_never_uses_mid(self):
        b = BidAskBar(START, START + timedelta(seconds=60), Dc("1.1000"), Dc("1.1010"), Dc("1.0990"), Dc("1.1005"),
                      Dc("1.1001"), Dc("1.1012"), Dc("1.0992"), Dc("1.1006"))
        long_ = expand_bar(b, "EURUSD", Side.LONG)
        self.assertEqual(long_[1].bid, Dc("1.0990"))                              # lowest BID first for an open LONG
        short = expand_bar(b, "EURUSD", Side.SHORT)
        self.assertEqual(short[1].ask, Dc("1.1012"))                              # highest ASK first for an open SHORT
        fav = expand_bar(b, "EURUSD", Side.LONG, "favourable_first")
        self.assertEqual(fav[1].bid, Dc("1.1010"))
        for qs in (long_, short, fav):
            self.assertTrue(all(q.bid <= q.ask for q in qs))
            self.assertEqual((qs[0].bid, qs[0].ask), (Dc("1.1000"), Dc("1.1001")))
            self.assertEqual((qs[-1].bid, qs[-1].ask), (Dc("1.1005"), Dc("1.1006")))
            self.assertTrue(all(a.market_ts <= c.market_ts for a, c in zip(qs, qs[1:])))
            self.assertLess(qs[-1].market_ts, b.end_ts)


class TestAggregatorEquivalence(unittest.TestCase):
    def test_property_incremental_equals_batch_including_gaps(self):
        rnd = random.Random(3)
        closes = [1.1 + rnd.uniform(-0.002, 0.002) for _ in range(400)]
        full = bars_from_closes(closes)
        bars = [b for b in full if rnd.random() > 0.08]                           # random missing minutes
        for tf in (300, 900):
            agg, got = BarAggregator(tf), []
            for i, b in enumerate(bars):
                got += agg.on_bar(b)
                self.assertEqual(got, aggregate(bars[:i + 1], tf, b.end_ts), (tf, i))


# ================================================================= engine mechanics
def expected_fill(side, quote, slip_pct=Dc("0.001"), tick=Dc("0.00001")):
    sgn = 1 if side is Side.LONG else -1
    px = quote.entry_price(side) * (1 + sgn * slip_pct / 100)
    return (px / tick).to_integral_value(rounding=ROUND_CEILING if side is Side.LONG else ROUND_FLOOR) * tick


class TestEngineMechanics(unittest.TestCase):
    def test_decision_on_closed_bar_fill_on_next_quote_with_latency_costs_and_cash_cap(self):
        q = ticks_from_closes(long_scenario())
        r = run_backtest(q, settings())
        self.assertEqual(len(r.trades), 1)
        t = r.trades[0]
        self.assertEqual((t.side, t.exit_reason), (Side.LONG, ExitReason.TRAILING_STOP))
        # order time is a bar END (minute boundary); fill = first quote >= order + 1s latency, on the ask + slippage
        order_ts = t.opened_ts.replace(second=0)
        self.assertGreaterEqual((t.opened_ts - order_ts).total_seconds(), 1)
        fill_q = next(x for x in q if x.market_ts == t.opened_ts)
        self.assertEqual(t.entry_avg, expected_fill(Side.LONG, fill_q))
        self.assertTrue(all(x.market_ts < order_ts + timedelta(seconds=1) or x.market_ts >= t.opened_ts
                            for x in q if x.market_ts > order_ts))                  # no earlier eligible quote
        self.assertLessEqual(t.qty * t.entry_avg * Dc("1.01"), Dc("110000"))          # own USD cash is the cap
        self.assertEqual(r.meta[t.position_id]["macd_mode"], "line")
        # cost identity: net = (exit - entry) * qty - commissions (no financing)
        ident = (t.exit_avg - t.entry_avg) * t.qty - t.costs.commission
        self.assertLess(abs(t.net_pnl - ident), Dc("1E-6"))
        self.assertEqual(t.net_pnl, t.gross_pnl - t.costs.total)
        self.assertGreater(t.costs.spread, 0); self.assertGreater(t.costs.slippage, 0)
        self.assertEqual(r.counters["signals"], 1)
        risk = Dc(r.meta[t.position_id]["initial_risk_quote"])
        self.assertAlmostEqual(float(risk), float(abs(t.entry_avg - t.entry_avg * Dc("0.999")) * t.qty), delta=float(t.qty * Dc("0.00001")))
        self.assertIn("avg net R", R.r_multiple_section(r.trades, r.meta))

    def test_gap_through_stop_fills_at_gapped_price_not_the_stop(self):
        q = ticks_from_closes(crash_scenario())
        r = run_backtest(q, settings())
        t = r.trades[0]
        self.assertEqual(t.exit_reason, ExitReason.INITIAL_STOP)
        stop = (t.entry_avg * Dc("0.999"))
        self.assertLess(t.exit_avg, stop - Dc("0.0020"))                           # filled far beyond the stop
        self.assertLess(t.exit_move_pct, Dc("-0.30"))
        self.assertGreater(-t.net_pnl, t.qty * t.entry_avg * Dc("0.001") * 2)       # loss > 2x the nominal stop loss

    def test_latency_delays_fills(self):
        q = ticks_from_closes(long_scenario())
        a = run_backtest(q, settings(latency_s=Dc("0"))).trades[0]
        b = run_backtest(q, settings(latency_s=Dc("20"))).trades[0]
        self.assertLess(a.opened_ts, b.opened_ts)
        self.assertLessEqual((b.opened_ts - b.opened_ts.replace(second=0)).total_seconds(), 50)

    def test_end_of_day_forces_flat_before_cutoff_and_blocks_late_entries(self):
        cl = long_scenario("flat", flat_minutes=700)
        r = run_backtest(ticks_from_closes(cl), settings(cfg=pair_cfg(cooldown_minutes=10, max_hold_minutes=900, max_trades_session=20)))
        t = r.trades[0]
        self.assertEqual(t.exit_reason, ExitReason.END_OF_DAY)
        cutoff = datetime(2026, 1, 5, 20, 0, tzinfo=UTC_)
        self.assertGreaterEqual(t.closed_ts, cutoff); self.assertLess(t.closed_ts, cutoff + timedelta(seconds=60))
        sess = SessionCalendar().session_of(datetime(2026, 1, 6, 21, 0, tzinfo=UTC_))
        self.assertEqual(cutoff_for(settings().gcfg, sess), datetime(2026, 1, 6, 20, 0, tzinfo=UTC_))   # legacy 20:00 UTC, winter

    def test_no_quote_currency_cash_means_no_long_and_it_is_reported(self):
        r = run_backtest(ticks_from_closes(long_scenario()), settings(balances={"EUR": Dc("100000")}, equity0_base=Dc("100000")))
        self.assertEqual(r.trades, [])
        self.assertTrue(any(k.startswith("sizing:") or k.startswith("funding:") for k in r.rejections))

    def test_refuses_to_run_with_unset_limits(self):
        s = settings(cfg=replace(pair_cfg(), max_spread_pct=None))
        with self.assertRaises(BacktestConfigError): run_backtest([], s)

    def test_cost_stress_reduces_results_and_commission_identity_holds(self):
        q = ticks_from_closes(long_scenario())
        base = run_backtest(q, settings()).trades[0]
        stress = run_backtest(q, settings(realised_slippage_multiplier=Dc("3"), realised_commission_multiplier=Dc("2"))).trades[0]
        self.assertLess(stress.net_pnl, base.net_pnl)
        self.assertEqual(stress.gross_pnl, base.gross_pnl)

    def test_profit_taking_off_vs_on_changes_exit_not_entry(self):
        q = ticks_from_closes(long_scenario())
        from fxbot.config.schema import MinNetProfit, MinNetProfitMode
        off = run_backtest(q, settings()).trades[0]
        on = run_backtest(q, settings(cfg=pair_cfg(cooldown_minutes=10, max_trades_session=20, profit_taking_enabled=True,
                                                  min_net_profit=MinNetProfit(MinNetProfitMode.PCT_NOTIONAL, Dc("0.05"))))).trades[0]
        self.assertEqual(off.opened_ts, on.opened_ts)
        self.assertEqual(on.exit_reason, ExitReason.PROFIT_TARGET)
        self.assertLess(on.closed_ts, off.closed_ts)

    def test_property_no_lookahead_trades_before_a_cut_are_unchanged_by_the_future(self):
        q = synth_ticks(days=6, seed=11, tick_s=60)
        s = settings(engine=EmaTrendParams(adx_min=15.0), max_age=90)
        full = run_backtest(q, s)
        self.assertGreater(len(full.trades), 3)
        rnd = random.Random(1)
        for cut in (len(q) // 3, len(q) // 2, 2 * len(q) // 3):
            part = run_backtest(q[:cut], s)
            for t in part.trades:
                self.assertIn(t, full.trades)                                       # identical records
            poisoned = list(q[:cut]) + [Quote("EURUSD", x.bid * 2, x.ask * 2, x.market_ts, x.market_ts) for x in q[cut:cut + 500]]
            for t in run_backtest(poisoned, s).trades:
                if t.closed_ts < q[cut - 1].market_ts - timedelta(minutes=1):
                    self.assertIn(t, full.trades)

    def test_property_invariants_on_random_data(self):
        for seed in (3, 4, 5):
            r = run_backtest(synth_ticks(days=8, seed=seed, tick_s=60), settings(engine=EmaTrendParams(adx_min=15.0), max_age=90))
            prev_close = None
            for t in sorted(r.trades, key=lambda x: x.opened_ts):
                if prev_close is not None:
                    self.assertGreaterEqual(t.opened_ts, prev_close)                  # one position at a time
                    self.assertGreaterEqual(t.opened_ts - prev_close, timedelta(minutes=10) - timedelta(seconds=60))   # cooldown
                prev_close = t.closed_ts
                self.assertEqual(t.net_pnl, t.gross_pnl - t.costs.total)
                sign = 1 if t.side is Side.LONG else -1
                ident = sign * (t.exit_avg - t.entry_avg) * t.qty - t.costs.commission
                self.assertLess(abs(t.net_pnl - ident), Dc("1E-6"))
                if t.exit_reason is ExitReason.INITIAL_STOP:                           # fills on a LATER quote, but the
                    self.assertLessEqual(t.max_adverse_pct, Dc("-0.099"))             # adverse extreme really reached the stop
                if t.exit_reason is ExitReason.TRAILING_STOP:
                    self.assertIsNotNone(t.trail_protected_pct_at_exit)
                m = r.meta[t.position_id]
                if m["same_direction_reentry"]:
                    self.assertGreaterEqual(Dc(m["reentry_move_pct"]), Dc("0.10"))    # movement threshold really met
                self.assertLessEqual(t.hold_seconds, 180 * 60 + 120)                  # max hold respected (+latency)

    def test_null_random_walk_has_no_gross_edge_and_net_is_not_positive(self):
        trades = []
        for seed in range(200, 212):
            trades += run_backtest(synth_ticks(days=4, seed=seed, tick_s=60), settings(max_age=90)).trades
        n = len(trades)
        self.assertGreater(n, 100)
        g = [float(t.gross_pnl_base) for t in trades]; nn = [float(t.net_pnl_base) for t in trades]
        se = statistics.stdev(g) / n ** 0.5
        self.assertLess(abs(statistics.mean(g)), 3 * se)                              # martingale: no gross edge
        self.assertLess(statistics.mean(nn), statistics.mean(g))                      # costs strictly reduce it
        self.assertLess(statistics.mean(nn) - 3 * se, 0)                              # net not significantly positive

    def test_planted_trend_edge_is_detected(self):
        trades = []
        for seed in range(1, 4):
            q = synth_ticks(days=5, seed=seed, tick_s=30, drift_fn=trending_regime(240, 0.004, seed))
            trades += run_backtest(q, settings()).trades
        s = summarise(trades, Dc("100000"))
        self.assertGreater(s.n, 30); self.assertGreater(s.expectancy_base, 100)
        self.assertGreater(s.profit_factor, Dc("3"))


class TestIndicatorWindowConvention(unittest.TestCase):
    def test_fixed_trailing_windows_match_full_history_values(self):
        rnd = random.Random(9)
        closes, px = [], 1.1
        for _ in range(16000):
            px += rnd.uniform(-0.0002, 0.00021); closes.append(px)
        bars = bars_from_closes(closes)
        ao = bars[-1].end_ts
        b5, b15 = aggregate(bars, 300, ao), aggregate(bars, 900, ao)
        eng = EmaTrendEngine()
        full = eng._htf(b5, b15)
        win = eng._htf(b5[-600:], b15[-400:])
        for k in ("e_fast15", "e_slow15", "e_fast5", "line5", "hist5", "rsi5", "adx_v", "atr5"):
            self.assertLess(abs(full[k] - win[k]) / (abs(full[k]) + 1e-9), 1e-5, k)


# ================================================================= sweeps / splits / walk-forward
def fake_result(expectancy, n=40):
    from fxbot.backtesting.engine import BacktestResult
    trades = [trade(net=Dc(str(expectancy)), day=i) for i in range(n)]
    return BacktestResult("EURUSD", trades, {}, Dc("100000"), "fp", None, None, 0, {}, {}, {}, [])


class TestSweeps(unittest.TestCase):
    def test_grid_expansion_names_and_independent_application(self):
        g = ParamGrid({"pair.trailing_activation_pct": ["0.10", "0.15"], "pair.trailing_distance_pct": ["0.05", "0.10", "0.20"],
                       "engine.macd_mode": ["line", "histogram"], "pair.min_net_profit_pct": [None, "0.03"]})
        vs = g.variants()
        self.assertEqual(len(vs), 2 * 3 * 2 * 2)
        base = settings()
        v = next(v for v in vs if v.values["pair.trailing_distance_pct"] == "0.20" and v.values["engine.macd_mode"] == "histogram"
                 and v.values["pair.min_net_profit_pct"] == "0.03" and v.values["pair.trailing_activation_pct"] == "0.15")
        s = apply_variant(base, v)
        self.assertEqual((s.cfg.trailing_activation_pct, s.cfg.trailing_distance_pct), (Dc("0.15"), Dc("0.20")))
        self.assertEqual(s.engine_params.macd_mode, "histogram")
        self.assertTrue(s.cfg.profit_taking_enabled); self.assertEqual(s.cfg.min_net_profit.value, Dc("0.03"))
        self.assertEqual(s.cfg.initial_stop_pct, base.cfg.initial_stop_pct)             # untouched parameters stay
        self.assertEqual(s.cfg.same_direction_reentry_min_move_pct, Dc("0.10"))
        off = apply_variant(base, next(v for v in vs if v.values["pair.min_net_profit_pct"] is None))
        self.assertFalse(off.cfg.profit_taking_enabled); self.assertIsNone(off.cfg.min_net_profit)
        with self.assertRaises(Exception): apply_variant(base, Variant("x", {}, {"pair.nonsense": 1}))

    def test_robust_selection_prefers_plateau_over_isolated_spike(self):
        vals = [2.0, 2.5, 2.2, 10.0, -8.0]
        res = [VariantResult(v, fake_result(e)) for v, e in zip(ParamGrid({"engine.adx_min": [10, 15, 20, 25, 30]}).variants(), vals)]
        best = select_best(res, min_trades=30)
        sc = robust_scores(res, 30)
        self.assertNotEqual(best.variant.values["engine.adx_min"], 25)                 # the isolated 10.0 spike is not chosen
        self.assertLess(sc[res[3].variant.name], sc[best.variant.name])                # its neighbours (2.2, -8.0) drag it down
        self.assertLess(sc[res[4].variant.name], sc[best.variant.name])
        self.assertIsNone(robust_scores([VariantResult(res[0].variant, fake_result(5, n=5))], 30)[res[0].variant.name])
        self.assertIsNone(select_best([VariantResult(res[0].variant, fake_result(5, n=5))], 30))


class TestSplitsAndHoldout(unittest.TestCase):
    def setUp(self):
        self.tmpdir = tempfile.TemporaryDirectory(); self.reg = os.path.join(self.tmpdir.name, "reg.json")
        self.q = synth_ticks(days=14, seed=21, tick_s=60)
        self.plan = SplitPlan(self.q[0].market_ts, self.q[-1].market_ts + timedelta(seconds=60), 0.2, 4, 2, 2, 180, False, 1500, 2)
        self.sha = quote_report(self.q, "EURUSD").sha256
        self.s = settings(engine=EmaTrendParams(adx_min=15.0), max_age=90)

    def tearDown(self):
        self.tmpdir.cleanup()

    def test_plan_folds_are_ordered_embargoed_and_inside_development(self):
        f = self.plan.folds()
        self.assertGreaterEqual(len(f), 2)
        for a in f:
            self.assertEqual(a.test_start - a.train_end, timedelta(minutes=180))
            self.assertLessEqual(a.test_end, self.plan.holdout_start)
            self.assertLess(a.train_start, a.train_end)
        for a, b in zip(f, f[1:]):
            self.assertLessEqual(a.test_end, b.test_start + timedelta(days=self.plan.wf_test_days))     # no overlapping OOS windows
            self.assertGreaterEqual(b.test_start, a.test_end)
        self.assertEqual((self.plan.holdout_start.hour, self.plan.holdout_start.minute), (0, 0))
        with self.assertRaises(Exception): SplitPlan(self.plan.data_start, self.plan.data_end, 0.2, 6, 5, 3)
        anchored = replace(self.plan, anchored=True).folds()
        self.assertTrue(all(a.train_start == self.plan.data_start for a in anchored))

    def test_holdout_data_is_unreachable_for_development(self):
        sess = ResearchSession(self.q, self.plan, self.sha, self.reg)
        with self.assertRaises(HoldoutAccessError):
            sess.dev_slice(self.plan.data_start, self.plan.holdout_start + timedelta(minutes=1))
        with self.assertRaises(HoldoutAccessError):
            sess.run_dev(self.s, [Variant("v", {}, {})], self.plan.holdout_start - timedelta(days=1), self.plan.holdout_start + timedelta(days=1))
        self.assertGreater(len(sess.dev_slice(self.plan.data_start, self.plan.holdout_start)), 100)

    def test_changing_holdout_data_cannot_change_any_development_result(self):
        grid = ParamGrid({"engine.adx_min": [15.0, 25.0]}).variants()
        a = walk_forward(ResearchSession(self.q, self.plan, self.sha, self.reg), self.s, grid, 3)
        hs = self.plan.holdout_start
        poisoned = [x if x.market_ts < hs else Quote(x.pair, x.bid * Dc("1.3"), x.ask * Dc("1.3"), x.market_ts, x.received_ts) for x in self.q]
        b = walk_forward(ResearchSession(poisoned, self.plan, self.sha, self.reg), self.s, grid, 3)
        self.assertEqual(a.chosen_names, b.chosen_names)
        self.assertEqual(a.oos_trades, b.oos_trades)

    def test_selection_uses_train_only_and_tests_stay_in_their_windows(self):
        grid = ParamGrid({"engine.adx_min": [15.0, 25.0]}).variants()
        sess = ResearchSession(self.q, self.plan, self.sha, self.reg)
        wf = walk_forward(sess, self.s, grid, 3)
        for fr in wf.folds:
            if fr.chosen is not None:
                self.assertEqual(fr.chosen.name, select_best(fr.train, 3).variant.name)       # argmax of TRAIN scores
                for v in fr.train:
                    self.assertLessEqual(v.result.trade_until, fr.fold.train_end)
                for t in fr.test.trades:
                    self.assertGreaterEqual(t.opened_ts, fr.fold.test_start)
                    self.assertLess(t.opened_ts, fr.fold.test_end)
                    self.assertGreaterEqual(t.opened_ts, fr.fold.train_end)             # strictly after training data
        by = walk_forward_by_axis(sess, self.s, ParamGrid({"engine.macd_mode": ["line", "histogram"]}).variants(), "engine.macd_mode", 3)
        self.assertEqual(set(by), {"line", "histogram"})
        self.assertTrue(all(set(n for n in w.chosen_names if n) <= {f"macd_mode={k}"} for k, w in by.items()))

    def test_holdout_single_look_enforced_and_persistent(self):
        sess = ResearchSession(self.q, self.plan, self.sha, self.reg)
        grid = ParamGrid({"engine.adx_min": [15.0, 25.0]}).variants()
        ev = sess.run_dev(self.s, grid, self.plan.data_start + self.plan.warmup, self.plan.holdout_start)
        cand = sess.freeze(grid[0], ev)
        res = sess.run_holdout_once(cand, self.s)
        self.assertGreaterEqual(res.trade_from, self.plan.holdout_start)
        self.assertTrue(all(t.opened_ts >= self.plan.holdout_start for t in res.trades))
        with self.assertRaises(HoldoutAlreadyUsed): sess.run_holdout_once(sess.freeze(grid[1], ev), self.s)
        again = ResearchSession(self.q, self.plan, self.sha, self.reg)             # new process, same registry
        with self.assertRaises(HoldoutAlreadyUsed): again.run_holdout_once(cand, self.s)
        with open(self.reg) as fh:
            self.assertEqual(len(json.load(fh)["entries"]), 1)
        other = ResearchSession(self.q, replace(self.plan, holdout_fraction=0.3), self.sha, self.reg)
        self.assertEqual(other.holdout_uses(), [])                                  # a different holdout boundary is a different test set
        for tweak in (dict(wf_train_days=3), dict(wf_test_days=1, wf_step_days=1), dict(embargo_minutes=60), dict(anchored=True), dict(max_folds=1)):
            same = ResearchSession(self.q, replace(self.plan, **tweak), self.sha, self.reg)
            self.assertEqual(len(same.holdout_uses()), 1, tweak)                      # methodology changes never grant a new look
            with self.assertRaises(HoldoutAlreadyUsed): same.run_holdout_once(cand, self.s)
        # freezing from evidence that touched the holdout is refused
        bad = VariantResult(grid[0], replace(ev[0].result, trade_until=self.plan.data_end))
        with self.assertRaises(HoldoutAccessError): sess.freeze(grid[0], [bad])
        with self.assertRaises(Exception): sess.freeze(grid[0], [])


class TestResearchPipelineAndReports(unittest.TestCase):
    def test_end_to_end_dev_report_then_single_holdout(self):
        with tempfile.TemporaryDirectory() as d:
            q = synth_ticks(days=14, seed=33, tick_s=60)
            rep = quote_report(q, "EURUSD")
            plan = SplitPlan(rep.first_ts, rep.last_ts + timedelta(seconds=60), 0.2, 4, 2, 2, 180, False, 1500, 2)
            grid = ParamGrid({"engine.macd_mode": ["line", "histogram"]})
            base = settings(engine=EmaTrendParams(adx_min=15.0), max_age=90)
            reg = os.path.join(d, "reg.json")
            out = run_dev_research(q, rep, base, grid, plan, d, reg, min_trades_train=3)
            with open(out["report"]) as fh:
                md = fh.read()
            for needle in ("IN-SAMPLE", "OUT-OF-SAMPLE comparison by mode", "macd_mode=line", "macd_mode=histogram",
                           "Per pair and direction", "EURUSD LONG", "EURUSD SHORT", "Market regimes", "Trailing exits",
                           "Evidence status", "LIMITATION", "no economic-calendar provider", "Backtests are not evidence"):
                self.assertIn(needle, md, needle)
            self.assertRegex(md, r"out-of-sample trades \d+ < 300")                      # small sample is never 'validated'
            self.assertNotIn("**PASS**", md)
            self.assertTrue(os.path.exists(os.path.join(d, "dev_oos_trades_EURUSD.csv")))
            self.assertFalse(os.path.exists(reg))                                       # dev research never touches the holdout
            h = run_holdout(q, rep, base, grid, plan, "macd_mode=line", d, reg, min_trades_train=3)
            with open(h["report"]) as fh:
                self.assertIn("FINAL HOLDOUT", fh.read())
            with self.assertRaises(HoldoutAlreadyUsed):
                run_holdout(q, rep, base, grid, plan, "macd_mode=histogram", d, reg, min_trades_train=3)
            with self.assertRaises(ValueError):
                run_holdout(q, rep, base, grid, replace(plan, holdout_fraction=0.25), "nope", d, reg)

    def test_report_sections_state_status_and_limits(self):
        q = synth_ticks(days=6, seed=11, tick_s=60)
        r = run_backtest(q, settings(engine=EmaTrendParams(adx_min=15.0), max_age=90))
        eq = r.equity0_base
        ev = R.evidence_section(r.trades, eq, ["EURUSD"])
        self.assertNotIn("**PASS**", ev); self.assertRegex(ev, r"out-of-sample trades \d+ < 300")
        self.assertIn("| EURUSD SHORT |", R.pair_side_section(r.trades, eq))
        self.assertIn("same-direction re-entry", R.regime_section(r.trades, r.meta, eq) + "same-direction re-entry")
        self.assertIn("SHORT margin model", R.run_section(r))
        with tempfile.TemporaryDirectory() as d:
            p = os.path.join(d, "t.csv"); R.export_trades_csv(p, r.trades, r.meta)
            with open(p) as fh:
                rows = list(csv.DictReader(fh))
            self.assertEqual(len(rows), len(r.trades))


if __name__ == "__main__":
    unittest.main()


class TestExampleConfig(unittest.TestCase):
    def test_example_config_parses_validates_and_expands(self):
        from fxbot.backtesting.research import load_config
        path = os.path.join(os.path.dirname(__file__), "..", "docs", "research.example.json")
        base, grid, split = load_config(path)
        base.validate()                                                   # all required limits present
        import math
        self.assertEqual(len(grid.variants()), math.prod(len(v) for v in grid.axes.values()))
        self.assertFalse(base.ctx.schedule.verification.verified)         # placeholder schedule is flagged unverified
        self.assertEqual(base.cfg.same_direction_reentry_min_move_pct, Dc("0.10"))
        self.assertTrue(base.cfg.allow_same_direction_reentry)
        self.assertEqual(split["holdout_fraction"], 0.2); self.assertEqual(split["compare_train_days"], [20, 60, 120])
        self.assertEqual((base.gcfg.session_timezone, base.gcfg.session_start_local, base.gcfg.eod_cutoff_minutes_before_rollover),
                         ("America/New_York", "17:00", 30))
        from fxbot.backtesting.research import make_plan
        from fxbot.backtesting.data import DatasetReport
        rep = quote_report(synth_ticks(days=2, seed=1, tick_s=300), "EURUSD")
        self.assertEqual(make_plan(rep, split).wf_train_days, 20)
