"""TEST FIXTURES ONLY. Commission/slippage/limits below are arbitrary test values, NOT IBKR rates."""
from datetime import datetime, timedelta, timezone
from decimal import Decimal as Dc
import itertools

from fxbot.config.schema import AppConfig, GlobalConfig, MinNetProfit, MinNetProfitMode, PairConfig
from fxbot.core.money import FxRates, Money
from fxbot.core.types import Quote, Side
from fxbot.costs.model import CostContext, PercentOfNotional, ScheduleVerification
from fxbot.instruments.spec import PairSpec
from fxbot.position_manager.position import ExitReason, Fill, Position, StopParams, TradeRecord
from fxbot.costs.model import CostBreakdown

T0 = datetime(2026, 1, 5, 10, 0, tzinfo=timezone.utc)
UTC = timezone.utc
SPEC = PairSpec("EURUSD", "EUR", "USD", Dc("0.00001"), Dc("1000"), Dc("1000"), Dc("10000000"))
JPY = PairSpec("USDJPY", "USD", "JPY", Dc("0.001"), Dc("1000"), Dc("1000"), Dc("10000000"))
RATES = FxRates({"EURUSD": Dc("1.10"), "USDJPY": Dc("150")})
SCHED = PercentOfNotional(rate_bps=Dc("0.2"), min_per_order=Money(Dc("2.00"), "USD"), charge_ccy="USD",
                          verification=ScheduleVerification("test fixture", verified=False))
CTX = CostContext(SCHED, RATES, "EUR", slippage_pct=Dc("0.001"))
_ids = itertools.count(1)


def pair_cfg(**kw):
    base = dict(symbol="EURUSD", max_spread_pct=Dc("0.02"), est_slippage_pct=Dc("0.001"),
                max_cost_to_stop_ratio=Dc("0.5"), max_cost_to_reward_ratio=Dc("0.5"),
                cooldown_minutes=10, max_trades_session=10, risk_per_trade_pct=Dc("0.5"),
                max_notional_base=Dc("500000"))
    base.update(kw)
    return PairConfig(**base)


def gcfg(**kw):
    base = dict(max_open_positions=3, max_total_open_risk_pct=Dc("2"), min_cash_buffer_pct=Dc("1"),
                max_short_notional_base=Dc("1000000"), max_margin_utilisation_pct=Dc("30"),
                loss_streak_cooldown_minutes=60, max_daily_drawdown_pct=Dc("5"),
                market_data_max_age_seconds=10, unprotected_timeout_seconds=5, eod_cutoff_utc="20:00",
                currency_floors={"EUR": Dc("-200000")},
                max_currency_exposure_base={"EUR": Dc("300000"), "USD": Dc("300000"), "JPY": Dc("300000")})
    base.update(kw)
    return GlobalConfig(**base)


def qt(bid, ask=None, ts=T0, spread="0.0001", pair="EURUSD"):
    bid = Dc(bid)
    ask = Dc(ask) if ask is not None else bid + Dc(spread)
    return Quote(pair, bid, ask, ts, ts)


def entry_quote(side, price, ts=T0):
    price = Dc(price)
    return qt(price - Dc("0.0001"), price, ts) if side is Side.LONG else qt(price, price + Dc("0.0001"), ts)


def fill(qty, price, ref, ts=T0, eid=None, commission=None, spec=SPEC):
    commission = CTX.commission_quote(Dc(qty), Dc(price), spec.quote) if commission is None else commission
    return Fill(eid or f"E{next(_ids)}", Dc(qty), Dc(price), ts, ts, ref, commission)


def make_position(side=Side.LONG, price="1.10000", qty="100000", ts=T0, spec=SPEC, protect=True,
                  params=None):
    params = params or StopParams(Dc("0.10"), Dc("0.10"), Dc("0.10"))
    pos = Position(position_id=f"P{next(_ids)}", spec=spec, side=side, target_qty=Dc(qty), params=params,
                   created_ts=ts, config_hash="h", strategy_version="test", signal_ts=ts)
    pos.on_entry_fill(fill(qty, price, entry_quote(side, price, ts), ts, spec=spec))
    pos.complete_entry(ts)
    if protect:
        pos.confirm_protection("S1", pos.desired_stop, Dc(qty), ts)
    return pos


def trade(pair="EURUSD", side=Side.LONG, net=Dc("1"), ts=T0, reason=ExitReason.TRAILING_STOP,
          protected=None, costs=Dc("0.1"), est=None, day=0):
    t = ts + timedelta(days=day)
    return TradeRecord(
        position_id=f"T{next(_ids)}", pair=pair, side=side, quote_ccy="USD", qty=Dc("100000"),
        entry_avg=Dc("1.1"), exit_avg=Dc("1.1"), opened_ts=t, closed_ts=t + timedelta(minutes=30),
        exit_reason=reason, gross_pnl=net + costs, costs=CostBreakdown(commission=costs), net_pnl=net,
        fx_to_base=Dc(1), exit_move_pct=Dc(0), max_favourable_pct=Dc(0), max_adverse_pct=Dc(0),
        trail_protected_pct_at_exit=protected, est_entry_costs=est, est_exit_costs=est,
        config_hash="h", strategy_version="test", signal_ts=t)
