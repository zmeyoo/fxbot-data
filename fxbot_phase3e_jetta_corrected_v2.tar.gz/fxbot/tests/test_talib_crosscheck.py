"""Runs only where TA-Lib is installed (it is NOT installed in the authoring sandbox, so this has not
been executed yet). A failure means: investigate and document - do not edit the indicator to force a match."""
import unittest

from fxbot.indicators.crosscheck import compare, random_ohlc, render_markdown, run_crosscheck
from fxbot.indicators import core

try:
    import talib
except Exception:
    talib = None


class TestCompareHelper(unittest.TestCase):          # runs everywhere: tests the harness itself
    def test_compare_reports_zones_and_alignment(self):
        mine = [None, None, 1.0, 2.0, 3.0, 4.0]
        ref = [None, None, None, 2.0, 3.0001, float("nan")]
        d = compare("x", mine, ref, warmup=4, tolerance=1e-3)
        self.assertEqual((d.first_index_mine, d.first_index_ref), (2, 3))
        self.assertAlmostEqual(d.max_abs_after, 1e-4); self.assertEqual(d.defined_mismatch_after, 1)   # idx5: ref NaN
        self.assertFalse(d.ok)
        self.assertIn("investigate", render_markdown([d]))
        same = compare("y", mine, mine, 2, 1e-12)
        self.assertTrue(same.ok)


@unittest.skipIf(talib is None, "TA-Lib not installed")
class TestAgainstTaLib(unittest.TestCase):
    def test_after_warmup_agreement(self):
        for seed in (1, 2, 3):
            h, l, c = random_ohlc(3000, seed)
            for d in run_crosscheck(talib, h, l, c):
                self.assertTrue(d.ok, f"seed {seed}: {d}")


if __name__ == "__main__":
    unittest.main()
