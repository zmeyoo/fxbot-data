import json
import lzma
import os
import struct
import tempfile
import unittest
from datetime import datetime, timedelta, timezone
from unittest import mock

from fxbot.data_sources import cli, dukascopy
from fxbot.data_sources.dukascopy import encode_bi5, hour_url
from fxbot.data_sources.verify import SAMPLE_HOUR, analyze_raw, plan_verification_hours, render, verify_decoder
from tests.dukas_fixtures import DownServer, FakeServer, make_ticks, ticks_full_hour, verify_server

U = timezone.utc
START, END = datetime(2024, 3, 4, tzinfo=U), datetime(2024, 3, 18, tzinfo=U)           # the approved pilot period
SAMPLE = os.path.join(os.path.dirname(__file__), "data", "eurusd_dukascopy_published_sample_ticks.csv")


def z(*a):
    return datetime(*a, tzinfo=U)


class Tmp(unittest.TestCase):
    def setUp(self):
        self._d = tempfile.TemporaryDirectory(); self.d = self._d.name

    def tearDown(self):
        self._d.cleanup()

    def verify(self, server, ref=(1.05, 1.12), sample=SAMPLE, start=START, end=END):
        out = tempfile.mkdtemp(dir=self.d)          # fresh output dir per call: a second call in the same dir would (correctly) resume from cached files
        return verify_decoder(out, server, "EURUSD", start, end, sample, ref, retries=0, delay_s=0, sleep=lambda s: None, log=lambda s: None)


def status(res, prefix):
    return next(f.status for f in res.findings if f.assumption.startswith(prefix))


class TestPlan(unittest.TestCase):
    def test_pilot_hours_cover_active_regimes_and_the_dst_weekend_boundaries(self):
        p = plan_verification_hours(START, END)
        self.assertEqual(p["active"], [z(2024, 3, 5, 3), z(2024, 3, 5, 8), z(2024, 3, 5, 14)])
        self.assertEqual(p["closure"], [z(2024, 3, 8, 21), z(2024, 3, 8, 22), z(2024, 3, 8, 23)])      # Fri 17:00 EST = 22:00Z
        self.assertEqual(p["reopen"], [z(2024, 3, 10, 20), z(2024, 3, 10, 21), z(2024, 3, 10, 22)])    # Sun 17:00 EDT = 21:00Z (DST began 02:00)
        w = plan_verification_hours(z(2024, 1, 8), z(2024, 1, 22))                                      # winter: both boundaries at 22:00Z
        self.assertEqual((w["closure"][1], w["reopen"][1]), (z(2024, 1, 12, 22), z(2024, 1, 14, 22)))
        short = plan_verification_hours(z(2024, 3, 4), z(2024, 3, 7))
        self.assertEqual(short["closure"], [])


class TestVerification(Tmp):
    def test_clean_data_passes_every_independent_check(self):
        res = self.verify(verify_server(START, END))
        self.assertTrue(res.passed, [(f.assumption, f.status) for f in res.findings if f.status == "FAIL"])
        self.assertEqual({f.assumption.split(" (")[0].split(" ")[0]: f.status for f in res.findings}["LZMA"], "PASS")
        self.assertEqual(status(res, "20-byte"), "PASS"); self.assertEqual(status(res, "Price point"), "PASS")
        self.assertEqual(status(res, "BID/ASK"), "PASS"); self.assertEqual(status(res, "Timestamp"), "PASS")
        self.assertEqual(status(res, "Hour files are UTC"), "PASS"); self.assertEqual(status(res, "Published"), "PASS")
        self.assertEqual(status(res, "Volume"), "UNCERTAIN")                                         # never claimed as verified
        vol = next(f for f in res.findings if f.assumption.startswith("Volume"))
        self.assertIn("UNITS ARE NOT VERIFIABLE", vol.evidence); self.assertIn("NOT used by the strategy", vol.evidence)
        md = render(res, "EURUSD", START, END, "cmd")
        self.assertIn("VERDICT: PASSED (UNCERTAIN items remain", md); self.assertIn("never adapted", md)
        self.assertEqual(len(res.hours), 9)                                                           # 3 active + 3 closure + 3 reopen

    def test_verification_is_independent_of_decode_bi5(self):
        with mock.patch.object(dukascopy, "decode_bi5", side_effect=AssertionError("decoder under test was used")):
            self.assertTrue(self.verify(verify_server(START, END)).passed)

    def test_price_scale_is_uncertain_without_an_independent_reference_and_fails_when_wrong(self):
        res = self.verify(verify_server(START, END, sample=None), ref=None, sample=None)
        self.assertEqual(status(res, "Price point"), "UNCERTAIN"); self.assertTrue(res.passed)
        res = self.verify(verify_server(START, END, sample=None), ref=(0.2, 0.9), sample=None)         # reference you trust disagrees
        self.assertEqual(status(res, "Price point"), "FAIL"); self.assertFalse(res.passed)
        wrong = self.verify(verify_server(START, END, base_pts=11000))                                  # point value assumption wrong by 10x
        self.assertEqual(status(wrong, "Price point"), "FAIL"); self.assertFalse(wrong.passed)

    def test_swapped_bid_ask_fails(self):
        res = self.verify(verify_server(START, END, swap=True))
        self.assertEqual(status(res, "BID/ASK"), "FAIL"); self.assertFalse(res.passed)
        self.assertIn("fraction of records with field2 >= field3", next(f.evidence for f in res.findings if f.assumption.startswith("BID/ASK")))

    def test_timezone_shift_is_caught_by_the_closure_alignment_check(self):
        for shift in (2, -2, 5):
            res = self.verify(verify_server(START, END, shift_hours=shift))
            self.assertEqual(status(res, "Hour files are UTC"), "FAIL", shift); self.assertFalse(res.passed)
        self.assertTrue(self.verify(verify_server(START, END, shift_hours=0)).passed)

    def test_container_and_structure_faults_fail(self):
        p = plan_verification_hours(START, END)
        h = p["active"][1]
        res = self.verify(verify_server(START, END, garbage_hours=(h,)))
        self.assertEqual(status(res, "LZMA"), "FAIL"); self.assertFalse(res.passed)
        self.assertTrue(all(f.status == "FAIL" for f in res.findings if f.assumption.startswith(("20-byte", "Price point", "BID/ASK", "Timestamp"))))
        ok = b"".join(struct.pack(">IIIff", i * 1000, 110008, 110000, 1.0, 1.0) for i in range(100))
        trunc = lzma.compress(ok + b"\x00" * 7, format=lzma.FORMAT_ALONE)                              # 2007 bytes: not a multiple of 20
        res = self.verify(verify_server(START, END, custom={h: trunc}))
        self.assertEqual(status(res, "20-byte"), "FAIL")
        good = lzma.compress(ok, format=lzma.FORMAT_ALONE)
        bad_hdr = good[:5] + struct.pack("<q", 12345) + good[13:]                                       # declared size lies
        res = self.verify(verify_server(START, END, custom={h: bad_hdr}))
        self.assertEqual(status(res, "LZMA"), "FAIL")
        scrambled = [(5_000_000, 110008, 110000, 1.0, 1.0)] + [(i * 7000 % 3_000_000, 110008, 110000, 1.0, 1.0) for i in range(300)]
        res = self.verify(verify_server(START, END, custom={h: encode_bi5(scrambled)}))
        self.assertEqual(status(res, "Timestamp"), "FAIL"); self.assertFalse(res.passed)

    def test_sample_mismatch_is_inconclusive_not_a_failure_and_missing_sample_is_noted(self):
        res = self.verify(verify_server(START, END, sample="other"))
        f = next(f for f in res.findings if f.assumption.startswith("Published"))
        self.assertEqual(f.status, "INFO"); self.assertIn("INCONCLUSIVE", f.evidence); self.assertTrue(res.passed)
        res = self.verify(verify_server(START, END, sample=None))
        self.assertIn("unavailable", next(f.evidence for f in res.findings if f.assumption.startswith("Published")))

    def test_range_without_a_weekend_marks_the_boundary_check_uncertain(self):
        res = self.verify(verify_server(z(2024, 3, 4), z(2024, 3, 7)), start=z(2024, 3, 4), end=z(2024, 3, 7))
        self.assertEqual(status(res, "Hour files are UTC"), "UNCERTAIN"); self.assertTrue(res.passed)

    def test_cannot_verify_when_data_or_network_is_missing(self):
        res = self.verify(DownServer())
        self.assertIsNotNone(res.cannot_verify); self.assertFalse(res.passed); self.assertIn("nothing was substituted", res.cannot_verify)
        self.assertEqual(res.findings, [])
        p = plan_verification_hours(START, END)
        partial = verify_server(START, END, hours=[h for h in p["active"] if h != p["active"][0]])   # one active hour absent
        res = self.verify(partial)
        self.assertIn("no data", res.cannot_verify)

    def test_analyze_raw_reports_facts_without_raising(self):
        self.assertTrue(analyze_raw(b"", "EURUSD")["empty"])
        self.assertIn("lzma_error", analyze_raw(b"this is not an lzma stream at all", "EURUSD"))
        degenerate = analyze_raw(b"\x5d" + b"\x00" * 30, "EURUSD")                       # the library accepts this as an EMPTY stream ...
        self.assertEqual((degenerate["records"], "lzma_error" in degenerate), (0, False))
        res_dir = tempfile.mkdtemp()
        try:
            h = plan_verification_hours(START, END)["active"][0]
            r = verify_decoder(res_dir, verify_server(START, END, custom={h: b"\x5d" + b"\x00" * 30}), "EURUSD", START, END, SAMPLE, (1.05, 1.12),
                               retries=0, delay_s=0, sleep=lambda s: None, log=lambda s: None)
            self.assertFalse(r.passed)                                                      # ... but the verifier still fails it (no records)
        finally:
            import shutil; shutil.rmtree(res_dir, ignore_errors=True)
        a = analyze_raw(encode_bi5(ticks_full_hour(1)), "EURUSD")
        self.assertEqual((a["remainder"], a["records"], a["container"]), (0, 400, "lzma-alone"))
        self.assertTrue(a["lzma_eof"] and a["decompressors_identical"] and a["declared_size_ok"])


class TestVerifyDecoderCli(Tmp):
    def run_cli(self, argv, server):
        out = []
        with mock.patch.object(cli, "UrllibFetcher", lambda *a, **k: server):
            rc = cli.main(argv, out=out.append)
        return rc, "\n".join(out)

    BASE = ["verify-decoder", "--instrument", "EURUSD", "--start", "2024-03-04", "--end", "2024-03-18", "--reference-range", "1.05:1.12", "--sleep", "0", "--retries", "0"]

    def test_exit_codes_and_artifacts(self):
        out = os.path.join(self.d, "o")
        rc, txt = self.run_cli(self.BASE + ["--out", out, "--sample", SAMPLE], verify_server(START, END))
        self.assertEqual(rc, 0, txt)
        with open(os.path.join(out, "decoder_verification.json")) as f:
            j = json.load(f)
        self.assertTrue(j["passed"]); self.assertTrue(os.path.exists(os.path.join(out, "DECODER_VERIFICATION.md")))
        self.assertEqual(len(j["hours"]), 9)
        out2 = os.path.join(self.d, "o2")
        rc, txt = self.run_cli(self.BASE + ["--out", out2, "--sample", SAMPLE], verify_server(START, END, swap=True))
        self.assertEqual(rc, 5); self.assertIn("Nothing was adapted", txt)
        with open(os.path.join(out2, "decoder_verification.json")) as f:
            self.assertFalse(json.load(f)["passed"])
        self.assertFalse(os.path.exists(os.path.join(out2, "normalised")))                           # verification never builds a dataset
        out3 = os.path.join(self.d, "o3")
        rc, txt = self.run_cli(self.BASE + ["--out", out3, "--sample", SAMPLE], DownServer())
        self.assertEqual(rc, 3); self.assertIn("CANNOT VERIFY", txt)

    def test_verified_hours_are_reused_by_the_bulk_download(self):
        out = os.path.join(self.d, "o")
        srv = verify_server(START, END)
        self.run_cli(self.BASE + ["--out", out, "--sample", SAMPLE], srv)
        n = len(srv.calls)
        store = dukascopy.RawStore(os.path.join(out, "raw"))
        self.assertTrue(store.is_complete("EURUSD", z(2024, 3, 5, 8)))                              # same raw store as the full run
        self.assertTrue(os.path.exists(os.path.join(out, "verify_raw")))                            # the 2020 sample hour is kept apart
        self.assertGreater(n, 8)


if __name__ == "__main__":
    unittest.main()
