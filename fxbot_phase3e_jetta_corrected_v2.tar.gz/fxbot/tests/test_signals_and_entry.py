import random
import unittest
from datetime import timedelta
from decimal import Decimal as Dc

from fxbot.core.types import Side
from fxbot.market_data.bars import Bar
from fxbot.risk.currency import CurrencyLedger, OrderClass
from fxbot.risk.governor import RiskGovernor
from fxbot.signals.base import Signal
from fxbot.signals.ema_trend import EmaTrendEngine, EmaTrendParams, LookAheadError, SignalInputs
from fxbot.signals.news import ManualBlackoutProvider, NullNewsProvider
from fxbot.strategy.entry import evaluate_entry
from fxbot.strategy.pair_state import PairStrategy
from tests.fixtures import *
from tests.signal_helpers import *

ENG = EmaTrendEngine()


def run_engine(closes, engine=ENG, max_age=120, as_of=None, bars=None):
    bb = bars or bars_from_closes(closes)
    ao = as_of or bb[-1].end_ts
    return engine.evaluate(SignalInputs("EURUSD", ao, *pipeline(bb, ao), max_age_s=max_age))


class TestEmaTrendEngine(unittest.TestCase):
    def test_valid_long_signal_is_explainable_and_stamped(self):
        cl = uptrend_with_pullback(dip=5, rebound=3)
        bb = bars_from_closes(cl)
        r = run_engine(cl, bars=bb)
        s = r.signal
        self.assertEqual((s.direction, s.valid), (Side.LONG, True))
        self.assertEqual(s.signal_ts, bb[-1].end_ts); self.assertEqual(s.market_ts, bb[-1].end_ts)
        self.assertGreaterEqual(len(s.reasons), 7); self.assertEqual(s.failed, ())
        d = dict(s.diagnostics)
        self.assertEqual(d["engine"], "ema_trend_v0"); self.assertIn("not true volume", d["volume_proxy"])

    def test_short_is_exact_mirror_of_long(self):
        cl = uptrend_with_pullback(dip=5, rebound=3)
        a, b = run_engine(cl), run_engine(mirror(cl))
        self.assertEqual(b.signal.direction, Side.SHORT)
        self.assertEqual(a.long.flags, b.short.flags)                       # same pass/fail pattern
        self.assertEqual(a.short.flags, b.long.flags)

    def test_sideways_market_gives_no_signal(self):
        r = run_engine(sideways())
        self.assertIsNone(r.signal)
        self.assertTrue(r.long.failed and r.short.failed)

    def test_macd_modes_documented_interaction_with_pullback_entries(self):
        cl = uptrend_with_pullback(dip=5, rebound=3)
        self.assertIsNotNone(run_engine(cl, EmaTrendEngine(EmaTrendParams(macd_mode="line"))).signal)
        h = run_engine(cl, EmaTrendEngine(EmaTrendParams(macd_mode="histogram")))
        self.assertIsNone(h.signal)
        self.assertIn("5m MACD histogram > 0", h.long.failed)

    def test_data_quality_blocks(self):
        cl = uptrend_with_pullback(dip=5, rebound=3)
        bb = bars_from_closes(cl)
        short = run_engine(cl[:100]);                    self.assertTrue(any("insufficient" in x for x in short.blocked))
        self.assertTrue(any("not configured" in x for x in run_engine(cl, max_age=None).blocked))
        late = bb[-1].end_ts + timedelta(minutes=10)
        r = ENG.evaluate(SignalInputs("EURUSD", late, *pipeline(bb, late), max_age_s=120))
        self.assertTrue(any("stale" in x for x in r.blocked)); self.assertIsNone(r.signal)
        gap = bb[:-10] + [Bar(b.start_ts + timedelta(minutes=20), b.end_ts + timedelta(minutes=20), b.open, b.high, b.low, b.close, b.ticks)
                          for b in bb[-10:]]
        r = run_engine(None, bars=gap)
        self.assertTrue(any("gap" in x for x in r.blocked))

    def test_incomplete_candle_raises_lookahead_error(self):
        bb = bars_from_closes(uptrend_with_pullback(dip=5, rebound=3))
        as_of = bb[-1].end_ts - timedelta(seconds=30)                       # last 1m bar still forming
        with self.assertRaises(LookAheadError):
            ENG.evaluate(SignalInputs("EURUSD", as_of, bb, aggregate_(bb, 300, as_of), aggregate_(bb, 900, as_of), 120))

    def test_property_future_data_cannot_change_a_past_decision(self):
        rnd = random.Random(31)
        base = uptrend_with_pullback(dip=5, rebound=3)
        for _ in range(12):
            k = rnd.randint(800, len(base))
            future = base[:k] + [base[k - 1] + rnd.uniform(-0.01, 0.01) for _ in range(60)]   # wild future
            a = run_engine(None, bars=bars_from_closes(base[:k]))
            bb = bars_from_closes(future)
            cut = bb[k - 1].end_ts
            b = ENG.evaluate(SignalInputs("EURUSD", cut, *pipeline(bb, cut), 120))
            self.assertEqual((a.signal and a.signal.direction, a.long.flags, a.short.flags),
                             (b.signal and b.signal.direction, b.long.flags, b.short.flags))

    def test_memoised_engine_is_identical_to_plain_engine(self):
        cl = uptrend_with_pullback(dip=5, rebound=3)
        bb = bars_from_closes(cl)
        plain, fast = EmaTrendEngine(), EmaTrendEngine(memoize=True)
        for k in range(len(bb) - 40, len(bb) + 1):                     # consecutive minutes reuse the 5m/15m values
            ao = bb[k - 1].end_ts
            inp = SignalInputs("EURUSD", ao, *pipeline(bb, ao), 120)
            a, b = plain.evaluate(inp), fast.evaluate(inp)
            self.assertEqual((a.signal, a.long, a.short, a.blocked), (b.signal, b.long, b.short, b.blocked))

    def test_optional_filters_default_off_and_apply_when_enabled(self):
        cl = uptrend_with_pullback(dip=5, rebound=3)
        self.assertEqual(len(run_engine(cl).long.flags), 7)                 # EMA200 / ATR / activity all off
        strict = EmaTrendEngine(EmaTrendParams(min_atr_pct=5.0, max_atr_pct=9.0, use_ema200_filter=True,
                                               use_activity_proxy=True, activity_min_ratio=50.0))
        self.assertTrue(any("insufficient 15m" in x for x in run_engine(cl, strict).blocked))   # EMA200 needs 200 bars
        r = run_engine(uptrend_with_pullback(n_trend=3300, dip=5, rebound=3), strict)
        self.assertIsNone(r.signal)
        self.assertTrue(any("ATR%" in f for f in r.long.failed)); self.assertTrue(any("activity" in f for f in r.long.failed))

    def test_params_from_mapping_and_fingerprint(self):
        p = EmaTrendParams.from_mapping({"adx_min": "25", "ema_fast": "10", "use_ema200_filter": "true",
                                         "macd_mode": "histogram", "min_atr_pct": "0.01"})
        self.assertEqual((p.adx_min, p.ema_fast, p.use_ema200_filter, p.macd_mode, p.min_atr_pct), (25.0, 10, True, "histogram", 0.01))
        with self.assertRaises(ValueError): EmaTrendParams.from_mapping({"nope": "1"})
        self.assertNotEqual(EmaTrendParams().fingerprint(), p.fingerprint())
        self.assertEqual(EmaTrendParams().fingerprint(), EmaTrendParams().fingerprint())


def aggregate_(bb, tf, as_of):
    from fxbot.market_data.bars import aggregate
    return aggregate(bb, tf, as_of)


# ------------------------------------------------------------------ entry decision (all filters)
C = T0 + timedelta(minutes=30)


class World:
    def __init__(self, closed_side=Side.LONG, cfg=None, g=None, cash="700000", news=None):
        self.cfg = cfg or pair_cfg(cooldown_minutes=10)
        self.g = g or gcfg(max_currency_exposure_base={"EUR": Dc("2000000"), "USD": Dc("2000000")})
        self.st = PairStrategy(self.cfg)
        self.st.start(T0); self.st.on_entry_requested(T0); self.st.on_position_opened(T0)
        self.st.on_position_closed(closed_side, C)
        self.gov = RiskGovernor(self.g); self.gov.start_session(Dc("100000"))
        self.ledger = CurrencyLedger({"USD": Dc(cash), "EUR": Dc("0")})
        self.news = news or NullNewsProvider()
        self.now = C + timedelta(minutes=15)

    def feed_dip_and_recovery(self, side):
        if side is Side.LONG:
            path = [("1.0979", "1.0980"), ("1.0991", "1.0992")]
        else:
            path = [("1.1020", "1.1021"), ("1.1008", "1.1009")]
        for i, (b, a) in enumerate(path):
            self.st.on_quote(qt(b, a, C + timedelta(minutes=5 + i)))
        return qt(*path[-1], self.now)

    def decide(self, side, quote=None, sig=None, **kw):
        q = quote or self.feed_dip_and_recovery(side)
        sig = sig or Signal("EURUSD", side, self.now, self.now, True, ("fresh",))
        args = dict(strategy=self.st, signal=sig, quote=q, spec=SPEC, cfg=self.cfg, gcfg=self.g, ctx=CTX,
                    ledger=self.ledger, open_positions=[], governor=self.gov, equity_base=Dc("100000"),
                    news=self.news, now=self.now, margin_util_after_pct=Dc("10"))
        args.update(kw)
        return evaluate_entry(**args)


class TestEntryDecision(unittest.TestCase):
    def test_same_direction_long_reentry_approved_when_everything_passes(self):
        d = World().decide(Side.LONG)
        self.assertTrue(d.approved, d.reasons)
        self.assertTrue(d.is_same_direction_reentry and not d.is_reversal)
        self.assertGreater(d.sizing.qty, 0); self.assertEqual(d.funding.classification, OrderClass.FUNDED_LONG)
        self.assertTrue(any("NO news protection" in w for w in d.warnings))      # null provider is visible

    def test_same_direction_short_reentry_symmetric_authorised_borrow(self):
        d = World(Side.SHORT, cash="0").decide(Side.SHORT)
        self.assertTrue(d.approved, d.reasons)
        self.assertTrue(d.is_same_direction_reentry)
        self.assertEqual(d.funding.classification, OrderClass.AUTHORISED_SHORT_BORROW)
        self.assertLessEqual(d.sizing.qty, Dc("200000"))                            # inside the -200k EUR floor

    def test_opposite_direction_after_close_also_possible(self):
        w = World(Side.LONG)
        for i, (b, a) in enumerate([("1.1019", "1.1020"), ("1.0990", "1.0991")]):
            w.st.on_quote(qt(b, a, C + timedelta(minutes=5 + i)))
        d = w.decide(Side.SHORT, quote=qt("1.0990", "1.0991", w.now))
        self.assertTrue(d.approved, d.reasons); self.assertTrue(d.is_reversal and not d.is_same_direction_reentry)

    def test_no_reentry_merely_because_the_position_closed(self):
        w = World()
        q = w.feed_dip_and_recovery(Side.LONG)
        stale = Signal("EURUSD", Side.LONG, C - timedelta(minutes=1), C - timedelta(minutes=1), True, ())
        d = w.decide(Side.LONG, quote=q, sig=stale)
        self.assertFalse(d.approved); self.assertTrue(any("predates the close" in r for r in d.reasons))
        d2 = w.decide(Side.LONG, quote=q, sig=Signal("EURUSD", Side.LONG, w.now, w.now, False, ()))
        self.assertFalse(d2.approved)

    def test_movement_threshold_must_be_met(self):
        w = World()
        w.st.on_quote(qt("1.0979", "1.0980", C + timedelta(minutes=5)))
        d = w.decide(Side.LONG, quote=qt("1.0984", "1.0985", w.now))
        self.assertFalse(d.approved); self.assertTrue(any("move" in r for r in d.reasons))

    def test_each_filter_can_veto_a_valid_reentry(self):
        wide = World().decide(Side.LONG, quote=qt("1.0980", "1.0992", World().now))
        self.assertTrue(any(r.startswith("cost:") and "spread" in r for r in wide.reasons))
        poor = World(cash="1000").decide(Side.LONG)                          # own cash caps size to nothing
        self.assertTrue(any(r.startswith("sizing:") for r in poor.reasons))
        conv = World(g=gcfg(allow_auto_conversion=True, max_currency_exposure_base={"EUR": Dc("2000000"), "USD": Dc("2000000")})).decide(Side.LONG)
        self.assertTrue(any(r.startswith("funding:") for r in conv.reasons))
        lim = World(g=gcfg(max_currency_exposure_base={"EUR": Dc("100000"), "USD": Dc("100000")})).decide(Side.LONG)
        self.assertTrue(any(r.startswith("exposure:") for r in lim.reasons))
        w = World(); w.gov.update_equity(Dc("97000"))
        self.assertTrue(any(r.startswith("risk:") and "lockout" in r for r in w.decide(Side.LONG).reasons))
        w2 = World(); w2.gov.register_open("OPEN1", "EURUSD", Dc("100"), False)
        self.assertTrue(any("already has an open" in r for r in w2.decide(Side.LONG).reasons))
        w3 = World(); w3.gov.kill_switch = True
        self.assertTrue(any("emergency" in r for r in w3.decide(Side.LONG).reasons))

    def test_stale_quote_and_news_blackout(self):
        w = World()
        old = qt("1.0991", "1.0992", w.now - timedelta(minutes=5))
        d = w.decide(Side.LONG, quote=old)
        self.assertTrue(any(r.startswith("data:") for r in d.reasons)); self.assertIsNone(d.sizing)
        blackout = ManualBlackoutProvider(((w.now - timedelta(minutes=5), w.now + timedelta(minutes=5), ("USD",)),))
        w2 = World(news=blackout)
        d2 = w2.decide(Side.LONG)
        self.assertTrue(any(r.startswith("news:") for r in d2.reasons))
        self.assertFalse(any("NO news protection" in x for x in d2.warnings))     # manual policy is real protection

    def test_cooldown_still_enforced(self):
        w = World(); w.now = C + timedelta(minutes=4)
        q = qt("1.0991", "1.0992", w.now)
        w.st.on_quote(qt("1.0979", "1.0980", C + timedelta(minutes=2)))
        d = w.decide(Side.LONG, quote=q)
        self.assertTrue(any("cooldown" in r for r in d.reasons))

    def test_property_every_veto_blocks_and_all_clear_approves(self):
        rnd = random.Random(404)
        for _ in range(60):
            cash = rnd.choice(["700000", "1000"]); excl = rnd.choice([True, False])
            g = gcfg(max_currency_exposure_base={"EUR": Dc("2000000") if not excl else Dc("100000"),
                                                 "USD": Dc("2000000")})
            w = World(cash=cash, g=g)
            d = w.decide(Side.LONG)
            should_pass = cash == "700000" and not excl
            self.assertEqual(d.approved, should_pass, d.reasons)


if __name__ == "__main__":
    unittest.main()
