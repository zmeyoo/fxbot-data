import random
import unittest
from decimal import Decimal as Dc

from fxbot.core.types import FxBotError, Side
from fxbot.position_manager.position import (ExitReason, IllegalTransition, Position, PositionState as S,
                                             StopParams, unprotected_positions)
from fxbot.position_manager.trailing import (favourable_move_pct, initial_stop_price, is_stop_hit,
                                             trailing_stop_price)
from tests.fixtures import *

EPS = Dc("1E-12")


class TestStopMath(unittest.TestCase):
    def test_01_long_initial_stop(self):
        self.assertEqual(initial_stop_price(Side.LONG, Dc("1.10000"), Dc("0.10")), Dc("1.09890"))

    def test_02_short_initial_stop(self):
        self.assertEqual(initial_stop_price(Side.SHORT, Dc("1.10000"), Dc("0.10")), Dc("1.10110"))

    def test_03_04_trailing_table_long_and_short(self):
        p0 = Dc("1.10000")
        for move, prot in [("0.10", "0.00"), ("0.15", "0.05"), ("0.20", "0.10"), ("0.25", "0.15"), ("0.30", "0.20")]:
            lp = trailing_stop_price(Side.LONG, p0, p0 * (1 + Dc(move) / 100), Dc("0.10"), Dc("0.10"))
            sp = trailing_stop_price(Side.SHORT, p0, p0 * (1 - Dc(move) / 100), Dc("0.10"), Dc("0.10"))
            self.assertLess(abs(lp - p0 * (1 + Dc(prot) / 100)), EPS)
            self.assertLess(abs(sp - p0 * (1 - Dc(prot) / 100)), EPS)

    def test_trailing_inactive_below_activation(self):
        p0 = Dc("1.1")
        self.assertIsNone(trailing_stop_price(Side.LONG, p0, p0 * Dc("1.00099"), Dc("0.10"), Dc("0.10")))
        self.assertIsNone(trailing_stop_price(Side.SHORT, p0, p0 * Dc("0.99901"), Dc("0.10"), Dc("0.10")))

    def test_07_percent_relative_to_entry_price_not_equity(self):
        p0 = Dc("150.000")      # USDJPY: 0.10% of the PRICE is 0.15 yen
        self.assertEqual(initial_stop_price(Side.LONG, p0, Dc("0.10")), Dc("149.850"))
        self.assertEqual(favourable_move_pct(Side.LONG, p0, Dc("150.150")), Dc("0.1"))

    def test_08_executable_side_used(self):
        long_ = make_position(Side.LONG)
        # ask spikes, bid does not: a LONG's favourable extreme must not move (it exits on the bid)
        long_.update_market(qt("1.10000", "1.10500"))
        self.assertEqual(long_.p_best, Dc("1.10000"))
        short = make_position(Side.SHORT)
        short.update_market(qt("1.09000", "1.10000"))      # bid collapses, ask unchanged
        self.assertEqual(short.p_best, Dc("1.10000"))
        self.assertTrue(is_stop_hit(Side.LONG, Dc("1.0989"), qt("1.0988", "1.0990")))
        self.assertFalse(is_stop_hit(Side.LONG, Dc("1.0989"), qt("1.0990", "1.0991")))
        self.assertTrue(is_stop_hit(Side.SHORT, Dc("1.1011"), qt("1.1009", "1.1011")))
        self.assertFalse(is_stop_hit(Side.SHORT, Dc("1.1011"), qt("1.1008", "1.1010")))

    def test_05_06_property_ratchet_never_loosens_and_extreme_never_resets(self):
        rnd = random.Random(1234)
        for side in Side:
            for _ in range(300):
                pos = make_position(side)
                last_stop, last_best = pos.desired_stop, pos.p_best
                px = Dc("1.10000")
                for _ in range(150):
                    px += Dc(rnd.randint(-40, 45)) * Dc("0.00001")
                    pos.update_market(qt(px - Dc("0.00005"), px + Dc("0.00005")))
                    if side is Side.LONG:
                        self.assertGreaterEqual(pos.desired_stop, last_stop)
                        self.assertGreaterEqual(pos.p_best, last_best)
                    else:
                        self.assertLessEqual(pos.desired_stop, last_stop)
                        self.assertLessEqual(pos.p_best, last_best)
                    last_stop, last_best = pos.desired_stop, pos.p_best

    def test_property_long_short_mirror_symmetry(self):
        rnd = random.Random(99)
        p0 = Dc("1.10000")
        for _ in range(200):
            lp, sp = make_position(Side.LONG), make_position(Side.SHORT)
            for _ in range(100):
                step = Dc(rnd.randint(-30, 32)) * Dc("0.00001")
                x = p0 + step * rnd.randint(1, 5)
                lq = qt(x, x + Dc("0.0001"))
                mirrored = p0 - (x - p0)
                sq = qt(mirrored - Dc("0.0001"), mirrored)
                lp.update_market(lq); sp.update_market(sq)
            self.assertEqual(lp.max_favourable_pct.quantize(Dc("1E-9")), sp.max_favourable_pct.quantize(Dc("1E-9")))
            self.assertLess(abs((lp.desired_stop - p0) + (sp.desired_stop - p0)), Dc("0.0001"))


class TestPositionLifecycle(unittest.TestCase):
    def test_long_lifecycle_to_trailing(self):
        pos = make_position(Side.LONG)
        self.assertEqual(pos.state, S.OPEN_PROTECTED)
        self.assertEqual(pos.desired_stop, Dc("1.09890"))
        pos.update_market(qt("1.10110"))
        self.assertTrue(pos.trailing_engaged)
        pos.mark_trailing_if_protected(T0)
        self.assertEqual(pos.state, S.TRAILING_ACTIVE)
        self.assertEqual(pos.desired_stop, Dc("1.10000"))        # protected level 0.00%
        self.assertEqual(pos.stop_basis, "trailing")

    def test_stop_from_actual_average_entry_not_requested(self):
        pos = make_position(Side.LONG, price="1.10020")           # filled worse than "requested"
        self.assertEqual(pos.desired_stop, Dc("1.09910"))         # 1.10020 * 0.999 -> tick-rounded up

    def test_18_partial_fills_and_protection_coverage(self):
        pos = Position(position_id="PX", spec=SPEC, side=Side.LONG, target_qty=Dc("100000"),
                       params=StopParams(Dc("0.10"), Dc("0.10"), Dc("0.10")), created_ts=T0,
                       config_hash="h", strategy_version="t")
        pos.on_entry_fill(fill("40000", "1.10000", entry_quote(Side.LONG, "1.10000")))
        self.assertEqual(pos.state, S.OPEN_UNPROTECTED)
        pos.confirm_protection("S1", pos.desired_stop, Dc("40000"), T0)
        self.assertEqual(pos.state, S.OPEN_PROTECTED)
        pos.on_entry_fill(fill("60000", "1.10010", entry_quote(Side.LONG, "1.10010")))
        self.assertEqual(pos.state, S.OPEN_UNPROTECTED)           # new qty not covered
        self.assertEqual(pos.avg_entry, Dc("1.10006"))
        pos.confirm_protection("S2", pos.desired_stop, Dc("100000"), T0)
        self.assertEqual(pos.state, S.OPEN_PROTECTED)

    def test_duplicate_execution_ack_ignored(self):
        pos = make_position(Side.LONG)
        pos2 = Position(position_id="PD", spec=SPEC, side=Side.LONG, target_qty=Dc("100000"),
                        params=pos.params, created_ts=T0, config_hash="h", strategy_version="t")
        f = fill("50000", "1.1", entry_quote(Side.LONG, "1.1"), eid="DUP")
        self.assertTrue(pos2.on_entry_fill(f))
        self.assertFalse(pos2.on_entry_fill(f))
        self.assertEqual(pos2.open_qty, Dc("50000"))

    def test_overfill_rejected_and_illegal_transition(self):
        pos = make_position(Side.LONG)
        with self.assertRaises(IllegalTransition):                # entry already completed
            pos.on_entry_fill(fill("1000", "1.1", entry_quote(Side.LONG, "1.1")))
        pos.request_exit(ExitReason.MANUAL, T0)
        pos.on_exit_fill(fill("100000", "1.0999", qt("1.0999")), None)
        self.assertEqual(pos.state, S.CLOSED)
        with self.assertRaises(IllegalTransition):
            pos._go(S.OPEN_PROTECTED, T0, "bad")
        small = Position(position_id="PO", spec=SPEC, side=Side.LONG, target_qty=Dc("1000"),
                         params=pos.params, created_ts=T0, config_hash="h", strategy_version="t")
        with self.assertRaises(FxBotError):                       # overfill
            small.on_entry_fill(fill("2000", "1.1", entry_quote(Side.LONG, "1.1")))

    def test_19_entry_rejected_no_fill_closes_cleanly(self):
        pos = Position(position_id="PR", spec=SPEC, side=Side.SHORT, target_qty=Dc("1000"),
                       params=StopParams(Dc("0.1"), Dc("0.1"), Dc("0.1")), created_ts=T0,
                       config_hash="h", strategy_version="t")
        pos.complete_entry(T0)
        self.assertEqual(pos.state, S.CLOSED)
        self.assertEqual(pos.exit_reason, ExitReason.ENTRY_CANCELLED)

    def test_net_identity_and_pro_rata_partial_exit(self):
        pos = make_position(Side.LONG, qty="100000")
        pos.request_exit(ExitReason.MANUAL, T0)
        r1, r2 = qt("1.10200"), qt("1.10300")
        f1, f2 = fill("40000", "1.10198", r1), fill("60000", "1.10299", r2)
        pos.on_exit_fill(f1); self.assertEqual(pos.open_qty, Dc("60000"))
        pos.on_exit_fill(f2); self.assertEqual(pos.state, S.CLOSED)
        entry_comm = CTX.commission_quote(Dc("100000"), Dc("1.1"), "USD")
        direct = (Dc("1.10198") - Dc("1.1")) * 40000 + (Dc("1.10299") - Dc("1.1")) * 60000
        direct -= entry_comm + f1.commission + f2.commission
        self.assertLess(abs(pos.realised_net - direct), Dc("1E-9"))
        self.assertLess(abs(pos.entry_costs_open.total), Dc("1E-9"))     # all entry cost released

    def test_exit_aborted_and_unprotected_detection(self):
        pos = make_position(Side.LONG)
        pos.request_exit(ExitReason.MANUAL, T0)
        pos.on_exit_aborted(T0, protection_confirmed=False)
        self.assertEqual(pos.state, S.OPEN_UNPROTECTED)
        later = T0 + timedelta(seconds=6)
        self.assertEqual(unprotected_positions([pos], later, 5), [pos])
        self.assertEqual(unprotected_positions([pos], T0 + timedelta(seconds=2), 5), [])
        err = make_position(Side.SHORT); err.mark_error(T0, "unknown broker state")
        self.assertEqual(unprotected_positions([err], T0, 5), [err])

    def test_25_reconcile_resume_is_unprotected_until_reconfirmed(self):
        pos = make_position(Side.LONG)
        pos.mark_error(T0, "restart")
        pos.resume_after_reconciliation(T0, Dc("100000"))
        self.assertEqual(pos.state, S.OPEN_UNPROTECTED)
        self.assertIsNone(pos.broker_stop)

    def test_17_position_independence(self):
        a, b = make_position(Side.LONG), make_position(Side.SHORT, spec=JPY, price="150.000")
        b_stop = b.desired_stop
        a.request_exit(ExitReason.INITIAL_STOP, T0)
        a.on_exit_fill(fill("100000", "1.0989", qt("1.0989")))
        self.assertEqual(a.state, S.CLOSED)
        self.assertEqual(b.state, S.OPEN_PROTECTED)
        self.assertEqual(b.desired_stop, b_stop)
        self.assertNotEqual(a.id, b.id)


if __name__ == "__main__":
    unittest.main()
