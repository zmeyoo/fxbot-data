import random
import unittest
from datetime import timedelta
from decimal import Decimal as Dc

from fxbot.core.types import Side
from fxbot.risk.currency import (CurrencyLedger, ExpectedBalances, OrderClass, check_currency_exposure,
                                 check_order_funding, detect_discrepancies, net_exposure_by_ccy)
from fxbot.risk.governor import RiskGovernor
from fxbot.risk.sizing import size_position
from tests.fixtures import *


def fund(side, qty, price, ledger, g=None, closing=False, margin=Dc("10"), comm=Dc("2.2"), notional=Dc(0)):
    return check_order_funding(spec=SPEC, side=side, qty=Dc(qty), price=Dc(price), closing=closing, ledger=ledger,
                               gcfg=g or gcfg(), commission_quote=comm, rates=RATES,
                               current_short_notional_base=notional, margin_util_after_pct=margin)


class TestSizing(unittest.TestCase):
    def test_sizing_respects_budget_and_explains(self):
        r = size_position(side=Side.LONG, quote=qt("1.09990", "1.10000"), spec=SPEC, cfg=pair_cfg(max_notional_base=Dc("5000000")),
                          ctx=CTX, equity_base=Dc("100000"))
        self.assertTrue(r.approved)
        self.assertEqual(r.qty % SPEC.qty_step, 0)
        self.assertLessEqual(r.worst_case_loss_quote, r.risk_budget_quote)
        self.assertTrue(len(r.explanation) >= 4)

    def test_property_never_exceeds_risk_budget(self):
        rnd = random.Random(7)
        for _ in range(300):
            eq = Dc(rnd.randint(2000, 2000000))
            cfg = pair_cfg(risk_per_trade_pct=Dc(rnd.choice(["0.1", "0.25", "0.5", "1"])), max_notional_base=Dc("100000000"))
            side = rnd.choice(list(Side))
            r = size_position(side=side, quote=qt("1.09990", "1.10000"), spec=SPEC, cfg=cfg, ctx=CTX, equity_base=eq)
            if r.approved:
                self.assertLessEqual(r.worst_case_loss_quote, r.risk_budget_quote)
                self.assertGreaterEqual(r.qty, SPEC.min_qty)

    def test_caps_and_too_small(self):
        r = size_position(side=Side.LONG, quote=qt("1.0999", "1.1"), spec=SPEC, cfg=pair_cfg(max_notional_base=Dc("20000")),
                          ctx=CTX, equity_base=Dc("1000000"))
        self.assertLessEqual(r.qty * Dc("1.1"), Dc("20000") * Dc("1.1") + 1)
        tiny = size_position(side=Side.LONG, quote=qt("1.0999", "1.1"), spec=SPEC, cfg=pair_cfg(), ctx=CTX, equity_base=Dc("100"))
        self.assertFalse(tiny.approved)
        cash = size_position(side=Side.LONG, quote=qt("1.0999", "1.1"), spec=SPEC, cfg=pair_cfg(max_notional_base=Dc("5000000")),
                             ctx=CTX, equity_base=Dc("1000000"), long_cash_quote=Dc("50000"), cash_buffer_pct=Dc("1"))
        self.assertLessEqual(cash.qty * Dc("1.1") * Dc("1.01"), Dc("50000"))

    def test_unconfigured_risk_blocks(self):
        r = size_position(side=Side.LONG, quote=qt("1.0999", "1.1"), spec=SPEC, cfg=pair_cfg(risk_per_trade_pct=None),
                          ctx=CTX, equity_base=Dc("1000"))
        self.assertFalse(r.approved)


class TestCurrencyControls(unittest.TestCase):
    def test_funded_long_and_unfunded_long(self):
        ok = fund(Side.LONG, "100000", "1.1", CurrencyLedger({"USD": Dc("200000")}))
        self.assertEqual(ok.classification, OrderClass.FUNDED_LONG)
        bad = fund(Side.LONG, "100000", "1.1", CurrencyLedger({"USD": Dc("100000")}))
        self.assertFalse(bad.allowed)
        self.assertIn("UNINTENDED BORROWING", bad.reasons[0])
        # buffer matters: exactly notional is not enough
        edge = fund(Side.LONG, "100000", "1.1", CurrencyLedger({"USD": Dc("110000")}))
        self.assertFalse(edge.allowed)

    def test_short_proceeds_are_not_free_cash(self):
        led = CurrencyLedger({"USD": Dc("500000")}, locked_short_proceeds={"USD": Dc("450000")})
        self.assertEqual(led.available_cash("USD"), Dc("50000"))
        self.assertFalse(fund(Side.LONG, "100000", "1.1", led).allowed)

    def test_authorised_short_borrow_vs_floor(self):
        led = CurrencyLedger({"EUR": Dc("0"), "USD": Dc("0")})
        ok = fund(Side.SHORT, "100000", "1.1", led)
        self.assertEqual(ok.classification, OrderClass.AUTHORISED_SHORT_BORROW)
        self.assertTrue(any("financing" in n for n in ok.notes))
        self.assertFalse(fund(Side.SHORT, "300000", "1.1", led).allowed)                 # below EUR floor -200k
        self.assertFalse(fund(Side.SHORT, "100000", "1.1", led, g=gcfg(currency_floors={})).allowed)   # no floor => no borrowing
        self.assertFalse(fund(Side.SHORT, "100000", "1.1", led, margin=None).allowed)    # cannot verify margin
        self.assertFalse(fund(Side.SHORT, "100000", "1.1", led, margin=Dc("50")).allowed)
        self.assertFalse(fund(Side.SHORT, "100000", "1.1", led, notional=Dc("950000")).allowed)

    def test_short_from_holdings_and_closing_never_blocked(self):
        held = fund(Side.SHORT, "100000", "1.1", CurrencyLedger({"EUR": Dc("150000")}))
        self.assertEqual(held.classification, OrderClass.SHORT_FROM_HOLDINGS)
        c = fund(Side.LONG, "100000", "1.1", CurrencyLedger({}), closing=True)           # closing a LONG = SELL
        self.assertTrue(c.allowed)
        self.assertEqual(c.classification, OrderClass.CLOSING)

    def test_auto_conversion_flag_rejected_in_v1(self):
        self.assertFalse(fund(Side.LONG, "1000", "1.1", CurrencyLedger({"USD": Dc("9999999")}),
                              g=gcfg(allow_auto_conversion=True)).allowed)

    def test_per_currency_exposure_limit(self):
        cur = [(SPEC, Side.LONG, Dc("100000"), Dc("1.1"))]
        ok = check_currency_exposure(cur, (SPEC, Side.LONG, Dc("100000"), Dc("1.1")), RATES, gcfg())
        self.assertEqual(ok, [])
        bad = check_currency_exposure(cur, (SPEC, Side.LONG, Dc("250000"), Dc("1.1")), RATES, gcfg())
        self.assertTrue(any("EUR" in r for r in bad))
        offset = check_currency_exposure([(SPEC, Side.LONG, Dc("250000"), Dc("1.1"))],
                                         (SPEC, Side.SHORT, Dc("250000"), Dc("1.1")), RATES, gcfg())
        self.assertEqual(offset, [])
        missing = check_currency_exposure([], (SPEC, Side.LONG, Dc("1000"), Dc("1.1")), RATES,
                                          gcfg(max_currency_exposure_base={}))
        self.assertEqual(len(missing), 2)

    def test_balance_discrepancy_detection(self):
        eb = ExpectedBalances({"EUR": Dc("0"), "USD": Dc("200000")})
        eb.apply_fill(SPEC, "BUY", Dc("100000"), Dc("1.1"), commission=Dc("2.2"))
        exp = eb.expected()
        self.assertEqual(exp, {"EUR": Dc("100000"), "USD": Dc("200000") - Dc("110000") - Dc("2.2")})
        self.assertEqual(detect_discrepancies(exp, dict(exp), {}, Dc("0.01")), [])
        actual = dict(exp); actual["USD"] -= Dc("15")                      # unexplained charge
        actual["CHF"] = Dc("50")                                           # unexpected currency
        d = {x.ccy: x for x in detect_discrepancies(exp, actual, {}, Dc("0.01"))}
        self.assertEqual(set(d), {"USD", "CHF"})
        self.assertEqual(d["USD"].diff, Dc("-15"))


class TestGovernor(unittest.TestCase):
    def setUp(self):
        self.g = RiskGovernor(gcfg())
        self.g.start_session(Dc("100000"))
        self.cfg = pair_cfg(max_trades_session=2)

    def chk(self, pair="EURUSD", risk="500", now=T0, rev=False):
        return self.g.check_new_entry(pair, self.cfg, Dc(risk), Dc("100000"), now, rev)

    def test_23_daily_loss_lockout_is_sticky(self):
        self.assertTrue(self.chk().allowed)
        self.g.update_equity(Dc("98000"))                                  # -2.0% incl. unrealised
        r = self.chk()
        self.assertFalse(r.allowed)
        self.assertTrue(any("lockout" in x for x in r.reasons))
        self.g.update_equity(Dc("101000"))                                 # recovery does not unlock
        self.assertFalse(self.chk().allowed)

    def test_drawdown_lockout(self):
        self.g.update_equity(Dc("103000")); self.g.update_equity(Dc("97900"))
        self.assertIsNotNone(self.g.lockout_reason)

    def test_consecutive_losses_cooldown(self):
        for i in range(3):
            pid = f"L{i}"
            self.g.register_open(pid, "EURUSD", Dc("500"), False)
            t = trade(net=Dc("-5"), ts=T0); object.__setattr__(t, "position_id", pid)
            self.g.on_trade_closed(t, T0)
        r = self.chk(now=T0 + timedelta(minutes=30))
        self.assertTrue(any("cooldown" in x for x in r.reasons))
        self.assertTrue(self.chk("GBPUSD", now=T0 + timedelta(minutes=61)).allowed)   # cooldown elapsed
        self.assertFalse(self.chk("GBPUSD", now=T0 + timedelta(minutes=30)).allowed)

    def test_limits_one_per_pair_trades_reversals_total_risk_killswitch(self):
        self.g.register_open("A", "EURUSD", Dc("500"), False)
        self.assertFalse(self.chk().allowed)                               # one position per pair
        self.assertTrue(self.chk("GBPUSD").allowed)
        self.assertFalse(self.chk("GBPUSD", risk="2000").allowed)          # total open risk 2% of equity
        t = trade(); object.__setattr__(t, "position_id", "A"); object.__setattr__(t, "pair", "EURUSD")
        self.g.on_trade_closed(t, T0)
        self.g.register_open("B", "EURUSD", Dc("500"), True)
        object.__setattr__(t, "position_id", "B"); self.g.on_trade_closed(t, T0)
        self.assertFalse(self.chk().allowed)                               # 2 trades = max_trades_session
        self.assertEqual(self.g.reversals_by_pair["EURUSD"], 1)
        self.g.start_session(Dc("100000")); self.g.kill_switch = True
        self.assertTrue(any("emergency" in x for x in self.chk().reasons))

    def test_unconfigured_limits_reject(self):
        g = RiskGovernor(gcfg(max_open_positions=None)); g.start_session(Dc("1000"))
        self.assertFalse(g.check_new_entry("EURUSD", self.cfg, Dc("1"), Dc("1000"), T0, False).allowed)


if __name__ == "__main__":
    unittest.main()
