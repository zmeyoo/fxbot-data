from datetime import timedelta
from decimal import Decimal as Dc
from fxbot.core.types import Quote
from tests.signal_helpers import START, uptrend_with_pullback


def ticks_from_closes(closes, start=START, wick=0.00004, half=0.00004, pair="EURUSD"):
    """4 quotes per minute (open, high, low, close of the MID) so 1m bars resemble bars_from_closes."""
    out, prev = [], closes[0]
    for i, c in enumerate(closes):
        t0 = start + timedelta(minutes=i)
        for sec, mid in ((0, prev), (15, max(prev, c) + wick), (30, min(prev, c) - wick), (50, c)):
            m = Dc(f"{mid:.5f}")
            t = t0 + timedelta(seconds=sec)
            out.append(Quote(pair, m - Dc(f"{half:.5f}"), m + Dc(f"{half:.5f}"), t, t))
        prev = c
    return out


def long_scenario(tail="run_then_reverse", flat_minutes=0):
    cl = uptrend_with_pullback(dip=5, rebound=3)
    px = cl[-1]
    if tail == "run_then_reverse":
        for i in range(70):
            px += 0.00004; cl.append(px)           # +0.25% run: trailing engages
        for i in range(40):
            px -= 0.00012; cl.append(px)           # sharp reversal
    elif tail == "flat":
        cl += [px] * flat_minutes
    return cl


def crash_scenario():
    cl = uptrend_with_pullback(dip=5, rebound=3)
    px = cl[-1]
    cl += [px] * 3
    cl += [px - 0.0045]                        # -0.4% in one minute: gaps through the 0.10% stop
    cl += [px - 0.0045] * 5
    return cl


def densify(quotes, start, end, step_s=0.5):
    """Insert linearly interpolated quotes every `step_s` seconds between consecutive quotes inside [start, end)."""
    from datetime import timedelta
    out = []
    for a, b in zip(quotes, quotes[1:]):
        out.append(a)
        if start <= a.market_ts < end:
            n = int((b.market_ts - a.market_ts).total_seconds() / step_s)
            for i in range(1, n):
                f = Dc(i) / Dc(n)
                t = a.market_ts + (b.market_ts - a.market_ts) * i / n
                bid = (a.bid + (b.bid - a.bid) * f).quantize(Dc("0.00001")); ask = (a.ask + (b.ask - a.ask) * f).quantize(Dc("0.00001"))
                if bid < ask:
                    out.append(Quote(a.pair, bid, ask, t, t))
    out.append(quotes[-1])
    return out
