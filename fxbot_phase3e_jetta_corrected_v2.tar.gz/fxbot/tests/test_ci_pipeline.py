import json
import os
import re
import stat
import subprocess
import sys
import tempfile
import unittest
from datetime import datetime, timezone

from fxbot.data_sources.dataset import finalize_dataset
from fxbot.data_sources.dukascopy import DownloadManager, RawStore
from tests.dukas_fixtures import FakeServer, week_files

try:
    import yaml
except Exception:
    yaml = None

ROOT = os.path.join(os.path.dirname(__file__), "..")
WORKFLOW = os.path.join(ROOT, ".github", "workflows", "dukascopy_dataset.yml")
U = timezone.utc
START, END = datetime(2024, 3, 8, tzinfo=U), datetime(2024, 3, 12, tzinfo=U)
NOW = datetime(2026, 11, 9, tzinfo=U)


def run_verdict(out, summary=None, gh_out=None):
    args = [sys.executable, os.path.join(ROOT, "tools", "ci_verdict.py"), "--out", out]
    if summary: args += ["--summary", summary]
    if gh_out: args += ["--github-output", gh_out]
    return subprocess.run(args, capture_output=True, text=True, env={**os.environ, "PYTHONPATH": ROOT})


class Tmp(unittest.TestCase):
    def setUp(self):
        self._d = tempfile.TemporaryDirectory(); self.out = os.path.join(self._d.name, "out")
        os.makedirs(os.path.join(self.out, "review")); os.makedirs(os.path.join(self.out, "dataset"))

    def tearDown(self):
        self._d.cleanup()

    def stages(self, **kw):
        with open(os.path.join(self.out, "review", "stages.txt"), "w") as f:
            for k in ("tests", "env", "decoder", "run"):
                f.write(f"{k}={kw.get(k, 'skipped')}\n")

    def build_dataset(self, decoder_passed=True, files=None):
        ds = os.path.join(self.out, "dataset")
        m = DownloadManager(FakeServer(files if files is not None else week_files(START, END)), RawStore(os.path.join(ds, "raw")), "EURUSD",
                            retries=0, delay_s=0, sleep=lambda s: None, now=lambda: NOW, log=lambda s: None)
        m.run(START, END)
        man = finalize_dataset(ds, "EURUSD", START, END, "python tools/dukascopy.py run ...", now=NOW)
        with open(os.path.join(ds, "decoder_verification.json"), "w") as f:
            json.dump({"passed": decoder_passed, "findings": [], "hours": []}, f)
        with open(os.path.join(ds, "DECODER_VERIFICATION.md"), "w") as f:
            f.write("# Decoder verification\nVERDICT: PASSED\n")
        return man

    def verdict(self):
        gh, sm = os.path.join(self.out, "gh_output.txt"), os.path.join(self.out, "summary.md")
        r = run_verdict(self.out, sm, gh)
        with open(gh) as f:
            outs = dict(l.strip().split("=", 1) for l in f if "=" in l)
        with open(os.path.join(self.out, "review", "VERDICT.json")) as f:
            v = json.load(f)
        with open(os.path.join(self.out, "review", "VERDICT.txt")) as f:
            txt = f.read()
        with open(sm) as f:
            summ = f.read()
        return r, outs, v, txt, summ


class TestVerdict(Tmp):
    def test_all_stages_ok_and_validated_dataset_is_the_only_pass(self):
        man = self.build_dataset()
        self.stages(tests=0, env=0, decoder=0, run=0)
        r, outs, v, txt, summ = self.verdict()
        self.assertEqual(r.returncode, 0, r.stderr)
        self.assertEqual((outs["status"], outs["validated"]), ("PASSED", "true"))
        self.assertTrue(txt.startswith("STATUS: PASSED")); self.assertIn(man["normalised"]["sha256"], txt)
        self.assertEqual(v["csv_sha256"], man["normalised"]["sha256"])
        rev = os.path.join(self.out, "review")
        for name in ("dataset.json", "DATA_QUALITY_REPORT.md", "DECODER_VERIFICATION.md", "decoder_verification.json", "SHA256SUMS.txt", "VERDICT.txt", "VERDICT.json"):
            self.assertTrue(os.path.exists(os.path.join(rev, name)), name)
        metas = [f for _, _, fs in os.walk(os.path.join(rev, "raw_meta")) for f in fs]
        self.assertGreater(len(metas), 50)                                          # per-hour provenance travels with the small pack
        with open(os.path.join(rev, "SHA256SUMS.txt")) as f:
            self.assertIn(man["normalised"]["sha256"], f.read())
        self.assertIn("PASSED", summ); self.assertIn("Data quality report", summ); self.assertIn("Decoder verification", summ)
        self.assertLess(sum(os.path.getsize(os.path.join(dp, f)) for dp, _, fs in os.walk(rev) for f in fs), 5_000_000)   # review pack stays small

    def expect(self, status, **stages):
        self.stages(**stages)
        r, outs, v, txt, summ = self.verdict()
        self.assertEqual(r.returncode, 1)
        self.assertEqual((outs["status"], outs["validated"]), (status, "false"), v["reason"])
        self.assertIn("NOT VALIDATED. DO NOT USE", txt); self.assertIn("No dataset artifact is published", summ)
        return v

    def test_every_non_pass_is_labelled_not_validated(self):
        self.expect("TESTS_FAILED", tests=1)
        self.expect("NETWORK_UNAVAILABLE", tests=0, env=2)
        self.expect("DECODER_ASSUMPTION_FAILED", tests=0, env=0, decoder=5)
        self.expect("DECODER_NOT_VERIFIED", tests=0, env=0, decoder=3)
        self.expect("DECODER_NOT_VERIFIED", tests=0, env=0, decoder=0, run=0)                  # decoder stage "ok" but no passing json: refused
        with open(os.path.join(self.out, "dataset", "decoder_verification.json"), "w") as f:
            json.dump({"passed": True}, f)
        self.expect("DOWNLOAD_INCOMPLETE", tests=0, env=0, decoder=0, run=3)

    def test_incomplete_download_failed_validation_and_tampering_cannot_pass(self):
        self.build_dataset()
        v = self.expect("DOWNLOAD_INCOMPLETE", tests=0, env=0, decoder=0, run=3)
        self.assertIn("some hours could not be downloaded", v["reason"])
        # a dataset whose validation FAILED (a missing open-market hour beyond the threshold) must not pass even though every stage exited 0
        self.tearDown(); self.setUp()
        missing = {datetime(2024, 3, 11, h, tzinfo=U) for h in range(0, 8)}
        man = self.build_dataset(files=week_files(START, END, skip=missing))
        self.assertEqual(man["validation"]["status"], "FAILED")
        v = self.expect("VALIDATION_FAILED", tests=0, env=0, decoder=0, run=1 - 1)
        self.assertIn("Missing hours", v["reason"])
        # tampering after validation
        self.tearDown(); self.setUp()
        man = self.build_dataset()
        with open(os.path.join(self.out, "dataset", man["normalised"]["path"]), "a") as f:
            f.write("1710000000000,1.10001,1.10000,1.0,1.0\n")
        v = self.expect("INTEGRITY_FAILED", tests=0, env=0, decoder=0, run=0)
        # decoder verification failed although the rest looks fine
        self.tearDown(); self.setUp()
        self.build_dataset(decoder_passed=False)
        self.expect("DECODER_NOT_VERIFIED", tests=0, env=0, decoder=0, run=0)

    def test_no_stage_file_means_pipeline_crashed(self):
        r = run_verdict(self.out)
        self.assertEqual(r.returncode, 1)
        with open(os.path.join(self.out, "review", "VERDICT.json")) as f:
            self.assertEqual(json.load(f)["status"], "PIPELINE_CRASHED")


class TestPipelineScript(unittest.TestCase):
    """Runs tools/ci_run.sh with a stub `python` on PATH to test the stage control flow without network or the slow tests."""
    def run_script(self, rc_tests=0, rc_env=0, rc_dec=0, rc_run=0):
        with tempfile.TemporaryDirectory() as d:
            bin_ = os.path.join(d, "bin"); os.makedirs(bin_)
            log = os.path.join(d, "calls.log")
            shim = os.path.join(bin_, "python")
            with open(shim, "w") as f:
                f.write(f'#!/usr/bin/env bash\necho "$@" >> "{log}"\n'
                        'case "$*" in *unittest*) exit $RC_TESTS;; *env-check*) exit $RC_ENV;; *verify-jetta*) exit $RC_DEC;; *" run "*) exit $RC_RUN;; esac\nexit 0\n')
            os.chmod(shim, os.stat(shim).st_mode | stat.S_IEXEC)
            out = os.path.join(d, "out")
            env = {**os.environ, "PATH": bin_ + os.pathsep + os.environ["PATH"], "RC_TESTS": str(rc_tests), "RC_ENV": str(rc_env), "RC_DEC": str(rc_dec), "RC_RUN": str(rc_run)}
            r = subprocess.run(["bash", os.path.join(ROOT, "tools", "ci_run.sh"), out, "EURUSD", "2024-03-04", "2024-03-18", "0.3", "1.05:1.12"],
                               capture_output=True, text=True, env=env)
            with open(os.path.join(out, "review", "stages.txt")) as f:
                stages = dict(l.strip().split("=") for l in f)
            calls = open(log).read().splitlines() if os.path.exists(log) else []
            return r.returncode, stages, calls

    def test_stages_stop_at_the_first_problem_and_pass_exact_arguments(self):
        rc, st, calls = self.run_script()
        self.assertEqual((rc, st), (0, {"tests": "0", "env": "0", "decoder": "0", "run": "0"}))
        self.assertEqual(len(calls), 4)
        self.assertIn("verify-jetta --instrument EURUSD --start 2024-03-04 --end 2024-03-18", calls[2]); self.assertIn("env-check --source jetta", calls[1]); self.assertIn("run --instrument EURUSD --source jetta", calls[3])
        self.assertIn("run --instrument EURUSD --source jetta --start 2024-03-04 --end 2024-03-18", calls[3]); self.assertIn("--sleep 0.3", calls[3])
        for c in calls[2:]:
            self.assertIn("/dataset", c)
        rc, st, calls = self.run_script(rc_tests=1)
        self.assertEqual((rc, st), (1, {"tests": "1", "env": "skipped", "decoder": "skipped", "run": "skipped"})); self.assertEqual(len(calls), 1)
        rc, st, calls = self.run_script(rc_env=2)
        self.assertEqual((rc, st["env"], st["decoder"], st["run"]), (1, "2", "skipped", "skipped"))
        rc, st, calls = self.run_script(rc_dec=5)
        self.assertEqual((rc, st["decoder"], st["run"]), (1, "5", "skipped")); self.assertFalse(any(" run " in c for c in calls))   # NO bulk download after a failed assumption
        rc, st, calls = self.run_script(rc_run=3)
        self.assertEqual((rc, st["run"]), (3, "3"))


@unittest.skipIf(yaml is None, "PyYAML not installed")
class TestWorkflowFile(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        with open(WORKFLOW) as f:
            cls.text = f.read()
        cls.wf = yaml.safe_load(cls.text)
        cls.steps = cls.wf["jobs"]["dataset"]["steps"]

    def step(self, name_part):
        return next(s for s in self.steps if name_part in s.get("name", ""))

    def test_trigger_inputs_and_defaults_are_the_approved_pilot(self):
        on = self.wf.get("on", self.wf.get(True))
        ins = on["workflow_dispatch"]["inputs"]
        self.assertEqual((ins["instrument"]["default"], ins["start"]["default"], ins["end"]["default"]), ("EURUSD", "2024-03-04", "2024-03-18"))
        self.assertTrue(all(v["type"] == "string" and v["required"] for v in ins.values()))
        self.assertEqual(self.wf["permissions"], {"contents": "read"})

    def test_inputs_are_never_interpolated_into_shell_code(self):
        for s in self.steps:
            if "run" in s:
                self.assertNotIn("${{", s["run"], s.get("name"))                               # only env vars inside scripts
        env = self.wf["jobs"]["dataset"]["env"]
        self.assertEqual(env["PYTHONPATH"], "."); self.assertTrue(env["OUT"].endswith("/out"))

    def test_structure_import_paths_and_order(self):
        names = [s.get("name", s.get("uses")) for s in self.steps]
        i = lambda part: next(k for k, n in enumerate(names) if part in n)
        self.assertLess(i("Check out"), i("Unpack")); self.assertLess(i("Unpack"), i("Run the pipeline")); self.assertLess(i("Run the pipeline"), i("Verdict"))
        self.assertLess(i("Verdict"), i("Upload the review pack")); self.assertLess(i("Upload the review pack"), i("Upload the normalised CSV"))
        self.assertLess(i("Upload the normalised CSV"), i("Upload the original raw")); self.assertLess(i("Upload the original raw"), i("Fail the run"))
        pipe = self.step("Run the pipeline")
        self.assertEqual(pipe["working-directory"], "work/fxbot")                               # archive unpacks to work/fxbot (tar of fxbot/)
        self.assertTrue(pipe["continue-on-error"]); self.assertIn("tools/ci_run.sh", pipe["run"])
        self.assertIn("work/fxbot/tools/ci_run.sh", self.step("Unpack")["run"])
        self.assertEqual(self.step("Verdict")["working-directory"], "work/fxbot")

    def test_reports_upload_even_when_validation_fails_but_dataset_only_when_validated(self):
        self.assertEqual(self.step("Verdict")["if"], "always()")
        rp = self.step("Upload the review pack")
        self.assertEqual(rp["if"], "always()"); self.assertEqual(rp["with"]["path"], "out/review")
        self.assertIn("steps.verdict.outputs.status", rp["with"]["name"])                       # artifact name carries the verdict
        for part in ("Upload the normalised CSV", "Upload the original raw"):
            ds = self.step(part)
            self.assertIn("validated == 'true'", ds["if"]); self.assertTrue(ds["with"]["name"].endswith("-VALIDATED"), part)
            self.assertEqual(ds["with"]["if-no-files-found"], "error"); self.assertEqual(ds["with"]["retention-days"], 14)
        self.assertIn("out/dataset/raw", self.step("Upload the original raw")["with"]["path"])
        self.assertIn("out/dataset/normalised", self.step("Upload the normalised CSV")["with"]["path"])
        self.assertNotIn("raw", self.step("Upload the normalised CSV")["with"]["path"].replace("out/dataset/raw", ""))   # raw and normalised stay separate artifacts
        last = self.steps[-1]
        self.assertEqual(last["if"], "always()"); self.assertIn("exit 1", last["run"])          # a non-validated run is a RED run

    def test_every_step_name_is_quoted_so_the_yaml_stays_valid(self):
        for ln in self.text.splitlines():
            m = re.match(r"\s+- name: (.*)$", ln)
            if m:
                self.assertTrue(m.group(1).startswith('"') and m.group(1).endswith('"'), ln)

    def test_actions_are_pinned_to_major_versions_and_python_is_3_12(self):
        uses = [s["uses"] for s in self.steps if "uses" in s]
        self.assertEqual(sorted(uses), sorted(["actions/checkout@v4", "actions/setup-python@v5"] + ["actions/upload-artifact@v4"] * 3))
        self.assertEqual(self.step("Set up Python")["with"]["python-version"], "3.12")
        self.assertLessEqual(self.wf["jobs"]["dataset"]["timeout-minutes"], 360)

    def test_archive_detection_requires_exactly_one_archive(self):
        run = self.step("Unpack")["run"]
        self.assertIn("-ne 1", run); self.assertIn("*.tar.gz", run); self.assertIn("tar xf", run)


if __name__ == "__main__":
    unittest.main()
