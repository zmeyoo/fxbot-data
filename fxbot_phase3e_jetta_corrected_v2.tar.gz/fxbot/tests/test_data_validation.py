import csv
import os
import random
import tempfile
import unittest
from datetime import datetime, timedelta, timezone
from decimal import Decimal as Dc

from fxbot.backtesting.data import (CANONICAL, DUKASCOPY, FORMATS, IBKR_PROVISIONAL, DataError, TickFormat, classify_gap,
                                    detect_format, infer_epoch_unit, load_ticks_csv, parse_epoch, parse_ts, quote_report)
from fxbot.backtesting.validate import main as validate_main, render_markdown, validate_tick_file
from fxbot.core.sessions import SessionCalendar
from fxbot.core.types import Quote, Side

SAMPLE = os.path.join(os.path.dirname(__file__), "data", "eurusd_dukascopy_published_sample_ticks.csv")
CAL = SessionCalendar()
U = timezone.utc


def z(*a):
    return datetime(*a, tzinfo=U)


class Tmp(unittest.TestCase):
    def setUp(self):
        self._d = tempfile.TemporaryDirectory(); self.d = self._d.name

    def tearDown(self):
        self._d.cleanup()

    def write(self, name, header, rows):
        p = os.path.join(self.d, name)
        with open(p, "w", newline="") as f:
            w = csv.writer(f); w.writerow(header); w.writerows(rows)
        return p


class TestRealSample(unittest.TestCase):
    def test_exact_values_of_the_published_sample(self):
        q, r = load_ticks_csv(SAMPLE, "EURUSD")
        self.assertEqual(r.format_name, "dukascopy_csv"); self.assertEqual(r.ts_unit, "ms")
        self.assertEqual([x.market_ts for x in q], [datetime(2020, 3, 30, 0, 0, 0, 104000, tzinfo=U), datetime(2020, 3, 30, 0, 0, 0, 256000, tzinfo=U)])
        self.assertEqual([(x.bid, x.ask) for x in q], [(Dc("1.11361"), Dc("1.11369")), (Dc("1.11361"), Dc("1.11371"))])   # ask column was FIRST in the file
        self.assertEqual([x.spread for x in q], [Dc("0.00008"), Dc("0.00010")])
        self.assertEqual([x.mid for x in q], [Dc("1.11365"), Dc("1.11366")])
        self.assertEqual([round(float(x.spread / x.mid * 100), 5) for x in q], [0.00718, 0.00898])
        self.assertEqual((q[0].entry_price(Side.LONG), q[0].exit_price(Side.LONG)), (Dc("1.11369"), Dc("1.11361")))
        self.assertEqual((q[0].entry_price(Side.SHORT), q[0].exit_price(Side.SHORT)), (Dc("1.11361"), Dc("1.11369")))
        self.assertEqual((r.dropped_crossed_or_invalid, r.dropped_duplicate, r.dropped_out_of_order), (0, 0, 0))
        self.assertEqual(r.price_decimals, (5,)); self.assertEqual(r.ts_resolution, "sub-second")

    def test_timezone_and_session_of_the_sample_are_dst_correct(self):
        q, _ = load_ticks_csv(SAMPLE, "EURUSD")
        ny = q[0].market_ts.astimezone(CAL._tz())
        self.assertEqual((ny.hour, ny.utcoffset()), (20, timedelta(hours=-4)))               # 30 Mar 2020 is EDT (DST began 8 Mar)
        s = CAL.session_of(q[0].market_ts)
        self.assertEqual((s.label.isoformat(), s.start_utc, s.end_utc), ("2020-03-30", z(2020, 3, 29, 21), z(2020, 3, 30, 21)))
        self.assertTrue(s.is_trading_day); self.assertFalse(CAL.closure_contains(q[0].market_ts))

    def test_validation_report_statuses_are_honest_for_two_rows(self):
        res = validate_tick_file(SAMPLE)
        st = {c.name: c.status for c in res.checks}
        self.assertTrue(res.ok)
        for n in ("Timestamp parsing / timezone", "BID/ASK field mapping + executable side", "Bid/ask spread calculation", "Original quote precision preserved"):
            self.assertEqual(st[n], "PASS", n)
        self.assertEqual(st["Duplicate / out-of-order / stale quotes"], "NOT TESTABLE")      # n=2 cannot support these
        self.assertEqual(st["Data gaps and session boundaries"], "NOT TESTABLE")
        md = render_markdown(res)
        for needle in ("1585526400104", "2020-03-29T20:00:00.104000-04:00", "0.8 pips", "1.0 pips", "NOT TESTABLE", "sha256"):
            self.assertIn(needle, md)
        with tempfile.TemporaryDirectory() as d:
            out = os.path.join(d, "r.md")
            import contextlib, io
            with contextlib.redirect_stdout(io.StringIO()):
                self.assertEqual(validate_main([SAMPLE, "--out", out]), 0)
            self.assertTrue(os.path.exists(out))


class TestTimestamps(unittest.TestCase):
    def test_epoch_units_are_exact_not_float(self):
        for raw, unit in (("1585526400104", "ms"), ("1585526400.104", "s"), ("1585526400104000", "us"), ("1585526400104000000", "ns")):
            d, u = parse_epoch(raw, unit)
            self.assertEqual((d, u), (datetime(2020, 3, 30, 0, 0, 0, 104000, tzinfo=U), unit))
            self.assertEqual(parse_epoch(raw, "auto")[1], unit)
        self.assertEqual(parse_epoch("1585526400", "auto")[0], z(2020, 3, 30))
        # a value that is not representable in binary floating point stays exact
        self.assertEqual(parse_epoch("1585526400123", "ms")[0].microsecond, 123000)
        self.assertEqual(parse_epoch("1585526400.999999", "s")[0].microsecond, 999999)

    def test_wrong_unit_is_refused_not_guessed(self):
        with self.assertRaises(DataError): parse_epoch("1585526400104", "s")          # would be year ~52000
        with self.assertRaises(DataError): parse_epoch("1585526400", "ms")            # would be 1970
        with self.assertRaises(DataError): parse_epoch("abc", "auto")
        with self.assertRaises(DataError): parse_epoch("1", "furlongs")
        self.assertEqual(infer_epoch_unit(Dc("1.7e9")), "s"); self.assertEqual(infer_epoch_unit(Dc("1.7e12")), "ms")

    def test_iso_timestamps_need_an_explicit_timezone_and_convert_to_utc(self):
        self.assertEqual(parse_ts("2026-07-07T17:00:00-04:00"), z(2026, 7, 7, 21))
        self.assertEqual(parse_ts("2026-07-07T21:00:00Z"), z(2026, 7, 7, 21))
        with self.assertRaises(DataError): parse_ts("2026-07-07T21:00:00")
        self.assertEqual(parse_ts("1585526400104"), datetime(2020, 3, 30, 0, 0, 0, 104000, tzinfo=U))   # old seconds-only bug fixed


class TestMappingAndFormats(Tmp):
    def test_mapping_is_by_name_not_position(self):
        a = self.write("a.csv", ["ts", "bid", "ask"], [["2026-01-05T10:00:00Z", "1.1000", "1.1001"]])
        b = self.write("b.csv", ["ask", "ts", "bid"], [["1.1001", "2026-01-05T10:00:00Z", "1.1000"]])
        qa, ra = load_ticks_csv(a, "EURUSD"); qb, rb = load_ticks_csv(b, "EURUSD")
        self.assertEqual([(x.bid, x.ask, x.market_ts) for x in qa], [(x.bid, x.ask, x.market_ts) for x in qb])
        self.assertEqual(ra.sha256, rb.sha256)

    def test_swapped_mapping_is_detected_instead_of_silently_dropping_everything(self):
        wrong = TickFormat("wrong", "timestamp", "askPrice", "bidPrice", "ms")      # deliberately wrong way round
        with self.assertRaises(DataError) as cm: load_ticks_csv(SAMPLE, "EURUSD", fmt=wrong)
        self.assertIn("wrong way round", str(cm.exception))
        self.assertIs(detect_format(["timestamp", "askPrice", "bidPrice", "askVolume", "bidVolume"]), DUKASCOPY)
        self.assertIs(detect_format(["ts", "bid", "ask"]), CANONICAL)
        with self.assertRaises(DataError): detect_format(["time", "mid"])
        self.assertIn("ibkr_ticks_provisional", FORMATS)

    def test_missing_columns_and_mid_only_rejected(self):
        p = self.write("m.csv", ["ts", "bid"], [["2026-01-05T10:00:00Z", "1.1"]])
        with self.assertRaises(DataError): load_ticks_csv(p, "EURUSD")


class TestIbkrStyleSecondsData(Tmp):
    """IBKR historical ticks are (as I understand it, to be CONFIRMED on a real sample) stamped at 1-second resolution, so several
    quotes can share a second. They must be kept in file order, not treated as duplicates or out-of-order."""
    def test_multiple_quotes_per_second_kept_in_order_with_resolution_reported(self):
        t = 1767607200                                       # 2026-01-05 10:00:00 UTC
        rows = [[t, "1.10000", "1.10010"], [t, "1.10001", "1.10011"], [t, "1.10002", "1.10012"], [t + 1, "1.10002", "1.10012"],
                [t + 1, "1.10002", "1.10012"], [t + 2, "1.10003", "1.10013"], [t - 5, "1.1", "1.1001"], [t + 3, "1.10010", "1.10009"]]
        p = self.write("i.csv", ["ts", "bid", "ask", "bid_size", "ask_size"], [r + [1, 1] for r in rows])
        q, r = load_ticks_csv(p, "EURUSD", fmt=IBKR_PROVISIONAL)
        self.assertEqual([x.bid for x in q], [Dc("1.10000"), Dc("1.10001"), Dc("1.10002"), Dc("1.10002"), Dc("1.10003")])
        self.assertEqual(r.ts_resolution, "1 second"); self.assertEqual(r.max_ticks_per_timestamp, 3)
        self.assertEqual((r.dropped_duplicate, r.dropped_out_of_order, r.dropped_crossed_or_invalid), (1, 1, 1))
        self.assertEqual(r.unchanged_quotes, 1)                  # t+1 repeats t's prices with a newer stamp: kept and counted


class TestQualityStatistics(Tmp):
    def mk(self, times, pair="EURUSD"):
        return [Quote(pair, Dc("1.1000") + Dc(i) * Dc("0.00001"), Dc("1.1001") + Dc(i) * Dc("0.00001"), t, t) for i, t in enumerate(times)]

    def test_duplicates_unchanged_quotes_and_staleness_metrics(self):
        base = z(2026, 1, 6, 10)
        qs = [Quote("EURUSD", Dc("1.1000"), Dc("1.1001"), base + timedelta(seconds=s), base + timedelta(seconds=s)) for s in (0, 1, 2, 40, 41)]
        r = quote_report(qs, "EURUSD")
        self.assertEqual(r.unchanged_quotes, 4)                  # same price re-stamped: kept, counted, not "duplicates"
        self.assertEqual(r.interarrival_s, (1.0, 38.0, 38.0, 38.0)); self.assertEqual(r.n_gaps_over, ((10, 1), (30, 1), (60, 0)))

    def test_gap_classification_around_weekend_rollover_and_dst(self):
        # winter: Friday 21:59:59Z (16:59:59 EST) -> Sunday 22:00:01Z (17:00:01 EST)
        self.assertEqual(classify_gap(z(2026, 1, 2, 21, 59, 59), z(2026, 1, 4, 22, 0, 1), CAL), "weekend_closure")
        # summer: Friday 20:59:59Z (16:59:59 EDT) -> Sunday 21:00:01Z
        self.assertEqual(classify_gap(z(2026, 7, 3, 20, 59, 59), z(2026, 7, 5, 21, 0, 1), CAL), "weekend_closure")
        # a vendor that stops 3h early and resumes 1h late is still the weekly closure
        self.assertEqual(classify_gap(z(2026, 1, 2, 19, 0), z(2026, 1, 4, 23, 0), CAL), "weekend_closure")
        self.assertEqual(classify_gap(z(2026, 1, 6, 10, 0), z(2026, 1, 6, 10, 5), CAL), "intra_session_gap")
        self.assertEqual(classify_gap(z(2026, 1, 6, 21, 58), z(2026, 1, 6, 22, 3), CAL), "rollover_gap")          # spans 17:00 EST
        self.assertEqual(classify_gap(z(2026, 1, 6, 8, 0), z(2026, 1, 7, 12, 0), CAL), "rollover_gap")           # 28 h mid-week outage is NOT a closure

    def test_report_separates_closures_from_unexpected_gaps_and_flags_closure_quotes(self):
        times = [z(2026, 1, 2, 21, 58, 0), z(2026, 1, 2, 21, 59, 0), z(2026, 1, 4, 22, 0, 5), z(2026, 1, 4, 22, 0, 6),
                 z(2026, 1, 5, 9, 0, 0), z(2026, 1, 5, 9, 0, 1)]
        r = quote_report(self.mk(times), "EURUSD")
        self.assertEqual(len(r.closures), 1); self.assertEqual(len(r.gaps), 1)             # the 9h gap on Monday is unexpected
        self.assertEqual(r.quotes_in_closure, 0)
        r2 = quote_report(self.mk([z(2026, 1, 3, 12, 0, 0), z(2026, 1, 3, 12, 0, 1)]), "EURUSD")
        self.assertEqual(r2.quotes_in_closure, 2)                                           # quotes on a Saturday are flagged
        self.assertEqual(r.sessions[0][0].isoformat(), "2026-01-02")
        self.assertEqual([s[0].isoformat() for s in r.sessions], ["2026-01-02", "2026-01-05"])

    def test_validation_runs_on_a_large_synthetic_file_and_marks_stats_testable(self):
        rnd = random.Random(3)
        t = z(2026, 1, 5, 12)
        rows, px = [], Dc("1.10000")
        for i in range(400):
            t += timedelta(milliseconds=rnd.randint(50, 1500)); px += Dc(rnd.randint(-3, 3)) * Dc("0.00001")
            rows.append([int(t.timestamp() * 1000), str(px + Dc("0.00008")), str(px)])
        rows.insert(100, rows[99])                                  # a duplicate row
        p = self.write("big.csv", ["timestamp", "askPrice", "bidPrice"], rows)
        res = validate_tick_file(p, fmt=TickFormat("d", "timestamp", "bidPrice", "askPrice", "ms"))
        st = {c.name: c.status for c in res.checks}
        self.assertTrue(res.ok)
        self.assertEqual(st["Duplicate / out-of-order / stale quotes"], "PASS"); self.assertEqual(res.report.dropped_duplicate, 1)
        self.assertEqual(st["Data gaps and session boundaries"], "PASS")


class TestPrecision(Tmp):
    def test_property_price_text_round_trips_exactly(self):
        rnd = random.Random(7)
        rows = []
        for i in range(300):
            dec = rnd.choice([4, 5, 6])
            bid = Dc(rnd.randint(10 ** (dec), 2 * 10 ** dec)).scaleb(-dec)            # e.g. 1.23456, 1.2000 (trailing zeros)
            ask = bid + Dc(rnd.randint(1, 30)).scaleb(-dec)
            rows.append([1767607200000 + i * 137, f"{ask:.{dec}f}", f"{bid:.{dec}f}"])
        p = self.write("p.csv", ["timestamp", "askPrice", "bidPrice"], rows)
        q, r = load_ticks_csv(p, "EURUSD", fmt=TickFormat("d", "timestamp", "bidPrice", "askPrice", "ms"))
        self.assertEqual(len(q), 300)
        for row, x in zip(rows, q):
            self.assertEqual((str(x.ask), str(x.bid)), (row[1], row[2]))                # incl. trailing zeros such as 1.2000
            self.assertIsInstance(x.bid, Dc)
            self.assertEqual(int((x.market_ts - datetime(1970, 1, 1, tzinfo=U)) // timedelta(milliseconds=1)), row[0])
        self.assertTrue(set(r.price_decimals) <= {4, 5, 6})


if __name__ == "__main__":
    unittest.main()
