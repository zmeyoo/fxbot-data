from decimal import Decimal as Dc
from fxbot.backtesting.engine import BacktestSettings
from fxbot.signals.ema_trend import EmaTrendParams
from tests.fixtures import CTX, SPEC, gcfg, pair_cfg


def settings(engine=None, cfg=None, g=None, balances=None, max_age=30, **kw):
    cfg = cfg or pair_cfg(cooldown_minutes=10, max_trades_session=20)
    g = g or gcfg(market_data_max_age_seconds=max_age, max_open_positions=1,
                  max_currency_exposure_base={"EUR": Dc("5000000"), "USD": Dc("5000000")},
                  currency_floors={"EUR": Dc("-300000")})
    return BacktestSettings(spec=SPEC, cfg=cfg, gcfg=g, ctx=CTX, engine_params=engine or EmaTrendParams(),
                            initial_balances=balances or {"USD": Dc("110000"), "EUR": Dc("0")},
                            fx_margin_rate_pct=Dc("5"), **kw)
