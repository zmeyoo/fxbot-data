import random
import unittest
from datetime import timedelta
from decimal import Decimal as Dc

from fxbot.core.types import Quote
from fxbot.indicators.core import (activity_ratio, adx, atr, ema, macd, rsi, sma, stochastic, true_range)
from fxbot.market_data.bars import Bar, BarBuilder, aggregate, bucket_start
from tests.fixtures import T0, qt
from tests.signal_helpers import START, bars_from_closes

try:
    import pandas as pd
except Exception:                                  # pragma: no cover
    pd = None


def walk(n, seed, step=0.0003, base=1.1):
    rnd, px, c, h, l = random.Random(seed), base, [], [], []
    for _ in range(n):
        o = px
        px += rnd.uniform(-step, step)
        c.append(px); h.append(max(o, px) + rnd.uniform(0, step / 2)); l.append(min(o, px) - rnd.uniform(0, step / 2))
    return h, l, c


class TestIndicators(unittest.TestCase):
    def test_sma_and_ema_hand_calculated(self):
        self.assertEqual(sma([1, 2, 3, 4], 2), [None, 1.5, 2.5, 3.5])
        self.assertEqual(ema([1, 2, 3, 4, 5], 3), [None, None, 2.0, 3.0, 4.0])     # seed SMA(1,2,3)=2, alpha=.5
        self.assertEqual(ema([5.0] * 30, 20)[-1], 5.0)

    @unittest.skipIf(pd is None, "pandas not installed")
    def test_ema_matches_pandas_after_warmup(self):
        _, _, c = walk(600, 1)
        ref = pd.Series(c).ewm(span=20, adjust=False).mean().tolist()
        mine = ema(c, 20)
        self.assertLess(abs(mine[-1] - ref[-1]), 1e-9)                 # seeds differ; difference decays away

    def test_rsi_extremes_and_independent_wilder_recomputation(self):
        self.assertEqual(rsi([float(i) for i in range(40)], 14)[-1], 100.0)
        self.assertEqual(rsi([float(-i) for i in range(40)], 14)[-1], 0.0)
        self.assertEqual(rsi([1.0] * 40, 14)[-1], 50.0)
        _, _, c = walk(120, 2)
        n, out = 14, rsi(c, 14)
        self.assertTrue(all(v is None for v in out[:n]) and out[n] is not None)
        ch = [c[i] - c[i - 1] for i in range(1, len(c))]                   # independent re-derivation
        ag = sum(x for x in ch[:n] if x > 0) / n
        al = sum(-x for x in ch[:n] if x < 0) / n
        for i in range(n, len(c)):
            if i > n:
                ag = (ag * (n - 1) + max(ch[i - 1], 0)) / n
                al = (al * (n - 1) + max(-ch[i - 1], 0)) / n
            self.assertAlmostEqual(out[i], 100 - 100 / (1 + ag / al), places=9)

    def test_macd_identities(self):
        _, _, c = walk(200, 3)
        line, sig, hist = macd(c, 12, 26, 9)
        ef, es = ema(c, 12), ema(c, 26)
        self.assertAlmostEqual(line[100], ef[100] - es[100], places=12)
        self.assertAlmostEqual(hist[100], line[100] - sig[100], places=12)
        self.assertIsNone(line[24]); self.assertIsNotNone(line[25])        # first at slow-1
        self.assertIsNone(sig[32]); self.assertIsNotNone(sig[33])          # first at slow+signal-2
        with self.assertRaises(ValueError): macd(c, 26, 12)

    def test_atr_hand_calculated(self):
        h, l, c = [10, 11, 12, 13], [9, 9.5, 10, 11], [9.5, 10.5, 11, 12]
        self.assertEqual(true_range(h, l, c), [1, 1.5, 2, 2])
        a = atr(h, l, c, 3)
        self.assertEqual(a[:2], [None, None]); self.assertAlmostEqual(a[2], 1.5); self.assertAlmostEqual(a[3], 5 / 3)

    def test_adx_trend_vs_range_and_warmup(self):
        up_h = [100 + i * 0.5 + 0.2 for i in range(80)]; up_l = [x - 0.4 for x in up_h]; up_c = [x - 0.1 for x in up_h]
        a, pdi, mdi = adx(up_h, up_l, up_c, 14)
        self.assertTrue(a[26] is None and a[27] is not None)               # first ADX at 2n-1
        self.assertTrue(pdi[13] is None and pdi[14] is not None)
        self.assertGreater(a[-1], 40); self.assertGreater(pdi[-1], mdi[-1])
        osc = [100 + (1 if i % 2 else -1) * 0.5 for i in range(80)]
        ao, _, _ = adx([x + 0.1 for x in osc], [x - 0.1 for x in osc], osc, 14)
        self.assertLess(ao[-1], 20)
        h, l, c = walk(300, 4)
        self.assertTrue(all(0 <= v <= 100 for v in adx(h, l, c, 14)[0] if v is not None))

    def test_stochastic_bounds_and_extremes(self):
        h, l, c = walk(300, 5)
        k, d = stochastic(h, l, c, 14, 3, 3)
        self.assertTrue(all(0 <= v <= 100 for v in k + d if v is not None))
        rising = [float(i) for i in range(40)]
        kk, _ = stochastic([x + 0.0 for x in rising], [x - 1 for x in rising], rising, 14, 3, 3)
        self.assertGreater(kk[-1], 90)
        kf, _ = stochastic([1.0] * 30, [1.0] * 30, [1.0] * 30, 14, 3, 3)
        self.assertEqual(kf[-1], 50.0)

    def test_activity_proxy_constant(self):
        self.assertAlmostEqual(activity_ratio([10] * 30, 20)[-1], 1.0)

    def test_property_causality_truncation_invariance_for_every_indicator(self):
        rnd = random.Random(8)
        h, l, c = walk(400, 9)
        full = {"ema": ema(c, 20), "rsi": rsi(c, 14), "macd": macd(c)[2], "atr": atr(h, l, c, 14),
                "adx": adx(h, l, c, 14)[0], "stoch": stochastic(h, l, c)[1]}
        for _ in range(40):
            k = rnd.randint(60, 399)
            part = {"ema": ema(c[:k], 20), "rsi": rsi(c[:k], 14), "macd": macd(c[:k])[2],
                    "atr": atr(h[:k], l[:k], c[:k], 14), "adx": adx(h[:k], l[:k], c[:k], 14)[0],
                    "stoch": stochastic(h[:k], l[:k], c[:k])[1]}
            for name in full:
                self.assertEqual(part[name], full[name][:k], name)           # identical prefix: no look-ahead

    def test_property_long_short_mirror_symmetry_of_indicators(self):
        h, l, c = walk(300, 10)
        M = 2.2
        mh, ml, mc = [M - x for x in l], [M - x for x in h], [M - x for x in c]
        for a, b in zip(rsi(c)[20:], rsi(mc)[20:]): self.assertAlmostEqual(a, 100 - b, places=8)
        for a, b in zip(macd(c)[2][40:], macd(mc)[2][40:]): self.assertAlmostEqual(a, -b, places=10)
        for a, b in zip(adx(h, l, c)[0][40:], adx(mh, ml, mc)[0][40:]): self.assertAlmostEqual(a, b, places=8)
        for a, b in zip(stochastic(h, l, c)[0][30:], stochastic(mh, ml, mc)[0][30:]): self.assertAlmostEqual(a, 100 - b, places=8)


class TestBars(unittest.TestCase):
    def q(self, mid, sec, **kw):
        t = START + timedelta(seconds=sec)
        return Quote("EURUSD", Dc(mid) - Dc("0.00005"), Dc(mid) + Dc("0.00005"), t, kw.get("recv", t))

    def test_bar_closes_only_when_next_bucket_starts_or_on_flush(self):
        bb = BarBuilder(60)
        self.assertIsNone(bb.on_quote(self.q("1.1000", 1)))
        self.assertIsNone(bb.on_quote(self.q("1.1010", 20)))
        self.assertIsNone(bb.on_quote(self.q("1.0990", 40)))
        self.assertIsNone(bb.flush(START + timedelta(seconds=59)))             # forming bar is never exposed
        closed = bb.on_quote(self.q("1.1005", 61))
        self.assertEqual((closed.open, closed.high, closed.low, closed.close, closed.ticks), (1.1, 1.101, 1.099, 1.099, 3))
        self.assertEqual(closed.end_ts, START + timedelta(seconds=60))
        f = bb.flush(START + timedelta(seconds=120))
        self.assertEqual(f.close, 1.1005)

    def test_uses_market_ts_and_ignores_late_ticks(self):
        bb = BarBuilder(60)
        bb.on_quote(self.q("1.1", 70))
        self.assertIsNone(bb.on_quote(self.q("9.9", 10, recv=START + timedelta(seconds=75))))   # late
        self.assertEqual(bb.late_ticks, 1)
        self.assertEqual(bb.flush(START + timedelta(seconds=200)).high, 1.1)

    def test_aggregate_only_closed_buckets_and_alignment(self):
        b1 = bars_from_closes([1.1 + i * 0.0001 for i in range(17)])            # minutes 0..16
        out = aggregate(b1, 300, b1[-1].end_ts)
        self.assertEqual(len(out), 3)                                           # 0-5,5-10,10-15 closed; 15-17 forming
        self.assertEqual(out[0].start_ts, START); self.assertEqual(out[0].n_source, 5)
        self.assertEqual(out[0].open, b1[0].open); self.assertEqual(out[0].close, b1[4].close)
        self.assertEqual(out[0].high, max(b.high for b in b1[:5])); self.assertEqual(out[0].ticks, 5 * 30)
        self.assertEqual(len(aggregate(b1, 300, START + timedelta(minutes=9))), 1)   # as_of before bucket end
        self.assertEqual(bucket_start(START + timedelta(minutes=7, seconds=3), 300), START + timedelta(minutes=5))

    def test_property_aggregate_prefix_is_independent_of_future_bars(self):
        rnd = random.Random(21)
        closes = [1.1 + rnd.uniform(-0.01, 0.01) for _ in range(300)]
        full = bars_from_closes(closes)
        for _ in range(40):
            k = rnd.randint(20, 299)
            cut = full[k - 1].end_ts
            self.assertEqual(aggregate(full, 900, cut), aggregate(full[:k], 900, cut))


if __name__ == "__main__":
    unittest.main()
