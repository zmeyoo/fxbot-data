import csv
import glob
import hashlib
import json
import os
import random
import struct
import tempfile
import unittest
from datetime import datetime, timedelta, timezone
from unittest import mock

from fxbot.backtesting.research import load_research_data
from fxbot.data_sources import cli
from fxbot.data_sources.dataset import (DatasetNotValidated, finalize_dataset, load_validated_dataset, read_manifest, validate_dataset)
from fxbot.data_sources.dukascopy import (Bi5Error, DownloadManager, DukascopyError, RawStore, build_normalised, decode_bi5,
                                          encode_bi5, expected_closed_hour, f32_text, hour_relpath, hour_url, hours_between,
                                          merge_normalised_csvs, price_text, raw_combined_sha256, sha256_file)
from tests.dukas_fixtures import DownServer, FakeServer, ScriptedServer, make_ticks, week_files

U = timezone.utc
NOW = datetime(2026, 11, 9, 12, 0, tzinfo=U)
SAMPLE = os.path.join(os.path.dirname(__file__), "data", "eurusd_dukascopy_published_sample_ticks.csv")
START, END = datetime(2024, 3, 8, tzinfo=U), datetime(2024, 3, 12, tzinfo=U)       # Fri..Mon: contains the US DST change (10 Mar)


def z(*a):
    return datetime(*a, tzinfo=U)


class Tmp(unittest.TestCase):
    def setUp(self):
        self._d = tempfile.TemporaryDirectory(); self.d = self._d.name
        self.sleeps = []

    def tearDown(self):
        self._d.cleanup()

    def mgr(self, server, out=None, **kw):
        store = RawStore(os.path.join(out or self.d, "raw"))
        kw.setdefault("delay_s", 0); kw.setdefault("retries", 1); kw.setdefault("log", lambda s: None)
        return DownloadManager(server, store, "EURUSD", sleep=self.sleeps.append, now=lambda: NOW, **kw), store

    def build_pass_dataset(self, out=None, files=None, command="python tools/dukascopy.py run ...", **kw):
        out = out or self.d
        files = files if files is not None else week_files(START, END)
        m, store = self.mgr(FakeServer(files), out)
        m.run(START, END)
        return finalize_dataset(out, "EURUSD", START, END, command, now=NOW, **kw)


class TestUrlsAndDecoding(unittest.TestCase):
    def test_url_uses_zero_based_months_and_padded_fields(self):
        self.assertEqual(hour_url("EURUSD", z(2020, 3, 30, 0)), "https://datafeed.dukascopy.com/datafeed/EURUSD/2020/02/30/00h_ticks.bi5")
        self.assertEqual(hour_url("EURUSD", z(2024, 1, 5, 7)).split("EURUSD/")[1], "2024/00/05/07h_ticks.bi5")
        self.assertEqual(hour_url("EURUSD", z(2024, 12, 31, 23)).split("EURUSD/")[1], "2024/11/31/23h_ticks.bi5")
        self.assertEqual(hour_relpath("EURUSD", z(2024, 12, 31, 23)), "EURUSD/2024/11/31/23h_ticks.bi5")
        self.assertEqual(len(hours_between(z(2024, 3, 4), z(2024, 3, 18))), 336)
        with self.assertRaises(DukascopyError): hours_between(z(2024, 3, 4, 0, 30), z(2024, 3, 5))
        with self.assertRaises(DukascopyError): hour_url("EURUSD", datetime(2024, 1, 1))

    def test_closure_detection_is_dst_aware(self):
        self.assertFalse(expected_closed_hour(z(2024, 3, 8, 21)))      # Fri 16:00 EST open
        self.assertTrue(expected_closed_hour(z(2024, 3, 8, 22)))       # Fri 17:00 EST: closed
        self.assertTrue(expected_closed_hour(z(2024, 3, 10, 20)))      # Sun 16:00 EDT closed (DST began at 02:00)
        self.assertFalse(expected_closed_hour(z(2024, 3, 10, 21)))     # Sun 17:00 EDT = 21:00Z: open
        self.assertTrue(expected_closed_hour(z(2024, 1, 7, 21)))       # winter: Sun 16:00 EST closed
        self.assertFalse(expected_closed_hour(z(2024, 1, 7, 22)))

    def test_decode_roundtrip_exact_and_container_errors(self):
        ticks = make_ticks(1, 200)
        dec = decode_bi5(encode_bi5(ticks))
        self.assertEqual(len(dec.ticks), 200)
        for a, b in zip(ticks, dec.ticks):
            self.assertEqual(a[:3], b[:3])
            self.assertEqual(struct.pack(">f", a[3]), struct.pack(">f", b[3]))
        self.assertEqual((dec.non_monotone, dec.offset_beyond_hour, dec.crossed, dec.zero_price), (0, 0, 0, 0))
        self.assertEqual(decode_bi5(b"").ticks, [])                          # empty body = no ticks
        with self.assertRaises(Bi5Error): decode_bi5(b"this is not lzma at all")
        import lzma
        with self.assertRaises(Bi5Error): decode_bi5(lzma.compress(b"x" * 21, format=lzma.FORMAT_ALONE))   # not a multiple of 20
        anomalous = decode_bi5(encode_bi5([(5, 100, 101, 1.0, 1.0), (3, 100, 100, 1.0, 1.0), (4_000_000, 0, 5, 1.0, 1.0)]))
        self.assertEqual((anomalous.non_monotone, anomalous.offset_beyond_hour, anomalous.crossed, anomalous.zero_price), (1, 1, 2, 1))   # ask 0 < bid 5 is crossed too

    def test_price_and_volume_text_preserve_precision(self):
        self.assertEqual(price_text(111360, 100000), "1.11360")          # trailing zero kept
        self.assertEqual(price_text(111369, 100000), "1.11369")
        self.assertEqual(price_text(5, 100000), "0.00005"); self.assertEqual(price_text(150123, 1000), "150.123")
        f = lambda v: struct.unpack(">f", struct.pack(">f", v))[0]
        for v, txt in ((0.75, "0.75"), (f(0.94), "0.94"), (1.5, "1.5"), (2.0, "2.0"), (f(0.1), "0.1"), (0.0, "0.0"), (f(123.456), "123.456")):
            self.assertEqual(f32_text(v), txt, v)
        rnd = random.Random(1)
        for _ in range(500):
            v = f(rnd.uniform(0, 50))
            self.assertEqual(f(float(f32_text(v))), v)                    # shortest text that round-trips the float32


class TestPublishedSampleAnchor(Tmp):
    def test_pipeline_reproduces_the_published_sample_file_exactly(self):
        h = z(2020, 3, 30, 0)
        f32 = lambda v: struct.unpack(">f", struct.pack(">f", v))[0]
        ticks = [(104, 111369, 111361, 0.75, 0.75), (256, 111371, 111361, f32(0.94), 1.5)]    # the two published records, as bi5 container
        m, store = self.mgr(FakeServer({hour_url("EURUSD", h): encode_bi5(ticks)}))
        s = m.run(h, h + timedelta(hours=1))
        self.assertEqual((s.ok, s.errors), (1, 0))
        out = os.path.join(self.d, "n.csv")
        bs = build_normalised(store, "EURUSD", h, h + timedelta(hours=1), out)
        with open(SAMPLE) as a, open(out) as b:
            self.assertEqual(a.read(), b.read())                              # byte-identical to the file you supplied
        self.assertEqual((bs.rows_written, bs.first_timestamp_ms), (2, 1585526400104))


class TestDownloadManager(Tmp):
    def test_raw_bytes_and_metadata_are_preserved_exactly(self):
        h = z(2024, 3, 5, 10)
        files = week_files(h, h + timedelta(hours=1))
        m, store = self.mgr(FakeServer(files))
        s = m.run(h, h + timedelta(hours=1))
        raw = files[hour_url("EURUSD", h)]
        self.assertEqual(store.read("EURUSD", h), raw)                        # byte-for-byte
        meta = store.meta("EURUSD", h)
        self.assertEqual((meta["outcome"], meta["http_status"], meta["bytes"], meta["sha256"]), ("ok", 200, len(raw), hashlib.sha256(raw).hexdigest()))
        self.assertEqual((meta["url"], meta["downloaded_at"], meta["attempt_statuses"]), (hour_url("EURUSD", h), NOW.isoformat(), [200]))
        self.assertEqual(meta["etag"], '"x"')
        self.assertEqual(glob.glob(os.path.join(self.d, "**", "*.part"), recursive=True), [])

    def test_closure_hours_empty_and_missing_hours_are_distinguished(self):
        sat = z(2024, 3, 9, 12)
        m, store = self.mgr(FakeServer({hour_url("EURUSD", sat): b""}))
        s = m.run(sat, sat + timedelta(hours=2))
        self.assertEqual((s.empty, s.not_found, s.ok), (1, 1, 0))
        self.assertEqual(store.meta("EURUSD", sat)["outcome"], "empty"); self.assertFalse(os.path.exists(store.path("EURUSD", sat)))
        self.assertEqual(store.meta("EURUSD", sat + timedelta(hours=1))["outcome"], "not_found")

    def test_resume_after_a_crash_fetches_only_what_is_missing(self):
        a = z(2024, 3, 5, 0); b = a + timedelta(hours=6)
        files = week_files(a, b)
        crashing = FakeServer(files, fail_after=3)
        m, store = self.mgr(crashing)
        with self.assertRaises(RuntimeError): m.run(a, b)
        self.assertEqual(sum(1 for h in hours_between(a, b) if store.meta("EURUSD", h)), 3)
        self.assertEqual(glob.glob(os.path.join(self.d, "**", "*.part"), recursive=True), [])
        again = FakeServer(files)
        m2, _ = self.mgr(again)
        s = m2.run(a, b)
        self.assertEqual((s.skipped_complete, s.fetched, s.ok), (3, 3, 3)); self.assertEqual(len(again.calls), 3)
        s3 = self.mgr(FakeServer(files))[0].run(a, b)
        self.assertEqual((s3.skipped_complete, s3.fetched), (6, 0))             # fully complete: nothing is requested

    def test_corrupted_or_half_written_files_are_detected_and_refetched(self):
        h = z(2024, 3, 5, 3)
        files = week_files(h, h + timedelta(hours=1))
        m, store = self.mgr(FakeServer(files)); m.run(h, h + timedelta(hours=1))
        good = store.read("EURUSD", h)
        with open(store.path("EURUSD", h), "ab") as f: f.write(b"garbage")      # corrupt after download
        srv = FakeServer(files); s = self.mgr(srv)[0].run(h, h + timedelta(hours=1))
        self.assertEqual((s.refetched_corrupt, s.fetched, len(srv.calls)), (1, 1, 1)); self.assertEqual(store.read("EURUSD", h), good)
        os.remove(store.meta_path("EURUSD", h))                                  # data written but process died before the meta
        s = self.mgr(FakeServer(files))[0].run(h, h + timedelta(hours=1))
        self.assertEqual(s.fetched, 1)

    def test_not_found_is_not_hammered_but_errors_are_always_retried(self):
        h = z(2024, 3, 5, 3)
        srv = FakeServer({}); m, store = self.mgr(srv)
        m.run(h, h + timedelta(hours=1)); self.assertEqual(len(srv.calls), 1)
        self.mgr(srv)[0].run(h, h + timedelta(hours=1)); self.assertEqual(len(srv.calls), 1)          # skipped
        self.mgr(srv)[0].run(h, h + timedelta(hours=1), retry_missing=True); self.assertEqual(len(srv.calls), 2)
        forb = ScriptedServer({}, [403, 403, 403]); m2, st2 = self.mgr(forb, out=os.path.join(self.d, "b"))
        m2.run(h, h + timedelta(hours=1)); self.assertEqual(st2.meta("EURUSD", h)["outcome"], "error"); self.assertEqual(forb.calls, 1)  # 4xx: no retry
        self.mgr(forb, out=os.path.join(self.d, "b"))[0].run(h, h + timedelta(hours=1)); self.assertEqual(forb.calls, 2)      # but retried on resume

    def test_transient_failures_are_retried_with_exponential_backoff(self):
        h = z(2024, 3, 5, 3)
        files = week_files(h, h + timedelta(hours=1))
        for script, expect_sleeps, statuses in (([503, 503], [2.0, 4.0], [503, 503, 200]), ([429], [2.0], [429, 200]), (["net", 500], [2.0, 4.0], [-1, 500, 200])):
            self.sleeps.clear()
            srv = ScriptedServer(files, script)
            m, store = self.mgr(srv, out=os.path.join(self.d, str(len(statuses)) + str(script[0])), retries=3)
            s = m.run(h, h + timedelta(hours=1))
            self.assertEqual(s.ok, 1); self.assertEqual(self.sleeps, expect_sleeps)
            self.assertEqual(store.meta("EURUSD", h)["attempt_statuses"], statuses)

    def test_unreachable_network_aborts_loudly_and_substitutes_nothing(self):
        a = z(2024, 3, 5, 0)
        srv = DownServer()
        m, store = self.mgr(srv, max_consecutive_errors=3, retries=1)
        s = m.run(a, a + timedelta(hours=10))
        self.assertTrue(s.aborted); self.assertEqual((s.errors, s.ok), (3, 0))
        self.assertIn("Nothing was substituted", s.abort_reason); self.assertIn("Name or service not known", s.abort_reason)
        self.assertEqual(glob.glob(os.path.join(self.d, "raw", "**", "*.bi5"), recursive=True), [])       # no data files at all
        self.assertEqual(len(srv.calls), 6)                                                               # 3 hours x (1 try + 1 retry)
        m2 = finalize_dataset(self.d, "EURUSD", a, a + timedelta(hours=10), "cmd", now=NOW)
        self.assertEqual(m2["validation"]["status"], "FAILED")                                            # incomplete download is a FAIL
        self.assertEqual(m2["normalised"]["rows"], 0)


class TestBuildAndMerge(Tmp):
    def test_duplicates_ordering_and_anomalies_in_the_normalised_file(self):
        h = z(2024, 3, 5, 3)
        ticks = [(100, 110008, 110000, 1.0, 1.0), (100, 110008, 110000, 1.0, 1.0),          # exact duplicate -> removed
                 (100, 110009, 110001, 1.0, 1.0),                                            # same ms, different price -> kept
                 (50, 110007, 110000, 2.0, 2.0),                                             # out of order -> sorted
                 (4_000_000, 110010, 110002, 1.0, 1.0), (200, 109999, 110005, 1.0, 1.0)]     # beyond hour; crossed
        m, store = self.mgr(FakeServer({hour_url("EURUSD", h): encode_bi5(ticks)})); m.run(h, h + timedelta(hours=1))
        out = os.path.join(self.d, "n.csv")
        bs = build_normalised(store, "EURUSD", h, h + timedelta(hours=1), out)
        with open(out) as f: rows = list(csv.reader(f))
        ts = [int(r[0]) for r in rows[1:]]
        self.assertEqual(ts, sorted(ts))
        self.assertEqual([r[0] for r in rows[1:4]], [str(int(h.timestamp() * 1000) + x) for x in (50, 100, 100)])
        self.assertEqual((bs.duplicates_removed, bs.hours_non_monotone, bs.offsets_beyond_hour, bs.crossed_ticks), (1, 1, 1, 1))
        self.assertEqual(bs.rows_written, 5)
        self.assertEqual(rows[0], ["timestamp", "askPrice", "bidPrice", "askVolume", "bidVolume"])
        self.assertEqual(bs.csv_sha256, sha256_file(out))

    def test_merging_overlapping_chunks_drops_only_exact_duplicates(self):
        def write(name, rows):
            p = os.path.join(self.d, name)
            with open(p, "w", newline="") as f:
                w = csv.writer(f, lineterminator="\n"); w.writerow(["timestamp", "askPrice", "bidPrice", "askVolume", "bidVolume"]); w.writerows(rows)
            return p
        a = write("a.csv", [[1000, "1.10001", "1.10000", "1.0", "1.0"], [2000, "1.10002", "1.10001", "1.0", "1.0"], [3000, "1.10003", "1.10002", "1.0", "1.0"]])
        b = write("b.csv", [[2000, "1.10002", "1.10001", "1.0", "1.0"], [2000, "1.10009", "1.10005", "1.0", "1.0"], [4000, "1.10004", "1.10003", "1.0", "1.0"]])
        out = os.path.join(self.d, "m.csv")
        n, d = merge_normalised_csvs([a, b], out)
        self.assertEqual((n, d), (5, 1))
        with open(out) as f: ts = [r[0] for r in list(csv.reader(f))[1:]]
        self.assertEqual(ts, ["1000", "2000", "2000", "3000", "4000"])
        n2, d2 = merge_normalised_csvs([out, a, b], os.path.join(self.d, "m2.csv"))                 # idempotent on repeats
        self.assertEqual(n2, 5)                                                                   # merging repeats adds nothing
        bad = write("bad.csv", [[2000, "1.1", "1.0", "1.0", "1.0"], [1000, "1.1", "1.0", "1.0", "1.0"]])
        with self.assertRaises(DukascopyError): merge_normalised_csvs([bad], os.path.join(self.d, "x.csv"))
        with open(os.path.join(self.d, "h.csv"), "w") as f: f.write("ts,bid,ask\n")
        with self.assertRaises(DukascopyError): merge_normalised_csvs([os.path.join(self.d, "h.csv")], os.path.join(self.d, "x.csv"))


class TestManifestAndValidation(Tmp):
    def test_good_week_passes_with_complete_provenance_and_report(self):
        m = self.build_pass_dataset(command="python tools/dukascopy.py run --instrument EURUSD --start 2024-03-08 --end 2024-03-12 --out X")
        self.assertEqual(m["validation"]["status"], "PASSED", [c for c in m["validation"]["checks"] if c["status"] == "FAIL"])
        self.assertEqual((m["instrument"], m["source"]["base_url"], m["range_utc"]["hours"]), ("EURUSD", "https://datafeed.dukascopy.com/datafeed", 96))
        self.assertEqual((m["download"]["first_at"], m["download"]["last_at"]), (NOW.isoformat(), NOW.isoformat()))
        self.assertIn("--start 2024-03-08", m["command"])
        oc = m["download"]["hour_outcomes"]; self.assertEqual((oc["error"], oc["not_attempted"], oc["not_found"]), (0, 0, 0))
        self.assertEqual(oc["ok"] + oc["empty"], 96)
        csv_path = os.path.join(self.d, m["normalised"]["path"])
        with open(csv_path, "rb") as fh:
            self.assertEqual(m["normalised"]["sha256"], hashlib.sha256(fh.read()).hexdigest())
        store = RawStore(os.path.join(self.d, "raw"))
        self.assertEqual(m["raw"]["combined_sha256"], raw_combined_sha256(store, "EURUSD", hours_between(START, END))[0])
        with open(os.path.join(self.d, "DATA_QUALITY_REPORT.md")) as fh:
            rep = fh.read()
        for needle in ("Verdict: PASSED", "Spread distribution", "Median spread by New York hour", "Gaps longer than", "exact duplicates",
                       "timestamp resolution", "Sessions (17:00 America/New_York", "Missing hours during open market", "Thin hours",
                       m["normalised"]["sha256"], "python tools/dukascopy.py run", "No strategy was run", "Existing tick validator output",
                       "weekend_closure", "Download completeness"):
            self.assertIn(needle, rep, needle)
        self.assertEqual(m["validation"]["validator_scope"], "full")

    def test_pipeline_is_reproducible_byte_for_byte(self):
        a = self.build_pass_dataset(out=os.path.join(self.d, "a"))
        b = self.build_pass_dataset(out=os.path.join(self.d, "b"))
        self.assertEqual((a["normalised"]["sha256"], a["raw"]["combined_sha256"], a["dataset_id"]),
                         (b["normalised"]["sha256"], b["raw"]["combined_sha256"], b["dataset_id"]))
        again = validate_dataset(os.path.join(self.d, "a"), now=NOW)                         # re-validation changes nothing
        self.assertEqual(again["normalised"]["sha256"], a["normalised"]["sha256"])

    def test_validated_dataset_loads_and_matches_the_manifest(self):
        m = self.build_pass_dataset()
        quotes, rep, man = load_validated_dataset(self.d)
        self.assertEqual(len(quotes) + rep.dropped_duplicate + rep.dropped_crossed_or_invalid + rep.dropped_out_of_order, m["normalised"]["rows"])
        self.assertGreater(len(quotes), 1000)
        self.assertEqual(rep.sha256, man["normalised"]["loader_content_sha256"])
        self.assertEqual(rep.format_name, "dukascopy_csv"); self.assertEqual(rep.ts_resolution, "sub-second")
        self.assertEqual(rep.price_decimals, (5,))
        first_open = min(h for h in hours_between(START, END) if not expected_closed_hour(h))
        self.assertGreaterEqual(quotes[0].market_ts, first_open); self.assertEqual(rep.quotes_in_closure, 0)

    def test_wrong_price_scale_fails_validation_and_blocks_research(self):
        m = self.build_pass_dataset(point_value=1000)                                        # decoder assumption deliberately wrong
        v = m["validation"]
        self.assertEqual(v["status"], "FAILED")
        self.assertTrue(any(c["name"].startswith("Price scale") and c["status"] == "FAIL" for c in v["checks"]))
        with self.assertRaises(DatasetNotValidated): load_validated_dataset(self.d)
        with self.assertRaises(DatasetNotValidated): load_research_data(dataset=self.d)

    def test_incomplete_download_fails(self):
        files = week_files(START, END)
        m, store = self.mgr(FakeServer(files)); m.run(START, END)
        h = z(2024, 3, 11, 5)
        with open(store.meta_path("EURUSD", h)) as f: meta = json.load(f)
        meta["outcome"] = "error"
        with open(store.meta_path("EURUSD", h), "w") as f: json.dump(meta, f)
        man = finalize_dataset(self.d, "EURUSD", START, END, "cmd", now=NOW)
        self.assertEqual(man["validation"]["status"], "FAILED")
        self.assertTrue(any(c["name"] == "Download completeness" and c["status"] == "FAIL" for c in man["validation"]["checks"]))

    def test_missing_open_hours_warn_then_fail_beyond_the_threshold(self):
        miss1 = {z(2024, 3, 11, 5)}
        m = self.build_pass_dataset(files=week_files(START, END, skip=miss1))
        c = next(c for c in m["validation"]["checks"] if c["name"] == "Missing hours during open market")
        self.assertEqual(c["status"], "WARN"); self.assertIn("2024-03-11 05h", c["detail"]); self.assertEqual(m["validation"]["status"], "PASSED")
        with tempfile.TemporaryDirectory() as d2:
            many = {z(2024, 3, 11, h) for h in range(0, 8)}
            m2 = self.build_pass_dataset(out=d2, files=week_files(START, END, skip=many))
            self.assertEqual(next(c for c in m2["validation"]["checks"] if c["name"] == "Missing hours during open market")["status"], "FAIL")
            self.assertEqual(m2["validation"]["status"], "FAILED")

    def test_crossed_quotes_and_closure_quotes_are_gated(self):
        files = week_files(START, END)
        h = z(2024, 3, 11, 9)
        t = make_ticks(99, 300)
        for i in range(300):
            ms, a, b, av, bv = t[i]; t[i] = (ms, b, a, av, bv)                               # every tick of one hour crossed (1.4% of the file)
        files[hour_url("EURUSD", h)] = encode_bi5(t)
        m = self.build_pass_dataset(files=files)
        cr = next(c for c in m["validation"]["checks"] if c["name"].startswith("Crossed"))
        self.assertEqual(cr["status"], "FAIL"); self.assertEqual(m["validation"]["status"], "FAILED")
        with tempfile.TemporaryDirectory() as d2:
            files2 = week_files(START, END)
            sat = z(2024, 3, 9, 12)
            files2[hour_url("EURUSD", sat)] = encode_bi5(make_ticks(7, 40))                  # quotes during the closed weekend
            m2 = self.build_pass_dataset(out=d2, files=files2)
            cq = next(c for c in m2["validation"]["checks"] if c["name"].startswith("Quotes inside"))
            self.assertEqual(cq["status"], "WARN"); self.assertIn("40", cq["detail"])

    def test_tampering_after_validation_is_detected(self):
        m = self.build_pass_dataset()
        p = os.path.join(self.d, m["normalised"]["path"])
        with open(p, "a") as f: f.write("1710000000000,1.10001,1.10000,1.0,1.0\n")
        with self.assertRaises(DatasetNotValidated): load_validated_dataset(self.d)
        re = validate_dataset(self.d, now=NOW)
        self.assertEqual(re["validation"]["status"], "FAILED")
        self.assertEqual(re["validation"]["checks"][0]["name"], "File integrity (SHA-256)"); self.assertEqual(re["validation"]["checks"][0]["status"], "FAIL")

    def test_large_files_are_validated_in_hour_slices_with_complete_coverage(self):
        m = self.build_pass_dataset(full_validator_row_limit=1000)
        self.assertTrue(m["validation"]["validator_scope"].startswith("SLICED"), m["validation"]["validator_scope"])
        self.assertEqual(m["validation"]["status"], "PASSED")
        det = next(c["detail"] for c in m["validation"]["checks"] if c["name"] == "Tick validator (existing)")
        n_hours = m["download"]["hour_outcomes"]["ok"]
        self.assertIn(f"slices passed {n_hours}/{n_hours}", det)                            # every hour with data was validated
        with open(os.path.join(self.d, "DATA_QUALITY_REPORT.md")) as fh:
            self.assertIn("SLICED", fh.read())

    def test_a_bad_slice_in_a_large_file_fails_the_dataset_and_memory_stays_bounded(self):
        import tracemalloc
        files = week_files(START, END)
        h = z(2024, 3, 11, 9)
        t = make_ticks(5, 300)
        for i in range(300):
            ms, a, b, av, bv = t[i]; t[i] = (ms, b, a, av, bv)                               # a fully crossed hour inside the file
        files[hour_url("EURUSD", h)] = encode_bi5(t)
        m, store = self.mgr(FakeServer(files)); m.run(START, END)
        tracemalloc.start()
        man = finalize_dataset(self.d, "EURUSD", START, END, "cmd", now=NOW, full_validator_row_limit=1000)
        peak = tracemalloc.get_traced_memory()[1]; tracemalloc.stop()
        self.assertEqual(man["validation"]["status"], "FAILED")
        self.assertTrue(any("slices passed" in c["detail"] and c["status"] == "FAIL" for c in man["validation"]["checks"]))
        self.assertLess(peak, 60 * 1024 * 1024)                                              # ~20k rows total; never holds the whole file


class TestCli(Tmp):
    def run_cli(self, argv, server):
        out = []
        with mock.patch.object(cli, "UrllibFetcher", lambda *a, **k: server):
            rc = cli.main(argv, out=out.append)
        return rc, "\n".join(out)

    def test_env_check_reports_the_exact_failure_and_creates_nothing(self):
        rc, txt = self.run_cli(["env-check"], DownServer())
        self.assertEqual(rc, 2)
        for needle in ("NOT READY", "Name or service not known", "No data was created or substituted", "DUKASCOPY_RUNBOOK"):
            self.assertIn(needle, txt)
        rc, txt = self.run_cli(["env-check"], FakeServer({}))
        self.assertEqual(rc, 0); self.assertIn("READY", txt)

    def test_plan_counts_and_calibrated_scale_warning(self):
        rc, txt = self.run_cli(["plan", "--start", "2024-03-04", "--end", "2024-03-18"], FakeServer({}))
        self.assertIn("336 hourly files", txt); self.assertIn("241 are in open-market time", txt); self.assertIn("size unknown until a pilot", txt)
        self.build_pass_dataset()
        rc, txt = self.run_cli(["plan", "--start", "2025-01-01", "--end", "2026-01-01", "--calibrate", self.d], FakeServer({}))
        self.assertIn("quotes / ok hour", txt); self.assertIn("in-memory research load", txt); self.assertNotIn("WARNING", txt)
        with mock.patch.object(cli, "MEASURED_BYTES_PER_QUOTE_IN_MEMORY", 10 ** 7):
            rc, txt = self.run_cli(["plan", "--start", "2025-01-01", "--end", "2026-01-01", "--calibrate", self.d], FakeServer({}))
        self.assertIn("WARNING", txt); self.assertIn("streaming milestone", txt)

    def test_run_downloads_builds_validates_and_records_the_command(self):
        srv = FakeServer(week_files(START, END))
        out = os.path.join(self.d, "pilot")
        rc, txt = self.run_cli(["run", "--instrument", "EURUSD", "--start", "2024-03-08", "--end", "2024-03-12", "--out", out, "--sleep", "0", "--retries", "0"], srv)
        self.assertEqual(rc, 0, txt)
        m = read_manifest(out)
        self.assertEqual(m["validation"]["status"], "PASSED")
        self.assertIn("python tools/dukascopy.py run --instrument EURUSD --start 2024-03-08 --end 2024-03-12", m["command"])
        for needle in (m["normalised"]["sha256"], "validation: PASSED", "DATA_QUALITY_REPORT.md"): self.assertIn(needle, txt)

    def test_download_in_stages_is_resumable_and_incomplete_download_never_builds(self):
        srv = FakeServer(week_files(START, END)); out = os.path.join(self.d, "p")
        base = ["--instrument", "EURUSD", "--start", "2024-03-08", "--end", "2024-03-12", "--out", out, "--sleep", "0", "--retries", "0"]
        rc, txt = self.run_cli(["run"] + base + ["--max-hours", "10"], srv)
        self.assertEqual(rc, 3); self.assertIn("stopped by --max-hours", txt); self.assertIn("not building", txt)
        self.assertFalse(os.path.exists(os.path.join(out, "dataset.json")))
        n_first = len(srv.calls)
        rc, txt = self.run_cli(["run"] + base, srv)
        self.assertEqual(rc, 0, txt); self.assertEqual(len(srv.calls) - n_first, 86)             # only the remaining hours
        rc, txt = self.run_cli(["run"] + base, DownServer())                                        # everything complete: no network needed
        self.assertEqual(rc, 0)

    def test_network_failure_exit_code_and_message(self):
        out = os.path.join(self.d, "p")
        rc, txt = self.run_cli(["run", "--start", "2024-03-08", "--end", "2024-03-12", "--out", out, "--sleep", "0", "--retries", "0"], DownServer())
        self.assertEqual(rc, 3); self.assertIn("ABORTED", txt); self.assertIn("Nothing was substituted", txt)
        self.assertFalse(os.path.exists(os.path.join(out, "dataset.json")))
        self.assertEqual(glob.glob(os.path.join(out, "**", "*.csv"), recursive=True), [])

    def test_verify_sample_match_mismatch_and_unreachable(self):
        h = z(2020, 3, 30, 0)
        f32 = lambda v: struct.unpack(">f", struct.pack(">f", v))[0]
        good = FakeServer({hour_url("EURUSD", h): encode_bi5([(104, 111369, 111361, 0.75, 0.75), (256, 111371, 111361, f32(0.94), 1.5)] + make_ticks(1, 50)[:0])})
        rc, txt = self.run_cli(["verify-sample", "--out", os.path.join(self.d, "v1"), "--sample", SAMPLE, "--retries", "0"], good)
        self.assertEqual(rc, 0, txt); self.assertIn("MATCH", txt)
        other = FakeServer({hour_url("EURUSD", h): encode_bi5(make_ticks(2, 20))})
        rc, txt = self.run_cli(["verify-sample", "--out", os.path.join(self.d, "v2"), "--sample", SAMPLE, "--retries", "0"], other)
        self.assertEqual(rc, 4); self.assertIn("MISMATCH", txt)
        rc, txt = self.run_cli(["verify-sample", "--out", os.path.join(self.d, "v3"), "--sample", SAMPLE, "--retries", "0"], DownServer())
        self.assertEqual(rc, 3); self.assertIn("cannot verify", txt)


class TestResearchDataGate(Tmp):
    def test_only_validated_datasets_feed_research(self):
        self.build_pass_dataset()
        q, rep, banner = load_research_data(dataset=self.d)
        self.assertGreater(len(q), 1000); self.assertIn("validated dataset", banner)
        csvp = os.path.join(self.d, read_manifest(self.d)["normalised"]["path"])
        with self.assertRaises(DatasetNotValidated): load_research_data(ticks=csvp)               # bare file refused by default
        q2, _, banner2 = load_research_data(ticks=csvp, allow_unvalidated=True)
        self.assertIn("UNVALIDATED", banner2)
        with self.assertRaises(DatasetNotValidated): load_research_data()
        with self.assertRaises(DatasetNotValidated): load_research_data(dataset=os.path.join(self.d, "nope"))


if __name__ == "__main__":
    unittest.main()
