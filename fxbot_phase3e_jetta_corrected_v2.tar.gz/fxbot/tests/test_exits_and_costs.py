import unittest
from datetime import timedelta
from decimal import Decimal as Dc

from fxbot.config.schema import MinNetProfit, MinNetProfitMode as M
from fxbot.core.money import FxRates, Money, MissingRate
from fxbot.core.types import Side
from fxbot.costs.model import (CostBreakdown, CostRecord, FinancingModel, FlatPerOrder, PercentOfNotional,
                               ScheduleVerification, TieredPercent, assess_entry_costs)
from fxbot.position_manager.exits import ExitPolicy, evaluate_exit
from fxbot.position_manager.pnl import estimate_open_pnl
from fxbot.position_manager.position import ExitReason, PositionState as S
from tests.fixtures import *

V = ScheduleVerification("test")


def policy(**kw):
    base = dict(max_hold_seconds=3 * 3600, max_quote_age_s=10)
    base.update(kw)
    return ExitPolicy(**base)


class TestCostModel(unittest.TestCase):
    def test_09_golden_commission_values(self):
        s = PercentOfNotional(Dc("0.2"), Money(Dc("2.00"), "USD"), "USD", V)
        self.assertEqual(s.commission(Money(Dc("1100000"), "USD"), RATES).amount, Dc("22"))       # 0.2bp
        self.assertEqual(s.commission(Money(Dc("50000"), "USD"), RATES).amount, Dc("2.00"))       # minimum bites
        capped = PercentOfNotional(Dc("0.2"), Money(Dc("2.00"), "USD"), "USD", V, cap_pct_of_notional=Dc("0.001"))
        self.assertEqual(capped.commission(Money(Dc("100000"), "USD"), RATES).amount, Dc("1.00"))
        fixed = PercentOfNotional(Dc("0.2"), Money(Dc("2.00"), "USD"), "USD", V, fixed_per_order=Money(Dc("0.10"), "USD"))
        self.assertEqual(fixed.commission(Money(Dc("50000"), "USD"), RATES).amount, Dc("2.10"))

    def test_alternative_structures_and_currency_conversion(self):
        self.assertEqual(FlatPerOrder(Money(Dc("3"), "USD"), V).commission(Money(Dc("1"), "USD"), RATES).amount, 3)
        tiers = TieredPercent(((Dc("0"), Dc("0.20")), (Dc("1000000000"), Dc("0.15"))), Money(Dc("1"), "USD"), "USD", V)
        n = Money(Dc("10000000"), "USD")
        self.assertEqual(tiers.commission(n, RATES, Dc("0")).amount, Dc("200"))
        self.assertEqual(tiers.commission(n, RATES, Dc("2000000000")).amount, Dc("150"))
        eur = PercentOfNotional(Dc("0.2"), Money(Dc("2.00"), "USD"), "EUR", V)     # charged in EUR
        c = eur.commission(Money(Dc("11000000"), "USD"), RATES)                    # 10m EUR notional
        self.assertEqual((c.ccy, c.amount), ("EUR", Dc("200")))

    def test_fx_rates_never_silently_one(self):
        self.assertEqual(RATES.rate("USD", "EUR").quantize(Dc("0.0001")), Dc("0.9091"))
        with self.assertRaises(MissingRate):
            RATES.rate("EUR", "CHF")
        self.assertEqual(RATES.rate("EUR", "JPY"), Dc("165.00"))                   # triangulated

    def test_financing_unknown_is_none_not_zero(self):
        fm = FinancingModel({"EUR": (Dc("4"), Dc("1")), "USD": (Dc("6"), Dc("2"))})
        short = fm.carry_cost(Side.SHORT, "EUR", "USD", Dc("100000"), Dc("1.1"), 3600)
        self.assertGreater(short, 0)
        self.assertIsNone(fm.carry_cost(Side.SHORT, "EUR", "CHF", Dc("1"), Dc("1"), 1))

    def test_estimated_vs_realised_record(self):
        r = CostRecord("entry", CostBreakdown(commission=Dc("2")), CostBreakdown(commission=Dc("2.5")))
        self.assertEqual(r.variance.commission, Dc("0.5"))


class TestEntryCostGate(unittest.TestCase):
    def test_accept_and_numbers(self):
        a = assess_entry_costs(side=Side.LONG, quote=qt("1.09990", "1.10000"), qty=Dc("100000"),
                               cfg=pair_cfg(), ctx=CTX, base="EUR", quote_ccy="USD")
        self.assertTrue(a.accepted, a.reasons)
        self.assertLess(a.cost_to_stop_ratio, Dc("0.5"))
        self.assertLess(a.net_at_stop, 0)
        self.assertIn("financing estimate unavailable (no reliable rates)", a.warnings)
        # gross-breakeven first protected level is net NEGATIVE after costs
        self.assertLess(a.net_at_first_protected_level, 0)
        self.assertGreater(a.net_at_trail_activation, a.net_at_first_protected_level)

    def test_reject_wide_spread_and_cost_ratio(self):
        a = assess_entry_costs(side=Side.LONG, quote=qt("1.09900", "1.10000"), qty=Dc("100000"),
                               cfg=pair_cfg(), ctx=CTX, base="EUR", quote_ccy="USD")
        self.assertFalse(a.accepted)
        self.assertTrue(any("spread" in r for r in a.reasons))
        b = assess_entry_costs(side=Side.LONG, quote=qt("1.09990", "1.10000"), qty=Dc("100000"),
                               cfg=pair_cfg(max_cost_to_stop_ratio=Dc("0.05")), ctx=CTX, base="EUR", quote_ccy="USD")
        self.assertFalse(b.accepted)
        self.assertTrue(any("cost/stop" in r for r in b.reasons))

    def test_unconfigured_cost_params_block_trading(self):
        a = assess_entry_costs(side=Side.LONG, quote=qt("1.0999", "1.1"), qty=Dc("1000"),
                               cfg=pair_cfg(max_spread_pct=None), ctx=CTX, base="EUR", quote_ccy="USD")
        self.assertFalse(a.accepted)


class TestExits(unittest.TestCase):
    def test_11_protective_exit_despite_negative_net_and_with_profit_taking_on(self):
        pos = make_position(Side.LONG)
        pol = policy(profit_taking_enabled=True, min_net_profit=MinNetProfit(M.PCT_NOTIONAL, Dc("0.01")))
        ev = evaluate_exit(pos, qt("1.09880"), T0, pol, CTX)
        self.assertEqual(ev.exit.reason, ExitReason.INITIAL_STOP)
        self.assertTrue(ev.exit.protective)
        self.assertLess(ev.pnl.expected_net_pnl, 0)

    def test_trailing_at_gross_breakeven_is_net_negative(self):
        pos = make_position(Side.LONG)
        evaluate_exit(pos, qt("1.10110"), T0, policy(), CTX)               # +0.10%: trailing engages
        self.assertTrue(pos.trailing_engaged)
        ev = evaluate_exit(pos, qt("1.10000"), T0, policy(), CTX)          # falls back to P0
        self.assertEqual(ev.exit.reason, ExitReason.TRAILING_STOP)
        self.assertEqual(pos.trail_protected_pct, Dc("0.1") - Dc("0.1"))
        self.assertLess(ev.pnl.expected_net_pnl, 0)                        # costs make it a net loss

    def test_12_profit_taking_vs_trailing_only(self):
        target = MinNetProfit(M.PCT_NOTIONAL, Dc("0.08"))                  # 88 USD on 110k notional
        on = policy(profit_taking_enabled=True, min_net_profit=target)
        off = policy(profit_taking_enabled=False, min_net_profit=target)
        pos = make_position(Side.LONG)
        self.assertIsNone(evaluate_exit(pos, qt("1.10080"), T0, on, CTX).exit)          # net ~74 < 88
        ev = evaluate_exit(pos, qt("1.10100"), T0, on, CTX)                             # net ~94 >= 88
        self.assertEqual(ev.exit.reason, ExitReason.PROFIT_TARGET)
        self.assertGreaterEqual(ev.pnl.expected_net_pnl, ev.pnl.min_net_profit_target)
        pos2 = make_position(Side.LONG)
        self.assertIsNone(evaluate_exit(pos2, qt("1.10100"), T0, off, CTX).exit)       # trailing-only: no exit

    def test_gross_positive_but_net_below_target_does_not_take_profit(self):
        pos = make_position(Side.LONG)
        pol = policy(profit_taking_enabled=True, min_net_profit=MinNetProfit(M.ABSOLUTE_BASE, Dc("500")))
        ev = evaluate_exit(pos, qt("1.10050"), T0, pol, CTX)
        self.assertIsNone(ev.exit)
        self.assertGreater(ev.pnl.gross_pnl, 0)

    def test_10_breakeven_price_gives_zero_net(self):
        pos = make_position(Side.LONG)
        q = qt("1.10040")
        be = estimate_open_pnl(pos, q, CTX).cost_breakeven_price
        self.assertGreater(be, pos.avg_entry)                              # not equal to gross breakeven
        n = estimate_open_pnl(pos, qt(be, be + Dc("0.0001")), CTX).expected_net_pnl
        self.assertLess(abs(n), Dc("0.05"))                                # ~0 (commission depends mildly on px)
        short = make_position(Side.SHORT)
        sbe = estimate_open_pnl(short, qt("1.09960"), CTX).cost_breakeven_price
        self.assertLess(sbe, short.avg_entry)

    def test_24_max_holding_and_eod_exit_independent_of_price(self):
        pos = make_position(Side.LONG)
        later = T0 + timedelta(hours=3)
        ev = evaluate_exit(pos, qt("1.10010", ts=later), later, policy(max_quote_age_s=10), CTX)
        self.assertEqual(ev.exit.reason, ExitReason.MAX_HOLD_TIME)
        ev2 = evaluate_exit(make_position(Side.LONG), None, T0 + timedelta(minutes=5),
                            policy(eod_cutoff=T0 + timedelta(minutes=1)), CTX)
        self.assertEqual(ev2.exit.reason, ExitReason.END_OF_DAY)

    def test_08_stale_data_blocks_price_exits_and_warns(self):
        pos = make_position(Side.LONG)
        old = qt("1.05000", ts=T0)                                         # would hit the stop if trusted
        ev = evaluate_exit(pos, old, T0 + timedelta(seconds=60), policy(), CTX)
        self.assertIsNone(ev.exit)
        self.assertTrue(any("stale" in w for w in ev.warnings))
        ev = evaluate_exit(pos, None, T0, policy(), CTX)
        self.assertIn("data: no quote", ev.warnings)

    def test_no_duplicate_exit_while_pending(self):
        pos = make_position(Side.LONG)
        self.assertTrue(pos.request_exit(ExitReason.MANUAL, T0))
        self.assertFalse(pos.request_exit(ExitReason.MANUAL, T0))
        self.assertIsNone(evaluate_exit(pos, qt("1.0"), T0, policy(), CTX).exit)

    def test_broker_side_stop_fill_is_attributed(self):
        pos = make_position(Side.LONG)
        pos.on_exit_fill(fill("100000", "1.0989", qt("1.0989")))          # resting broker stop filled
        self.assertEqual(pos.state, S.CLOSED)
        self.assertEqual(pos.exit_reason, ExitReason.INITIAL_STOP)


if __name__ == "__main__":
    unittest.main()
