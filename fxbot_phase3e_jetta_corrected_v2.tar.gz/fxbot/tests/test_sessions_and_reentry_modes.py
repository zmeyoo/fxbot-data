import json
import random
import unittest
from dataclasses import replace
from datetime import datetime, timedelta, timezone
from decimal import Decimal as Dc

from fxbot.backtesting.engine import cutoff_for, run_backtest
from fxbot.backtesting.synth import synth_ticks
from fxbot.config.schema import ConfigError, GlobalConfig, PairConfig
from fxbot.core.sessions import SessionCalendar
from fxbot.core.types import FxBotError, Side
from fxbot.position_manager.position import ExitReason
from fxbot.signals.ema_trend import EmaTrendParams
from fxbot.strategy.pair_state import PairState as P, PairStrategy, PostCloseTracker
from tests.bt_helpers import settings
from tests.bt_scenarios import ticks_from_closes, long_scenario
from tests.fixtures import *
from tests.test_reentry_and_trailing_rules import C, closed, feed, sg

U = timezone.utc
CAL = SessionCalendar()


def z(*a):
    return datetime(*a, tzinfo=U)


class TestSessionCalendar(unittest.TestCase):
    def test_winter_boundary_is_22_utc_summer_is_21_utc(self):
        w = CAL.session_of(z(2026, 1, 6, 21, 59, 59))
        self.assertEqual((w.label, w.start_utc, w.end_utc), (datetime(2026, 1, 6).date(), z(2026, 1, 5, 22), z(2026, 1, 6, 22)))
        self.assertEqual(CAL.session_of(z(2026, 1, 6, 22, 0, 0)).label, datetime(2026, 1, 7).date())
        s = CAL.session_of(z(2026, 7, 7, 20, 59, 59))
        self.assertEqual((s.label, s.start_utc, s.end_utc), (datetime(2026, 7, 7).date(), z(2026, 7, 6, 21), z(2026, 7, 7, 21)))
        self.assertEqual(CAL.session_of(z(2026, 7, 7, 21, 0, 0)).label, datetime(2026, 7, 8).date())

    def test_dst_transition_sessions_are_23h_and_25h_and_only_on_the_closed_weekend(self):
        spring = CAL.session_of(z(2026, 3, 8, 12))                  # Sunday 8 Mar 2026: clocks go forward at 02:00 local
        self.assertEqual((spring.start_utc, spring.end_utc, spring.length), (z(2026, 3, 7, 22), z(2026, 3, 8, 21), timedelta(hours=23)))
        self.assertFalse(spring.is_trading_day)                      # label = Sunday: no trading
        mon = CAL.session_of(z(2026, 3, 9, 12))
        self.assertEqual((mon.start_utc, mon.end_utc, mon.length), (z(2026, 3, 8, 21), z(2026, 3, 9, 21), timedelta(hours=24)))
        self.assertTrue(mon.is_trading_day)
        fall = CAL.session_of(z(2026, 11, 1, 12))                    # Sunday 1 Nov 2026: clocks go back at 02:00 local
        self.assertEqual((fall.start_utc, fall.end_utc, fall.length), (z(2026, 10, 31, 21), z(2026, 11, 1, 22), timedelta(hours=25)))
        self.assertFalse(fall.is_trading_day)
        for d in range(2, 7):                                         # every business session around the changes is 24h
            for base in (z(2026, 3, 8), z(2026, 11, 1)):
                s = CAL.session_of(base + timedelta(days=d, hours=12))
                self.assertEqual(s.length, timedelta(hours=24))

    def test_weekly_open_and_close_in_new_york_time(self):
        mon_open = CAL.session_of(z(2026, 1, 4, 22, 0, 0))           # Sunday 17:00 EST
        self.assertEqual(mon_open.label, datetime(2026, 1, 5).date()); self.assertTrue(mon_open.is_trading_day)
        self.assertFalse(CAL.closure_contains(z(2026, 1, 2, 21, 59)))          # Fri 16:59 EST: open
        self.assertTrue(CAL.closure_contains(z(2026, 1, 2, 22, 0)))            # Fri 17:00 EST: closed
        self.assertTrue(CAL.closure_contains(z(2026, 1, 3, 12)))
        self.assertTrue(CAL.closure_contains(z(2026, 1, 4, 21, 59)))           # Sun 16:59 EST: still closed
        self.assertFalse(CAL.closure_contains(z(2026, 1, 4, 22, 0)))
        self.assertTrue(CAL.closure_contains(z(2026, 7, 5, 20, 59)))           # summer: reopens 21:00 UTC
        self.assertFalse(CAL.closure_contains(z(2026, 7, 5, 21, 0)))

    def test_property_sessions_tile_time_without_gaps_or_overlaps(self):
        rnd = random.Random(1)
        for _ in range(3000):
            ts = z(2026, 1, 1) + timedelta(seconds=rnd.randint(0, 365 * 86400))
            s = CAL.session_of(ts)
            self.assertTrue(s.start_utc <= ts < s.end_utc)
            nxt = CAL.session_of(s.end_utc)
            self.assertEqual(nxt.start_utc, s.end_utc)
            self.assertEqual(CAL.session_of(s.start_utc - timedelta(microseconds=1)).end_utc, s.start_utc)
            self.assertIn(s.length, (timedelta(hours=23), timedelta(hours=24), timedelta(hours=25)))
            self.assertEqual(s.label, s.end_utc.astimezone(CAL._tz()).date())

    def test_eod_cutoff_is_relative_to_rollover_and_follows_dst(self):
        g = gcfg(eod_cutoff_minutes_before_rollover=60, eod_cutoff_utc=None)
        self.assertEqual(cutoff_for(g, CAL.session_of(z(2026, 1, 6, 12))), z(2026, 1, 6, 21))
        self.assertEqual(cutoff_for(g, CAL.session_of(z(2026, 7, 7, 12))), z(2026, 7, 7, 20))
        legacy = gcfg(eod_cutoff_utc="20:00")                                       # legacy UTC cutoff does NOT follow DST
        self.assertEqual(cutoff_for(legacy, CAL.session_of(z(2026, 7, 7, 12))), z(2026, 7, 7, 20))

    def test_bad_definitions_are_rejected(self):
        with self.assertRaises(ConfigError): GlobalConfig(session_timezone="Mars/Phobos")
        with self.assertRaises(ConfigError): GlobalConfig(session_start_local="25:99")
        with self.assertRaises(FxBotError): SessionCalendar("America/New_York", "02:30").session_of(z(2026, 3, 8, 12))   # DST gap
        self.assertEqual(GlobalConfig().session_start_local, "17:00")

    def test_backtest_flattens_before_rollover_in_winter_and_summer(self):
        for start, expect in ((z(2026, 1, 5), z(2026, 1, 5, 21)), (z(2026, 7, 6), z(2026, 7, 6, 20))):
            g = gcfg(eod_cutoff_minutes_before_rollover=60, eod_cutoff_utc=None, market_data_max_age_seconds=30, max_open_positions=1,
                     max_currency_exposure_base={"EUR": Dc("5000000"), "USD": Dc("5000000")}, currency_floors={"EUR": Dc("-300000")})
            q = ticks_from_closes(long_scenario("flat", flat_minutes=800), start=start)
            r = run_backtest(q, settings(g=g, cfg=pair_cfg(cooldown_minutes=10, max_hold_minutes=1200, max_trades_session=20)))
            t = r.trades[0]
            self.assertEqual(t.exit_reason, ExitReason.END_OF_DAY)
            self.assertGreaterEqual(t.closed_ts, expect); self.assertLess(t.closed_ts, expect + timedelta(seconds=60))
            self.assertTrue(any("17:00 America/New_York" in n and "60 min before rollover" in n for n in r.notes))

    def test_unset_cutoff_blocks_a_run(self):
        from fxbot.backtesting.engine import BacktestConfigError
        g = gcfg(eod_cutoff_utc=None)
        with self.assertRaises(BacktestConfigError): run_backtest([], settings(g=g))

    def test_daily_returns_use_session_labels(self):
        from fxbot.reporting.metrics import daily_returns_from_trades
        a = trade(net=Dc("100"), ts=z(2026, 1, 6, 21, 0))        # closes 21:30 UTC winter: before rollover -> Tue session
        b = trade(net=Dc("50"), ts=z(2026, 1, 6, 22, 0))         # closes 22:30 UTC: after rollover -> Wed session
        r = daily_returns_from_trades([a, b], Dc("10000"))
        self.assertEqual(len(r), 2); self.assertAlmostEqual(r[0], 0.01); self.assertAlmostEqual(r[1], 50 / 10100)


class TestReentryReferenceModes(unittest.TestCase):
    def mk(self, mode, age=None):
        cfg = pair_cfg(cooldown_minutes=10, reentry_reference_reset=mode, reentry_reference_max_age_minutes=age)
        st = closed(Side.LONG, cfg)
        feed(st, [("1.0979", "1.0980"), ("1.0991", "1.0992")], start_min=5)
        return st

    def test_config_validation_and_default(self):
        self.assertEqual(PairConfig(symbol="EURUSD").reentry_reference_reset, "new_session")      # current behaviour
        with self.assertRaises(ConfigError): PairConfig(symbol="EURUSD", reentry_reference_reset="never")
        with self.assertRaises(ConfigError): PairConfig(symbol="EURUSD", reentry_reference_max_age_minutes=0)

    def test_new_session_mode_drops_the_reference_next_close_mode_preserves_it(self):
        reset, keep = self.mk("new_session"), self.mk("next_close")
        t = C + timedelta(hours=6)
        reset.new_session(t); keep.new_session(t)
        self.assertEqual((reset.state, reset.closed_ts, reset.post_close), (P.ANALYSING, None, None))
        self.assertEqual(keep.state, P.WAIT_FOR_REENTRY_CONFIRMATION)
        self.assertEqual((keep.closed_ts, keep.last_closed_side, keep.post_close.low_ask), (C, Side.LONG, Dc("1.0980")))
        now = t + timedelta(minutes=30); q = qt("1.0991", "1.0992", now)
        g = keep.gate(sg(Side.LONG, now), now, q, 10)                    # move measured from the PRESERVED low
        self.assertTrue(g.allowed, g.reasons); self.assertTrue(g.is_same_direction_reentry)
        g2 = reset.gate(sg(Side.LONG, now), now, q, 10)                  # fresh session: first-entry rules, no movement rule
        self.assertTrue(g2.allowed); self.assertFalse(g2.is_same_direction_reentry)
        stale_sig = Signal_(now, C - timedelta(minutes=1))
        self.assertFalse(keep.gate(stale_sig, now, q, 10).allowed)       # preserved close still demands a signal AFTER it

    def test_preserved_reference_is_not_kept_across_a_data_gap(self):
        keep = self.mk("next_close")
        t = C + timedelta(hours=40)                                       # e.g. the weekend closure
        keep.on_quote(qt("1.0995", "1.0996", t), t, 10)
        self.assertEqual((keep.post_close.gaps, keep.post_close.low_ask), (1, Dc("1.0996")))

    def test_max_age_restarts_the_reference(self):
        keep = self.mk("next_close", age=60)
        for i in range(1, 80):                                            # quotes every minute keep the feed alive
            t = C + timedelta(minutes=10 + i)
            keep.on_quote(qt("1.0990", "1.0991", t), t, 120)
        self.assertGreaterEqual(keep.post_close.age_resets, 1)
        self.assertGreater(keep.post_close.low_ask, Dc("1.0980"))         # the old low expired
        # gate also refuses to use an expired reference even if no quote restarted it yet
        st = self.mk("next_close", age=30)
        now = C + timedelta(minutes=45); q = qt("1.0991", "1.0992", now)
        g = st.gate(sg(Side.LONG, now), now, q, 10)
        self.assertFalse(g.allowed); self.assertEqual(g.directional_move_pct, Dc(0))

    def test_snapshot_keeps_reference_age_state(self):
        keep = self.mk("next_close", age=60)
        r = PairStrategy.from_snapshot(json.loads(json.dumps(keep.snapshot())), keep.cfg)
        self.assertEqual((r.post_close.ref_started_ts, r.post_close.age_resets), (keep.post_close.ref_started_ts, 0))

    def test_backtest_modes_differ_and_session_mode_never_reenters_across_a_session(self):
        q = synth_ticks(days=12, seed=5, tick_s=60)
        eng = EmaTrendParams(adx_min=15.0)
        res = {}
        for mode in ("new_session", "next_close"):
            res[mode] = run_backtest(q, settings(engine=eng, max_age=90, cfg=pair_cfg(cooldown_minutes=10, max_trades_session=20,
                                                                                         reentry_reference_reset=mode)))
        self.assertNotEqual(res["new_session"].settings_fp, res["next_close"].settings_fp)
        r = res["new_session"]
        prev = None
        for t in sorted(r.trades, key=lambda x: x.opened_ts):
            m = r.meta[t.position_id]
            if prev is not None and CAL.session_of(prev.closed_ts).label != CAL.session_of(t.opened_ts).label:
                self.assertFalse(m["same_direction_reentry"] or m["reversal"])      # first entry of a new session
            prev = t
        for mode, rr in res.items():
            self.assertTrue(any(f"reset: {mode}" in n for n in rr.notes))


def Signal_(now, signal_ts):
    from fxbot.signals.base import Signal
    return Signal("EURUSD", Side.LONG, signal_ts, signal_ts, True, ())


if __name__ == "__main__":
    unittest.main()
