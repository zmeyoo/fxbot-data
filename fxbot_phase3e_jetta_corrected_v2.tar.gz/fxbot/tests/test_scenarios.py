"""Simulated market scenarios replayed through the real exit engine (no broker, no DB)."""
import math
import unittest
from datetime import timedelta
from decimal import Decimal as Dc

from fxbot.core.types import Side
from fxbot.costs.model import assess_entry_costs
from fxbot.position_manager.exits import ExitPolicy, evaluate_exit
from fxbot.position_manager.position import ExitReason, PositionState as S
from fxbot.reporting.exit_analysis import trailing_gross_breakeven_report
from tests.fixtures import *

POL = ExitPolicy(max_hold_seconds=3 * 3600, max_quote_age_s=120)
P0 = Dc("1.10000")


def feed(mids, start=T0, step_min=1, spread="0.0001"):
    h = Dc(spread) / 2
    return [(start + timedelta(minutes=i * step_min), qt(Dc(m) - h, Dc(m) + h, start + timedelta(minutes=i * step_min)))
            for i, m in enumerate(mids)]


def pct(p):  # price at p percent from P0 (mid, quantised to 1/10 pip)
    return (P0 * (1 + Dc(str(p)) / 100)).quantize(Dc("0.00001"))


def run(pos, ticks, pol=POL):
    last, stops = None, []
    for ts, q in ticks:
        ev = evaluate_exit(pos, q, ts, pol, CTX)
        stops.append(pos.desired_stop)
        if q is not None:
            last = q
        if ev.exit:
            ref = q or last
            px = ref.exit_price(pos.side)
            pos.request_exit(ev.exit.reason, ts, snapshot={})
            pos.on_exit_fill(fill(pos.open_qty, px, ref, ts))
            return ev, stops
    return None, stops


def monotone(side, stops):
    return all((b >= a) if side is Side.LONG else (b <= a) for a, b in zip(stops, stops[1:]))


class TestScenarios(unittest.TestCase):
    def test_strong_uptrend_long_trails_to_profit_short_stopped(self):
        up = [pct(0.02 * i) for i in range(40)] + [pct(0.78 - 0.02 * i) for i in range(40)]
        pos = make_position(Side.LONG)
        ev, stops = run(pos, feed(up))
        self.assertEqual(ev.exit.reason, ExitReason.TRAILING_STOP)
        self.assertGreater(pos.realised_net, 0)
        self.assertGreaterEqual(pos.max_favourable_pct, Dc("0.7"))
        self.assertTrue(monotone(Side.LONG, stops))
        short = make_position(Side.SHORT)
        ev, _ = run(short, feed(up))
        self.assertEqual(ev.exit.reason, ExitReason.INITIAL_STOP)
        self.assertLess(short.realised_net, 0)

    def test_strong_downtrend_mirror(self):
        dn = [pct(-0.02 * i) for i in range(40)] + [pct(-0.78 + 0.02 * i) for i in range(40)]
        short = make_position(Side.SHORT)
        ev, stops = run(short, feed(dn))
        self.assertEqual(ev.exit.reason, ExitReason.TRAILING_STOP)
        self.assertGreater(short.realised_net, 0)
        self.assertTrue(monotone(Side.SHORT, stops))
        self.assertEqual(run(make_position(Side.LONG), feed(dn))[0].exit.reason, ExitReason.INITIAL_STOP)

    def test_sideways_market_exits_on_time_not_price(self):
        mids = [pct(0.04 * math.sin(i / 7)) for i in range(200)]
        for side in Side:
            pos = make_position(side)
            ev, _ = run(pos, feed(mids))
            self.assertEqual(ev.exit.reason, ExitReason.MAX_HOLD_TIME, side)
            self.assertGreaterEqual((pos.closed_ts - pos.opened_ts).total_seconds(), 3 * 3600)

    def test_whipsaw_trailing_exits_at_gross_breakeven_are_net_negative(self):
        records = []
        for _ in range(5):
            pos = make_position(Side.LONG)
            # bid peaks at exactly +0.10% (1.10110) -> protected level 0.00% -> stop at P0
            ev, _ = run(pos, feed([Dc("1.10000"), Dc("1.10050"), Dc("1.10115"), Dc("1.10050"), Dc("1.10005")]))
            self.assertEqual(ev.exit.reason, ExitReason.TRAILING_STOP)
            records.append(pos.to_trade_record(Dc("0.9091")))
        rep = trailing_gross_breakeven_report(records)
        self.assertEqual((rep.trailing_exits, rep.at_gross_breakeven_level, rep.of_which_negative_net), (5, 5, 5))
        self.assertEqual(rep.share_negative_net, Dc(1))

    def test_sudden_volatility_spike_locks_in_protected_level(self):
        pos = make_position(Side.LONG)
        ev, _ = run(pos, feed([pct(0), pct(0.30), pct(0.25), pct(0.19)]))
        self.assertEqual(ev.exit.reason, ExitReason.TRAILING_STOP)         # protected 0.20% breached
        self.assertGreater(pos.realised_net, 0)

    def test_wide_spread_is_rejected_before_entry(self):
        a = assess_entry_costs(side=Side.LONG, quote=qt("1.09900", "1.10100"), qty=Dc("100000"),
                               cfg=pair_cfg(), ctx=CTX, base="EUR", quote_ccy="USD")
        self.assertFalse(a.accepted)

    def test_news_spike_through_stop_loss_exceeds_nominal_stop(self):
        pos = make_position(Side.LONG)
        ev, _ = run(pos, feed([pct(0), pct(-0.35)]))
        self.assertEqual(ev.exit.reason, ExitReason.INITIAL_STOP)
        rec = pos.to_trade_record(Dc("0.9091"))
        nominal_stop_loss = Dc("1.10000") * Dc("0.001") * 100000
        self.assertGreater(-rec.net_pnl, nominal_stop_loss * 3)            # a stop is NOT a loss cap
        self.assertLess(rec.exit_avg, Dc("1.0989"))
        self.assertLess(rec.exit_move_pct, Dc("-0.10"))

    def test_gap_through_stop_after_weekend_short(self):
        pos = make_position(Side.SHORT)
        gap = [(T0 + timedelta(days=2, minutes=1), qt("1.10900", "1.11000", T0 + timedelta(days=2, minutes=1)))]
        pol = ExitPolicy(max_hold_seconds=10 * 86400, max_quote_age_s=60)
        ev, _ = run(pos, gap, pol)
        self.assertEqual(ev.exit.reason, ExitReason.INITIAL_STOP)
        self.assertGreater(pos.exit_avg, pos.desired_stop)                 # filled beyond the stop price

    def test_broker_disconnection_during_open_position(self):
        pos = make_position(Side.LONG)
        outage = [(T0 + timedelta(minutes=i), None) for i in range(1, 11)]
        ev, _ = run(pos, outage)
        self.assertIsNone(ev)                                              # no price decisions on missing data
        self.assertEqual(pos.state, S.OPEN_PROTECTED)                      # resting broker stop is the protection
        q = qt("1.09500", ts=T0 + timedelta(minutes=11))
        ev = evaluate_exit(pos, None, T0 + timedelta(minutes=5), POL, CTX)
        self.assertIn("data: no quote", ev.warnings)
        ev, _ = run(pos, [(T0 + timedelta(minutes=11), q)])                # reconnect below stop
        self.assertEqual(ev.exit.reason, ExitReason.INITIAL_STOP)
        # outage lasting past max hold: time exit still fires without any quote
        p2 = make_position(Side.SHORT)
        ev, _ = run(p2, [(T0, qt("1.1", ts=T0)), (T0 + timedelta(hours=3, minutes=1), None)])
        self.assertEqual(ev.exit.reason, ExitReason.MAX_HOLD_TIME)


if __name__ == "__main__":
    unittest.main()
