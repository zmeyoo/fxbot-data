import os
import random
import tempfile
import unittest
from dataclasses import replace
from datetime import datetime, timedelta, timezone
from decimal import Decimal as Dc

from fxbot.backtesting import report as R
from fxbot.backtesting.data import quote_report
from fxbot.backtesting.engine import run_backtest
from fxbot.backtesting.nullcheck import MeanSE, null_study, render
from fxbot.backtesting.sensitivity import (DEFAULT_LATENCIES, LatencyRow, common_period_trades, compare_walk_forward_windows,
                                           latency_rows_from_results, latency_section, latency_study, wf_methodology_section)
from fxbot.backtesting.splits import HoldoutAccessError, ResearchSession, SplitPlan
from fxbot.backtesting.sweeps import ParamGrid, VariantResult, slice_source
from fxbot.backtesting.synth import synth_ticks
from fxbot.backtesting.walkforward import walk_forward, walk_forward_by_axis
from fxbot.signals.ema_trend import EmaTrendParams
from tests.bt_helpers import settings
from tests.bt_scenarios import densify, long_scenario, ticks_from_closes
from tests.fixtures import *

U = timezone.utc


class TestLatency(unittest.TestCase):
    def test_default_set_covers_the_required_latencies(self):
        self.assertTrue({0.5, 1, 2, 5} <= set(DEFAULT_LATENCIES))

    def test_all_four_latencies_on_dense_quotes_shift_entry_and_exit_by_exactly_the_latency(self):
        base = ticks_from_closes(long_scenario())
        dense = densify(base, datetime(2026, 1, 5, 15, 0, tzinfo=U), datetime(2026, 1, 5, 16, 45, tzinfo=U), 0.5)
        self.assertGreater(len(dense), len(base) + 10000)
        res, entries, exits = {}, {}, {}
        for lat in (0.5, 1, 2, 5):
            r = run_backtest(dense, settings(latency_s=Dc(str(lat))))
            self.assertEqual(len(r.trades), 1, lat)
            t = r.trades[0]; m = r.meta[t.position_id]
            self.assertEqual((m["entry_delay_s"], m["exit_delay_s"]), (lat, lat))       # fills at order time + latency, exactly
            res[lat], entries[lat], exits[lat] = r, t.opened_ts, t.closed_ts
        self.assertLess(entries[0.5], entries[1]); self.assertLess(entries[1], entries[2]); self.assertLess(entries[2], entries[5])
        self.assertEqual(entries[1] - entries[0.5], timedelta(seconds=0.5))
        self.assertEqual(len({res[l].settings_fp for l in res}), 4)                       # latency is part of the run fingerprint
        rows = latency_rows_from_results([VariantResult(replace_variant(l), res[l]) for l in res])
        txt = latency_section(rows)
        for needle in ("| 0.5 |", "| 1 |", "| 2 |", "| 5 |", "NOT assumed representative", "paper-trading latency"):
            self.assertIn(needle, txt)

    def test_latency_below_quote_granularity_is_flagged_and_study_is_development_only(self):
        q = synth_ticks(days=12, seed=41, tick_s=60)
        plan = SplitPlan(q[0].market_ts, q[-1].market_ts + timedelta(seconds=60), 0.2, 4, 2, 2, 180, False, 1500, 1)
        rep = quote_report(q, "EURUSD")
        with tempfile.TemporaryDirectory() as d:
            sess = ResearchSession(q, plan, rep.sha256, os.path.join(d, "r.json"))
            s = settings(engine=EmaTrendParams(adx_min=15.0), max_age=90)
            rows = latency_study(sess, s, plan.data_start + plan.warmup, plan.holdout_start)
            self.assertEqual([float(r.latency_s) for r in rows], [0.5, 1, 2, 5])
            self.assertEqual(rows[0].summary.n, rows[1].summary.n)                        # 60s ticks: 0.5s vs 1s cannot differ
            self.assertIn("not distinguishable", latency_section(rows, rep))
            with self.assertRaises(HoldoutAccessError):
                latency_study(sess, s, plan.data_start + plan.warmup, plan.holdout_start + timedelta(days=1))
            self.assertFalse(os.path.exists(os.path.join(d, "r.json")))


def replace_variant(lat):
    from fxbot.backtesting.sweeps import Variant
    return Variant(f"latency_s={lat}", {}, {"bt.latency_s": lat})


class TestWalkForwardComparisons(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.q = synth_ticks(days=14, seed=51, tick_s=60)
        cls.rep = quote_report(cls.q, "EURUSD")
        cls.plan = SplitPlan(cls.q[0].market_ts, cls.q[-1].market_ts + timedelta(seconds=60), 0.2, 4, 2, 2, 180, False, 1500, 2)
        cls.s = settings(engine=EmaTrendParams(adx_min=15.0), max_age=90)
        cls.grid = ParamGrid({"engine.adx_min": [15.0]})
        cls.d = tempfile.TemporaryDirectory(); cls.reg = os.path.join(cls.d.name, "r.json")
        cls.rows = compare_walk_forward_windows(cls.q, cls.rep, cls.s, cls.grid, cls.plan, cls.reg, train_days=(2, 4, 6, 60), min_trades_train=1)

    @classmethod
    def tearDownClass(cls):
        cls.d.cleanup()

    def test_each_training_window_is_run_on_development_data_only_and_unusable_ones_are_reported(self):
        ok = [r for r in self.rows if r.wf is not None]
        self.assertEqual([r.train_days for r in ok], [2, 4, 6])
        bad = self.rows[-1]
        self.assertEqual((bad.train_days, bad.wf), (60, None)); self.assertIn("not computable", bad.error)
        hs = self.plan.holdout_start
        for r in ok:
            for f in r.wf.folds:
                self.assertEqual((f.fold.test_start - f.fold.train_end), timedelta(minutes=180))
                self.assertLessEqual(f.fold.test_end, hs)
                self.assertEqual(f.fold.train_end - f.fold.train_start, timedelta(days=r.train_days))
        self.assertFalse(os.path.exists(self.reg))                                     # no holdout use was recorded

    def test_longer_windows_start_oos_later_and_common_period_is_like_for_like(self):
        ok = [r for r in self.rows if r.wf is not None]
        starts = [r.wf.folds[0].fold.test_start for r in ok]
        self.assertEqual(starts, sorted(starts)); self.assertLess(starts[0], starts[-1])
        start, common = common_period_trades(self.rows)
        self.assertEqual(start, max(starts))
        for lab, ts in common.items():
            self.assertTrue(all(t.opened_ts >= start for t in ts), lab)
        md = wf_methodology_section(self.rows, Dc("100000"))
        for needle in ("train 2d / test 2d", "train 6d / test 2d", "Like-for-like", "untouched", "not computable"):
            self.assertIn(needle, md)

    def test_holdout_boundary_and_registry_key_are_identical_for_all_windows(self):
        keys = {replace(self.plan, wf_train_days=d).holdout_fingerprint() for d in (2, 4, 20, 60, 120)}
        self.assertEqual(len(keys), 1)
        self.assertEqual(len({replace(self.plan, wf_train_days=d).holdout_start for d in (2, 60, 120)}), 1)

    def test_changing_only_holdout_data_changes_nothing_in_the_comparison(self):
        hs = self.plan.holdout_start
        poisoned = [x if x.market_ts < hs else Quote(x.pair, x.bid * 2, x.ask * 2, x.market_ts, x.received_ts) for x in self.q]
        rows = compare_walk_forward_windows(poisoned, self.rep, self.s, self.grid, self.plan, self.reg, (2, 4), 1)
        for a, b in zip(rows, [r for r in self.rows if r.train_days in (2, 4)]):
            self.assertEqual(a.wf.oos_trades, b.wf.oos_trades)

    def test_slice_source_reads_only_the_requested_window(self):
        class Spy(list):
            reads = set()
            def __getitem__(self, i):
                if isinstance(i, int):
                    Spy.reads.add(i)
                return super().__getitem__(i)
        spy = Spy(self.q)
        out = slice_source(spy, self.q[1000].market_ts, self.q[1100].market_ts)
        self.assertEqual(len(out), 100)
        self.assertTrue(all(i < 1200 or i > len(self.q) // 2 - 1 or True for i in Spy.reads))
        self.assertLess(len(Spy.reads), 60)                                            # O(log n) probes, not a full scan

    def test_reentry_reference_comparison_and_frequency_report(self):
        g = ParamGrid({"pair.reentry_reference_reset": ["new_session", "next_close"]}).variants()
        sess = ResearchSession(self.q, self.plan, self.rep.sha256, self.reg)
        by = walk_forward_by_axis(sess, self.s, g, "pair.reentry_reference_reset", 1)
        self.assertEqual(set(by), {"new_session", "next_close"})
        md = R.frequency_section(by)
        for lab in by:
            self.assertIn(f"| {lab} |", md)
        for lab, wf in by.items():
            n = len(wf.oos_trades)
            same = sum(1 for t in wf.oos_trades if wf.oos_meta[t.position_id]["same_direction_reentry"])
            rev = sum(1 for t in wf.oos_trades if wf.oos_meta[t.position_id]["reversal"])
            self.assertLessEqual(same + rev, n)
        self.assertIn("movement-threshold rejections", md)
        self.assertFalse(os.path.exists(self.reg))


class TestNullStudyStatistics(unittest.TestCase):
    def fake(self, g, c):
        return trade(net=Dc(str(g - c)), costs=Dc(str(c)))

    def test_units_means_and_standard_errors_are_computed_as_documented(self):
        rnd = random.Random(1)
        seeds = [[self.fake(rnd.gauss(0, 100), 30) for _ in range(25)] for _ in range(12)]          # equal cluster sizes
        s = null_study(seeds)
        gross = [float(t.gross_pnl_base) for sd in seeds for t in sd]
        import statistics as st
        self.assertAlmostEqual(s.gross.mean, st.fmean(gross), places=9)                           # pooled over trades
        self.assertAlmostEqual(s.gross.se_naive, st.stdev(gross) / 300 ** 0.5, places=9)
        seed_means = [st.fmean([float(t.gross_pnl_base) for t in sd]) for sd in seeds]
        self.assertAlmostEqual(s.gross.se_cluster, st.stdev(seed_means) / 12 ** 0.5, places=9)    # equal n => ratio estimator = classic
        self.assertAlmostEqual(s.net.mean, s.gross.mean - s.costs.mean, places=9)                 # net = gross - costs
        self.assertAlmostEqual(s.costs.mean, 30.0, places=9)
        self.assertAlmostEqual(s.min_detectable_gross_2se, 2 * s.gross.se_naive)
        txt = render(s)
        for needle in ("unit = base currency per trade", "pooled over trades", "SE naive", "SE by seed", "95% CI"):
            self.assertIn(needle, txt)
        m = MeanSE(9.18, 6.84, 7.08)
        self.assertAlmostEqual(m.z, 1.342, places=2); self.assertAlmostEqual(m.p_two_sided, 0.18, places=2)
        self.assertLess(m.ci95[0], 0); self.assertGreater(m.ci95[1], 0)


if __name__ == "__main__":
    unittest.main()


class TestEodCutoffStudy(unittest.TestCase):
    def test_global_axis_applies_and_cutoffs_shift_exits_by_the_stated_minutes(self):
        from fxbot.backtesting.sweeps import Variant, apply_variant
        s0 = settings(g=gcfg(eod_cutoff_minutes_before_rollover=30, eod_cutoff_utc=None, market_data_max_age_seconds=30, max_open_positions=1,
                             max_currency_exposure_base={"EUR": Dc("5000000"), "USD": Dc("5000000")}, currency_floors={"EUR": Dc("-300000")}),
                      cfg=pair_cfg(cooldown_minutes=10, max_hold_minutes=1200, max_trades_session=20))
        self.assertEqual(s0.gcfg.eod_cutoff_minutes_before_rollover, 30)
        v = apply_variant(s0, Variant("x", {}, {"global.eod_cutoff_minutes_before_rollover": 15}))
        self.assertEqual((v.gcfg.eod_cutoff_minutes_before_rollover, v.gcfg.session_start_local), (15, "17:00"))
        with self.assertRaises(Exception): apply_variant(s0, Variant("x", {}, {"global.nonsense": 1}))
        q = ticks_from_closes(long_scenario("flat", flat_minutes=800))               # winter: session ends 22:00 UTC
        for m in (15, 30, 60):
            r = run_backtest(q, apply_variant(s0, Variant("x", {}, {"global.eod_cutoff_minutes_before_rollover": m})))
            t = r.trades[0]
            exp = datetime(2026, 1, 5, 22, 0, tzinfo=U) - timedelta(minutes=m)
            self.assertGreaterEqual(t.closed_ts, exp); self.assertLess(t.closed_ts, exp + timedelta(seconds=60))

    def test_study_runs_on_development_data_only_and_reports_the_provisional_value(self):
        from fxbot.backtesting.sensitivity import EodRow, eod_cutoff_study, eod_section
        q = synth_ticks(days=12, seed=61, tick_s=60)
        plan = SplitPlan(q[0].market_ts, q[-1].market_ts + timedelta(seconds=60), 0.2, 4, 2, 2, 180, False, 1500, 1)
        g = gcfg(eod_cutoff_minutes_before_rollover=30, eod_cutoff_utc=None, market_data_max_age_seconds=90, max_open_positions=1,
                 max_currency_exposure_base={"EUR": Dc("5000000"), "USD": Dc("5000000")}, currency_floors={"EUR": Dc("-300000")})
        with tempfile.TemporaryDirectory() as d:
            sess = ResearchSession(q, plan, quote_report(q, "EURUSD").sha256, os.path.join(d, "r.json"))
            base = settings(g=g, engine=EmaTrendParams(adx_min=15.0))
            rows = eod_cutoff_study(sess, base, plan.data_start + plan.warmup, plan.holdout_start)
            self.assertEqual([r.minutes for r in rows], [15, 30, 60])
            self.assertTrue(all(isinstance(r, EodRow) for r in rows))
            md = eod_section(rows, 30)
            self.assertIn("| 30 (provisional) |", md); self.assertIn("holdout is untouched", md)
            with self.assertRaises(HoldoutAccessError):
                eod_cutoff_study(sess, base, plan.data_start + plan.warmup, plan.holdout_start + timedelta(days=1))
            self.assertFalse(os.path.exists(os.path.join(d, "r.json")))
