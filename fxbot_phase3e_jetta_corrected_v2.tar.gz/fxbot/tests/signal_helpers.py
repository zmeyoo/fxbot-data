import math
import random
from datetime import datetime, timedelta, timezone

from fxbot.market_data.bars import Bar, aggregate

START = datetime(2026, 1, 5, 0, 0, tzinfo=timezone.utc)      # aligned to 15m/5m/1m boundaries


def bars_from_closes(closes, start=START, tf_s=60, wick=0.00004, ticks=30):
    out, prev = [], closes[0]
    for i, c in enumerate(closes):
        o = prev
        s = start + timedelta(seconds=i * tf_s)
        out.append(Bar(s, s + timedelta(seconds=tf_s), o, max(o, c) + wick, min(o, c) - wick, c, ticks, 1))
        prev = c
    return out


def uptrend_with_pullback(n_trend=900, drift=0.000025, dip=7, rebound=3, base=1.10000, seed=3):
    """Steady uptrend, a short dip, then a rebound: stochastic cross-up lands in the last bars."""
    rnd = random.Random(seed)
    px, out = base, []
    for i in range(n_trend):
        px += drift + rnd.uniform(-0.00002, 0.00002)
        out.append(px)
    for i in range(dip):
        px -= 0.00006
        out.append(px)
    for i in range(rebound):
        px += 0.00007
        out.append(px)
    return out


def mirror(closes, centre=1.10000):
    return [2 * centre - c for c in closes]


def sideways(n=900, base=1.10000, amp=0.0002, seed=5):
    rnd = random.Random(seed)
    return [base + amp * math.sin(i / 9.0) + rnd.uniform(-0.00003, 0.00003) for i in range(n)]


def pipeline(bars_1m, as_of):
    """The exact way a caller must build engine inputs: only closed bars as of `as_of`."""
    b1 = [b for b in bars_1m if b.end_ts <= as_of]
    return b1, aggregate(bars_1m, 300, as_of), aggregate(bars_1m, 900, as_of)
