"""TEST FIXTURES ONLY: hour files in the real bi5 container format, built in memory/temp dirs to exercise the pipeline.
They are never written to a deliverable and are NOT market data."""
import random
from datetime import datetime, timedelta, timezone

from fxbot.data_sources.dukascopy import NetworkUnavailable, FetchResult, encode_bi5, expected_closed_hour, hour_url

U = timezone.utc


def make_ticks(seed, n=300, base_pts=110000, spread_pts=8):
    rnd = random.Random(seed)
    ms, px, out = 0, base_pts, []
    for _ in range(n):
        ms += rnd.randint(1, 20000)
        if ms >= 3_600_000:
            ms = 3_599_999
        px += rnd.randint(-3, 3)
        out.append((ms, px + spread_pts, px, round(rnd.uniform(0.1, 3.0), 2), round(rnd.uniform(0.1, 3.0), 2)))
    return sorted(out, key=lambda t: t[0])


def week_files(start, end, n=300, closed_as="empty", skip=()):
    """url -> bytes for every hour in [start, end): ticks in open hours, empty (or absent => 404) in the weekly closure."""
    files = {}
    h = start
    i = 0
    while h < end:
        if h in skip:
            pass
        elif expected_closed_hour(h):
            if closed_as == "empty":
                files[hour_url("EURUSD", h)] = b""
        else:
            files[hour_url("EURUSD", h)] = encode_bi5(make_ticks(i, n))
        h += timedelta(hours=1)
        i += 1
    return files


class FakeServer:
    def __init__(self, files, fail_after=None):
        self.files, self.calls, self.fail_after = dict(files), [], fail_after

    def fetch(self, url):
        self.calls.append(url)
        if self.fail_after is not None and len(self.calls) > self.fail_after:
            raise RuntimeError("process killed")                      # simulates the machine dying mid-run
        if url in self.files:
            return FetchResult(200, self.files[url], {"etag": '"x"', "last-modified": "Mon, 01 Jan 2024 00:00:00 GMT"})
        return FetchResult(404)

    def head(self, url):
        r = self.fetch(url)
        return FetchResult(r.status, b"", {"content-length": str(len(r.body))})


class DownServer:
    def __init__(self, exc=None):
        self.calls = []
        self.exc = exc or NetworkUnavailable("Name or service not known")

    def fetch(self, url):
        self.calls.append(url); raise self.exc

    head = fetch


class ScriptedServer:
    """status codes per call, then the real file"""
    def __init__(self, files, script):
        self.files, self.script, self.calls = files, list(script), 0

    def fetch(self, url):
        self.calls += 1
        if self.script:
            c = self.script.pop(0)
            if c == "net":
                raise NetworkUnavailable("timed out")
            return FetchResult(c)
        return FetchResult(200, self.files[url]) if url in self.files else FetchResult(404)


# ---------------------------------------------------------------- decoder-verification fixtures
import struct as _struct
from fxbot.data_sources.dukascopy import hours_between as _hours_between


def ticks_full_hour(seed, n=400, base_pts=110000, spread_pts=8, swap=False):
    """Ticks spread over the WHOLE hour (first within 20 s, last within the final 20 s), so closure-boundary checks are meaningful."""
    rnd = random.Random(seed)
    offs = sorted([rnd.randint(0, 20000)] + [rnd.randint(0, 3_599_999) for _ in range(n - 2)] + [rnd.randint(3_580_000, 3_599_000)])
    px, out = base_pts, []
    for o in offs:
        px += rnd.randint(-3, 3)
        ask, bid = px + spread_pts, px
        out.append((o, bid, ask, round(rnd.uniform(0.1, 3), 2), round(rnd.uniform(0.1, 3), 2)) if swap else (o, ask, bid, round(rnd.uniform(0.1, 3), 2), round(rnd.uniform(0.1, 3), 2)))
    return out


def verify_server(start, end, hours=None, swap=False, base_pts=110000, shift_hours=0, sample="match", garbage_hours=(), custom=None):
    """FakeServer holding only the hours the verifier needs (or all hours in [start,end) if hours is None)."""
    from fxbot.data_sources.verify import plan_verification_hours, SAMPLE_HOUR
    plan = plan_verification_hours(start, end)
    need = [h for k in ("active", "closure", "reopen") for h in plan[k]] if hours is None else list(hours)
    files = {}
    for i, h in enumerate(sorted(set(need))):
        closed = expected_closed_hour(h - timedelta(hours=shift_hours))
        if h in garbage_hours:
            files[hour_url("EURUSD", h)] = b"this is not an lzma stream at all"
        elif custom and h in custom:
            files[hour_url("EURUSD", h)] = custom[h]
        elif closed:
            files[hour_url("EURUSD", h)] = b""
        else:
            files[hour_url("EURUSD", h)] = encode_bi5(ticks_full_hour(i, swap=swap, base_pts=base_pts))
    f32 = lambda v: _struct.unpack(">f", _struct.pack(">f", v))[0]
    if sample == "match":
        files[hour_url("EURUSD", SAMPLE_HOUR)] = encode_bi5([(104, 111369, 111361, 0.75, 0.75), (256, 111371, 111361, f32(0.94), 1.5)])
    elif sample == "other":
        files[hour_url("EURUSD", SAMPLE_HOUR)] = encode_bi5(ticks_full_hour(77))
    return FakeServer(files)
