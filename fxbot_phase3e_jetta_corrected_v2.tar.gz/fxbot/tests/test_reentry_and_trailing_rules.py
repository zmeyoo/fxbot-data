"""Tests for the 2026-11-07 amendments: same-direction re-entry, trailing clarification,
independent per-pair parameters, persistence/restore, safe stop replacement."""
import json
import random
import unittest
from datetime import timedelta
from decimal import Decimal as Dc

from fxbot.config.audit import ConfigStore
from fxbot.config.schema import AppConfig
from fxbot.core.types import Side
from fxbot.instruments.spec import PairSpec
from fxbot.position_manager.exits import ExitPolicy, evaluate_exit
from fxbot.position_manager.position import ExitReason, Position, PositionState as S, StopParams
from fxbot.position_manager.stop_orders import StopAction, plan_stop_update
from fxbot.position_manager.trailing import (favourable_move_pct, trailing_active, trailing_stop_price,
                                             trailing_threshold_from_extreme)
from fxbot.signals.base import Signal
from fxbot.strategy.pair_state import PairState as P, PairStrategy
from tests.fixtures import *

XSPEC = PairSpec("AAAUSD", "AAA", "USD", Dc("0.01"), Dc("1"), Dc("1"), Dc("1000000"))
POL = ExitPolicy(max_hold_seconds=10 ** 6, max_quote_age_s=10 ** 6)
EPS = Dc("1E-12")


def xq(bid, ask=None, ts=T0):
    return qt(bid, ask if ask is not None else Dc(bid) + Dc("0.01"), ts, pair="AAAUSD")


def xpos(side, price="100.00", params=None):
    return make_position(side, price, "1000", spec=XSPEC, params=params)


class TestTrailingSpecification(unittest.TestCase):
    def test_long_example_entry_100_extreme_101_threshold_100_90(self):
        pos = xpos(Side.LONG)                                          # fill 100.00 (ask)
        self.assertIsNone(evaluate_exit(pos, xq("101.00"), T0, POL, None).exit)
        self.assertEqual(pos.p_best, Dc("101.00"))
        self.assertTrue(pos.trailing_engaged)
        self.assertEqual(pos.desired_stop, Dc("100.90"))               # +0.90%
        self.assertEqual(favourable_move_pct(Side.LONG, pos.avg_entry, pos.desired_stop), Dc("0.9"))
        for bid in ("100.95", "100.91"):                                # stays open while above 100.90
            self.assertIsNone(evaluate_exit(pos, xq(bid), T0, POL, None).exit, bid)
        ev = evaluate_exit(pos, xq("100.90"), T0, POL, None)            # reaches the threshold
        self.assertEqual(ev.exit.reason, ExitReason.TRAILING_STOP)

    def test_short_example_mirror_threshold_99_10(self):
        pos = xpos(Side.SHORT)                                         # fill 100.00 (bid)
        evaluate_exit(pos, xq("98.99", "99.00"), T0, POL, None)         # lowest ASK 99.00 (+1.00%)
        self.assertEqual(pos.p_best, Dc("99.00"))
        self.assertEqual(pos.desired_stop, Dc("99.10"))
        self.assertIsNone(evaluate_exit(pos, xq("99.08", "99.09"), T0, POL, None).exit)
        ev = evaluate_exit(pos, xq("99.09", "99.10"), T0, POL, None)
        self.assertEqual(ev.exit.reason, ExitReason.TRAILING_STOP)

    def test_distance_is_from_the_extreme_not_entry_and_not_a_share_of_profit(self):
        pos = xpos(Side.LONG)
        gaps = []
        for hi in ("101.00", "102.00", "105.00"):
            evaluate_exit(pos, xq(hi), T0, POL, None)
            gaps.append(Dc(hi) - pos.desired_stop)
        self.assertEqual(gaps, [Dc("0.10")] * 3)                        # constant distance from the extreme
        self.assertEqual(pos.desired_stop, Dc("104.90"))                # NOT entry+90% of profit (=104.50)

    def test_distance_is_anchored_to_entry_price_not_a_percentage_of_the_extreme(self):
        p0 = Dc("100.00")
        for ext, expect_long in (("101.00", "100.90"), ("105.00", "104.90"), ("150.00", "149.90")):
            t = trailing_threshold_from_extreme(Side.LONG, p0, Dc(ext), Dc("0.10"))
            self.assertEqual(t, Dc(expect_long))                              # fixed 0.10 price amount (0.10% of ENTRY)
            self.assertNotEqual(t, Dc(ext) * Dc("0.999"))                      # not 0.10% of the extreme
        for ext, expect_short in (("99.00", "99.10"), ("95.00", "95.10"), ("50.00", "50.10")):
            self.assertEqual(trailing_threshold_from_extreme(Side.SHORT, p0, Dc(ext), Dc("0.10")), Dc(expect_short))
        # the distance stays a fixed price amount for the whole life of the position
        d = {trailing_threshold_from_extreme(Side.LONG, p0, e, Dc("0.10")) - e for e in (Dc("101"), Dc("103"), Dc("120"))}
        self.assertEqual(d, {Dc("-0.10")})

    def test_activation_boundary_exact(self):
        p0 = Dc("1.10000")
        self.assertTrue(trailing_active(Side.LONG, p0, Dc("1.10110"), Dc("0.10")))      # exactly +0.10%
        self.assertFalse(trailing_active(Side.LONG, p0, Dc("1.10109"), Dc("0.10")))
        self.assertTrue(trailing_active(Side.SHORT, p0, Dc("1.09890"), Dc("0.10")))
        self.assertFalse(trailing_active(Side.SHORT, p0, Dc("1.09891"), Dc("0.10")))
        self.assertEqual(trailing_stop_price(Side.LONG, p0, Dc("1.10110"), Dc("0.10"), Dc("0.10")), p0)

    def test_threshold_moves_with_each_new_extreme_and_holds_on_pullbacks(self):
        pos = make_position(Side.LONG)
        seq = ["1.10120", "1.10200", "1.10150", "1.10260", "1.10260", "1.10100", "1.10300"]
        seen, best = [], Dc("1.1")
        for b in seq:
            pos.update_market(qt(b))
            best = max(best, Dc(b))
            seen.append(pos.desired_stop)
            self.assertEqual(pos.desired_stop, best - Dc("1.10000") * Dc("0.001"))   # extreme - distance
        self.assertEqual(seen[1], seen[2])                              # pullback: unchanged
        self.assertEqual(seen[3], seen[4])
        self.assertTrue(all(b >= a for a, b in zip(seen, seen[1:])))

    def test_distance_larger_than_activation_never_loosens_below_initial_stop(self):
        pos = make_position(Side.LONG, params=StopParams(Dc("0.10"), Dc("0.10"), Dc("0.30")))
        pos.update_market(qt("1.10110"))                                # trailing active; raw threshold below P0
        self.assertTrue(pos.trailing_engaged)
        self.assertEqual(pos.desired_stop, Dc("1.09890"))              # initial stop kept (tighter)
        self.assertEqual(pos.stop_basis, "initial")

    def test_property_price_form_equals_percentage_point_form(self):
        rnd = random.Random(5)
        for _ in range(2000):
            p0 = Dc(rnd.randint(8000, 20000)) / 10000
            d = Dc(rnd.randint(1, 60)) / 1000
            for side in Side:
                ext = p0 * (1 + side.sign * Dc(rnd.randint(1, 120)) / 10000)
                rmax = favourable_move_pct(side, p0, ext)
                pp_form = p0 * (1 + side.sign * (rmax - d) / 100)
                self.assertLess(abs(trailing_threshold_from_extreme(side, p0, ext, d) - pp_form), EPS)

    def test_property_long_short_symmetry(self):
        rnd = random.Random(11)
        for _ in range(2000):
            p0 = Dc(rnd.randint(8000, 20000)) / 10000
            act, d = Dc(rnd.randint(1, 30)) / 100, Dc(rnd.randint(1, 30)) / 100
            move = Dc(rnd.randint(0, 80)) / 100                         # favourable move in % of p0
            el, es = p0 * (1 + move / 100), p0 * (1 - move / 100)
            tl = trailing_stop_price(Side.LONG, p0, el, act, d)
            ts_ = trailing_stop_price(Side.SHORT, p0, es, act, d)
            self.assertEqual(tl is None, ts_ is None)                   # same activation decision
            if tl is not None:
                self.assertLess(abs((tl - p0) + (ts_ - p0)), EPS)       # mirror images around p0

    def test_property_exit_only_on_retracement_and_stop_never_loosens(self):
        rnd = random.Random(2024)
        for _ in range(250):
            act = Dc(rnd.randint(5, 20)) / 100
            dist = Dc(rnd.randint(2, 20)) / 100
            side = rnd.choice(list(Side))
            pos = make_position(side, params=StopParams(Dc("0.10"), act, dist))
            mid, last = Dc("1.10000"), pos.desired_stop
            for i in range(400):
                mid += Dc(rnd.randint(-25, 30)) * Dc("0.00001")
                q = qt(mid - Dc("0.00005"), mid + Dc("0.00005"))
                ev = evaluate_exit(pos, q, T0, POL, None)
                stop = pos.desired_stop
                self.assertTrue(stop >= last if side is Side.LONG else stop <= last)
                last = stop
                if ev.exit:
                    self.assertEqual(ev.exit.reason in (ExitReason.TRAILING_STOP, ExitReason.INITIAL_STOP), True)
                    self.assertTrue(q.bid <= stop if side is Side.LONG else q.ask >= stop)
                    break
                self.assertTrue(q.bid > stop if side is Side.LONG else q.ask < stop)   # open only while beyond it

    def test_executable_side_not_mid_or_last(self):
        pos = make_position(Side.LONG)
        pos.update_market(qt("1.10000", "1.10400"))                     # mid 1.10200 would activate trailing
        self.assertFalse(pos.trailing_engaged)
        self.assertEqual(pos.p_best, Dc("1.10000"))
        sh = make_position(Side.SHORT)
        sh.update_market(qt("1.09600", "1.10000"))                      # mid 1.09800 would activate trailing
        self.assertFalse(sh.trailing_engaged)

    def test_positions_are_independent(self):
        a = make_position(Side.LONG, params=StopParams(Dc("0.10"), Dc("0.10"), Dc("0.10")))
        b = make_position(Side.LONG, params=StopParams(Dc("0.20"), Dc("0.30"), Dc("0.05")))
        a.update_market(qt("1.10500"))
        self.assertTrue(a.trailing_engaged); self.assertFalse(b.trailing_engaged)
        self.assertEqual(b.p_best, Dc("1.10000")); self.assertEqual(b.desired_stop, Dc("1.09780"))


class TestPersistenceAndStopReplacement(unittest.TestCase):
    def test_snapshot_roundtrip_and_trailing_survives_restart(self):
        pos = make_position(Side.LONG)
        pos.update_market(qt("1.10300"))
        pos.mark_trailing_if_protected(T0)
        snap = json.loads(json.dumps(pos.snapshot()))                   # JSON-safe
        r = Position.from_snapshot(snap, SPEC)
        self.assertEqual(r.snapshot(), pos.snapshot())
        self.assertEqual((r.p_best, r.desired_stop, r.trailing_engaged, r.state),
                         (pos.p_best, pos.desired_stop, True, S.TRAILING_ACTIVE))
        # restart protocol: reconcile with broker, then re-protect at the RATCHETED level
        r.mark_error(T0, "restart"); r.resume_after_reconciliation(T0, Dc("100000"))
        self.assertEqual(r.state, S.OPEN_UNPROTECTED)
        self.assertEqual(r.protection_target(), (Dc("1.10190"), Dc("100000")))   # 1.10300 - 0.00110
        r.update_market(qt("1.10000"))                                  # lower price must not reset anything
        self.assertEqual((r.p_best, r.desired_stop), (Dc("1.10300"), Dc("1.10190")))
        plan = plan_stop_update(r, supports_modify=True)
        self.assertEqual((plan.action, plan.price), (StopAction.PLACE_NEW, Dc("1.10190")))

    def test_snapshot_restores_exits_costs_and_duplicate_protection(self):
        pos = make_position(Side.SHORT)
        pos.request_exit(ExitReason.MANUAL, T0)
        f = fill("40000", "1.09900", qt("1.0990"), eid="X1")
        pos.on_exit_fill(f)
        r = Position.from_snapshot(json.loads(json.dumps(pos.snapshot())), SPEC)
        self.assertFalse(r.on_exit_fill(f))                              # seen exec ids survive the restart
        self.assertEqual(r.realised_net, pos.realised_net)
        self.assertEqual(r.entry_costs_open, pos.entry_costs_open)
        with self.assertRaises(Exception):
            Position.from_snapshot(pos.snapshot(), JPY)

    def test_planner_modify_vs_replace_and_never_loosens(self):
        pos = make_position(Side.LONG)                                  # broker stop at 1.09890
        self.assertEqual(plan_stop_update(pos, True).action, StopAction.NONE)
        pos.update_market(qt("1.10300"))                                # desired 1.10190 > broker 1.09890
        m = plan_stop_update(pos, True)
        self.assertEqual((m.action, m.price, m.cancel_order_id), (StopAction.MODIFY_IN_PLACE, Dc("1.10190"), "S1"))
        r = plan_stop_update(pos, False)
        self.assertEqual(r.action, StopAction.REPLACE_NEW_THEN_CANCEL_OLD)
        self.assertLess(r.steps.index("SUBMIT_NEW_STOP"), r.steps.index("CANCEL_OLD_STOP"))
        self.assertLess(r.steps.index("AWAIT_ACK_NEW"), r.steps.index("CANCEL_OLD_STOP"))   # cancel only after ack
        self.assertTrue(any("QUERY_BROKER" in s for s in r.steps))
        pos.confirm_protection("S2", Dc("1.10190"), Dc("100000"), T0)
        self.assertEqual(plan_stop_update(pos, True).action, StopAction.NONE)
        pos.broker_stop = pos.broker_stop.__class__("S3", Dc("1.10250"), Dc("100000"), T0)   # already tighter
        self.assertEqual(plan_stop_update(pos, True).action, StopAction.NONE)

    def test_planner_partial_cover_unprotected_and_pending_exit(self):
        pos = make_position(Side.SHORT, protect=False)
        self.assertEqual(plan_stop_update(pos, True).action, StopAction.PLACE_NEW)
        pos.confirm_protection("S1", pos.desired_stop, Dc("50000"), T0)           # half covered
        self.assertEqual(pos.state, S.OPEN_UNPROTECTED)
        p = plan_stop_update(pos, True)
        self.assertEqual((p.action, p.qty, p.price), (StopAction.MODIFY_IN_PLACE, Dc("100000"), pos.desired_stop))
        pos.confirm_protection("S2", pos.desired_stop, Dc("100000"), T0)
        pos.request_exit(ExitReason.MANUAL, T0)
        self.assertEqual(plan_stop_update(pos, True).action, StopAction.NONE)


def sg(direction, ts, valid=True):
    return Signal("EURUSD", direction, ts, ts, valid, ("fresh confirmed signal",))


C = T0 + timedelta(minutes=30)                                          # time of the previous close


def closed(side, cfg=None):
    st = PairStrategy(cfg or pair_cfg(cooldown_minutes=10))
    st.start(T0); st.on_entry_requested(T0); st.on_position_opened(T0)
    st.on_position_closed(side, C)
    return st


def feed(st, asks_bids, start_min=1):
    last = None
    for i, (bid, ask) in enumerate(asks_bids):
        last = qt(bid, ask, C + timedelta(minutes=start_min + i))
        st.on_quote(last)
    return last


class TestReentry(unittest.TestCase):
    def test_same_direction_long_reentry_after_fresh_signal_and_directional_move(self):
        st = closed(Side.LONG)
        # price dips to ask 1.0980, then recovers to ask 1.0992 = +0.109% off the post-close low
        q = feed(st, [("1.0979", "1.0980"), ("1.0985", "1.0986"), ("1.0991", "1.0992")], start_min=5)
        now = C + timedelta(minutes=12)
        g = st.gate(sg(Side.LONG, now), now, qt("1.0991", "1.0992", now), 10)
        self.assertTrue(g.allowed, g.reasons)
        self.assertTrue(g.is_same_direction_reentry and not g.is_reversal)
        self.assertGreaterEqual(g.directional_move_pct, Dc("0.10"))
        self.assertEqual(st.state, P.WAIT_FOR_REENTRY_CONFIRMATION)

    def test_same_direction_short_reentry_symmetric(self):
        st = closed(Side.SHORT)
        feed(st, [("1.1020", "1.1021"), ("1.1015", "1.1016"), ("1.1008", "1.1009")], start_min=5)
        now = C + timedelta(minutes=12)
        g = st.gate(sg(Side.SHORT, now), now, qt("1.1008", "1.1009", now), 10)      # bid -0.109% off the high
        self.assertTrue(g.allowed and g.is_same_direction_reentry, g.reasons)

    def test_insufficient_directional_move_is_rejected(self):
        st = closed(Side.LONG)
        feed(st, [("1.0979", "1.0980"), ("1.0984", "1.0985")], start_min=5)
        now = C + timedelta(minutes=12)
        g = st.gate(sg(Side.LONG, now), now, qt("1.0984", "1.0985", now), 10)        # only +0.0455%
        self.assertFalse(g.allowed)
        self.assertTrue(any("move" in r and "required" in r for r in g.reasons))

    def test_no_reentry_without_a_fresh_valid_signal(self):
        st = closed(Side.LONG)
        feed(st, [("1.0979", "1.0980"), ("1.0991", "1.0992")], start_min=5)
        now = C + timedelta(minutes=12)
        q = qt("1.0991", "1.0992", now)
        self.assertFalse(st.gate(sg(Side.LONG, C), now, q, 10).allowed)                          # signal at the close
        self.assertFalse(st.gate(sg(Side.LONG, C - timedelta(minutes=5)), now, q, 10).allowed)   # pre-close signal
        self.assertFalse(st.gate(sg(Side.LONG, now, valid=False), now, q, 10).allowed)           # invalid
        stale = Signal("EURUSD", Side.LONG, now, C, True, ())                                # data older than close
        self.assertFalse(st.gate(stale, now, q).allowed)
        self.assertTrue(st.gate(sg(Side.LONG, now), now, q, 10).allowed)                         # control: fresh passes
        self.assertEqual(st.state, P.WAIT_FOR_REENTRY_CONFIRMATION)                          # no signal => stays out

    def test_cooldown_still_applies_to_same_direction(self):
        st = closed(Side.LONG)
        feed(st, [("1.0979", "1.0980"), ("1.0991", "1.0992")], start_min=1)
        now = C + timedelta(minutes=4)
        g = st.gate(sg(Side.LONG, now), now, qt("1.0991", "1.0992", now), 10)
        self.assertFalse(g.allowed); self.assertTrue(any("cooldown" in r for r in g.reasons))

    def test_both_directions_possible_depending_on_new_signal(self):
        st = closed(Side.LONG, pair_cfg(cooldown_minutes=10, opposite_direction_reentry_min_move_pct=Dc("0.10")))
        feed(st, [("1.1019", "1.1020"), ("1.1005", "1.1006"), ("1.0990", "1.0991")], start_min=5)
        now = C + timedelta(minutes=12)
        down = qt("1.0990", "1.0991", now)                                       # bid -0.27% off the high
        gs = st.gate(sg(Side.SHORT, now), now, down, 10)
        self.assertTrue(gs.allowed and gs.is_reversal and not gs.is_same_direction_reentry, gs.reasons)
        st2 = closed(Side.LONG)
        feed(st2, [("1.0979", "1.0980"), ("1.0991", "1.0992")], start_min=5)
        gl = st2.gate(sg(Side.LONG, now), now, qt("1.0991", "1.0992", now), 10)
        self.assertTrue(gl.allowed and gl.is_same_direction_reentry and not gl.is_reversal)

    def test_same_and_opposite_thresholds_are_independent(self):
        cfg = pair_cfg(same_direction_reentry_min_move_pct=Dc("0.10"), opposite_direction_reentry_min_move_pct=Dc("0.50"))
        st = closed(Side.LONG, cfg)
        feed(st, [("1.1019", "1.1020"), ("1.0990", "1.0991")], start_min=5)       # SHORT move = -0.27%
        now = C + timedelta(minutes=12)
        self.assertFalse(st.gate(sg(Side.SHORT, now), now, qt("1.0990", "1.0991", now), 10).allowed)   # needs 0.50
        cfg2 = pair_cfg(same_direction_reentry_min_move_pct=Dc("0.50"), opposite_direction_reentry_min_move_pct=Dc("0.10"))
        st2 = closed(Side.LONG, cfg2)
        feed(st2, [("1.1019", "1.1020"), ("1.0990", "1.0991")], start_min=5)
        self.assertTrue(st2.gate(sg(Side.SHORT, now), now, qt("1.0990", "1.0991", now), 10).allowed)

    def test_same_direction_can_be_switched_off(self):
        st = closed(Side.LONG, pair_cfg(allow_same_direction_reentry=False))
        feed(st, [("1.0979", "1.0980"), ("1.0991", "1.0992")], start_min=5)
        now = C + timedelta(minutes=12)
        g = st.gate(sg(Side.LONG, now), now, qt("1.0991", "1.0992", now), 10)
        self.assertFalse(g.allowed); self.assertTrue(any("disabled" in r for r in g.reasons))

    def test_zero_threshold_disables_movement_check_and_first_entry_exempt(self):
        st = closed(Side.LONG, pair_cfg(same_direction_reentry_min_move_pct=Dc("0")))
        now = C + timedelta(minutes=12)
        self.assertFalse(st.gate(sg(Side.LONG, now), now, None, 10).allowed)           # missing data still blocks
        self.assertTrue(st.gate(sg(Side.LONG, now), now, qt("1.1000", "1.1001", now), 10).allowed)
        fresh = PairStrategy(pair_cfg()); fresh.start(T0)
        self.assertTrue(fresh.gate(sg(Side.SHORT, T0), T0, None).allowed)         # no prior close: no movement rule

    def test_reference_is_post_close_extreme_never_entry_or_exit_price(self):
        import inspect
        self.assertNotIn("exit_price", inspect.signature(PairStrategy.on_position_closed).parameters)
        self.assertFalse(hasattr(pair_cfg(), "reentry_move_reference"))
        st = closed(Side.LONG)                                                  # nothing observed yet
        self.assertIsNone(st.post_close.low_ask)
        feed(st, [("1.0979", "1.0980"), ("1.0991", "1.0992")], start_min=5)
        self.assertEqual(st.post_close.low_ask, Dc("1.0980"))                    # lowest ASK since the close
        sh = closed(Side.SHORT)
        feed(sh, [("1.1020", "1.1021"), ("1.1008", "1.1009")], start_min=5)
        self.assertEqual(sh.post_close.high_bid, Dc("1.1020"))                   # highest BID since the close

    def test_reference_resets_on_every_close_and_starts_at_the_close(self):
        st = closed(Side.LONG)
        feed(st, [("1.0979", "1.0980")], start_min=5)
        st.on_entry_requested(C + timedelta(minutes=20)); st.on_position_opened(C + timedelta(minutes=20))
        c2 = C + timedelta(minutes=60)
        st.on_position_closed(Side.SHORT, c2)                                    # second close
        self.assertIsNone(st.post_close.low_ask); self.assertEqual(st.post_close.observed, 0)
        st.on_quote(qt("1.0900", "1.0901", c2 - timedelta(seconds=1)))           # before the confirmed close
        self.assertEqual(st.post_close.observed, 0)
        st.on_quote(qt("1.0950", "1.0951", c2))                                   # tracking starts AT the close
        self.assertEqual(st.post_close.low_ask, Dc("1.0951"))

    def test_stale_or_missing_data_cannot_trigger_reentry(self):
        st = closed(Side.LONG, pair_cfg(same_direction_reentry_min_move_pct=Dc("0")))      # even with no movement rule
        feed(st, [("1.0979", "1.0980"), ("1.0991", "1.0992")], start_min=5)
        now = C + timedelta(minutes=12)
        s_ = sg(Side.LONG, now)
        self.assertFalse(st.gate(s_, now, None, 10).allowed)                                 # missing quote
        old = qt("1.0991", "1.0992", now - timedelta(minutes=2))
        g = st.gate(s_, now, old, 10)
        self.assertFalse(g.allowed); self.assertTrue(any("stale" in r for r in g.reasons))   # stale quote
        self.assertFalse(st.gate(s_, now, qt("1.0991", "1.0992", now), None).allowed)         # freshness limit unset
        self.assertTrue(st.gate(s_, now, qt("1.0991", "1.0992", now), 10).allowed)            # control

    def test_data_gap_restarts_reference_and_cannot_create_a_false_move(self):
        st = closed(Side.LONG)
        for i, (b, a) in enumerate([("1.0979", "1.0980"), ("1.0981", "1.0982")]):
            st.on_quote(qt(b, a, C + timedelta(seconds=2 + i)), C + timedelta(seconds=2 + i), 10)
        self.assertEqual(st.post_close.low_ask, Dc("1.0980"))
        t = C + timedelta(minutes=10)                                                        # 10-minute outage
        st.on_quote(qt("1.0990", "1.0991", t), t, 10)
        self.assertEqual((st.post_close.gaps, st.post_close.low_ask), (1, Dc("1.0991")))      # restarted, not 1.0980
        g = st.gate(sg(Side.LONG, t + timedelta(minutes=3)), t + timedelta(minutes=3),
                    qt("1.0992", "1.0993", t + timedelta(minutes=3)), 10)
        self.assertFalse(g.allowed)                                                          # move 0.018% < 0.10%
        st.on_quote(qt("1.0900", "1.0901", t - timedelta(minutes=9)), t, 10)                  # stale quote ignored
        self.assertEqual(st.post_close.ignored_stale, 1)

    def test_movement_threshold_alone_never_triggers_an_entry(self):
        st = closed(Side.LONG)
        feed(st, [("1.0979", "1.0980"), ("1.0995", "1.0996")], start_min=5)                  # +0.146% move
        now = C + timedelta(minutes=12); q = qt("1.0995", "1.0996", now)
        for bad in (Signal("EURUSD", Side.LONG, C - timedelta(minutes=1), C - timedelta(minutes=1), True, ()),
                    Signal("EURUSD", Side.LONG, now, now, False, ()),
                    Signal("EURUSD", Side.SHORT, now, now, False, ())):
            g = st.gate(bad, now, q, 10)
            self.assertFalse(g.allowed); self.assertGreaterEqual(g.directional_move_pct or Dc(0), Dc("0.10") if bad.direction is Side.LONG else Dc(0))

    def test_tracker_ignores_pre_close_quotes_and_snapshot_restores_gate(self):
        st = closed(Side.LONG)
        st.on_quote(qt("1.0000", "1.0001", C - timedelta(minutes=1)))               # before the close: ignored
        self.assertIsNone(st.post_close.low_ask)
        feed(st, [("1.0979", "1.0980"), ("1.0991", "1.0992")], start_min=5)
        r = PairStrategy.from_snapshot(json.loads(json.dumps(st.snapshot())), st.cfg)
        now = C + timedelta(minutes=12)
        a = st.gate(sg(Side.LONG, now), now, qt("1.0991", "1.0992", now), 10)
        b = r.gate(sg(Side.LONG, now), now, qt("1.0991", "1.0992", now), 10)
        self.assertEqual((a.allowed, a.directional_move_pct), (b.allowed, b.directional_move_pct))
        self.assertEqual(r.state, P.WAIT_FOR_REENTRY_CONFIRMATION)
        self.assertEqual(r.post_close.low_ask, st.post_close.low_ask)               # reference extreme restored
        self.assertEqual((r.post_close.closed_ts, r.post_close.observed), (st.post_close.closed_ts, st.post_close.observed))

    def test_property_gate_matches_independent_oracle_and_is_long_short_symmetric(self):
        rnd = random.Random(77)
        for _ in range(300):
            thr = Dc(rnd.choice(["0.05", "0.10", "0.20"]))
            cfg = pair_cfg(cooldown_minutes=5, same_direction_reentry_min_move_pct=thr)
            side = rnd.choice(list(Side))
            st, mirror = closed(side, cfg), closed(side.opposite, cfg)
            mid, lo_ask, hi_bid, path = Dc("1.10000"), None, None, []
            for i in range(rnd.randint(1, 30)):
                mid += Dc(rnd.randint(-40, 40)) * Dc("0.00001")
                bid, ask = mid - Dc("0.00005"), mid + Dc("0.00005")
                t = C + timedelta(minutes=1 + i)
                st.on_quote(qt(bid, ask, t))
                lo_ask = ask if lo_ask is None else min(lo_ask, ask); hi_bid = bid if hi_bid is None else max(hi_bid, bid)
                mb, ma = Dc("2.2") - ask, Dc("2.2") - bid                  # mirrored price path (mirror about 1.1)
                mirror.on_quote(qt(mb, ma, t))
            now = C + timedelta(minutes=40)
            cur = qt(bid, ask, now)
            exp_move = ((ask - lo_ask) / lo_ask * 100) if side is Side.LONG else ((hi_bid - bid) / hi_bid * 100)
            g = st.gate(sg(side, now), now, cur, 10)
            self.assertEqual(g.allowed, exp_move >= thr, (side, exp_move, thr))
            mcur = qt(Dc("2.2") - ask, Dc("2.2") - bid, now)
            gm = mirror.gate(sg(side.opposite, now), now, mcur, 10)
            self.assertAlmostEqual(float(gm.directional_move_pct), float(g.directional_move_pct), places=1)


class TestPerPairConfigIndependence(unittest.TestCase):
    def test_parameters_are_independent_per_pair_and_per_parameter(self):
        s = ConfigStore(AppConfig.default_universe())
        names = ["trailing_activation_pct", "trailing_distance_pct", "same_direction_reentry_min_move_pct",
                 "opposite_direction_reentry_min_move_pct", "initial_stop_pct"]
        for i, n in enumerate(names):
            before = {m: getattr(s.config.pairs["GBPUSD"], m) for m in names}
            s.set(f"pairs.GBPUSD.{n}", f"0.{i + 2}5", "alice", T0)
            after = {m: getattr(s.config.pairs["GBPUSD"], m) for m in names}
            self.assertEqual([m for m in names if before[m] != after[m]], [n])         # only that parameter moved
            for other in s.config.pairs:
                if other != "GBPUSD":
                    self.assertEqual(getattr(s.config.pairs[other], n), Dc("0.10"))       # other pairs untouched
        self.assertEqual(len(s.audit), 5)
        self.assertTrue(all(r.actor == "alice" and r.old_value == "0.1" for r in s.audit[:1]))

    def test_defaults_match_the_spec_and_reentry_enabled_in_v1(self):
        for p in AppConfig.default_universe().pairs.values():
            self.assertEqual((p.trailing_activation_pct, p.trailing_distance_pct), (Dc("0.10"), Dc("0.10")))
            self.assertEqual((p.same_direction_reentry_min_move_pct, p.opposite_direction_reentry_min_move_pct),
                             (Dc("0.10"), Dc("0.10")))
            self.assertTrue(p.allow_same_direction_reentry)
            self.assertFalse(p.profit_taking_enabled)                      # min_net_profit is its own mechanism

    def test_pairs_with_different_parameters_behave_differently(self):
        a = make_position(Side.LONG, params=StopParams(Dc("0.10"), Dc("0.10"), Dc("0.10")))
        b = make_position(Side.LONG, params=StopParams(Dc("0.10"), Dc("0.25"), Dc("0.10")), spec=SPEC)
        for pos in (a, b):
            pos.update_market(qt("1.10150"))                                # +0.136%
        self.assertTrue(a.trailing_engaged); self.assertFalse(b.trailing_engaged)
        g_a = PairStrategy(pair_cfg(same_direction_reentry_min_move_pct=Dc("0.05")))
        g_b = PairStrategy(pair_cfg(same_direction_reentry_min_move_pct=Dc("0.30")))
        for g in (g_a, g_b):
            g.start(T0); g.on_entry_requested(T0); g.on_position_opened(T0)
            g.on_position_closed(Side.LONG, C)
            g.on_quote(qt("1.0979", "1.0980", C + timedelta(minutes=2)))
        now = C + timedelta(minutes=12); q = qt("1.0991", "1.0992", now)     # +0.109%
        self.assertTrue(g_a.gate(sg(Side.LONG, now), now, q, 10).allowed)
        self.assertFalse(g_b.gate(sg(Side.LONG, now), now, q, 10).allowed)


if __name__ == "__main__":
    unittest.main()
