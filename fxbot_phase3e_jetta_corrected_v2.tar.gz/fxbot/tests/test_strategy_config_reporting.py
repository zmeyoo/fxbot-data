import unittest
from datetime import timedelta
from decimal import Decimal as Dc

from fxbot.config.audit import ConfigStore
from fxbot.config.schema import (AppConfig, ConfigError, LiveTradingNotAuthorised, NewsPolicy, OperatingMode)
from fxbot.core.types import Side
from fxbot.position_manager.position import ExitReason
from fxbot.reporting.exit_analysis import (compare_exit_modes, estimated_vs_realised, exit_reason_breakdown,
                                           trailing_gross_breakeven_report)
from fxbot.reporting.metrics import summarise
from fxbot.reporting.readiness import (OperationalCounts, ReadinessCriteria, Status, evaluate_readiness)
from fxbot.strategy.pair_state import PairState as P, PairStrategy, Signal
from tests.fixtures import *


def sig(direction, ts, market=None, valid=True):
    return Signal("EURUSD", direction, ts, market or ts, valid, ("test",))


class TestConfig(unittest.TestCase):
    def test_defaults_and_blockers(self):
        c = AppConfig.default_universe()
        self.assertEqual(c.pairs["EURUSD"].initial_stop_pct, Dc("0.10"))
        self.assertFalse(c.global_.live_enabled)
        self.assertTrue(c.trading_blockers())                              # nothing silently invented

    def test_audit_trail_and_validation(self):
        s = ConfigStore(AppConfig.default_universe())
        h0 = s.config.hash()
        rec = s.set("pairs.USDJPY.trailing_distance_pct", "0.15", "alice", T0)
        self.assertEqual((rec.old_value, rec.new_value, rec.actor), ("0.1", "0.15", "alice"))
        self.assertNotEqual(h0, s.config.hash()); self.assertEqual(rec.old_hash, h0)
        self.assertEqual(s.config.pairs["EURUSD"].trailing_distance_pct, Dc("0.10"))   # pairs independent
        with self.assertRaises(ConfigError): s.set("pairs.EURUSD.initial_stop_pct", "0", "alice", T0)
        with self.assertRaises(ConfigError): s.set("pairs.EURUSD.nope", "1", "alice", T0)
        with self.assertRaises(ConfigError): s.set("pairs.EURUSD.initial_stop_pct", 0.1, "alice", T0)  # float
        self.assertEqual(len(s.audit), 1)

    def test_live_never_switched_on_silently(self):
        s = ConfigStore(AppConfig.default_universe())
        with self.assertRaises(LiveTradingNotAuthorised): s.set("global.mode", "LIVE", "bob", T0)
        with self.assertRaises(LiveTradingNotAuthorised): s.set("global.live_enabled", True, "bob", T0)

    def test_missing_news_provider_is_not_a_news_filter(self):
        c = AppConfig.default_universe()
        s = ConfigStore(c); s.set("global.operating_mode", "AUTONOMOUS", "a", T0)
        self.assertTrue(any("news" in b for b in s.config.live_blockers(True)))
        self.assertTrue(any("commission" in b for b in s.config.live_blockers(False)))


class TestReporting(unittest.TestCase):
    def test_gross_breakeven_report(self):
        ts = [trade(net=Dc("-3"), reason=ExitReason.TRAILING_STOP, protected=Dc("0")),
              trade(net=Dc("4"), reason=ExitReason.TRAILING_STOP, protected=Dc("0")),
              trade(net=Dc("9"), reason=ExitReason.TRAILING_STOP, protected=Dc("0.1")),
              trade(net=Dc("-9"), reason=ExitReason.INITIAL_STOP)]
        r = trailing_gross_breakeven_report(ts)
        self.assertEqual((r.trailing_exits, r.at_gross_breakeven_level, r.of_which_negative_net), (3, 2, 1))
        self.assertEqual(r.share_negative_net, Dc("0.5")); self.assertEqual(r.total_net_loss_base, Dc("-3"))

    def test_compare_modes_and_breakdown_and_cost_variance(self):
        a = [trade(net=Dc("-2"), day=i) for i in range(4)]
        b = [trade(net=Dc("3"), day=i, reason=ExitReason.PROFIT_TARGET) for i in range(4)]
        cmp = compare_exit_modes({"trailing_only": a, "trailing+profit": b}, Dc("100000"))
        self.assertLess(cmp["trailing_only"].net_pnl_base, 0); self.assertGreater(cmp["trailing+profit"].net_pnl_base, 0)
        self.assertEqual(set(exit_reason_breakdown(a + b)), {"TRAILING_STOP", "PROFIT_TARGET"})
        from fxbot.costs.model import CostBreakdown
        est = CostBreakdown(commission=Dc("0.04"))
        v = estimated_vs_realised([trade(costs=Dc("0.1"), est=est)])
        self.assertEqual(v["commission"]["variance"], Dc("0.1") - Dc("0.08"))
        self.assertIsNone(estimated_vs_realised([trade()]))

    def test_metrics(self):
        ts = [trade(net=Dc(x), day=i) for i, x in enumerate([5, -2, -2, 3, -1])]
        s = summarise(ts, Dc("1000"))
        self.assertEqual((s.n, s.max_consecutive_losses), (5, 2))
        self.assertEqual(s.profit_factor, Dc("8") / Dc("5")); self.assertEqual(s.net_pnl_base, Dc("3"))
        self.assertIsNotNone(s.costs_pct_of_gross_profit)

    def _book(self, bad_pair=None, n_each=60):
        out, day = [], 0
        for pair in ("EURUSD", "GBPUSD", "USDJPY", "AUDUSD"):
            for side in Side:
                for i in range(n_each):
                    win = (i % 2 == 0)
                    net = Dc("3") if win else Dc("-1")
                    if pair == bad_pair: net = Dc("-1") if win else Dc("-2")
                    out.append(trade(pair=pair, side=side, net=net, day=day)); day += 1
        return out

    OPS = OperationalCounts(0, 0, 0, 0, 100, frozenset({"forced_disconnect", "app_restart", "broker_timeout"}))

    def test_readiness_pass_fail_insufficient(self):
        c = ReadinessCriteria()
        rets = [0.001, 0.002, -0.0005, 0.0015] * 30
        pairs = ["EURUSD", "GBPUSD", "USDJPY", "AUDUSD"]
        good = evaluate_readiness(c, self._book(), rets, Dc("100000"), self.OPS, pairs)
        self.assertEqual(good.status, Status.PASS, good.reasons)
        self.assertEqual(sorted(good.validated_pairs), sorted(pairs))
        # one consistently losing pair must not be hidden by the profitable ones
        bad = evaluate_readiness(c, self._book(bad_pair="USDJPY"), rets, Dc("100000"), self.OPS, pairs)
        self.assertEqual(bad.status, Status.FAIL)
        self.assertGreater(bad.overall.expectancy_base, 0)
        # too few trades => insufficient evidence, never validated
        few = evaluate_readiness(c, self._book(n_each=5), rets, Dc("100000"), self.OPS, pairs)
        self.assertEqual(few.status, Status.INSUFFICIENT_EVIDENCE)
        # operational failure => FAIL regardless of profits
        ops = OperationalCounts(0, 1, 0, 0, 100, self.OPS.recovery_drills_passed)
        self.assertEqual(evaluate_readiness(c, self._book(), rets, Dc("100000"), ops, pairs).status, Status.FAIL)
        # paper period too short => insufficient
        short = OperationalCounts(0, 0, 0, 0, 30, self.OPS.recovery_drills_passed)
        self.assertEqual(evaluate_readiness(c, self._book(), rets, Dc("100000"), short, pairs).status, Status.INSUFFICIENT_EVIDENCE)

    def test_criteria_fingerprint_is_stable_and_detects_tuning(self):
        self.assertEqual(ReadinessCriteria().fingerprint(), ReadinessCriteria().fingerprint())
        self.assertNotEqual(ReadinessCriteria().fingerprint(), ReadinessCriteria(min_profit_factor=Dc("1.1")).fingerprint())


if __name__ == "__main__":
    unittest.main()
