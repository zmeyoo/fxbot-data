import csv
import os
import tempfile
import unittest
from datetime import datetime, timezone
from types import SimpleNamespace
from unittest import mock

from fxbot.data_sources.dukascopy import (DownloadManager, FetchResult, JETTA_CODES, RawStore,
    decode_bi5, decode_jetta, f32_text, hour_url, jetta_hour_url, price_text, build_normalised)
from fxbot.data_sources.dataset import finalize_dataset, read_manifest
from fxbot.data_sources import cli

U = timezone.utc
HOUR = datetime(2024, 3, 4, 12, tzinfo=U)
DATA = os.path.join(os.path.dirname(__file__), "data")
JETTA = open(os.path.join(DATA, "jetta_eurusd_2024-03-04_12.json"), "rb").read()
BI5 = open(os.path.join(DATA, "bi5_eurusd_2024-03-04_12.bi5"), "rb").read()


class StaticFetcher:
    def __init__(self, body): self.body, self.calls = body, []
    def fetch(self, url):
        self.calls.append(url)
        return FetchResult(200, self.body, {"content-type": "application/json"})


class TestJettaDecoder(unittest.TestCase):
    def test_endpoint_uses_iso_code_and_one_based_month(self):
        self.assertEqual(jetta_hour_url("EURUSD", HOUR), "https://jetta.dukascopy.com/v1/ticks/EUR-USD/2024/3/4/12")
        self.assertEqual(JETTA_CODES["USDJPY"], "USD-JPY")

    def test_real_jettajson_matches_bi5_for_every_tick(self):
        j = decode_jetta(JETTA, "EURUSD")
        b = decode_bi5(BI5)
        self.assertEqual(len(j.ticks), 2670)
        self.assertEqual(len(b.ticks), 2670)
        base = int(HOUR.timestamp() * 1000)
        jr = [(base + t[0], price_text(t[1], 100000), price_text(t[2], 100000), f32_text(t[3]), f32_text(t[4])) for t in j.ticks]
        br = [(base + t[0], price_text(t[1], 100000), price_text(t[2], 100000), f32_text(t[3]), f32_text(t[4])) for t in b.ticks]
        self.assertEqual(jr, br)

    def test_download_and_build_preserve_jettaraw_and_normalised_schema(self):
        with tempfile.TemporaryDirectory() as d:
            store = RawStore(os.path.join(d, "raw"), source="jetta")
            fetcher = StaticFetcher(JETTA)
            manager = DownloadManager(fetcher, store, "EURUSD", retries=0, delay_s=0, log=lambda _: None)
            summary = manager.run(HOUR, HOUR.replace(hour=13))
            self.assertEqual((summary.ok, summary.errors), (1, 0))
            self.assertTrue(store.path("EURUSD", HOUR).endswith("12h_ticks.json"))
            self.assertIn(os.path.join("2024", "03", "04"), store.path("EURUSD", HOUR))
            self.assertEqual(store.read("EURUSD", HOUR), JETTA)
            self.assertEqual(store.meta("EURUSD", HOUR)["source"], "jetta")
            out = os.path.join(d, "ticks.csv")
            built = build_normalised(store, "EURUSD", HOUR, HOUR.replace(hour=13), out)
            self.assertEqual(built.rows_written, 2670)
            with open(out, newline="") as f:
                rows = list(csv.reader(f))
            self.assertEqual(rows[0], ["timestamp", "askPrice", "bidPrice", "askVolume", "bidVolume"])
            self.assertEqual(len(rows) - 1, 2670)

    def test_jettadataset_manifest_records_provider_and_validates(self):
        with tempfile.TemporaryDirectory() as d:
            store = RawStore(os.path.join(d, "raw"), source="jetta")
            manager = DownloadManager(StaticFetcher(JETTA), store, "EURUSD", retries=0, delay_s=0, log=lambda _: None)
            manager.run(HOUR, HOUR.replace(hour=13))
            manifest = finalize_dataset(d, "EURUSD", HOUR, HOUR.replace(hour=13), "test", source="jetta")
            self.assertEqual(manifest["source"]["provider"], "jetta")
            self.assertEqual(manifest["normalised"]["rows"], 2670)
            self.assertEqual(read_manifest(d)["source"]["format"], "JSON delta-encoded ticks; time and price arrays are cumulative deltas")

    def test_verify_jetta_writes_machine_readable_gate_report(self):
        class FakeHttp:
            def __init__(self, timeout): pass
            def fetch(self, url):
                return FetchResult(200, BI5 if "www.dukascopy.com/datafeed" in url else JETTA, {})
        args = SimpleNamespace(instrument="EURUSD", start="2024-03-04", end="2024-03-05", timeout=5,
                               out=tempfile.mkdtemp())
        try:
            with mock.patch.object(cli, "UrllibFetcher", FakeHttp):
                self.assertEqual(cli.verify_jetta(args, out=lambda _: None), 0)
            import json
            with open(os.path.join(args.out, "decoder_verification.json")) as f:
                report = json.load(f)
            self.assertTrue(report["passed"])
            self.assertTrue(any("all 2670 EURUSD ticks match BI5 exactly" in x for x in report["findings"]))
        finally:
            import shutil
            shutil.rmtree(args.out)

    def test_rejects_bad_arrays_and_wrong_multiplier(self):
        import json
        payload = json.loads(JETTA)
        payload["bids"].pop()
        with self.assertRaises(Exception): decode_jetta(json.dumps(payload).encode(), "EURUSD")
        payload = json.loads(JETTA)
        payload["multiplier"] = 0.0001
        with self.assertRaises(Exception): decode_jetta(json.dumps(payload).encode(), "EURUSD")

    def test_usdjpy_uses_three_decimal_price_scale(self):
        import json
        payload = {"timestamp": 1709553600000, "multiplier": 0.001, "ask": 150.123,
                   "bid": 150.122, "times": [10, 5], "asks": [1, 0], "bids": [0, -1],
                   "askVolumes": [1000000, 2000000], "bidVolumes": [2000000, 1000000]}
        decoded = decode_jetta(json.dumps(payload).encode(), "USDJPY")
        self.assertEqual([(x[0], x[1], x[2]) for x in decoded.ticks], [(10, 150124, 150122), (15, 150124, 150121)])


if __name__ == "__main__": unittest.main()
