# JETTA decoder verification

Verdict: **PASSED**

This report checks representative live JETTA hours, timestamp/price structure, plausible instrument price bands, and exact BI5 parity for the EURUSD reference hour when both endpoints are reachable.

- PASS 2024-03-04 12Z: 2670 ticks; price range 1.08416..1.08576
- PASS 2024-03-11 12Z: 4605 ticks; price range 1.09293..1.09434
- PASS 2024-03-15 12Z: 4962 ticks; price range 1.08843..1.08945
- WARN cross-source parity unavailable: JETTA HTTP 200, www BI5 HTTP 503; JETTA structural checks passed
- JETTA verification passed. This is a source/decoder check, not a claim that the requested full dataset is complete.
