# Data quality report - EURUSD (5d3865b3d06907c6)

> This report validates DATA only. No strategy was run and no performance is reported. Research must not start until the verdict below is PASSED and you have reviewed this report.

**Verdict: PASSED**  (validated 2026-11-14T15:19:42.750038+00:00; validator scope: full)

## Provenance
- source: Dukascopy JETTA public tick API (delta-encoded JSON) - `https://jetta.dukascopy.com/v1`
- URL pattern: `/ticks/{BASE-QUOTE}/{YYYY}/{MM}/{DD}/{HH} (calendar month is one-based)`
- source format: JSON delta-encoded ticks; time and price arrays are cumulative deltas
- instrument: EURUSD (point value 100000, pip 0.0001)
- range (UTC): 2024-03-04T00:00:00+00:00 .. 2024-03-18T00:00:00+00:00 (end exclusive), 336 hourly files
- downloaded: 2026-11-14T14:48:18.416416+00:00 .. 2026-11-14T15:19:42.447612+00:00; hour outcomes {'empty': 95, 'error': 0, 'not_attempted': 0, 'not_found': 0, 'ok': 241}
- tool: dukascopy-downloader/2; built 2026-11-14T15:19:42.750038+00:00
- command: `python tools/dukascopy.py run --instrument EURUSD --source jetta --start 2024-03-04 --end 2024-03-18 --out /home/runner/work/fxbot-data/fxbot-data/out/dataset --sleep 0.3`
- raw files: 241; combined raw SHA-256 `f0add90ddf948210618013e0780a6cf1ec4f39ca6c41acd1c9f33e134d32e02c`
- normalised CSV: `normalised/EURUSD_20240304_20240318_ticks.csv` - 723344 rows, **SHA-256 `6fc5a2824f0267f95487adde05248f419627c39563a15fb465a2ff2ee5f24fa1`**; loader content hash `4b08cd2a2550a03e9555f8ff98fe154aaf5c309c8ba1662f85ecc3efa929d03f`
- first/last timestamp ms: 1709510400064 / 1710719998733; price range 1.08377 .. 1.09815

## Validation gates
| check | status | detail |
|---|---|---|
| File integrity (SHA-256) | **PASS** | manifest 6fc5a2824f0267f9... vs file 6fc5a2824f0267f9... |
| Download completeness | **PASS** | 336 hours requested: ok 241, empty 95, not_found 0, error 0, not_attempted 0 |
| Tick validator (existing) | **PASS** | scope: FULL file (723344 rows); checks: Timestamp parsing / timezone=PASS, BID/ASK field mapping + executable side=PASS, Duplicate / out-of-order / stale quotes=PASS, Bid/ask spread calculation=PASS, Data gaps and session boundaries=PASS, Original quote precision preserved=PASS, Dataset fingerprint=INFO |
| Price scale / plausibility | **PASS** | mid price range 1.08378 .. 1.098135 vs plausible band 0.5 .. 2.0 for EURUSD (a wrong point value would show up here) |
| Crossed quotes (ask < bid) | **PASS** | 0 of 723344 (0.0000%); FAIL above 0.5% |
| Timestamp order | **PASS** | 0 out-of-order rows; FAIL above 0.1% |
| Duplicates | **PASS** | 0 exact duplicate rows remain after the build (removed at build: 0) |
| Quotes inside the weekly closure | **PASS** | 0 (0.0000%); FAIL above 1.0% |
| Median spread plausibility | **PASS** | median 0.225 pips vs expected 0.05..3.0 |
| Build anomalies | **PASS** | {'crossed_ticks': 0, 'hours_with_non_monotone_offsets': 0, 'offsets_beyond_hour': 0, 'zero_price_ticks': 0} (non-monotone hours are re-sorted by millisecond offset, stable; originals are untouched in raw/) |
| Missing hours during open market | **PASS** | 0 of 241 open-market hours have no data (0.00%); FAIL above 5.0% |
| Thin hours during open market | **PASS** | 0 open-market hours with < 200 ticks |
| Unexpected gaps (> threshold, outside weekly closure) | **INFO** | 12 gaps > 120s ({'intra_session_gap': 12, 'weekend_closure': 2}); listed in the report |

Thresholds: crossed FAIL > 0.5%, out-of-order FAIL > 0.1%, closure quotes FAIL > 1.0%, missing open-market hours FAIL > 5.0%, thin hour < 200 ticks. WARN items need your review; they do not block.

## Quality statistics
### Spread distribution (pips; percentiles from 0.05-pip bins, so +-0.025 pip)
mean 0.267 | p1 0.12 | p5 0.12 | p25 0.23 | median 0.23 | p75 0.28 | p95 0.58 | p99 1.53 | p99.9 2.88
zero-spread quotes 0; crossed (ask < bid) 0; widest 5 spreads (pips @ UTC): 10.1 @ 2024-03-10 21:04:07, 9.8 @ 2024-03-10 21:04:05, 9.4 @ 2024-03-10 21:06:22, 9.4 @ 2024-03-10 21:06:14, 9.3 @ 2024-03-10 21:06:14

Median spread by New York hour (look for widening around the 17:00 rollover):

| NY hour | 00 | 01 | 02 | 03 | 04 | 05 | 06 | 07 | 08 | 09 | 10 | 11 | 12 | 13 | 14 | 15 | 16 | 17 | 18 | 19 | 20 | 21 | 22 | 23 |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| median pips | 0.23 | 0.23 | 0.23 | 0.23 | 0.23 | 0.23 | 0.23 | 0.23 | 0.23 | 0.23 | 0.23 | 0.23 | 0.23 | 0.23 | 0.23 | 0.23 | 0.28 | 1.03 | 0.28 | 0.28 | 0.23 | 0.23 | 0.23 | 0.23 |

### Timestamps and arrival rate
quotes 723344; first 2024-03-04 00:00:00.064000+00:00; last 2024-03-17 23:59:58.733000+00:00
timestamp resolution: milliseconds (637 of 723344 stamps fall on a whole second = 0.1%; ~0.1% expected if truly millisecond-resolution); max quotes sharing one timestamp 1
exact duplicates (same ts, ask, bid) 0; out-of-order 0; unchanged re-quotes (same prices, newer ts) 9893

Inter-arrival time between consecutive quotes (ms), excluding gaps > threshold:

| bin (ms) | 0+ | 10+ | 50+ | 100+ | 250+ | 500+ | 1000+ | 2000+ | 5000+ | 10000+ | 30000+ | 60000+ | 120000+ |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| count | 0 | 0 | 40203 | 300046 | 101388 | 96825 | 78865 | 68314 | 25256 | 11223 | 1039 | 170 | 0 |

### Gaps longer than 120s
classes: intra_session_gap 12, weekend_closure 2

| start (UTC) | end (UTC) | duration | class |
|---|---|---|---|
| 2024-03-15 20:59:59 | 2024-03-17 21:00:01 | 2 days, 0:00:02.777000 | weekend_closure |
| 2024-03-08 21:59:59 | 2024-03-10 21:00:04 | 1 day, 23:00:05.399000 | weekend_closure |
| 2024-03-04 22:00:09 | 2024-03-04 22:04:15 | 0:04:06.156000 | intra_session_gap |
| 2024-03-13 23:15:00 | 2024-03-13 23:18:30 | 0:03:30.183000 | intra_session_gap |
| 2024-03-04 03:54:00 | 2024-03-04 03:57:30 | 0:03:29.343000 | intra_session_gap |
| 2024-03-17 21:47:00 | 2024-03-17 21:50:21 | 0:03:20.641000 | intra_session_gap |
| 2024-03-04 23:43:40 | 2024-03-04 23:46:44 | 0:03:03.908000 | intra_session_gap |
| 2024-03-05 22:01:02 | 2024-03-05 22:04:02 | 0:02:59.912000 | intra_session_gap |
| 2024-03-14 23:47:55 | 2024-03-14 23:50:40 | 0:02:44.858000 | intra_session_gap |
| 2024-03-13 23:28:55 | 2024-03-13 23:31:36 | 0:02:40.720000 | intra_session_gap |
| 2024-03-13 23:23:53 | 2024-03-13 23:26:32 | 0:02:39.397000 | intra_session_gap |
| 2024-03-12 20:21:58 | 2024-03-12 20:24:37 | 0:02:38.938000 | intra_session_gap |
| 2024-03-12 22:22:32 | 2024-03-12 22:24:57 | 0:02:25.648000 | intra_session_gap |
| 2024-03-12 22:30:04 | 2024-03-12 22:32:17 | 0:02:12.738000 | intra_session_gap |

### Sessions (17:00 America/New_York; label = closing date)
| session | quotes |
|---|---|
| 2024-03-04 | 50724 |
| 2024-03-05 | 65239 |
| 2024-03-06 | 73612 |
| 2024-03-07 | 79201 |
| 2024-03-08 | 89393 |
| 2024-03-11 | 58435 |
| 2024-03-12 | 85078 |
| 2024-03-13 | 72159 |
| 2024-03-14 | 78786 |
| 2024-03-15 | 65723 |
| 2024-03-18 | 4994 |

quotes stamped inside the weekly closure (Fri 17:00 - Sun 17:00 New York): 0

## Existing tick validator output (full)

- file: `/home/runner/work/fxbot-data/fxbot-data/out/dataset/normalised/EURUSD_20240304_20240318_ticks.csv`
- format: **dukascopy_csv** (ts=`timestamp` [ms], bid=`bidPrice`, ask=`askPrice`)
- records kept: 723344; span 2024-03-04 00:00:00.064000+00:00 .. 2024-03-17 23:59:58.733000+00:00
- overall: **NO FAILED CHECKS**

| check | status | detail |
|---|---|---|
| Timestamp parsing / timezone | **PASS** | unit=ms; all UTC-aware=True; non-decreasing=True; exact epoch round-trip mismatches=0; resolution=sub-second; max quotes sharing one timestamp=1 |
| BID/ASK field mapping + executable side | **PASS** | mapped by NAME: bid<-'bidPrice', ask<-'askPrice'; rows where parsed != raw column: 0; bid<=ask on all kept rows: True; crossed fraction in file: 0.000; LONG enters at ASK and exits at BID, SHORT enters at BID and exits at ASK: True |
| Duplicate / out-of-order / stale quotes | **PASS** | dropped: 0 exact duplicates, 0 out-of-order, 0 crossed/invalid; unchanged-price re-quotes kept: 9893; inter-arrival s median/p95/p99/max = 0.257/5.146/13.078/246.156; intervals >10s/30s/60s: ((10, 12438), (30, 1221), (60, 182)) |
| Bid/ask spread calculation | **PASS** | spread=ask-bid, mid=(ask+bid)/2 recomputed from the raw text with exact Decimals; mismatches vs loader: 0; mean/median/max spread % = 0.00245/0.00184/0.09230 |
| Data gaps and session boundaries | **PASS** | unexpected gaps (> 120s, outside the weekly closure): 12; weekend closures: 2; quotes stamped inside the Fri-17:00/Sun-17:00 New York closure: 0; sessions seen: 2024-03-04: 50724 quotes 2024-03-04T00:00:00.064000+00:00..2024-03-04T21:59:59.164000+00:00; 2024-03-05: 65239 quotes 2024-03-04T22:00:00.071000+00:00..2024-03-05T21:59:59.399000+00:00; 2024-03-06: 73612 quotes 2024-03-05T22:00:00.053000+00:00..2024-03-06T21:59:59.091000+00:00; 2024-03-07: 79201 quotes 2024-03-06T22:00:00.049000+00:00..2024-03-07T21:59:59.154000+00:00; first quote falls in session '2024-03-04' = 2024-03-03T22:00:00+00:00 .. 2024-03-04T22:00:00+00:00 |
| Original quote precision preserved | **PASS** | prices stored as exact Decimal (no float); text of every price identical after parsing (rows changed: 0); decimal places seen: (5,) |
| Dataset fingerprint | **INFO** | sha256 of canonical (ts,bid,ask) = 4b08cd2a2550a03e9555f8ff98fe154aaf5c309c8ba1662f85ecc3efa929d03f |

## Sample rows (raw text -> parsed)

**Row 1** raw: `{'timestamp': '1709510400064', 'askPrice': '1.08419', 'bidPrice': '1.08417', 'askVolume': '1.8', 'bidVolume': '0.9'}`
- UTC `2024-03-04T00:00:00.064000+00:00`  |  New York `2024-03-03T19:00:00.064000-05:00`  |  session `2024-03-04` (2024-03-03T22:00:00+00:00 .. 2024-03-04T22:00:00+00:00)
- bid `1.08417`  ask `1.08419`  spread `0.00002` (0.2 pips, 0.00184%)  mid `1.08418`

**Row 2** raw: `{'timestamp': '1709510400168', 'askPrice': '1.08420', 'bidPrice': '1.08418', 'askVolume': '5.4', 'bidVolume': '3.97'}`
- UTC `2024-03-04T00:00:00.168000+00:00`  |  New York `2024-03-03T19:00:00.168000-05:00`  |  session `2024-03-04` (2024-03-03T22:00:00+00:00 .. 2024-03-04T22:00:00+00:00)
- bid `1.08418`  ask `1.08420`  spread `0.00002` (0.2 pips, 0.00184%)  mid `1.08419`

**Row 3** raw: `{'timestamp': '1709510400272', 'askPrice': '1.08422', 'bidPrice': '1.08421', 'askVolume': '4.14', 'bidVolume': '1.89'}`
- UTC `2024-03-04T00:00:00.272000+00:00`  |  New York `2024-03-03T19:00:00.272000-05:00`  |  session `2024-03-04` (2024-03-03T22:00:00+00:00 .. 2024-03-04T22:00:00+00:00)
- bid `1.08421`  ask `1.08422`  spread `0.00001` (0.1 pips, 0.00092%)  mid `1.084215`

## Limitations
- Tick data: stop/trailing fills are simulated at the first quote after the trigger plus latency; quote timestamps have the source's granularity (IBKR ticks are not guaranteed to be every quote).
- Financing/rollover is not modelled unless rates are supplied; positions are flat before the EOD cutoff.
- No economic calendar is connected: the backtest has NO news protection.


## Reproduce
Re-run the command above with the same range (downloads are resumable and byte-verified); the manifest records every SHA-256.
