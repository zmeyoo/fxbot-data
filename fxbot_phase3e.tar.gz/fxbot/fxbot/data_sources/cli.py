"""Command line for the Dukascopy pipeline.   python tools/dukascopy.py <command> ...
Exit codes: 0 ok | 1 dataset FAILED validation | 2 usage / environment not ready | 3 download aborted/incomplete or cannot verify | 4 sample mismatch | 5 decoder assumption FAILED"""
from __future__ import annotations

import argparse
import json
import os
import shlex
import sys
import time
from datetime import datetime, timedelta, timezone
from typing import Callable, List, Optional, Sequence

from .dataset import DATASET_JSON, REPORT_MD, FULL_VALIDATOR_ROW_LIMIT, finalize_dataset, read_manifest
from .dukascopy import (BASE_URL, DownloadManager, NetworkUnavailable, POINT_VALUES, RawStore, UrllibFetcher, decode_bi5,
                        expected_closed_hour, f32_text, hour_url, hours_between, merge_normalised_csvs, price_text)

MEASURED_BYTES_PER_QUOTE_IN_MEMORY = 369      # measured in this project's sandbox (Quote with Decimal prices, UTC datetimes)
MEASURED_US_PER_QUOTE_DENSE = 19              # measured on 1-second synthetic quotes, single run, no sweep (indicative only)


def _date(s: str) -> datetime:
    return datetime.strptime(s, "%Y-%m-%d").replace(tzinfo=timezone.utc)


def env_check(fetcher=None, out=print) -> int:
    import lzma, platform
    out(f"python {platform.python_version()} | lzma module: {'available' if lzma else 'MISSING'}")
    f = fetcher or UrllibFetcher(timeout=15)
    url = hour_url("EURUSD", datetime(2020, 3, 30, 0, tzinfo=timezone.utc))
    try:
        r = f.head(url)
    except NetworkUnavailable as e:
        out(f"NOT READY: cannot reach {BASE_URL}\n  exact error: {e}\n  Nothing can be downloaded from this machine. "
            "See docs/DUKASCOPY_RUNBOOK.md for options that do not need a local computer. No data was created or substituted.")
        return 2
    out(f"HEAD {url} -> HTTP {r.status} (content-length {r.headers.get('content-length')}, last-modified {r.headers.get('last-modified')})")
    if r.status in (200, 404):
        out("READY: the datafeed is reachable from this machine.")
        return 0
    out(f"NOT READY: unexpected HTTP status {r.status}")
    return 2


def plan(instrument: str, start: datetime, end: datetime, delay_s: float, calibrate: Optional[str], out=print) -> int:
    hours = hours_between(start, end)
    open_h = sum(1 for h in hours if not expected_closed_hour(h))
    out(f"{instrument}: {start:%Y-%m-%d} .. {end:%Y-%m-%d} (end exclusive) = {len(hours)} hourly files, of which {open_h} are in open-market time "
        f"({len(hours) - open_h} expected closed: Fri 17:00 - Sun 17:00 New York)")
    out(f"requests: {len(hours)} (all hours are requested so closures are verified, not assumed); request delay {delay_s}s -> at least {len(hours) * delay_s / 60:.0f} min "
        "of pure waiting plus transfer time (unknown until measured)")
    if calibrate:
        m = read_manifest(calibrate)
        d = os.path.join(calibrate, "raw")
        raw_bytes = sum(os.path.getsize(os.path.join(dp, f)) for dp, _, fs in os.walk(d) for f in fs if f.endswith(".bi5"))
        csv_bytes = os.path.getsize(os.path.join(calibrate, m["normalised"]["path"]))
        ok_hours = m["download"]["hour_outcomes"]["ok"]
        rows = m["normalised"]["rows"]
        if ok_hours:
            rows_h, raw_h, csv_row = rows / ok_hours, raw_bytes / ok_hours, csv_bytes / max(rows, 1)
            R = rows_h * open_h
            out(f"calibration from {calibrate}: {rows_h:,.0f} quotes / ok hour, {raw_h / 1e3:,.0f} kB raw / ok hour, {csv_row:.1f} bytes / CSV row")
            out(f"estimate for this range: ~{R:,.0f} quotes, raw ~{raw_h * open_h / 1e9:.2f} GB, CSV ~{R * csv_row / 1e9:.2f} GB")
            out(f"in-memory research load: ~{R * MEASURED_BYTES_PER_QUOTE_IN_MEMORY / 1e9:.1f} GB (measured {MEASURED_BYTES_PER_QUOTE_IN_MEMORY} bytes/quote); "
                f"one backtest run ~{R * MEASURED_US_PER_QUOTE_DENSE / 1e6 / 60:.0f} min (indicative {MEASURED_US_PER_QUOTE_DENSE} us/quote); "
                f"validator in-memory limit {FULL_VALIDATOR_ROW_LIMIT:,} rows (larger files are sampled)")
            if R * MEASURED_BYTES_PER_QUOTE_IN_MEMORY > 8e9:
                out("WARNING: this range will NOT fit the current in-memory research loader and parameter sweeps would take days. Streaming from disk is "
                    "approved but NOT yet implemented: do not start a large download until the streaming milestone's acceptance tests pass "
                    "(docs/STREAMING_DESIGN.md). Raw data is always kept, so nothing is lost either way.")
    else:
        out("size unknown until a pilot dataset is measured: run the pilot, then `plan --calibrate <pilot dir>` extrapolates quotes, GB, memory and run time")
    return 0


def run_download(args, out=print) -> int:
    start, end = _date(args.start), _date(args.end)
    store = RawStore(os.path.join(args.out, "raw"))
    mgr = DownloadManager(UrllibFetcher(args.timeout), store, args.instrument, retries=args.retries, delay_s=args.sleep, log=out)
    s = mgr.run(start, end, retry_missing=args.retry_missing, max_hours=args.max_hours)
    out(f"download: requested {s.requested_hours}; skipped (already complete) {s.skipped_complete}; fetched {s.fetched}: ok {s.ok}, empty {s.empty}, "
        f"not_found {s.not_found}, errors {s.errors}; corrupt files re-fetched {s.refetched_corrupt}")
    if s.aborted:
        out("ABORTED: " + s.abort_reason)
        return 3
    if s.stopped_by_max_hours:
        out("stopped by --max-hours; re-run the same command to continue (resumable)")
        return 3
    return 3 if s.errors else 0


def run_build(args, out=print) -> int:
    start, end = _date(args.start), _date(args.end)
    argv = getattr(args, "_argv", sys.argv[1:])
    cmd = " ".join(shlex.quote(a) for a in (["python", "tools/dukascopy.py"] + list(argv))) if args.record_command is None else args.record_command
    m = finalize_dataset(args.out, args.instrument, start, end, cmd, gap_threshold_s=args.gap_threshold)
    v = m["validation"]
    out(f"dataset {m['dataset_id']}: {m['normalised']['rows']} rows, CSV SHA-256 {m['normalised']['sha256']}")
    out(f"validation: {v['status']}  ({sum(1 for c in v['checks'] if c['status'] == 'FAIL')} FAIL, {sum(1 for c in v['checks'] if c['status'] == 'WARN')} WARN)")
    for c in v["checks"]:
        if c["status"] in ("FAIL", "WARN"):
            out(f"  {c['status']}: {c['name']}: {c['detail']}")
    out(f"report: {os.path.join(args.out, REPORT_MD)}\nmanifest: {os.path.join(args.out, DATASET_JSON)}")
    return 0 if v["passed"] else 1


def verify_sample(args, sample_csv: str, out=print) -> int:
    """Downloads ONE hour (2020-03-30 00:00 UTC) and compares the first ticks with the published sample records supplied earlier."""
    import csv
    h = datetime(2020, 3, 30, 0, tzinfo=timezone.utc)
    store = RawStore(os.path.join(args.out, "raw_verify"))
    mgr = DownloadManager(UrllibFetcher(args.timeout), store, "EURUSD", retries=args.retries, delay_s=0, log=out)
    s = mgr.run(h, h + timedelta(hours=1))
    if s.aborted or s.errors or s.ok != 1:
        out(f"cannot verify: {s.abort_reason or 'the hour file was not downloaded'} (ok={s.ok}, errors={s.errors}, not_found={s.not_found}, empty={s.empty})")
        return 3
    dec = decode_bi5(store.read("EURUSD", h))
    got = [(h.timestamp() * 1000 + t[0], price_text(t[1], 100000), price_text(t[2], 100000), f32_text(t[3]), f32_text(t[4])) for t in dec.ticks[:2]]
    got = [(int(a), b, c, d, e) for a, b, c, d, e in got]
    with open(sample_csv, newline="") as f:
        exp = [(int(r["timestamp"]), r["askPrice"], r["bidPrice"], r["askVolume"], r["bidVolume"]) for r in csv.DictReader(f)]
    out(f"ticks in the hour file: {len(dec.ticks)}")
    out(f"decoded first two : {got}")
    out(f"published sample  : {exp}")
    if got == exp:
        out("MATCH: URL layout, LZMA/record layout, ask/bid order, point value and volume text all reproduce the published sample.")
        return 0
    out("MISMATCH: the sample may come from a different hour/feed OR the decoder assumptions are wrong. Check that decoded prices are plausible "
        "(~1.11) and spreads small before drawing conclusions; do not use the dataset until this is understood.")
    return 4


def run_verify_decoder(a, out=print) -> int:
    from .verify import render, verify_decoder, write_outputs
    start, end = _date(a.start), _date(a.end)
    rr = None
    if a.reference_range:
        lo, hi = a.reference_range.split(":")
        rr = (float(lo), float(hi))
    os.makedirs(a.out, exist_ok=True)
    res = verify_decoder(a.out, UrllibFetcher(a.timeout), a.instrument, start, end, a.sample, rr, a.retries, a.sleep, log=out)
    cmd = " ".join(shlex.quote(x) for x in ["python", "tools/dukascopy.py"] + list(getattr(a, "_argv", sys.argv[1:])))
    md = render(res, a.instrument, start, end, cmd)
    write_outputs(a.out, res, md)
    out(md)
    if res.cannot_verify:
        out("CANNOT VERIFY: " + res.cannot_verify)
        return 3
    if not res.passed:
        out("STOP: at least one decoder assumption FAILED. Nothing was adapted. Report this and do not download further.")
        return 5
    return 0


def main(argv: Optional[Sequence[str]] = None, out=print) -> int:
    ap = argparse.ArgumentParser(prog="dukascopy", description="Reproducible Dukascopy tick downloader + validator")
    sub = ap.add_subparsers(dest="cmd", required=True)

    def common(p, need_dates=True):
        p.add_argument("--instrument", default="EURUSD", choices=sorted(POINT_VALUES))
        if need_dates:
            p.add_argument("--start", required=True, help="UTC date YYYY-MM-DD (inclusive)")
            p.add_argument("--end", required=True, help="UTC date YYYY-MM-DD (exclusive)")
    sub.add_parser("env-check")
    p = sub.add_parser("plan"); common(p); p.add_argument("--sleep", type=float, default=0.2); p.add_argument("--calibrate")
    for name in ("download", "build", "run"):
        p = sub.add_parser(name); common(p); p.add_argument("--out", required=True)
        p.add_argument("--sleep", type=float, default=0.2); p.add_argument("--retries", type=int, default=4); p.add_argument("--timeout", type=float, default=30)
        p.add_argument("--retry-missing", action="store_true", help="re-request hours previously answered 404"); p.add_argument("--max-hours", type=int)
        p.add_argument("--gap-threshold", type=int, default=120); p.add_argument("--record-command", default=None)
    p = sub.add_parser("verify-sample"); p.add_argument("--out", required=True); p.add_argument("--timeout", type=float, default=30); p.add_argument("--retries", type=int, default=3)
    p.add_argument("--sample", default=os.path.join(os.path.dirname(__file__), "..", "..", "tests", "data", "eurusd_dukascopy_published_sample_ticks.csv"))
    p = sub.add_parser("verify-decoder"); common(p); p.add_argument("--out", required=True)
    p.add_argument("--reference-range", help="LO:HI independent price level you trust for this period, e.g. 1.05:1.12")
    p.add_argument("--sample", default=os.path.join(os.path.dirname(__file__), "..", "..", "tests", "data", "eurusd_dukascopy_published_sample_ticks.csv"))
    p.add_argument("--sleep", type=float, default=0.2); p.add_argument("--retries", type=int, default=3); p.add_argument("--timeout", type=float, default=30)
    p = sub.add_parser("merge"); p.add_argument("--inputs", nargs="+", required=True); p.add_argument("--out", required=True)
    a = ap.parse_args(argv)
    a._argv = list(argv if argv is not None else sys.argv[1:])

    if a.cmd == "env-check":
        return env_check(out=out)
    if a.cmd == "plan":
        return plan(a.instrument, _date(a.start), _date(a.end), a.sleep, a.calibrate, out)
    if a.cmd == "verify-sample":
        return verify_sample(a, a.sample, out)
    if a.cmd == "verify-decoder":
        return run_verify_decoder(a, out)
    if a.cmd == "merge":
        n, d = merge_normalised_csvs(a.inputs, a.out)
        out(f"merged {len(a.inputs)} files -> {a.out}: {n} rows, {d} exact duplicates dropped")
        return 0
    if a.cmd == "download":
        return run_download(a, out)
    if a.cmd == "build":
        return run_build(a, out)
    rc = run_download(a, out)                         # run = download + build + validate
    if rc != 0:
        out("not building: the download is incomplete. Fix the cause and re-run (it resumes).")
        return rc
    return run_build(a, out)
