"""Reproducible Dukascopy historical tick downloader (public datafeed, no authentication).

SOURCE FORMAT (from public decoders; confirmed by several independent implementations, NOT yet by a live download here):
  URL   https://datafeed.dukascopy.com/datafeed/{SYMBOL}/{YYYY}/{MM0}/{DD}/{HH}h_ticks.bi5     MM0 = ZERO-BASED month (Jan = 00)
  body  LZMA-compressed; decompresses to 20-byte BIG-ENDIAN records: uint32 ms-offset-in-hour, uint32 ask (points),
        uint32 bid (points), float32 ask volume, float32 bid volume.  Empty body / 404 = no ticks that hour (weekend, holiday).
  point EURUSD 100000 (prices are integer multiples of 0.00001).
What is stored, separately:
  raw/        every hour file byte-for-byte as downloaded + a .meta.json (url, status, sha256, download time, attempts)
  normalised  one CSV in the Dukascopy published layout  timestamp(epoch ms, UTC),askPrice,bidPrice,askVolume,bidVolume
              prices as exact text with all 5 decimals, volumes as the shortest float32 text, sorted, exact duplicates removed
  dataset.json manifest: source, instrument, range, download times, SHA-256 of raw files and of the CSV, command, validation verdict
Nothing is generated or filled in: a missing hour stays missing and is reported.
"""
from __future__ import annotations

import csv
import hashlib
import heapq
import json
import lzma
import os
import socket
import struct
import sys
import time
import urllib.error
import urllib.request
from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone
from decimal import Decimal
from typing import Callable, Dict, Iterable, Iterator, List, Optional, Sequence, Tuple

from ..core.sessions import SessionCalendar
from ..core.types import FxBotError

BASE_URL = "https://datafeed.dukascopy.com/datafeed"
SOURCE_NAME = "Dukascopy public datafeed (bi5 hourly tick files)"
TOOL_VERSION = "dukascopy-downloader/1"
RECORD = struct.Struct(">IIIff")                       # 20 bytes, big-endian
CSV_HEADER = ["timestamp", "askPrice", "bidPrice", "askVolume", "bidVolume"]
_EPOCH = datetime(1970, 1, 1, tzinfo=timezone.utc)
_MS = timedelta(milliseconds=1)

# Price scale per instrument (points per 1.0). Verified for EURUSD by plausibility (decode must give ~1.0-1.2); other
# instruments are listed per published decoders and are ALSO checked by the price-band gate in validation.
POINT_VALUES = {"EURUSD": 100000, "GBPUSD": 100000, "AUDUSD": 100000, "NZDUSD": 100000, "USDCAD": 100000, "USDCHF": 100000,
                "USDJPY": 1000}
PIP_SIZE = {"USDJPY": Decimal("0.01")}
PRICE_BANDS = {"EURUSD": (Decimal("0.5"), Decimal("2.0")), "GBPUSD": (Decimal("0.8"), Decimal("2.5")),
               "AUDUSD": (Decimal("0.4"), Decimal("1.2")), "NZDUSD": (Decimal("0.4"), Decimal("1.2")),
               "USDCAD": (Decimal("0.9"), Decimal("1.8")), "USDCHF": (Decimal("0.6"), Decimal("1.5")),
               "USDJPY": (Decimal("70"), Decimal("200"))}


class DukascopyError(FxBotError):
    pass


class Bi5Error(DukascopyError):
    pass


class NetworkUnavailable(DukascopyError):
    pass


def pip_size(instrument: str) -> Decimal:
    return PIP_SIZE.get(instrument, Decimal("0.0001"))


def _utc(dt: datetime) -> datetime:
    if dt.tzinfo is None:
        raise DukascopyError("datetimes must be timezone-aware (UTC)")
    return dt.astimezone(timezone.utc)


def epoch_ms(dt: datetime) -> int:
    return (_utc(dt) - _EPOCH) // _MS


def hour_url(instrument: str, hour: datetime) -> str:
    h = _utc(hour)
    return f"{BASE_URL}/{instrument}/{h.year:04d}/{h.month - 1:02d}/{h.day:02d}/{h.hour:02d}h_ticks.bi5"


def hour_relpath(instrument: str, hour: datetime) -> str:
    """Mirrors the source path (including the zero-based month) so a stored file maps 1:1 to its URL."""
    h = _utc(hour)
    return f"{instrument}/{h.year:04d}/{h.month - 1:02d}/{h.day:02d}/{h.hour:02d}h_ticks.bi5"


def hours_between(start: datetime, end: datetime) -> List[datetime]:
    """Hour starts in [start, end), UTC, aligned to the hour."""
    s, e = _utc(start), _utc(end)
    if s.minute or s.second or s.microsecond or e.minute or e.second or e.microsecond:
        raise DukascopyError("start and end must be whole UTC hours")
    out, t = [], s
    while t < e:
        out.append(t); t += timedelta(hours=1)
    return out


def expected_closed_hour(hour: datetime, cal: Optional[SessionCalendar] = None) -> bool:
    """True when the whole hour lies inside the weekly closure (Fri 17:00 - Sun 17:00 New York)."""
    cal = cal or SessionCalendar()
    return cal.closure_contains(hour) and cal.closure_contains(hour + timedelta(hours=1) - timedelta(seconds=1))


# ------------------------------------------------------------------ decoding
def f32_text(x: float) -> str:
    """Shortest decimal text that round-trips the float32 value (what the published CSVs show, e.g. 0.94 not 0.9399999976)."""
    for d in range(1, 10):
        s = f"{x:.{d}g}"
        if struct.unpack(">f", struct.pack(">f", float(s)))[0] == x:
            break
    t = format(Decimal(s), "f")
    return t if "." in t else t + ".0"


def price_text(points: int, point_value: int) -> str:
    digits = len(str(point_value)) - 1
    return str(Decimal(points).scaleb(-digits))            # scaleb keeps trailing zeros: 111360 -> '1.11360'


@dataclass
class HourDecode:
    ticks: List[Tuple[int, int, int, float, float]]       # (ms offset, ask pts, bid pts, ask vol, bid vol) in FILE order
    decompressed_bytes: int = 0
    non_monotone: int = 0
    offset_beyond_hour: int = 0
    crossed: int = 0
    zero_price: int = 0


def decode_bi5(raw: bytes) -> HourDecode:
    if not raw:
        return HourDecode([])
    try:
        data = lzma.LZMADecompressor(format=lzma.FORMAT_AUTO).decompress(raw)
    except lzma.LZMAError as e:
        raise Bi5Error(f"not a valid LZMA stream: {e}") from e
    if len(data) % RECORD.size:
        raise Bi5Error(f"decompressed size {len(data)} is not a multiple of {RECORD.size}: truncated or wrong format")
    ticks = [RECORD.unpack_from(data, i) for i in range(0, len(data), RECORD.size)]
    nm = sum(1 for a, b in zip(ticks, ticks[1:]) if b[0] < a[0])
    return HourDecode(ticks, len(data), nm, sum(1 for t in ticks if t[0] >= 3_600_000),
                      sum(1 for t in ticks if t[1] < t[2]), sum(1 for t in ticks if t[1] <= 0 or t[2] <= 0))


def encode_bi5(ticks: Sequence[Tuple[int, int, int, float, float]]) -> bytes:
    """Inverse of decode (used by tests to build container fixtures; never used to create datasets)."""
    return lzma.compress(b"".join(RECORD.pack(*t) for t in ticks), format=lzma.FORMAT_ALONE) if ticks else b""


# ------------------------------------------------------------------ fetching
@dataclass
class FetchResult:
    status: int
    body: bytes = b""
    headers: Dict[str, str] = field(default_factory=dict)


class UrllibFetcher:
    def __init__(self, timeout: float = 30.0, user_agent: str = TOOL_VERSION):
        self.timeout, self.ua = timeout, user_agent

    def _req(self, url: str, method: str) -> FetchResult:
        req = urllib.request.Request(url, method=method, headers={"User-Agent": self.ua})
        try:
            with urllib.request.urlopen(req, timeout=self.timeout) as r:
                return FetchResult(r.status, r.read() if method == "GET" else b"", {k.lower(): v for k, v in r.headers.items()})
        except urllib.error.HTTPError as e:
            return FetchResult(e.code, b"", {k.lower(): v for k, v in (e.headers or {}).items()})
        except (urllib.error.URLError, socket.timeout, ConnectionError, OSError) as e:
            raise NetworkUnavailable(f"{url}: {type(e).__name__}: {e}") from e

    def fetch(self, url: str) -> FetchResult:
        return self._req(url, "GET")

    def head(self, url: str) -> FetchResult:
        return self._req(url, "HEAD")


# ------------------------------------------------------------------ raw store
def sha256_bytes(b: bytes) -> str:
    return hashlib.sha256(b).hexdigest()


def sha256_file(path: str) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def _atomic_write(path: str, data: bytes) -> None:
    os.makedirs(os.path.dirname(path), exist_ok=True)
    tmp = path + ".part"
    with open(tmp, "wb") as f:
        f.write(data); f.flush(); os.fsync(f.fileno())
    os.replace(tmp, path)


class RawStore:
    """Byte-exact hourly files under root/ with a sibling .meta.json each. The meta file is written AFTER the data file, so
    an interrupted download leaves no meta and is simply fetched again."""

    def __init__(self, root: str):
        self.root = root

    def path(self, instrument: str, hour: datetime) -> str:
        return os.path.join(self.root, hour_relpath(instrument, hour))

    def meta_path(self, instrument: str, hour: datetime) -> str:
        return self.path(instrument, hour) + ".meta.json"

    def meta(self, instrument: str, hour: datetime) -> Optional[dict]:
        p = self.meta_path(instrument, hour)
        if not os.path.exists(p):
            return None
        try:
            with open(p) as f:
                return json.load(f)
        except json.JSONDecodeError:
            return None

    def save(self, instrument: str, hour: datetime, res: FetchResult, outcome: str, attempts: List[int], now: datetime) -> dict:
        meta = {"url": hour_url(instrument, hour), "hour_utc": _utc(hour).isoformat(), "http_status": res.status,
                "outcome": outcome, "bytes": len(res.body), "sha256": sha256_bytes(res.body) if res.body else None,
                "downloaded_at": now.isoformat(), "attempt_statuses": attempts,
                "etag": res.headers.get("etag"), "last_modified": res.headers.get("last-modified")}
        if res.body:
            _atomic_write(self.path(instrument, hour), res.body)
        _atomic_write(self.meta_path(instrument, hour), json.dumps(meta, indent=1, sort_keys=True).encode())
        return meta

    def is_complete(self, instrument: str, hour: datetime, retry_missing: bool = False) -> bool:
        m = self.meta(instrument, hour)
        if m is None:
            return False
        if m["outcome"] == "ok":
            p = self.path(instrument, hour)
            return os.path.exists(p) and sha256_file(p) == m["sha256"]          # a corrupted/edited file is re-fetched
        if m["outcome"] == "empty":
            return True
        if m["outcome"] == "not_found":
            return not retry_missing
        return False                                                            # 'error' -> always retried

    def read(self, instrument: str, hour: datetime) -> bytes:
        with open(self.path(instrument, hour), "rb") as f:
            return f.read()


@dataclass
class DownloadSummary:
    requested_hours: int = 0
    skipped_complete: int = 0
    fetched: int = 0
    ok: int = 0
    empty: int = 0
    not_found: int = 0
    errors: int = 0
    refetched_corrupt: int = 0
    aborted: bool = False
    abort_reason: str = ""
    stopped_by_max_hours: bool = False


class DownloadManager:
    def __init__(self, fetcher, store: RawStore, instrument: str, retries: int = 4, backoff_s: float = 2.0, delay_s: float = 0.2,
                 sleep: Callable[[float], None] = time.sleep, now: Callable[[], datetime] = lambda: datetime.now(timezone.utc),
                 max_consecutive_errors: int = 5, log: Callable[[str], None] = print):
        self.f, self.store, self.inst = fetcher, store, instrument
        self.retries, self.backoff, self.delay, self.sleep, self.now = retries, backoff_s, delay_s, sleep, now
        self.max_err, self.log = max_consecutive_errors, log

    def _fetch_with_retries(self, url: str) -> Tuple[Optional[FetchResult], List[int], str]:
        statuses: List[int] = []
        last = ""
        for attempt in range(self.retries + 1):
            try:
                res = self.f.fetch(url)
            except NetworkUnavailable as e:
                statuses.append(-1); last = str(e)
            else:
                statuses.append(res.status)
                if res.status == 200 or res.status == 404:
                    return res, statuses, ""
                last = f"HTTP {res.status}"
                if res.status < 500 and res.status != 429:
                    return res, statuses, last                       # other 4xx: do not hammer
            if attempt < self.retries:
                self.sleep(self.backoff * (2 ** attempt))
        return None, statuses, last

    def run(self, start: datetime, end: datetime, retry_missing: bool = False, max_hours: Optional[int] = None) -> DownloadSummary:
        hours = hours_between(start, end)
        s = DownloadSummary(requested_hours=len(hours))
        consecutive = 0
        for h in hours:
            if self.store.is_complete(self.inst, h, retry_missing):
                s.skipped_complete += 1
                continue
            if self.store.meta(self.inst, h) is not None and self.store.meta(self.inst, h)["outcome"] == "ok":
                s.refetched_corrupt += 1
            if max_hours is not None and s.fetched >= max_hours:
                s.stopped_by_max_hours = True
                break
            res, statuses, err = self._fetch_with_retries(hour_url(self.inst, h))
            s.fetched += 1
            if res is None or (res.status not in (200, 404)):
                s.errors += 1; consecutive += 1
                self.store.save(self.inst, h, FetchResult(res.status if res else 0), "error", statuses, self.now())
                self.log(f"ERROR {h:%Y-%m-%d %H}h: {err}")
                if consecutive >= self.max_err:
                    s.aborted = True
                    s.abort_reason = (f"{consecutive} consecutive failures; last error: {err}. Nothing was substituted. "
                                      "Check network access to datafeed.dukascopy.com (see docs/DUKASCOPY_RUNBOOK.md).")
                    return s
            else:
                consecutive = 0
                outcome = "not_found" if res.status == 404 else ("ok" if res.body else "empty")
                self.store.save(self.inst, h, res, outcome, statuses, self.now())
                setattr(s, outcome, getattr(s, outcome) + 1)
            if self.delay:
                self.sleep(self.delay)
        return s


# ------------------------------------------------------------------ normalisation
@dataclass
class BuildSummary:
    rows_written: int = 0
    duplicates_removed: int = 0
    hours_decoded: int = 0
    hours_empty: int = 0
    hours_not_found: int = 0
    hours_error: int = 0
    hours_not_attempted: int = 0
    hours_non_monotone: int = 0
    offsets_beyond_hour: int = 0
    crossed_ticks: int = 0
    zero_price_ticks: int = 0
    price_min: Optional[str] = None
    price_max: Optional[str] = None
    first_timestamp_ms: Optional[int] = None
    last_timestamp_ms: Optional[int] = None
    csv_sha256: str = ""
    raw_combined_sha256: str = ""
    raw_files: int = 0


def raw_combined_sha256(store: RawStore, instrument: str, hours: Sequence[datetime]) -> Tuple[str, int]:
    lines = []
    for h in hours:
        m = store.meta(instrument, h)
        if m and m["outcome"] == "ok":
            lines.append(f"{hour_relpath(instrument, h)}:{m['sha256']}")
    return hashlib.sha256("\n".join(lines).encode()).hexdigest(), len(lines)


def build_normalised(store: RawStore, instrument: str, start: datetime, end: datetime, out_csv: str,
                     point_value: Optional[int] = None) -> BuildSummary:
    pv = point_value or POINT_VALUES.get(instrument)
    if pv is None:
        raise DukascopyError(f"no point value known for {instrument}; pass point_value explicitly")
    hours = hours_between(start, end)
    bs = BuildSummary()
    os.makedirs(os.path.dirname(os.path.abspath(out_csv)), exist_ok=True)
    tmp = out_csv + ".part"
    lo = hi = None
    last_key: Optional[tuple] = None
    with open(tmp, "w", newline="") as f:
        w = csv.writer(f, lineterminator="\n")
        w.writerow(CSV_HEADER)
        for h in hours:
            m = store.meta(instrument, h)
            if m is None:
                bs.hours_not_attempted += 1; continue
            oc = m["outcome"]
            if oc == "empty":
                bs.hours_empty += 1; continue
            if oc == "not_found":
                bs.hours_not_found += 1; continue
            if oc == "error":
                bs.hours_error += 1; continue
            dec = decode_bi5(store.read(instrument, h))                      # raises Bi5Error on a corrupt file
            bs.hours_decoded += 1
            bs.hours_non_monotone += 1 if dec.non_monotone else 0
            bs.offsets_beyond_hour += dec.offset_beyond_hour
            bs.crossed_ticks += dec.crossed
            bs.zero_price_ticks += dec.zero_price
            base_ms = epoch_ms(h)
            ticks = sorted(dec.ticks, key=lambda t: t[0]) if dec.non_monotone else dec.ticks      # stable: file order kept for ties
            for off, ask, bid, av, bv in ticks:
                ts = base_ms + off
                row = (ts, price_text(ask, pv), price_text(bid, pv), f32_text(av), f32_text(bv))
                key = row
                if last_key is not None and key == last_key:
                    bs.duplicates_removed += 1
                    continue
                last_key = key
                w.writerow(row)
                bs.rows_written += 1
                bs.first_timestamp_ms = ts if bs.first_timestamp_ms is None else bs.first_timestamp_ms
                bs.last_timestamp_ms = ts
                for p in (ask, bid):
                    lo = p if lo is None else min(lo, p)
                    hi = p if hi is None else max(hi, p)
        f.flush(); os.fsync(f.fileno())
    os.replace(tmp, out_csv)
    digits = len(str(pv)) - 1
    bs.price_min = None if lo is None else str(Decimal(lo).scaleb(-digits))
    bs.price_max = None if hi is None else str(Decimal(hi).scaleb(-digits))
    bs.csv_sha256 = sha256_file(out_csv)
    bs.raw_combined_sha256, bs.raw_files = raw_combined_sha256(store, instrument, hours)
    return bs


def merge_normalised_csvs(inputs: Sequence[str], out_csv: str) -> Tuple[int, int]:
    """Merge time-sorted normalised chunks (possibly overlapping) into one file, dropping exact duplicate rows. Returns (rows, dups).
    Each input must already be sorted by timestamp (verified); the merge is streaming (constant memory)."""
    def rows(path: str, idx: int) -> Iterator[Tuple[int, int, List[str]]]:
        with open(path, newline="") as f:
            rd = csv.reader(f)
            hdr = next(rd, None)
            if hdr != CSV_HEADER:
                raise DukascopyError(f"{path}: unexpected header {hdr}")
            prev = -1
            for r in rd:
                t = int(r[0])
                if t < prev:
                    raise DukascopyError(f"{path}: not sorted by timestamp at {t}")
                prev = t
                yield t, idx, r
    streams = [rows(p, i) for i, p in enumerate(inputs)]
    n = dup = 0
    tmp = out_csv + ".part"
    last_ts, seen = None, set()
    with open(tmp, "w", newline="") as f:
        w = csv.writer(f, lineterminator="\n")
        w.writerow(CSV_HEADER)
        for t, _, r in heapq.merge(*streams, key=lambda x: (x[0], x[1])):
            if t != last_ts:
                last_ts, seen = t, set()
            key = tuple(r)
            if key in seen:
                dup += 1; continue
            seen.add(key)
            w.writerow(r); n += 1
        f.flush(); os.fsync(f.fileno())
    os.replace(tmp, out_csv)
    return n, dup


def hour_outcomes(store: RawStore, instrument: str, hours: Sequence[datetime]) -> Dict[datetime, str]:
    out = {}
    for h in hours:
        m = store.meta(instrument, h)
        out[h] = "not_attempted" if m is None else m["outcome"]
    return out
