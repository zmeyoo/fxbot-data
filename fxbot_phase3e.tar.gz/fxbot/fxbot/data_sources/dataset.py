"""Dataset assembly, automatic validation, manifest and the validation gate.

Layout of a dataset directory:
  raw/<SYMBOL>/<YYYY>/<MM0>/<DD>/<HH>h_ticks.bi5(+.meta.json)   byte-exact downloads
  normalised/<SYMBOL>_<start>_<end>_ticks.csv                      Dukascopy-layout CSV (exact prices, UTC epoch ms)
  dataset.json                                                     manifest (source, range, times, SHA-256s, command, verdict)
  DATA_QUALITY_REPORT.md                                           human-readable validation + quality report
Strategy research must go through load_validated_dataset(), which refuses anything that has not passed.
"""
from __future__ import annotations

import csv
import json
import os
import tempfile
from dataclasses import asdict
from datetime import datetime, timedelta, timezone
from typing import Any, Dict, List, Optional, Sequence, Tuple

from ..backtesting.data import DUKASCOPY, DataError, DatasetReport, load_ticks_csv
from ..backtesting.validate import Check, render_markdown, validate_tick_file
from ..core.sessions import SessionCalendar
from ..core.types import FxBotError
from .dukascopy import (BASE_URL, PRICE_BANDS, POINT_VALUES, SOURCE_NAME, TOOL_VERSION, BuildSummary, RawStore, build_normalised,
                        expected_closed_hour, hour_outcomes, hours_between, pip_size, sha256_file)
from .quality import QualityStats, analyze_csv, render_stats

DATASET_JSON = "dataset.json"
REPORT_MD = "DATA_QUALITY_REPORT.md"
SCHEMA = 1

# validation thresholds (printed in every report)
MAX_CROSSED_FRACTION_FAIL = 0.005
MAX_CLOSURE_QUOTE_FRACTION_FAIL = 0.01
MAX_ORDER_VIOLATION_FRACTION_FAIL = 0.001
MAX_UNEXPECTED_MISSING_HOUR_FRACTION_FAIL = 0.05
THIN_HOUR_TICKS = 200
SPREAD_MEDIAN_PIPS_PLAUSIBLE = (0.05, 3.0)
FULL_VALIDATOR_ROW_LIMIT = 1_000_000          # in-memory validator budget ~1 GB; larger files are validated in per-hour slices


class DatasetNotValidated(FxBotError):
    pass


def _iso(d: datetime) -> str:
    return d.astimezone(timezone.utc).isoformat()


def csv_path(out_dir: str, instrument: str, start: datetime, end: datetime) -> str:
    return os.path.join(out_dir, "normalised", f"{instrument}_{start:%Y%m%d}_{end:%Y%m%d}_ticks.csv")


def finalize_dataset(out_dir: str, instrument: str, start: datetime, end: datetime, command: str,
                     point_value: Optional[int] = None, gap_threshold_s: int = 120,
                     now: Optional[datetime] = None, full_validator_row_limit: int = FULL_VALIDATOR_ROW_LIMIT) -> Dict[str, Any]:
    """Build the normalised CSV from the raw store, write the manifest, then validate automatically."""
    now = now or datetime.now(timezone.utc)
    store = RawStore(os.path.join(out_dir, "raw"))
    pv = point_value or POINT_VALUES[instrument]
    out_csv = csv_path(out_dir, instrument, start, end)
    bs = build_normalised(store, instrument, start, end, out_csv, pv)
    hours = hours_between(start, end)
    metas = [m for h in hours for m in [store.meta(instrument, h)] if m]
    times = sorted(m["downloaded_at"] for m in metas)
    oc = hour_outcomes(store, instrument, hours)
    counts = {k: sum(1 for v in oc.values() if v == k) for k in ("ok", "empty", "not_found", "error", "not_attempted")}
    dataset_id = __import__("hashlib").sha256(f"{bs.csv_sha256}|{instrument}|{_iso(start)}|{_iso(end)}".encode()).hexdigest()[:16]
    manifest = {
        "schema": SCHEMA, "tool": TOOL_VERSION, "dataset_id": dataset_id,
        "source": {"name": SOURCE_NAME, "base_url": BASE_URL, "url_pattern": "{base}/{SYMBOL}/{YYYY}/{MM0}/{DD}/{HH}h_ticks.bi5 (MM0 zero-based)",
                   "format": "LZMA-compressed 20-byte big-endian records (uint32 ms, uint32 ask pts, uint32 bid pts, float32 ask vol, float32 bid vol)"},
        "instrument": instrument, "point_value": pv, "pip_size": str(pip_size(instrument)),
        "range_utc": {"start": _iso(start), "end_exclusive": _iso(end), "hours": len(hours)},
        "download": {"first_at": times[0] if times else None, "last_at": times[-1] if times else None, "hour_outcomes": counts},
        "command": command, "built_at": _iso(now),
        "raw": {"dir": "raw", "files": bs.raw_files, "combined_sha256": bs.raw_combined_sha256},
        "normalised": {"path": os.path.relpath(out_csv, out_dir), "format": "dukascopy_csv", "rows": bs.rows_written,
                       "duplicates_removed": bs.duplicates_removed, "sha256": bs.csv_sha256,
                       "first_timestamp_ms": bs.first_timestamp_ms, "last_timestamp_ms": bs.last_timestamp_ms,
                       "price_min": bs.price_min, "price_max": bs.price_max, "loader_content_sha256": None},
        "build_anomalies": {"hours_with_non_monotone_offsets": bs.hours_non_monotone, "offsets_beyond_hour": bs.offsets_beyond_hour,
                            "crossed_ticks": bs.crossed_ticks, "zero_price_ticks": bs.zero_price_ticks},
        "validation": {"passed": False, "validated_at": None, "checks": [], "report": REPORT_MD, "status": "pending"},
    }
    _write_manifest(out_dir, manifest)
    return validate_dataset(out_dir, gap_threshold_s=gap_threshold_s, full_validator_row_limit=full_validator_row_limit, now=now)


def _write_manifest(out_dir: str, m: Dict[str, Any]) -> None:
    p = os.path.join(out_dir, DATASET_JSON)
    tmp = p + ".part"
    with open(tmp, "w") as f:
        json.dump(m, f, indent=1, sort_keys=True)
    os.replace(tmp, p)


def read_manifest(out_dir: str) -> Dict[str, Any]:
    p = os.path.join(out_dir, DATASET_JSON)
    if not os.path.exists(p):
        raise DatasetNotValidated(f"{p} not found: not a dataset directory (or never built)")
    with open(p) as f:
        return json.load(f)


def _dt_h(hidx: int) -> str:
    return (datetime(1970, 1, 1, tzinfo=timezone.utc) + timedelta(hours=hidx)).strftime('%Y-%m-%d %Hh')


def _sliced_validation(path: str, instrument: str, gap_threshold_s: int) -> Tuple[List[Tuple[int, Any]], List[Tuple[int, str]]]:
    """Run the existing in-memory validator on every UTC-hour slice of the file, one slice in memory at a time (bounded memory,
    COMPLETE coverage). Returns ([(hour_index, ValidationResult)], [(hour_index, error)])."""
    results: List[Tuple[int, Any]] = []
    errors: List[Tuple[int, str]] = []

    def flush(hidx: int, hdr: List[str], rows: List[List[str]]) -> None:
        if not rows:
            return
        with tempfile.TemporaryDirectory() as d:
            p = os.path.join(d, "slice.csv")
            with open(p, "w", newline="") as g:
                w = csv.writer(g, lineterminator="\n"); w.writerow(hdr); w.writerows(rows)
            try:
                results.append((hidx, validate_tick_file(p, instrument, DUKASCOPY, gap_threshold_s)))
            except DataError as e:
                errors.append((hidx, str(e)))

    with open(path, newline="") as f:
        rd = csv.reader(f)
        hdr = next(rd)
        cur, rows = None, []
        for r in rd:
            h = int(r[0]) // 3_600_000
            if h != cur:
                flush(cur, hdr, rows)
                cur, rows = h, []
            rows.append(r)
        flush(cur, hdr, rows)
    return results, errors


def validate_dataset(out_dir: str, gap_threshold_s: int = 120, full_validator_row_limit: int = FULL_VALIDATOR_ROW_LIMIT,
                     now: Optional[datetime] = None) -> Dict[str, Any]:
    now = now or datetime.now(timezone.utc)
    m = read_manifest(out_dir)
    inst = m["instrument"]
    start = datetime.fromisoformat(m["range_utc"]["start"]); end = datetime.fromisoformat(m["range_utc"]["end_exclusive"])
    path = os.path.join(out_dir, m["normalised"]["path"])
    checks: List[Check] = []
    add = lambda n, s, d: checks.append(Check(n, s, d))

    # 1. integrity
    actual = sha256_file(path) if os.path.exists(path) else None
    add("File integrity (SHA-256)", "PASS" if actual == m["normalised"]["sha256"] else "FAIL",
        f"manifest {m['normalised']['sha256'][:16]}... vs file {(actual or 'MISSING')[:16]}...")
    # 2. download completeness
    store = RawStore(os.path.join(out_dir, "raw"))
    hours = hours_between(start, end)
    oc = hour_outcomes(store, inst, hours)
    bad = [h for h, v in oc.items() if v in ("error", "not_attempted")]
    add("Download completeness", "PASS" if not bad else "FAIL",
        f"{len(hours)} hours requested: " + ", ".join(f"{k} {sum(1 for v in oc.values() if v == k)}" for k in ("ok", "empty", "not_found", "error", "not_attempted"))
        + ("" if not bad else f"; incomplete hours e.g. {', '.join(f'{h:%Y-%m-%d %Hh}' for h in bad[:5])}"))
    if actual != m["normalised"]["sha256"]:
        return _finish(out_dir, m, checks, None, None, None, now, "file missing or modified: validation stopped")

    # 3. existing validator (full or sampled)
    rows = m["normalised"]["rows"]
    vres, scope, loader_hash = None, "full", None
    try:
        if rows <= full_validator_row_limit:
            vres = validate_tick_file(path, inst, DUKASCOPY, gap_threshold_s)
            loader_hash = vres.report.sha256
            for c in vres.checks:
                if c.status == "FAIL":
                    add(f"tick validator: {c.name}", "FAIL", c.detail)
            add("Tick validator (existing)", "PASS" if vres.ok else "FAIL",
                f"scope: FULL file ({rows} rows); checks: " + ", ".join(f"{c.name}={c.status}" for c in vres.checks))
        else:
            parts, errs = _sliced_validation(path, inst, gap_threshold_s)
            failed = [(h, [c.name for c in v.checks if c.status == "FAIL"]) for h, v in parts if not v.ok]
            scope = f"SLICED ({len(parts) + len(errs)} UTC-hour slices of {rows} rows, each validated separately: complete coverage, bounded memory)"
            vres = parts[0][1] if parts else None
            ok = not failed and not errs
            add("Tick validator (existing)", "PASS" if ok else "FAIL",
                f"scope: {scope}; slices passed {len(parts) - len(failed)}/{len(parts) + len(errs)}"
                + ("" if ok else "; failing slices e.g. " + ", ".join(f"{_dt_h(h)}:{n}" for h, n in failed[:5])
                   + ("; loader errors " + "; ".join(f"{_dt_h(h)}:{e}" for h, e in errs[:3]) if errs else "")))
    except DataError as e:
        add("Tick validator (existing)", "FAIL", f"loader refused the file: {e}")

    # 4. streaming quality
    st = analyze_csv(path, inst, gap_threshold_s)
    n = max(st.n, 1)
    lo, hi = PRICE_BANDS.get(inst, (None, None))
    if lo is not None:
        ok_band = st.price_min is not None and lo <= st.price_min and st.price_max <= hi
        add("Price scale / plausibility", "PASS" if ok_band else "FAIL",
            f"mid price range {st.price_min} .. {st.price_max} vs plausible band {lo} .. {hi} for {inst} (a wrong point value would show up here)")
    add("Crossed quotes (ask < bid)", "PASS" if st.crossed == 0 else ("WARN" if st.crossed / n <= MAX_CROSSED_FRACTION_FAIL else "FAIL"),
        f"{st.crossed} of {st.n} ({100 * st.crossed / n:.4f}%); FAIL above {100 * MAX_CROSSED_FRACTION_FAIL}%")
    add("Timestamp order", "PASS" if st.order_violations == 0 else ("WARN" if st.order_violations / n <= MAX_ORDER_VIOLATION_FRACTION_FAIL else "FAIL"),
        f"{st.order_violations} out-of-order rows; FAIL above {100 * MAX_ORDER_VIOLATION_FRACTION_FAIL}%")
    add("Duplicates", "PASS" if st.exact_duplicates == 0 else "WARN", f"{st.exact_duplicates} exact duplicate rows remain after the build (removed at build: {m['normalised']['duplicates_removed']})")
    add("Quotes inside the weekly closure", "PASS" if st.closure_quotes == 0 else ("WARN" if st.closure_quotes / n <= MAX_CLOSURE_QUOTE_FRACTION_FAIL else "FAIL"),
        f"{st.closure_quotes} ({100 * st.closure_quotes / n:.4f}%); FAIL above {100 * MAX_CLOSURE_QUOTE_FRACTION_FAIL}%")
    med = st.spread_pct(0.5)
    plaus = med is not None and SPREAD_MEDIAN_PIPS_PLAUSIBLE[0] <= med <= SPREAD_MEDIAN_PIPS_PLAUSIBLE[1]
    add("Median spread plausibility", "PASS" if plaus else "WARN", f"median {med} pips vs expected {SPREAD_MEDIAN_PIPS_PLAUSIBLE[0]}..{SPREAD_MEDIAN_PIPS_PLAUSIBLE[1]}")
    ba = m["build_anomalies"]
    add("Build anomalies", "PASS" if not (ba["hours_with_non_monotone_offsets"] or ba["offsets_beyond_hour"] or ba["zero_price_ticks"]) else "WARN",
        f"{ba} (non-monotone hours are re-sorted by millisecond offset, stable; originals are untouched in raw/)")

    # 5. missing data (hour level)
    unexpected, thin, expected_open = [], [], 0
    for h, v in oc.items():
        closed = expected_closed_hour(h)
        if not closed:
            expected_open += 1
        hidx = int((h - datetime(1970, 1, 1, tzinfo=timezone.utc)).total_seconds() // 3600)
        cnt = st.ticks_per_hour.get(hidx, 0)
        if v in ("empty", "not_found") and not closed:
            unexpected.append((h, v))
        elif v == "ok" and not closed and cnt < THIN_HOUR_TICKS:
            thin.append((h, cnt))
    frac = len(unexpected) / max(expected_open, 1)
    add("Missing hours during open market", "PASS" if not unexpected else ("WARN" if frac <= MAX_UNEXPECTED_MISSING_HOUR_FRACTION_FAIL else "FAIL"),
        f"{len(unexpected)} of {expected_open} open-market hours have no data ({100 * frac:.2f}%); FAIL above {100 * MAX_UNEXPECTED_MISSING_HOUR_FRACTION_FAIL}%"
        + ("" if not unexpected else "; e.g. " + ", ".join(f"{h:%Y-%m-%d %Hh}({v})" for h, v in unexpected[:6])))
    add("Thin hours during open market", "PASS" if not thin else "WARN",
        f"{len(thin)} open-market hours with < {THIN_HOUR_TICKS} ticks" + ("" if not thin else "; e.g. " + ", ".join(f"{h:%Y-%m-%d %Hh}({c})" for h, c in thin[:6])))
    add("Unexpected gaps (> threshold, outside weekly closure)", "INFO",
        f"{sum(v for k, v in st.gap_classes.items() if k != 'weekend_closure')} gaps > {gap_threshold_s}s ({st.gap_classes}); listed in the report")
    return _finish(out_dir, m, checks, vres, st, loader_hash, now, scope, (unexpected, thin), oc)


def _finish(out_dir, m, checks, vres, st: Optional[QualityStats], loader_hash, now, scope, miss=None, oc=None):
    failed = [c for c in checks if c.status == "FAIL"]
    passed = not failed
    m["normalised"]["loader_content_sha256"] = loader_hash
    m["validation"] = {"passed": passed, "status": "PASSED" if passed else "FAILED", "validated_at": _iso(now),
                       "validator_scope": scope, "report": REPORT_MD,
                       "checks": [{"name": c.name, "status": c.status, "detail": c.detail} for c in checks]}
    _write_manifest(out_dir, m)
    with open(os.path.join(out_dir, REPORT_MD), "w") as f:
        f.write(render_report(m, checks, vres, st, miss, oc))
    return m


def render_report(m, checks: Sequence[Check], vres, st: Optional[QualityStats], miss, oc) -> str:
    v = m["validation"]
    n = m["normalised"]
    out = [f"# Data quality report - {m['instrument']} ({m['dataset_id']})", "",
           "> This report validates DATA only. No strategy was run and no performance is reported. Research must not start until the verdict "
           "below is PASSED and you have reviewed this report.", "",
           f"**Verdict: {v['status']}**  (validated {v['validated_at']}; validator scope: {v['validator_scope']})", "",
           "## Provenance", f"- source: {m['source']['name']} - `{m['source']['base_url']}`", f"- URL pattern: `{m['source']['url_pattern']}`",
           f"- source format: {m['source']['format']}", f"- instrument: {m['instrument']} (point value {m['point_value']}, pip {m['pip_size']})",
           f"- range (UTC): {m['range_utc']['start']} .. {m['range_utc']['end_exclusive']} (end exclusive), {m['range_utc']['hours']} hourly files",
           f"- downloaded: {m['download']['first_at']} .. {m['download']['last_at']}; hour outcomes {m['download']['hour_outcomes']}",
           f"- tool: {m['tool']}; built {m['built_at']}", f"- command: `{m['command']}`",
           f"- raw files: {m['raw']['files']}; combined raw SHA-256 `{m['raw']['combined_sha256']}`",
           f"- normalised CSV: `{n['path']}` - {n['rows']} rows, **SHA-256 `{n['sha256']}`**" + (f"; loader content hash `{n['loader_content_sha256']}`" if n['loader_content_sha256'] else ""),
           f"- first/last timestamp ms: {n['first_timestamp_ms']} / {n['last_timestamp_ms']}; price range {n['price_min']} .. {n['price_max']}", "",
           "## Validation gates", "| check | status | detail |", "|---|---|---|"]
    out += [f"| {c.name} | **{c.status}** | {c.detail} |" for c in checks]
    out += ["", f"Thresholds: crossed FAIL > {100 * MAX_CROSSED_FRACTION_FAIL}%, out-of-order FAIL > {100 * MAX_ORDER_VIOLATION_FRACTION_FAIL}%, "
            f"closure quotes FAIL > {100 * MAX_CLOSURE_QUOTE_FRACTION_FAIL}%, missing open-market hours FAIL > {100 * MAX_UNEXPECTED_MISSING_HOUR_FRACTION_FAIL}%, "
            f"thin hour < {THIN_HOUR_TICKS} ticks. WARN items need your review; they do not block."]
    if st is not None:
        out += ["", "## Quality statistics", render_stats(st)]
    if vres is not None:
        out += ["", "## Existing tick validator output (" + v["validator_scope"].split(" ")[0] + (", first slice shown as an example" if v["validator_scope"].startswith("SLICED") else "") + ")",
                render_markdown(vres, "Tick validator").split("\n", 1)[1]]
    out += ["", "## Reproduce", "Re-run the command above with the same range (downloads are resumable and byte-verified); the manifest records every SHA-256."]
    return "\n".join(out) + "\n"


def load_validated_dataset(out_dir: str):
    """The ONLY sanctioned way to feed a downloaded dataset to research. Refuses unvalidated or modified data."""
    m = read_manifest(out_dir)
    if not m.get("validation", {}).get("passed"):
        raise DatasetNotValidated(f"dataset {m.get('dataset_id')} has not passed validation (status {m.get('validation', {}).get('status')}); "
                                  f"see {os.path.join(out_dir, REPORT_MD)}")
    path = os.path.join(out_dir, m["normalised"]["path"])
    if not os.path.exists(path) or sha256_file(path) != m["normalised"]["sha256"]:
        raise DatasetNotValidated("normalised CSV is missing or does not match the manifest SHA-256 (modified after validation)")
    quotes, rep = load_ticks_csv(path, m["instrument"], fmt=DUKASCOPY)
    if m["normalised"].get("loader_content_sha256") and rep.sha256 != m["normalised"]["loader_content_sha256"]:
        raise DatasetNotValidated("loader content hash differs from the validated one")
    return quotes, rep, m
