# Dukascopy pilot dataset - runbook (Milestone 1)

## 1. Status
* The pilot is **approved**: EURUSD, **2024-03-04 inclusive to 2024-03-18 exclusive** (336 hourly files, 241 in open-market time; contains the US daylight-saving change of 10 Mar 2024). Full-resolution original tick files are kept (no decimation).
* **Nothing has been downloaded yet.** The authoring sandbox has no outbound network (re-checked: `env-check` -> NOT READY, `Name or service not known`). The real download happens in GitHub Actions (section 4) or on any machine with internet. No data is generated or substituted.
* No strategy research is run. Strategy rules unchanged. Live trading disabled. Streaming engine = Milestone 2, separate (`STREAMING_DESIGN.md`).

## 2. What the pipeline does, in order (`tools/ci_run.sh`; each stage stops the run on failure)
1. **Offline unit tests** of the pipeline (about 45 s).
2. **`env-check`** - can this machine reach `datafeed.dukascopy.com`?
3. **`verify-decoder`** - downloads ~9 representative hours (3 active hours in different tick-density regimes, the Friday-close hours and the Sunday-reopen hours around the DST change, plus the 2020-03-30 sample hour) and tests each BI5 assumption **independently of the decoder under test**:
   LZMA container (two independent decompressors agree, clean end of stream, declared size = real size) - 20-byte big-endian records (size multiple of 20 *and* field plausibility; misaligned data is garbage) -
   price point scaling (generic band + the reference range you supply + the published sample) - BID/ASK order (field 2 >= field 3, small positive spread) - timestamp offsets (inside the hour, non-decreasing) -
   UTC and closure alignment (ticks stop at Fri 17:00 New York and resume Sun 17:00 New York; a timezone/DST mistake shifts these by whole hours) - volume (**UNCERTAIN by design**: units cannot be verified from data; stored as published; not used by the strategy) -
   published two-row sample (an exact match supports; a mismatch is reported as inconclusive, not as proof).
   **Any FAIL stops everything (exit code 5). The decoder is never adapted to make prices look plausible.**
4. **`run`** - download all hours (byte-exact, hashed, resumable) -> normalised CSV -> manifest -> automatic validation (existing validator on every UTC-hour slice, constant-memory quality statistics, gates) -> `DATA_QUALITY_REPORT.md`.
5. **`ci_verdict.py`** - one verdict: **PASSED** only if every stage succeeded, decoder verification passed, validation PASSED and the CSV matches its manifest SHA-256. Anything else is **NOT VALIDATED** with the reason.

Outputs: `review-pack` (always; small: VERDICT, reports, logs, per-hour metadata, SHA256SUMS), and **only when validated** `dataset-normalised` (CSV + manifest + reports) and `dataset-raw-original` (byte-exact `.bi5` files + metadata).

## 3. Review of the GitHub Actions workflow (what I checked and changed)
| question | finding / fix |
|---|---|
| repository structure and import paths | The archive has a wrapper folder `fxbot/` and the workflow must sit at `.github/workflows/` in the repo root. **Changed:** the repo needs only two items (the archive + the workflow file); the job unpacks the archive to `work/fxbot`, runs everything from there with `PYTHONPATH=.`, and refuses to run unless exactly one archive is present. Control flow is unit-tested with a stub `python`. |
| workflow file validity | **A real bug found by a test:** an unquoted step name containing `: ` made the YAML invalid (GitHub would have rejected it). All step names are now quoted, the file is parsed in a test, and a test enforces the quoting. |
| uploads even when validation fails | `Verdict` and `Upload the review pack` use `if: always()`, so reports, logs, hashes and per-hour metadata are attached to failed runs too (a failing step, even a crash, cannot skip them). |
| failed/incomplete data mistaken for validated | (1) one verdict function with explicit statuses (TESTS_FAILED, NETWORK_UNAVAILABLE, DECODER_ASSUMPTION_FAILED, DECODER_NOT_VERIFIED, DOWNLOAD_INCOMPLETE, VALIDATION_FAILED, INTEGRITY_FAILED, PIPELINE_CRASHED); (2) the dataset artifacts are uploaded **only** when validated and their names end in `-VALIDATED`; (3) the review-pack name carries the status; (4) the final step fails the run (red) unless validated; (5) `VERDICT.txt` says "NOT VALIDATED. DO NOT USE ANY DATA FROM THIS RUN". Tested for incomplete, failed-validation, tampered CSV and failed-decoder cases. |
| security | Inputs are passed through environment variables and validated by regular expressions; they are never pasted into shell code. Read-only token permissions. |
| memory | **A real defect found in review:** for large files my validator loaded every CSV row into a list (could exhaust the 7 GB runner on a multi-million-tick pilot). Now it validates per UTC-hour slice with bounded memory and complete coverage. |
| decoder assumptions | New live verification stage before the bulk download (section 2, stage 3). |
| artifact size and retention (limits to check, from GitHub documentation and community write-ups I consulted; verify under Settings and Billing) | Retention is configurable per artifact (1-90 days; I use 30 for the review pack and 14 for datasets). **GitHub Free gives about 500 MB of shared storage for Actions artifacts and packages**, and private repositories get a monthly allowance of Actions minutes (commonly stated as 2,000). When storage is exhausted uploads can fail. The pilot's size is **unknown until measured** (I estimate tens to a few hundred MB; unverified), so the dataset is split into two artifacts (raw = master, CSV = derived and regenerable from raw by `build`), the review pack stays small, and the verdict summary prints the dataset size. A single oversized artifact may also hit per-artifact limits; sources disagree, so treat the quota as the binding constraint. Delete old artifacts in the run page after downloading them. |
| not verifiable here | The workflow has **never run on GitHub**. Its first run is its test; if a step fails for a reason I could not foresee, the review pack and summary will say where. |

## 4. Run it from an Android phone (browser only)
Use Chrome. GitHub's mobile layout hides some menus: if you cannot see something named below, open Chrome menu (three dots) and turn on **Desktop site**.
**One-time setup (about 10 minutes)**
1. In this chat, tap the file `fxbot_phase3e.tar.gz` and download it (it lands in Downloads). Also download `dukascopy_dataset.yml`, then open it in any text viewer, select all and copy.
2. Go to github.com, sign in (create a free account if needed).
3. Tap **+** (top right) -> **New repository**. Name: `fxbot-data`. Choose **Private**. Tick **Add a README file**. Tap **Create repository**.
4. In the repository tap **Add file** -> **Upload files**. Choose `fxbot_phase3e.tar.gz` from Downloads. Tap **Commit changes**.
5. Tap **Add file** -> **Create new file**. In the name box type exactly `.github/workflows/dukascopy_dataset.yml` (typing `/` makes folders). Paste the copied text into the editor. Tap **Commit changes** -> **Commit directly to the main branch**.
   (Alternative: upload `dukascopy_dataset.yml` the same way as the archive, open it, tap the pencil, put `.github/workflows/` in front of the file name, commit.)
6. Tap the **Actions** tab. If a green button says "I understand my workflows, go ahead and enable them", tap it.
**Each run**
7. Actions -> in the left list tap **Dukascopy dataset** -> **Run workflow**. The defaults are the approved pilot (EURUSD, 2024-03-04 to 2024-03-18, sleep 0.3, reference range 1.05:1.12). Leave them and tap the green **Run workflow**.
8. Pull to refresh; tap the new run (title "Dukascopy EURUSD 2024-03-04 to 2024-03-18"). Wait for the job to finish (duration unknown until the first run; the job limit is 300 minutes).
9. Tap **Summary**: the verdict, the decoder verification table and the data-quality report are shown right on the page (no download needed). A red X with "NOT VALIDATED" means do not use the data.
10. Scroll to **Artifacts** at the bottom of the Summary page. Tap `review-pack-...` to download it (small zip) and attach it to this chat. The two `dataset-...-VALIDATED` artifacts (large) stay on GitHub until I need them; do not delete them before the review.
**If something fails:** the run page shows which step failed; open the Summary and the review pack and send them to me. If step "Unpack the project archive" fails, the repository must contain exactly one `.tar.gz`/`.tgz`/`.tar` in its root (delete older archives).
**Running again later** (for example after a network failure) starts from scratch; the workflow does not cache downloads.

## 5. Same commands on any machine with Python 3.12 and internet (stdlib only)
    python tools/dukascopy.py env-check
    python tools/dukascopy.py verify-decoder --instrument EURUSD --start 2024-03-04 --end 2024-03-18 --out data/pilot --reference-range 1.05:1.12
    python tools/dukascopy.py run --instrument EURUSD --start 2024-03-04 --end 2024-03-18 --out data/pilot
    python tools/dukascopy.py plan --instrument EURUSD --start 2025-01-01 --end 2025-07-01 --calibrate data/pilot
`run` exit codes: 0 validated, 1 validation FAILED, 2 environment not ready, 3 incomplete/aborted (or cannot verify), 4 sample mismatch, 5 decoder assumption FAILED.
`--reference-range` (EURUSD in March 2024 was roughly 1.08-1.10 by my recollection; the default 1.05:1.12 is deliberately wide - narrow it if you know better) is an independent price-level check.
Check Dukascopy's terms of use for research use; I have not verified them.

## 6. Larger dataset
Not to be started until Milestone 2 (streaming engine) passes its acceptance tests (`STREAMING_DESIGN.md`) and you have reviewed the pilot. `plan --calibrate <pilot dir>` then gives the measured size, memory and run-time estimate.
